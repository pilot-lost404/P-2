# Verification and Validation (V&V) — Expanded Course Reader (2026 Edition)

> **Level:** Advanced undergraduate / early graduate; software engineering, discrete mathematics, programming/testing and basic systems engineering prerequisites.  
> **Duration:** 14 teaching weeks, 8–12 hours/week  
> **Status:** Self-study reader benchmarked against official 2026 university syllabi and primary documentation. It is not an accredited course or professional certification.

## Course outcomes

1. Differentiate verification, validation, qualification, acceptance and independent assurance.

2. Derive testable requirements, verification plans, test oracles and evidence packages.

3. Design tests using partitions, boundaries, decision tables, state models, coverage and fault injection.

4. Apply static analysis, unit/integration/system testing, model checking and program logic at appropriate levels.

5. Evaluate adequacy, reproducibility, statistical confidence, traceability and residual release risk.


## How to work through the course

For each week, read the concept notes, reproduce the derivation or model, complete the practical task, answer the challenge without looking at references, and record assumptions and evidence. A passing submission must include the exact environment, expected criterion, observed result and limitations. Use the weekly practical tasks as assessed work, not optional reading.


## Foundation reader retained from the first edition

The original first-edition chapter is preserved below for continuity. The expanded notes that follow add the missing depth, quantitative reasoning, labs and assessment structure identified in the academic audit.


---


# Course 4 — Verification and Validation (V&V)
**Level:** Upper-undergraduate / early graduate  
**Duration:** 14 teaching weeks  
**Expected workload:** 8–10 hours per week  
**Prerequisites:** Software engineering, requirements engineering, basic programming and systems concepts.

## Course description

Verification and validation are evidence-producing engineering processes. Verification asks whether a product or work product satisfies its specified requirements. Validation asks whether the resulting product fulfills its intended purpose in its intended context. The activities may use similar methods—test, analysis, inspection or demonstration—but they answer different questions.

A system may pass every test derived from an incomplete specification and still fail the user's real need. Conversely, a system may appear useful in a demonstration while violating a critical performance, security or safety requirement. V&V therefore begins before implementation: requirements, architecture, testability, acceptance criteria and evidence plans must be designed together.

This course covers requirements quality, V&V planning, test design, levels of testing, integration, automation, model-based testing, formal analysis, performance, safety/security testing, traceability, anomaly management and acceptance. NASA's systems engineering guidance is used as a systems-level reference; software testing methods are taught as complementary techniques.

## Learning outcomes

Students should be able to:
1. Distinguish verification, validation, qualification, acceptance and regression testing.
2. Assess whether a requirement is objectively verifiable.
3. Select test, analysis, inspection or demonstration based on the claim being made.
4. Design tests using equivalence classes, boundaries, decision tables, state transitions and pairwise coverage.
5. Plan unit, integration, system, acceptance and operational tests.
6. Use traceability and coverage measures without confusing coverage with correctness.
7. Design reliable test environments, test data and test oracles.
8. Apply automation, continuous integration, mutation testing and defect analysis appropriately.
9. Verify safety and security requirements with suitable evidence.
10. Produce a reproducible V&V report and support a release decision.

---

## Week 1 — Foundations and the V-model

The V-model is a lifecycle representation that pairs decomposition and specification activities on the left with integration and verification activities on the right. It is a planning aid, not a claim that all projects must follow a waterfall sequence. Early validation and continuous verification can occur throughout iterative development.

At the top, stakeholder needs and operational concepts are validated. System requirements are derived and verified for quality. Architecture and subsystem requirements are decomposed. Implementation follows. On the right, components are verified against their allocated requirements, subsystems are integrated and verified, and the complete system is validated against stakeholder needs and intended operational use.

### Verification vs validation

- **Verification:** evidence that specified requirements are met. "Did we build the product correctly against its approved specification?"
- **Validation:** evidence that the product is suitable for its intended use. "Did we build the right product for its users and mission?"

NASA describes verification as proof of compliance with requirements and validation as proof that the product accomplishes its intended purpose in the intended environment. This distinction should be preserved even when the same test produces evidence for both.

### Worked example

Requirement: `The API shall respond to 95% of valid status requests within 300 ms under 100 requests per second for a 10-minute test.` Verification needs a controlled test environment, request distribution, measurement boundary and pass criterion. Validation asks whether this service level is adequate for operators making decisions. Passing the requirement does not prove the chosen 300 ms threshold is useful.

### Laboratory

Create a V-model for the tank platform. Map each left-side work product to one or more right-side verification activities. Identify at least two validation activities that should occur before the final system is built.

---

## Week 2 — Requirements quality and testability

A requirement is verifiable when objective evidence can determine whether it has been satisfied. The requirement must define the relevant condition, system boundary, stimulus, required response and acceptable range. An untestable adjective is not made testable by writing a test that interprets it arbitrarily.

Weak: "The system shall reliably store telemetry."  
Improved: "For accepted telemetry events, the service shall durably commit the event and return an acknowledgement only after the database transaction commits."  
The improved form is more testable, but its storage durability semantics, failure model and acknowledgement boundary still need definition.

A good verification method is selected during requirements development. Not every requirement should be tested by executing software. A physical dimension may be inspected; a mathematical limit may be verified by analysis; an operator workflow may be demonstrated; a timing requirement may require a controlled test.

### Requirement verification record

For each requirement, capture: ID, exact baseline version, verification level, method, procedure, environment, equipment, sample size, acceptance criteria, result, anomaly ID, evidence URI and approver. This allows a reviewer to reconstruct what was verified and against which product configuration.

### Laboratory

Review 20 requirements. Mark each as verifiable, ambiguous, unverifiable or conflicting. Rewrite at least ten and document the evidence method before writing test cases.

---

## Week 3 — Verification methods and evidence planning

Four common methods are:

- **Test:** operate an end product or representative article to collect measured data.
- **Analysis:** use mathematical reasoning, models, simulation or engineering calculations.
- **Inspection:** examine an item, document, code, physical characteristic or configuration.
- **Demonstration:** show that an item performs a function, typically without the detailed data collection of a formal test.

Method selection depends on requirement type, risk, lifecycle stage, available article, uncertainty and cost. A test is not automatically stronger than analysis. A badly controlled test may provide weaker evidence than a validated analytical model. A demonstration may show a function works once but not establish statistical reliability.

### Worked example

- "Valve body material shall be stainless steel grade X" — inspection of certificates/marking and, where necessary, material test.
- "Valve shall close within 300 ms" — measured test with defined timing boundaries.
- "Network throughput shall not exceed a specified safe utilization in a fixed scenario" — analysis plus load test.
- "Operator can acknowledge alarm using the local panel" — demonstration with representative users, supplemented by usability validation.

### Laboratory

For every capstone requirement, select a method and justify why the method produces sufficient evidence. Identify cases where a combination of methods is required.

---

## Week 4 — Test design: partitions, boundaries and decision tables

Equivalence partitioning divides an input domain into classes expected to behave similarly. Boundary-value analysis concentrates on edges where defects often occur. For a permitted tank threshold of 10%–90%, test below the minimum, at the minimum, just above, typical interior values, just below the maximum, at the maximum and above the maximum. Include invalid units, missing values, overflow and numeric precision where relevant.

Decision tables test combinations of conditions. For example, a command may be accepted only if the user is authenticated, authorized for the facility, the controller is online, the command is within the allowed range and the interlock does not prohibit it. The table exposes combinations that one-condition-at-a-time tests miss.

State-transition testing checks state/event pairs, including invalid transitions. It is especially useful for authentication sessions, maintenance mode, controller states, retry logic and recovery workflows.

### Worked example

Input class for `level_percent`:
- invalid: less than 0;
- lower boundary: 0;
- valid low: 0–10;
- normal: 10–80;
- high: 80–100;
- upper boundary: 100;
- invalid: greater than 100;
- malformed: null, string, NaN, infinity.

The partition boundaries must match domain rules; overlapping classes should be resolved explicitly.

### Laboratory

Build a decision table for remote command acceptance. Derive a minimal test set that covers every rule and every boundary. Include invalid user, valid user without resource ownership, stale controller and active safety interlock.

---

## Week 5 — Unit, component and integration testing

Unit tests verify a small unit in isolation. They are fast and local but may miss interface mismatches, environmental assumptions and distributed failure behavior. Component tests exercise a subsystem with controlled collaborators. Integration tests examine actual interactions across component boundaries.

Test doubles are useful but can lie. A mock can encode the same mistaken assumption as the implementation. Use real dependencies selectively for integration tests, contract tests for interfaces, and fakes for deterministic control of rare failure conditions. The test pyramid is a heuristic about feedback speed and scope, not a universal mandate for a fixed ratio.

Integration strategies include top-down, bottom-up, sandwich and incremental integration. Big-bang integration delays feedback and makes fault localization difficult. Incremental integration reveals interface defects earlier.

### Worked example

The command service writes a command to PostgreSQL and publishes a message. A unit test can verify command validation. An integration test must verify transaction plus outbox behavior. A consumer contract test must verify the event schema. An end-to-end test must prove that an authorized command reaches the controller and local interlocks still dominate.

### Laboratory

Implement tests for one command path at three levels: unit, database integration and API end-to-end. Force the process to crash after database commit but before message publication; demonstrate the outbox recovery.

---

## Week 6 — System, acceptance and operational validation

System testing evaluates the integrated system against system requirements. Acceptance testing determines whether the product is acceptable under the agreed acceptance criteria. Validation assesses suitability for stakeholder use in realistic operational conditions.

A validation scenario should include a user goal, realistic constraints, environment, expected outcome and observation method. A feature demo is not necessarily validation. Ask whether representative users can complete real tasks safely and effectively under normal and degraded conditions.

The ConOps is a useful validation anchor. It describes how the system is intended to be used, including operator roles, mission sequences, training, maintenance and exceptions. If test scenarios cover only the ideal workflow, they cannot validate the actual operating concept.

### Laboratory

Run a scenario-based validation exercise with a representative operator. Include network loss, stale telemetry, conflicting command and maintenance mode. Record task success, time, errors, workarounds and user interpretation of system state.

---

## Week 7 — Test environments, data and reproducibility

A test result is only meaningful when the test configuration is known. Record software revision, hardware, database schema, dependency versions, configuration, environment variables, test data, instrumentation, network profile and time source. If the same test produces materially different outcomes in the same stated conditions, investigate nondeterminism or hidden environmental dependence.

Test data should be representative but safe. Use synthetic or sanitized data; control secrets; avoid production personal information unless a formal approved process exists. Test environments should model the behaviors relevant to the claim, not imitate every production detail blindly.

For distributed systems, deterministic clocks, controllable schedulers, network fault injection and repeatable state initialization make testing more effective. Time-dependent tests should avoid relying on arbitrary sleeps when explicit synchronization or controlled clocks are available.

### Laboratory

Create a reproducible test environment using containers or documented scripts. Run the same tests twice from a clean state. Produce a manifest of versions, data and configuration.

---

## Week 8 — Non-functional verification: performance and reliability

Non-functional requirements are still requirements and need measurable criteria. Performance testing may include load, stress, spike, endurance and capacity testing. Measure latency distribution, throughput, saturation, queue depth, resource consumption, error rate and recovery time.

Reliability testing examines failure behavior over time and under defined conditions. Availability is not identical to reliability. A highly available architecture may recover quickly from component failure; a reliable component may rarely fail but take a long time to repair.

Statistical interpretation matters. If zero failures occur in \(n\) independent trials, the failure probability is not proven to be zero. A rough "rule of three" gives an approximate 95% upper bound of \(3/n\) on the failure probability when zero failures are observed, under suitable independent Bernoulli assumptions. With 1000 failure-free trials, the bound is about 0.003, not zero.

### Laboratory

Load-test the telemetry API at gradually increasing rates. Report p50, p95, p99 latency, throughput, error rate, resource saturation and queue behavior. Run an endurance test and identify memory/resource drift.

---

## Week 9 — Security and safety verification

Security testing should be driven by threat models and security requirements. Test authentication, authorization, object ownership, input validation, session lifecycle, cryptographic configuration, secrets handling, logging and dependency integrity. Include negative tests: a user who is not allowed to act must be denied, and one user's resource must not be accessible through another user's identifier.

Safety verification must test the required safety functions and fault responses. Test normal, degraded and fault states; check timing, independence assumptions and safe-state behavior. A test that disables all safety interlocks for convenience is not a valid demonstration of safe operation.

No finite test suite proves the absence of vulnerabilities or hazards. Testing provides bounded evidence under specified conditions. Analysis, inspection, formal reasoning, operational monitoring and independent review complement it.

### Laboratory

Create one safety verification and one security verification package. Include traceability to the relevant requirement, expected result, negative test, evidence artifact and residual limitation.

---

## Week 10 — Model-based testing and formal verification

Model-based testing derives tests from a behavioral model such as a state machine, activity model or protocol automaton. It can improve transition coverage and reveal missing behaviors. The model itself must be reviewed; incorrect models generate systematic but misleading tests.

Formal methods use mathematical representations to prove properties under explicit assumptions. Examples include invariants, temporal logic, model checking, theorem proving and refinement. A proof applies to the model and assumptions, not automatically to the deployed physical system. The abstraction gap must be considered.

An invariant is a property that must hold in every reachable state. For the control system, one candidate is: `if sensor_valid = false then actuator_enable = false`, provided that this is the intended policy and the actuator is controllable. A temporal property may express that a high-high condition eventually leads to a close command within a time bound. Temporal logic notation should be learned only after the event/state semantics are unambiguous.

### Laboratory

Generate tests from a simple controller state model. Add a model checker or property-based test for an invariant. Deliberately alter a guard so a test exposes an unsafe transition.

---

## Week 11 — Automation, CI and regression

Automated tests provide fast, repeatable feedback, but automation has costs: maintenance, flaky tests, false confidence, environment drift and slow pipelines. Automate stable, valuable checks; retain human review where judgment or context is essential.

A CI pipeline should separate formatting/static analysis, unit tests, component tests, integration tests, security checks and longer system suites. Each stage should produce clear evidence and preserve the failing artifact. Flaky tests should be treated as defects in the test system, not ignored by rerunning until green.

Regression testing evaluates whether changes broke previously working behavior. Select regression tests based on risk and impact, not simply by rerunning every test without analysis. Mutation testing changes code in small ways to assess whether the suite detects behavior changes. It measures test sensitivity for the chosen mutations, not overall test quality.

### Laboratory

Create a CI workflow that runs formatting, linting, unit tests, SQL migration checks and an integration test suite. Add one deliberately introduced defect and demonstrate that the pipeline fails.

---

## Week 12 — Traceability, coverage and defect management

Traceability connects needs, requirements, architecture, code/model elements, tests, results, hazards, threats and anomalies. A verification matrix records which method and evidence demonstrate each requirement. Coverage measures help identify untested areas, but coverage is not proof of correctness.

Common measures include requirement coverage, statement coverage, branch coverage, condition coverage, transition coverage, interface coverage and risk-based scenario coverage. Each answers a different question. 100% statement coverage does not mean every decision outcome, input class or hazard scenario was tested.

An anomaly report should include observed behavior, expected behavior, environment, reproducible steps, evidence, severity, impact, frequency and suspected scope. Triage distinguishes defect, test defect, requirement defect, configuration issue and accepted limitation.

### Laboratory

Create a bidirectional traceability matrix. Calculate requirement verification coverage and identify orphan requirements, orphan tests and tests with no clear objective. Create three anomaly reports with reproducible evidence.

---

## Week 13 — V&V planning, evidence and release decisions

A V&V plan defines objectives, scope, organization, responsibilities, methods, environments, sequence, entry/exit criteria, configuration control, evidence records, reporting and risk handling. It should be baselined before formal verification begins.

A verification report identifies the requirement baseline, product configuration, procedure revision, tools/equipment, operating conditions, results, anomalies and decisions. A pass/fail result without configuration information is difficult to reproduce and may not apply to the delivered build.

Release readiness is a risk-informed decision. Open defects should be assessed against severity, probability, user impact, mitigations, operational constraints and evidence. "All tests pass" is not a sufficient release argument if required tests were omitted, test data was unrepresentative or the test suite does not address major threats and hazards.

### Laboratory

Write a V&V plan and a sample verification report. Include a requirements baseline, test configuration, test cases, evidence, anomaly disposition and release recommendation.

---

## Week 14 — Integrated V&V assessment

The final review should show the chain:

```text
Stakeholder need
      -> validated requirement
      -> architecture allocation
      -> verification method and acceptance criterion
      -> approved procedure
      -> reproducible result
      -> anomaly disposition
      -> verification conclusion

ConOps + representative user
      -> validation scenario
      -> observed operational outcome
      -> stakeholder acceptance / corrective action
```

### Final submission

Submit a requirements quality report, V&V plan, verification matrix, validation plan, test design specification, automated test suite, test environment manifest, executed test report, anomaly log and release decision.

### End-of-course problems

1. A service meets all specified requirements but operators cannot use it under realistic conditions. Is it verified? Validated?  
   **Solution:** It may be verified against its stated requirements but has failed validation. The stakeholder needs or ConOps may be incomplete, or the requirements may not adequately represent actual operations.

2. Does 100% line coverage prove correctness?  
   **Solution:** No. It only indicates executed lines under the coverage tool's measurement. It does not prove correct assertions, adequate input classes, branch outcomes, timing, security or requirement coverage.

3. Why record the tested software version and requirement baseline?  
   **Solution:** Evidence applies to a specific configuration. Without both versions, the reviewer cannot determine which product and specification were assessed.

## Selected sources and further study

- NASA Systems Engineering Handbook: https://www.nasa.gov/reference/systems-engineering-handbook/
- NASA distinction between verification and validation: https://www.nasa.gov/reference/2-4-distinctions-between-product-verification-and-product-validation/
- NASA product verification methods: https://www.nasa.gov/reference/5-3-product-verification/
- NASA V&V plan outline: https://www.nasa.gov/reference/appendix-i-verification-and-validation-plan-outline/
- ISTQB Certified Tester Foundation Level syllabus: https://www.istqb.org/certifications/certified-tester-foundation-level
- Google Testing Blog: https://testing.googleblog.com/
- Hypothesis property-based testing: https://hypothesis.readthedocs.io/
- TLA+ resources: https://lamport.azurewebsites.net/tla/tla.html
- OWASP ASVS 5.0.0: https://owasp.org/www-project-application-security-verification-standard/

NASA's systems-level V&V guidance is particularly useful for method selection and evidence structure. Use software-testing references for detailed test design and automation; do not confuse tool reports with engineering conclusions.


---

## Expanded 14-week lecture notes and practical sequence


### Week 01 — V&V foundations and the evidence chain

**Lecture notes.** Verification asks whether specified requirements have been satisfied; validation asks whether the resulting system meets stakeholder needs in its intended context. Qualification, acceptance and independent V&V have distinct authority and decision roles. Plan V&V from requirements and architecture, not after coding. Each claim should link to a requirement, method, environment, acceptance criterion, result, anomaly disposition and reviewer. The V-model is a useful planning representation, not a guarantee that development is linear. Iterative development still needs explicit baselines and re-verification after change.


**Worked application.** A test that shows a sensor API returns a numeric value verifies a software requirement. It does not validate that an operator can recognize an impending overflow under poor lighting and a network outage. Different claims require different evidence.


**Practical / assessed work.** Build a verification matrix for the tank controller. Include requirement ID, verification method, test stage, environment, objective pass criterion and evidence location.


**Checkpoint.** State the model assumptions, identify one failure mode or limitation, and explain what evidence would change your conclusion.


### Week 02 — Requirement quality, contracts and testability

**Lecture notes.** A requirement is testable when it defines observable conditions and measurable success. Identify preconditions, input domain, output/behavior, tolerances, timing, environment and error response. Convert vague adjectives into thresholds or scenarios agreed by stakeholders. Maintain one primary obligation per requirement where practical. Define an oracle: the independent rule used to decide whether the observed result is correct. Oracles may come from a reference model, invariant, analytic calculation, independently reviewed expected output or stakeholder judgment. A test without a trustworthy oracle can execute successfully while proving little.


**Worked application.** ‘The alarm shall be fast’ lacks a threshold and start/end points. ‘For valid samples above the high-high threshold, the local controller shall command valve closure within 250 ms, measured from ADC sample timestamp to command issue, under the stated load’ provides a measurable criterion.


**Practical / assessed work.** Rewrite 15 weak requirements, create boundary values and define a test oracle for each. Identify requirements that cannot be verified by test and justify analysis, inspection or demonstration instead.


**Checkpoint.** State the model assumptions, identify one failure mode or limitation, and explain what evidence would change your conclusion.


### Week 03 — Test design: equivalence, boundaries and decisions

**Lecture notes.** Black-box test design reduces a large input space by partitioning it into equivalence classes expected to behave similarly. Boundary-value analysis targets edges because off-by-one errors cluster there. Decision tables expose combinations of conditions and actions; state-transition tests cover legal and illegal state changes. Pairwise testing can reduce combinatorial explosion but does not guarantee detection of higher-order interactions. Select test techniques based on risk and logic, not a coverage slogan. For numeric limits, include just-below, exact-boundary and just-above values plus invalid types, missing values and overflow conditions.


**Worked application.** If accepted tank level is 0–100%, representative boundary tests are −ε, 0, ε, 99.9, 100 and 100+ε. The exact set depends on quantization and tolerance; the test specification must define those semantics rather than assume floating-point equality.


**Practical / assessed work.** Create partitions, boundary tests, a decision table and a state-transition suite for the command API. Show which logical conditions each test covers and the defect each is intended to detect.


**Checkpoint.** State the model assumptions, identify one failure mode or limitation, and explain what evidence would change your conclusion.


### Week 04 — Structural coverage, MC/DC and mutation testing

**Lecture notes.** Statement coverage shows which statements executed; branch coverage shows whether decision outcomes were exercised. Condition coverage examines individual Boolean terms. Modified Condition/Decision Coverage (MC/DC) demonstrates that each condition can independently affect the decision outcome while other conditions are appropriately held. Coverage is a measurement of exercised structure, not proof of correctness. Mutation testing changes code in small ways; a test suite that fails to detect a meaningful mutant has a possible oracle or coverage gap. Explain equivalent and invalid mutants rather than maximizing a raw mutation score.


**Worked application.** For decision `A && (B || C)`, MC/DC needs a set of tests demonstrating the independent influence of A, B and C on the final decision. The exact vectors must account for masking; simply testing all-true and all-false is insufficient.


**Practical / assessed work.** Calculate branch and condition coverage on a small controller function. Add deliberate mutants (reverse comparison, remove timeout guard) and show which tests kill them.


**Checkpoint.** State the model assumptions, identify one failure mode or limitation, and explain what evidence would change your conclusion.


### Week 05 — Reviews, static analysis and proof obligations

**Lecture notes.** Static verification includes inspection, review, type checking, linting, data-flow analysis and static analysis tools. A review needs defined scope, entry criteria, roles, checklist, defect log and closure evidence. Static analyzers can find classes of issues but have false positives, false negatives and configuration sensitivity. Formal methods express properties mathematically and can prove them relative to a model and assumptions. A proof does not establish that the model matches the deployed implementation unless the refinement/translation relationship is justified. Use reviews to challenge interfaces, assumptions and evidence quality, not only formatting.


**Worked application.** A static analyzer may report a possible nil dereference. A developer can prove the path unreachable only by documenting the guard/invariant or correcting the code; suppressing the message without justification destroys evidence.


**Practical / assessed work.** Run Go vet/staticcheck where installed, review the authorization code with a structured checklist and write a proof obligation for a safety invariant.


**Checkpoint.** State the model assumptions, identify one failure mode or limitation, and explain what evidence would change your conclusion.


### Week 06 — Unit, component and integration testing

**Lecture notes.** Unit tests isolate a small contract and should be fast, deterministic and clear. Component tests exercise a boundary with real serialization, storage or transport where feasible. Integration tests reveal contract mismatches across components. Mocks can make tests brittle or accidentally encode the same flawed assumption as production code; prefer fakes or real dependencies when the behavior under test belongs to that dependency. Use dependency injection to control time, randomness and failures. Test error paths, cleanup, concurrency and repeated execution, not just happy paths.


**Worked application.** A mocked database can prove that a handler calls `Save()`, but it cannot prove that the actual SQL transaction commits the deduplication record with the side effect. That requires an integration test against the real database engine.


**Practical / assessed work.** Build tests at unit, component and integration levels for a sample endpoint. Compare a mocked storage adapter with PostgreSQL-backed behavior and explain what each test actually establishes. Then run `labs/06-data-systems/tinydb/test_bptree_stateful.py`: a deterministic state-machine-style test generates 40 independent operation sequences and compares insert/update/lookup/range-scan behavior with a reference dictionary while checking structural invariants. Explain the generator seed, operation distribution, oracle and untested behaviors (the in-memory tree has no delete or concurrent operations).


**Checkpoint.** State the model assumptions, identify one failure mode or limitation, and explain what evidence would change your conclusion.


### Week 07 — System, acceptance and operational validation

**Lecture notes.** System testing examines the integrated product against system requirements. Acceptance testing examines agreed stakeholder outcomes in representative use. Operational validation includes installation, configuration, upgrade, recovery, training, monitoring and maintainability. Test realistic end-to-end scenarios, including degraded modes, accessibility and human interaction. Define entry/exit criteria and environment equivalence. A demonstration can support a claim but must be scripted, repeatable and recorded if it is to serve as objective evidence. Separate an observed success from the statistical claim that the system will succeed in the field.


**Worked application.** A tank operator scenario should include a stale telemetry display, uncertain sensor quality, a high-high alarm and a network outage. Task completion time and correct interpretation are measurable outcomes; ‘the UI looked good’ is not validation evidence.


**Practical / assessed work.** Conduct a scripted user acceptance tabletop. Record task success, time, errors, prompts, environment and limitations; link findings to requirements and design changes.


**Checkpoint.** State the model assumptions, identify one failure mode or limitation, and explain what evidence would change your conclusion.


### Week 08 — Performance, reliability and statistical testing

**Lecture notes.** Performance tests require a workload model, arrival process, data size, concurrency, warm-up, duration, resource metrics and acceptance threshold. Report latency percentiles and throughput under a defined error rate. Repeated runs and confidence intervals help separate signal from noise. Reliability demonstration tests need a failure definition and statistical model. For zero failures in n independent Bernoulli trials, the approximate 95% upper bound on failure probability is about 3/n (rule of three), not zero. This assumes independent, identically distributed trials and a fixed test condition; it is weak evidence for rare complex failures.


**Worked application.** Zero failures in 100 tests gives an approximate 95% upper bound of 3% per demand, not evidence of one-in-a-million reliability. To bound failure probability near 10⁻⁶ by a zero-failure test alone would require an enormous independent sample; use analysis and layered assurance too.


**Practical / assessed work.** Run a load test with three workload profiles. Report p50/p95/p99, throughput, error ratio, CPU/memory, variance across runs and a confidence statement that matches the sample size.


**Checkpoint.** State the model assumptions, identify one failure mode or limitation, and explain what evidence would change your conclusion.


### Week 09 — Concurrency, distributed and fault-injection testing

**Lecture notes.** Concurrency defects depend on interleavings, timing and state. Use race detectors, stress testing, barriers, deterministic schedulers where available and systematic fault injection. Distributed tests should inject delay, loss, duplication, reordering, partitions, crash/restart and partial persistence. A test must record the fault schedule; otherwise failures may be irreproducible. Chaos experiments in production require explicit authorization, blast-radius limits, stop conditions and rollback; this curriculum uses local disposable services only. Test the recovery invariant, not merely the fact that the process restarted.


**Worked application.** A timeout after a write may produce a duplicate command when a client retries. The regression test should simulate the response being lost after commit, then assert one effect and a stable result after process restart.


**Practical / assessed work.** Create a deterministic failure schedule for the replicated key-value toy lab. Run every injected schedule twice and compare traces; identify nondeterministic sources.


**Checkpoint.** State the model assumptions, identify one failure mode or limitation, and explain what evidence would change your conclusion.


### Week 10 — Formal specification, Hoare logic and model checking

**Lecture notes.** A Hoare triple {P} C {Q} states that if precondition P holds and command C terminates, postcondition Q holds. Loop invariants support inductive proofs: establish before the loop, preserve across an iteration, and use with loop exit to derive the result. Temporal logic expresses properties over traces; safety properties say something bad never happens, liveness properties say something good eventually happens. Model checking explores a finite or abstract state space against such properties. State explosion is fundamental; abstraction, symmetry reduction and bounded exploration manage cost but change what is proven.


**Worked application.** For a bounded counter loop, invariant `0≤i≤n` can be established at initialization, preserved by increment, and combined with exit `i=n+1` to prove a postcondition. A real proof must account for integer overflow and the program’s actual semantics.


**Practical / assessed work.** Write Hoare-style pre/postconditions for a valve command. Enumerate the finite controller state machine and check that ‘valve never remains open in SAFE_SHUTDOWN’ holds under the stated transition model. Then complete `labs/04-vv/quorum_model/` and `labs/04-vv/tla-plus/`: run the finite Python quorum-election graph, check `TypeOK`, `OneVotePerTerm` and `ElectionSafety`, then run the intentionally unsafe mutant and explain its shortest counterexample. Finally, run the corresponding `QuorumElection.tla` and `QuorumElectionUnsafe.tla` models with TLC and compare the trace to the Python result. The TLA+ CLI instructions pin the current official JAR and checksum; the local V3 build did not download/run TLC, so a student's TLC output is required before that part can be marked complete.


**Checkpoint.** State the model assumptions, identify one failure mode or limitation, and explain what evidence would change your conclusion.


### Week 11 — Security and safety verification

**Lecture notes.** Security tests examine unauthorized paths, trust boundaries, injection, session handling, resource ownership and resilience. Safety tests examine hazardous conditions, fault responses, timing and protective independence. A passing test demonstrates only the tested condition under the recorded configuration. Negative tests are important: unauthorized users, invalid sensor states, stale timestamps, message duplication and dependency failure. Requirements should include both positive and negative acceptance criteria. Independent review is valuable where the consequence of missing a defect is high; independence must be real, with authority and access to evidence.


**Worked application.** A role test that proves an ADMIN can read a record does not prove a USER cannot read another facility’s record by changing an object ID. The negative authorization test must target resource ownership, not only role labels.


**Practical / assessed work.** Build a traceable negative-test suite for safety and security requirements. Include direct-object-reference, stale measurement, sensor disagreement, fail-open and fail-closed cases.


**Checkpoint.** State the model assumptions, identify one failure mode or limitation, and explain what evidence would change your conclusion.


### Week 12 — Automation, CI, regression and evidence management

**Lecture notes.** A continuous-integration pipeline should run reproducible builds, static checks, unit/integration tests, security scans and artifact generation. Pin tool versions and dependencies; isolate secrets; avoid relying on mutable network state. Test data should be synthetic and resettable. A regression suite captures prior failures as durable tests. Flaky tests reduce trust and should be diagnosed, not hidden by reruns. Preserve test logs, environment, commit/model baseline, execution identity, timestamps and result. Trace evidence to requirement and anomaly records, and keep a clear distinction between automated pass status and engineering acceptance.


**Worked application.** A test pipeline that downloads an unpinned tool at runtime may pass today and fail tomorrow. Pinning the major/minor toolchain and recording checksums improves reproducibility; version updates require a controlled re-baseline.


**Practical / assessed work.** Create a CI workflow for the local labs. It must run tests and static checks, preserve output artefacts and fail on missing requirement-to-test links.


**Checkpoint.** State the model assumptions, identify one failure mode or limitation, and explain what evidence would change your conclusion.


### Week 13 — IV&V, release assurance and integrated V&V capstone

**Lecture notes.** Independent V&V evaluates the system from a perspective sufficiently independent of the development team to reveal assumptions and omissions. A release decision should combine requirement coverage, test results, unresolved defects, safety/security claims, performance limits, configuration identity and operational readiness. Coverage does not replace engineering judgment. Use risk-based prioritization but document what remains unverified. A final V&V report should state what was tested, what was not, limitations, anomalies, residual risk, acceptance authority and conditions for reuse of evidence after changes.


**Worked application.** If a firmware update changes sensor filtering, prior timing, reliability and hazard evidence may no longer apply. Reuse is justified only after impact analysis establishes which assumptions remain valid and which tests or analyses must be repeated.


**Practical / assessed work.** Produce a V&V plan and final evidence dossier for the integrated tank system. Conduct a peer review of traceability, test adequacy, anomaly closure and release assumptions. Include the local executable quorum-model results, the TLC run logs (or explicitly mark that gate not executed), all property-style graph-test results, tool versions and the abstraction/refinement limitations.


**Checkpoint.** State the model assumptions, identify one failure mode or limitation, and explain what evidence would change your conclusion.


### Week 14 — Configuration baselines, assurance metrics and integrated review

**Lecture notes.** Evidence is valid only for a defined configuration: source revision, build inputs, model version, test data, tool versions and operational settings. Configuration management identifies controlled items, baselines, changes, status accounting and audits. Assurance metrics should expose meaningful risk rather than optimize a single number: requirement coverage, test effectiveness, unresolved severity, code/model changes, flaky tests, escaped defects and confidence in the evidence chain. A final integrated review checks that V&V, safety and security arguments use the same system boundary and assumptions. It also checks whether test environments represent the intended operating context.


**Worked application.** A 100% pass rate on an outdated build does not verify a release candidate. A release claim must bind test results to the exact artifact hash and configuration baseline; changes after test execution require impact analysis and selective re-verification.


**Practical / assessed work.** Create a release evidence manifest with artifact hashes, build/toolchain versions, test logs, environment, requirement coverage, anomaly status and approval authority. Conduct an independent review and write a go/no-go recommendation with explicit residual risks.


**Checkpoint.** State the model assumptions, identify one failure mode or limitation, and explain what evidence would change your conclusion.


## Assessment design

| Component | Weight | Evidence expected |
|---|---:|---|
| Weekly problem sets and derivations | 20% | Correct reasoning, assumptions, units and worked calculations |
| Practical labs and reproducibility | 25% | Executable/model artefacts, tests, environment and results |
| Midterm assessment | 15% | Core concepts, derivations and design trade-offs |
| Individual cumulative project | 25% | Correct implementation/model, traceability and technical report |
| Final examination and oral defense | 15% | Transfer to unseen cases and explanation of submitted work |


## Minimum submission standard

Every practical report must include: objective; theory; assumptions; environment/tool versions; procedure; expected result; actual result; raw evidence; analysis; limitations; references. A screenshot alone is not proof of a model, test, or database property. Never label an external-tool lab as passed unless it was run in the named tool.


## Additional executable formal-methods lab — quorum election and counterexample analysis

The companion lab `labs/04-vv/quorum_model/` gives a complete bounded example of a safety property, a deliberate protocol mutation, and a shortest counterexample. The Python graph has 3 voters, 1 bounded term and a quorum of 2. Its safe transition relation enforces one vote per node per term. The mutant removes that guard; two candidates can then each receive the same two votes, violating election safety.

The companion directory `labs/04-vv/tla-plus/` contains the same one-vote-per-term and one-leader-per-term properties over finite `Nodes` and `Terms` constants. `QuorumElection.cfg` is the safe model; `QuorumElectionUnsafe.cfg` is the expected-failure model. The correct student submission includes the TLC version/checksum, the model configuration, full state count, the invariant status and the complete counterexample trace for the mutant. A static file review or Python simulation is not TLC evidence.

**Assessment boundary:** the quorum theorem is a necessary safety argument for majority voting, not sufficient evidence for Raft correctness. Log freshness/leader completeness, AppendEntries, replication, commit-index safety, durability, crash recovery, reconfiguration, and liveness under timing/failure assumptions require separate models and tests.


### Property-style testing: tested local suite versus optional Hypothesis extension

The local suite currently uses seeded generators from the Python standard library so it is reproducible without an external dependency. `labs/04-vv/quorum_model/test_modelcheck_properties.py` generates finite graphs and cross-checks reachability and shortest counterexample lengths against independent reference algorithms. `labs/06-data-systems/tinydb/test_bptree_stateful.py` generates insert/update/lookup/range-scan sequences and compares the B+ tree to a reference dictionary while validating tree structure. These are deterministic property-style tests, not an exhaustive proof across all inputs.

An optional extension is to install Hypothesis and express the same command sequence using `RuleBasedStateMachine`, `@rule`, `@precondition` and `@invariant`. Hypothesis can explore more generated sequences and shrink a failing history to a smaller counterexample; record the version and reproduction seed/blob for any reported defect. Hypothesis is not installed in this build environment and no Hypothesis execution is claimed.


## Edition 3 lab annex — bounded model checking and counterexamples

The V&V labs add a safe and deliberately unsafe quorum-election specification, a Python finite-state explorer, shortest counterexample checks and generated reference-model cases. Python tests are included in the 94-test aggregate. The TLA+ artifacts live in `labs/04-vv/tla-plus/`; use the official [TLA+ Tools v1.8.0 release](https://github.com/tlaplus/tlaplus/releases/tag/v1.8.0) and Java 11+ to run the CLI instructions in that folder. **TLC was not executed in this build environment**, so only the Python models and static artifact checks are counted as local passes. A finite bounded model explores only the state space and assumptions supplied; it does not prove an unbounded implementation correct. The [University of Surrey 2026/27 Systems Verification module](https://catalogue.surrey.ac.uk/2026-7/module/COM3028/SEMR2/2) is a useful benchmark for temporal logic, explicit/symbolic model checking, Hoare logic, BDDs and model-checker labs.

# Distributed Systems — Expanded Course Reader (2026 Edition)

> **Level:** Advanced undergraduate / early graduate; programming, algorithms, operating systems, networking and concurrency prerequisites.  
> **Duration:** 14 teaching weeks, 8–12 hours/week  
> **Status:** Self-study reader benchmarked against official 2026 university syllabi and primary documentation. It is not an accredited course or professional certification.

## Course outcomes

1. State the system, timing, communication, failure and adversary assumptions behind a distributed algorithm.

2. Implement and debug concurrent network services, RPC protocols, retries, idempotency and recovery paths.

3. Reason about causality, snapshots, consistency histories, replication, consensus and distributed transactions.

4. Measure latency, throughput, availability and tail behavior; use traces and controlled fault injection to explain results.

5. Critically compare designs and identify the guarantees they do and do not provide.


## How to work through the course

For each week, read the concept notes, reproduce the derivation or model, complete the practical task, answer the challenge without looking at references, and record assumptions and evidence. A passing submission must include the exact environment, expected criterion, observed result and limitations. Use the weekly practical tasks as assessed work, not optional reading.


## Foundation reader retained from the first edition

The original first-edition chapter is preserved below for continuity. The expanded notes that follow add the missing depth, quantitative reasoning, labs and assessment structure identified in the academic audit.


---


# Course 1 — Distributed Systems
**Level:** Upper-undergraduate / early graduate  
**Duration:** 14 teaching weeks  
**Expected workload:** 8–10 hours per week  
**Primary language for laboratories:** Go (examples are language-independent unless stated)  
**Prerequisites:** Data structures, operating systems fundamentals, computer networks (TCP/IP, HTTP), concurrency, basic probability, Git and command-line use.

## Course description

A distributed system consists of multiple autonomous processes that communicate through a network and coordinate to provide a service. The defining difficulty is not simply that the system has many machines. It is that components execute independently, communicate with delay, observe events in different orders, and can fail independently. The network may lose, delay, duplicate or reorder messages. A process may pause, restart, or become unreachable while other components continue. Consequently, a correct local algorithm does not automatically produce a correct distributed service.

This course develops the models and engineering techniques used to reason about such systems. It connects communication, concurrency, time, replication, consistency, consensus, transactions, partitioning, reliability and operational design. The course emphasizes the distinction between a guarantee that can be proved under a stated model and a behavior that merely appeared to work in a small test.

The recurring case is a remote water-tank monitoring and control platform. A local controller must continue safe local operation when the network or cloud service is unavailable. A remote service receives telemetry, persists observations, and accepts authorized commands. The case is deliberately used to expose end-to-end failure modes rather than as a deployable industrial design.

## Learning outcomes

By the end of the course, a student should be able to:

1. Define process, communication, timing and failure assumptions for a distributed design.
2. Explain why timeouts cannot prove that a remote operation did not execute.
3. Use happens-before relations and logical clocks to reason about event ordering.
4. Compare primary-backup replication, quorum replication and state-machine replication.
5. Distinguish linearizability, sequential consistency, causal consistency and eventual consistency.
6. Explain the assumptions and limits of consensus protocols such as Raft and Paxos.
7. Design safe retries using idempotency keys, deduplication and durable operation records.
8. Analyze distributed transactions, sagas, sharding and rebalancing.
9. Instrument, test and operate a distributed service under partial failure.
10. Defend a design by stating its guarantees, assumptions, failure behavior and evidence.

## Assessment model

Suggested weighting for self-study or a university course: weekly problem sets 15%; programming laboratories 35%; midterm design analysis 15%; final project 25%; oral/debugging review 10%. A student should not receive full credit for a working demonstration that has no stated failure model or correctness argument.

---

## Week 1 — What makes a system distributed?

### 1.1 Definition and design problem

A distributed system is a collection of processes that communicate by exchanging messages and coordinate to perform a task. The processes may execute on different computers, virtual machines, containers or devices. They do not share ordinary process memory, and they cannot assume a globally visible clock.

A useful model separates three dimensions:

- **Process model:** crash-stop, crash-recovery, omission, timing, or Byzantine behavior.
- **Communication model:** reliable or unreliable channels; bounded or unbounded message delay; point-to-point or group communication.
- **Timing model:** synchronous, asynchronous, or partially synchronous assumptions.

These are not academic labels. They determine which guarantees are possible. For example, an asynchronous system provides no known upper bound on message delay. A slow process and a failed process may therefore look identical to a remote observer.

### 1.2 Why distribution is useful

Distribution may improve scale, availability, geographic reach, fault isolation, resource utilization or organizational autonomy. Each benefit introduces costs: network latency, partial failure, coordination, operational complexity, data consistency problems and harder debugging. Moving a function from one process to another is not a neutral refactor; it changes the failure and timing model.

A useful system boundary identifies which components are inside the system, which dependencies are external, and what assumptions are made about each dependency. For the tank platform, the cloud service must not be the only component capable of stopping the pump: loss of Internet connectivity must not remove the local control loop.

### 1.3 Quantifying latency and load

Average latency is insufficient when a service has a long-tailed distribution. If 99 requests complete in 20 ms and one takes 2 seconds, the mean is 39.8 ms, but the 99th percentile is 20 ms and the 100th percentile is 2 seconds. Use percentiles, throughput and error rates together.

Little's Law states:

\[
L = \lambda W
\]

where \(L\) is the average number of items in a stable system, \(\lambda\) is the average arrival rate, and \(W\) is average time in the system. If a service receives 200 requests/s and average response time is 0.05 s, the average in-flight request count is about 10. This is a steady-state relationship, not a guarantee during overload or unstable queues.

### Worked example

A telemetry service receives 500 messages/s. Average processing time is 40 ms. Under stable load, Little's Law predicts \(L = 500 \times 0.04 = 20\) messages in the processing system. If the system is provisioned for only 10 concurrent workers, the queue grows unless each worker's effective processing capacity or the number of workers increases. Increasing concurrency may improve throughput until CPU, database or network contention becomes dominant.

### Laboratory

Create two processes that exchange a heartbeat message. Add an artificial delay and terminate one process. Observe that a timeout is an observation about elapsed time, not proof of process death. Record the assumptions used by your detector.

### Check your understanding

1. Why is a remote process's slowness indistinguishable from failure in a fully asynchronous model?
2. Name two benefits and three costs of distribution.
3. Under what assumptions is Little's Law useful?

**Worked answer:** A remote observer sees only messages and elapsed local time. If no message arrives, the process may have crashed, the message may be delayed, or the path may be partitioned. Distribution is beneficial for scale and fault isolation, but introduces network delay, partial failure and coordination. Little's Law applies to a stable system over an appropriate observation interval.

---

## Week 2 — Communication, RPC and failure semantics

### 2.1 Messages are not function calls

A local function call normally transfers control within one process. A remote procedure call (RPC) crosses a communication boundary. The caller must serialize arguments, send bytes, wait for a response, deserialize a result and handle connection and protocol errors. Either side may crash at any point.

A timeout means: **the caller stopped waiting**. It does not mean the server did not receive or execute the request. Consider a command to start a pump. The server can perform the command and crash before replying. The client retries, and the command may execute twice unless the application has an explicit deduplication rule.

### 2.2 Request/response states

Model a request as a state machine:

```text
CREATED -> SENT -> RECEIVED -> EXECUTING -> COMMITTED -> REPLIED
                      |            |             |
                      +------------+-------------+--> caller may time out
```

The caller can observe only a subset of these states. A timeout may occur after `COMMITTED` but before `REPLIED`. Thus, client-side timeout and server-side outcome are separate pieces of state.

### 2.3 Delivery and execution semantics

- **At-most-once attempt:** the client does not retry after uncertainty. An operation may be lost.
- **At-least-once attempt:** the client retries until it obtains a response or reaches a policy limit. The server may see duplicates.
- **Effectively-once business effect:** retries are allowed, but the application records a stable operation identifier and ensures the business effect is applied once within a defined scope.

"Exactly once delivery" is generally an unsafe promise across arbitrary failures. An engineer should specify what is exactly-once: message delivery, state transition, database commit, or external physical effect. These are different properties.

### 2.4 Timeouts, retries and backoff

Use a request deadline that propagates across service calls. A timeout hierarchy should be coherent: a downstream operation should not routinely outlive the caller's deadline. Retry only errors that are plausibly transient, and only when the operation is safe to retry. Exponential backoff with jitter reduces synchronized retry storms:

\[
d_n = \min(d_{\max}, d_0 2^n) \cdot U(0.5, 1.5)
\]

where \(d_0\) is the initial delay and \(U\) is a random multiplier. Enforce an overall deadline and retry budget. Retrying a permanently invalid request is not resilience; it is load amplification.

### Worked example: idempotent command

A client sends `command_id = 8f...` to set the pump state to ON. The server stores the command ID and result in the same durable transaction as the state change. A duplicate request with the same ID returns the original result. A different command ID is a distinct operation. The deduplication retention period must be at least as long as the maximum retry/replay horizon.

### Laboratory

Implement a Go HTTP endpoint that accepts `command_id` and a target state. Persist command IDs and results in PostgreSQL or, for the first exercise, in a mutex-protected in-memory map. Add an artificial crash after the state change but before the response. Demonstrate the duplicate-request case. Then explain why the in-memory map is not safe across restarts or multiple replicas.

### Practice

A client times out after sending an update. Give three possible server states and the correct client behavior for each. Explain why generating a new idempotency key on every retry defeats deduplication.

---

## Week 3 — Time, event ordering and logical clocks

### 3.1 Physical clocks are imperfect

A computer clock is an estimate of physical time. Clocks can drift, jump due to correction, or differ between machines. Network time synchronization reduces error but does not create a perfect global clock. Therefore, timestamps alone cannot reliably determine the causal order of distributed events.

### 3.2 Happens-before relation

Lamport's happens-before relation, written \(a \rightarrow b\), is defined by:

1. If events \(a\) and \(b\) occur in the same process and \(a\) occurs first, then \(a \rightarrow b\).
2. If \(a\) is sending a message and \(b\) is receiving that message, then \(a \rightarrow b\).
3. The relation is transitive.

If neither \(a \rightarrow b\) nor \(b \rightarrow a\), the events are concurrent in the causal model. Concurrent does not mean they happened at precisely the same physical instant. It means the model contains no causal path between them.

### 3.3 Lamport clocks

Each process maintains an integer clock. Before each local event, increment it. When sending a message, attach the clock. On receiving a message with timestamp \(t\), set the local clock to \(\max(local,t)+1\). If \(a \rightarrow b\), then \(L(a) < L(b)\). The converse does not necessarily hold: a smaller Lamport timestamp does not prove causality.

### 3.4 Vector clocks

Vector clocks retain a component per process. A process increments its own component for local events and merges received vectors by component-wise maximum before incrementing its own component. For vectors \(x\) and \(y\), \(x < y\) when every component of \(x\) is no greater than the corresponding component of \(y\), and at least one is smaller. If neither vector is less than the other, the events are concurrent.

Vector clocks provide richer causal information but require metadata proportional to the number of tracked processes or groups. Production designs may use bounded or hierarchical alternatives.

### Worked example

Two controllers create events with vector clocks. Process A creates \(x=(1,0)\). Process B creates \(y=(0,1)\). Neither vector dominates the other, so the events are concurrent. A later event at A after receiving B's event may be \(z=(2,1)\), for which \(x<z\) and \(y<z\); both are causally before \(z\).

### Laboratory

Build a three-process event simulator. Compare physical timestamps, Lamport clocks and vector clocks. Construct one execution where physical timestamps order concurrent events, and show why that ordering should not be interpreted as causality.

---

## Week 4 — Replication and state-machine replication

### 4.1 Why replicate?

Replication stores or computes multiple copies of state. It can improve availability, throughput, geographic proximity and recovery from faults. It also creates the problem of coordinating copies. The system must decide which writes are accepted, how updates propagate, how conflicts are resolved and what reads are allowed to observe.

### 4.2 Primary-backup replication

A primary receives writes and propagates ordered updates to backups. This is conceptually simple, but requires a protocol for primary failure and promotion. If two nodes both believe they are primary, split brain can produce conflicting histories. A fencing mechanism or quorum-backed lease can prevent an old primary from continuing to mutate shared resources after its authority expires.

### 4.3 State-machine replication

A deterministic state machine has an initial state \(s_0\), a sequence of commands \(c_1,\dots,c_n\), and a deterministic transition function \(\delta\). Replicas that start from the same state and apply the same commands in the same order reach the same state:

\[
s_{i+1} = \delta(s_i,c_i)
\]

The consensus protocol orders commands; the application state machine applies them. Nondeterminism must be controlled. For example, a replicated command should not independently read a local wall clock at each replica and branch on the result.

### 4.4 Quorums

For a replica set of \(N\) nodes, read and write quorums may be chosen so that they intersect. A common sufficient condition is \(R+W>N\), where \(R\) and \(W\) are read and write quorum sizes. Intersection alone is not the whole correctness proof: version selection, concurrent writes, failure handling and replica recovery also matter.

For \(N=5\), choosing \(R=3\) and \(W=3\) guarantees intersection because \(3+3>5\). It does not automatically guarantee linearizability; that depends on protocol details such as write ordering and read repair.

### Laboratory

Implement a primary plus two replicas for a counter. First use fire-and-forget replication, then wait for one backup, then wait for a majority. Kill nodes at different points. Record which acknowledged writes survive each failure. State the consistency guarantee actually achieved.

---

## Week 5 — Consistency models

### 5.1 Why one word is not enough

"Consistent" may refer to data integrity, replica agreement, or a formal visibility guarantee. A system can preserve database constraints while offering eventual consistency across replicas. Always name the property being promised.

### 5.2 Linearizability

An operation appears to take effect atomically at a point between its invocation and response, and respects real-time order between non-overlapping operations. If a write completes before a later read begins, the later read must observe that write or a later one. Linearizability is valuable for locks, unique ownership and externally visible control state, but it can require coordination and may reduce availability during partitions.

### 5.3 Sequential consistency

There is one total order of operations that respects each process's program order, but it need not respect real-time order across processes. It is weaker than linearizability.

### 5.4 Causal consistency

If one operation causally depends on another, every observer that sees the dependent operation must also see the cause first. Concurrent operations may be observed in different orders. This is useful for systems where causal relationships matter more than a single global order.

### 5.5 Eventual consistency

If no new updates occur and communication/reconciliation continues, replicas eventually converge. Eventual consistency alone does not specify read-your-writes, monotonic reads, conflict resolution or convergence time. A system must define these details.

### Worked comparison

An operator changes a tank threshold from 80% to 90%. A later read by the same operator should usually have read-your-writes behavior. A telemetry dashboard may tolerate a short delay before all regions show the new value. A safety interlock should not depend on an eventually consistent cloud replica. Choose consistency per operation and risk, not per product label.

### Exercise

For account transfer, collaborative document editing, telemetry dashboards and a local emergency stop, choose a consistency model and explain the trade-off. There is not one universally correct answer; the justification is the assessed part.

---

## Week 6 — Failure detection, impossibility and availability

### 6.1 Failure detectors are suspicions

A timeout-based detector can suspect a process, but suspicion is not certainty. A short timeout detects failures quickly but produces false suspicions during congestion. A long timeout reduces false suspicions but delays recovery. Adaptive detectors can estimate expected delay, but cannot eliminate uncertainty in an asynchronous system.

### 6.2 FLP result and practical systems

The Fischer-Lynch-Paterson result shows that in a fully asynchronous message-passing system, no deterministic consensus protocol can guarantee termination in every execution if even one process may crash. The result does not say consensus is impossible in practice. Real systems use additional assumptions such as eventual synchrony, randomized choices or failure detectors. The key is to state which assumption supports progress.

### 6.3 CAP theorem

In the presence of a network partition, a distributed data store cannot guarantee both linearizable consistency and availability for every request to every non-failing node. CAP is not a menu where a system permanently chooses two out of three in all conditions. Partition tolerance is a fact of networked operation; the design decision is how the system behaves when a partition occurs.

### 6.4 Availability budgets

Availability over an interval is \(A = \frac{uptime}{total\ time}\). The unavailability budget is \((1-A)\times T\). At 99.9% availability over a 30-day month, the downtime budget is approximately 43.2 minutes. This arithmetic does not describe the severity of an outage: a 30-second outage at the wrong moment may be unacceptable.

### Laboratory

Simulate a three-node service with controllable message delays and partitions. Change election timeouts and measure false leader suspicions. Distinguish detection latency from correctness.

---

## Week 7 — Consensus: Raft and the core invariants

### 7.1 Consensus problem

Consensus allows a group of nodes to agree on a value or ordered log under a specified failure model. A protocol should satisfy safety (no two correct participants decide conflicting values) and liveness (a decision eventually occurs under stated progress assumptions).

### 7.2 Raft conceptual model

Raft organizes time into terms. A leader is elected for a term; it accepts client commands and replicates log entries. Followers acknowledge entries. A leader commits an entry when the protocol's quorum and current-term rules are satisfied. A new leader must preserve committed history.

The main safety ideas are:
- at most one leader is elected in a term;
- leaders do not overwrite committed entries;
- a candidate's log must be sufficiently up-to-date to win an election;
- followers accept log entries according to term and index rules.

A correct Raft implementation is more than a leader-election demonstration. It must handle crashes, partitions, stale terms, log conflicts, snapshots, persistence ordering and client retries.

### 7.3 Majority arithmetic

For \(N\) voting members, a majority quorum is \(\lfloor N/2 \rfloor + 1\). With five members, three acknowledgements form a majority and tolerate up to two unavailable members for quorum decisions. This does not mean the service continues through every combination of failures: network placement and leader reachability matter.

### Worked example

A five-node cluster has nodes A–E. A leader A commits an entry after A, B and C persist it. A becomes partitioned from B–E. B, C, D and E can elect a new leader only if the new leader's log is eligible under the protocol. A must not independently continue committing entries without a quorum. The quorum intersection plus log-up-to-date rules protect committed history.

### Laboratory

Complete a Raft implementation lab from MIT 6.5840 or an equivalent teaching implementation. Start with deterministic tests and then inject loss, duplication, reordering, partitions and crashes. Do not claim correctness from passing only a happy-path test.

---

## Week 8 — Logs, snapshots, recovery and durable state

A replicated log is an ordered history of state-machine commands. The log must be persisted in a crash-safe order. If a node acknowledges an entry before the required durable write completes, a power loss can erase an acknowledged operation. The protocol's durability claim must match the storage semantics used.

Logs grow indefinitely unless the system takes snapshots or compacts old entries. A snapshot represents the state after a committed log index. A recovering replica loads the snapshot and then applies later entries. Snapshot creation must be coordinated with the log index and configuration so the system does not skip or replay state incorrectly.

Crash recovery separates volatile state, durable state and externally visible acknowledgements. A write-ahead logging discipline generally records the information needed for recovery before overwriting the corresponding data pages. The exact WAL protocol depends on the storage engine; the general rule is that acknowledged durability must have a well-defined persistence boundary.

**Worked example:** If a replica has committed through index 1000, it may snapshot state at 1000 and discard earlier entries only when the snapshot is durable and the replication protocol can safely install it on lagging followers. A follower at index 700 needs either the retained log range or a snapshot plus entries after 1000; it cannot infer the missing state.

**Lab:** Persist a key-value log to disk, restart after a forced process kill, replay committed operations and compare the reconstructed state to a clean execution. Include a crash between writing a record and updating an index. Document the recovery invariant.

---

## Week 9 — Distributed transactions and sagas

A transaction across independent services is difficult because each service owns its own state and may fail independently. Two-phase commit (2PC) separates prepare from commit. A coordinator asks participants to prepare; prepared participants promise they can commit or roll back. The coordinator then announces the decision. Classic 2PC can block if the coordinator fails at a critical time and participants cannot discover the durable decision.

A saga decomposes a long-running business transaction into local transactions with compensating actions. If step three fails after steps one and two committed, the system invokes compensations. A compensation is not necessarily a literal inverse: a refund is not the same as erasing the fact that a payment happened. Sagas trade atomicity for explicit workflow and recovery logic.

Use a transactional outbox when a service must update its database and publish an event. The service writes both the business change and an outbox record in one local transaction; a separate publisher sends the event and marks it delivered. Consumers should be idempotent because delivery may repeat.

**Worked example:** The command service records a requested valve setting and an outbox event. If the process crashes after the database commit but before publication, the outbox publisher recovers the event. If it publishes but crashes before marking it sent, it may publish again; the telemetry consumer deduplicates using event ID.

**Lab:** Build a two-service workflow: command acceptance and audit logging. Demonstrate the failure window without an outbox, then implement an outbox and duplicate-safe consumer.

---

## Week 10 — Sharding, partitioning and rebalancing

Partitioning divides a dataset into subsets. Horizontal sharding distributes rows, commonly by key range or hash. Range partitioning preserves key locality and supports range scans, but may create hotspots for monotonic keys. Hash partitioning distributes keys more evenly, but makes range queries expensive and complicates placement changes.

A partition key should distribute load while aligning with access patterns. A poor key can overload one shard. A shard is not simply a physical database: it also has ownership, routing, replication, failover and rebalancing rules.

Rebalancing transfers data when the number or capacity of nodes changes. Naive rehashing may move most keys. Consistent hashing reduces movement in many designs, but does not eliminate operational coordination, hotspot risk or replica placement concerns.

**Worked example:** A telemetry store receives 10,000 events/s. Sharding by `sensor_id` gives even load only if sensor activity is reasonably uniform. Sharding by event date creates a hot current partition. A composite partitioning scheme may use time buckets plus a hash of sensor ID.

**Lab:** Implement a consistent-hash ring or a deterministic hash partitioner. Measure key movement when adding a node. Then generate skewed sensor traffic and report the hottest partition.

---

## Week 11 — Distributed storage and data-processing architectures

Distributed file systems, object stores, key-value stores and stream processors solve different problems. A file system exposes files and directories; an object store exposes object keys and metadata; a key-value store optimizes keyed reads/writes; a log-based stream platform retains ordered events for consumers; batch frameworks process bounded datasets.

MapReduce introduced a programming model with map and reduce stages, partitioning and shuffle. Stream processors handle unbounded event sequences, where event time and processing time differ. Late-arriving events, duplicate events, watermarks, windowing and replay are first-class concerns.

A design must specify delivery guarantees, ordering scope, retention, backpressure, schema evolution and consumer recovery. "Exactly-once processing" must identify the boundary and mechanism. It often depends on transactional checkpoints or coordinated commits, not on the absence of duplicate messages.

**Lab:** Build an event consumer that aggregates telemetry by five-minute event-time windows. Inject delayed and duplicated events. Compare processing-time windows with event-time windows and describe how late data is handled.

---

## Week 12 — Concurrency control and coordination services

Distributed locks are not ordinary mutexes. A process may pause beyond a lease deadline, lose connectivity and later resume while another process has acquired the lock. A lease alone may not stop the stale process from modifying an external resource. Fencing tokens solve this by issuing monotonically increasing epochs; the resource rejects operations with an older token.

Coordination services provide membership, leader election, configuration and small pieces of shared metadata. They should not be used as high-throughput general-purpose databases. Chubby and ZooKeeper illustrate the separation between a coordination plane and application data plane.

**Worked example:** Process A obtains fencing token 41 and pauses. Its lease expires. Process B obtains token 42 and writes configuration. A resumes and submits a write with token 41. The storage service rejects it because 41 is lower than the last accepted token 42.

**Lab:** Implement a lease simulation with stale clients and a storage API that enforces fencing tokens. Demonstrate the failure of an unfenced lock.

---

## Week 13 — Reliability engineering and operations

Distributed-system correctness includes production behavior. Measure latency percentiles, throughput, saturation, error rates, queue depth, replication lag, leader changes and recovery time. Logs provide event detail; metrics reveal aggregate trends; traces connect work across service boundaries. Use correlation and trace IDs, but avoid logging secrets or personal data.

A service-level indicator (SLI) is a measured property such as successful request fraction or latency. A service-level objective (SLO) is a target over a defined window. An error budget is the allowed amount of SLI failure implied by the SLO. SLOs should reflect user impact, not just the easiest metric to collect.

Failure injection should test realistic fault classes: process crash, network delay, packet loss, disk full, slow database, expired credentials, clock jump and dependency overload. Chaos experiments are controlled hypotheses with safety limits, not random destruction of production systems.

**Lab:** Instrument a service with request counts, latency histogram and dependency errors. Create an SLO for a read API and calculate its error budget. Inject a slow database and show how the symptoms propagate.

---

## Week 14 — Design review and integrated capstone

A distributed-system design review should answer:
- What are the nodes, processes, links and external dependencies?
- What failures are assumed and which are out of scope?
- What consistency guarantee does each operation require?
- How are retries made safe?
- What state is durable, and at what point is success acknowledged?
- How are leaders elected and stale leaders fenced?
- What happens during a partition, overload and recovery?
- Which metrics and tests demonstrate the claimed behavior?

### Final assessment

Submit a running service or deterministic simulator, architecture diagram, failure model, API contract, consistency table, idempotency design, test report, performance report and a design decision record. At least five fault-injection scenarios must be reproducible.

### End-of-course problem set

1. A request takes effect but its response is lost. What does the client know?  
   **Solution:** Only that it did not receive a response before its deadline. The operation may not have arrived, may be executing, may have committed, or may have committed and lost its response. Use a stable operation ID and a query/retry protocol that returns the recorded result.

2. A cluster has seven voters. How many votes form a majority, and how many voters may be unavailable while retaining a majority?  
   **Solution:** A majority is four. Three may be unavailable, assuming the remaining four can communicate and the protocol's placement/failure assumptions hold.

3. Explain why a Lamport timestamp order is not proof of causality.  
   **Solution:** Lamport clocks preserve the implication from causality to increasing timestamp, but independent concurrent events can receive different scalar timestamps. The scalar order imposes an arbitrary total order on events that have no causal relation.

4. A service claims linearizable reads while allowing reads from any stale replica during a partition. What is wrong?  
   **Solution:** A stale replica may return a value older than a completed write, violating real-time order. The design must coordinate reads, use a valid lease/quorum/read-index mechanism, or weaken the guarantee.

## Selected sources and further study

- MIT 6.5840 Distributed Systems (Spring 2026): https://pdos.csail.mit.edu/6.5840/ — lectures, papers, programming labs and exams.
- Harvard CS 2620 Distributed Systems (2026): https://read.seas.harvard.edu/cs2620/2026/ — consensus, Paxos, PBFT, problem sets and papers.
- CMU 15-440/640 Distributed Systems: https://www.cs.cmu.edu/~dga/15-440/F12/ — systems programming and networked services.
- Martin Kleppmann & Chris Riccomini, *Designing Data-Intensive Applications*, 2nd ed. (2026): https://martin.kleppmann.com/2026/03/24/designing-data-intensive-applications-2e.html
- Raft paper and extended version: https://raft.github.io/raft.pdf
- Go memory model: https://go.dev/ref/mem
- Go concurrency and context documentation: https://pkg.go.dev/context
- PostgreSQL concurrency control: https://www.postgresql.org/docs/current/mvcc.html

Use research papers to understand the algorithm and its limits. Use the official lab/course repositories to reproduce implementations. Do not cite a course's existence as evidence that your own implementation is correct.


---

## Expanded 14-week lecture notes and practical sequence


### Week 01 — System models, boundaries and performance

**Lecture notes.** A distributed system consists of autonomous processes that communicate through channels and share no perfectly reliable global clock or memory. Start by writing the model: process set, network assumptions, failure model, state ownership, and adversary. Distinguish crash-stop, crash-recovery, omission, timing and Byzantine failures; each permits different proofs. A design is only correct relative to its model. For performance, distinguish service time from end-to-end latency. Measure distributions, not only means: p50, p95 and p99 reveal queueing and contention that an average hides. Little’s Law, L = λW, connects average in-flight work L, throughput λ and average time W for a stable system; it is not a substitute for a queueing model under overload.


**Worked application.** A service completes 800 requests/s with 0.15 s mean response time. Its average in-flight request count is L = 800 × 0.15 = 120. If the arrival rate exceeds sustainable service capacity for long enough, queues grow; adding workers can worsen contention instead of restoring stability. The engineering response is to measure saturation, bound queues, shed or defer work, and define overload behavior.


**Practical / assessed work.** Instrument a local client/server pair. Generate a fixed request load and report throughput plus p50/p95/p99. Repeat with an injected 100 ms delay and explain the observed queueing effect. Preserve raw measurements and machine details.


**Checkpoint.** State the model assumptions, identify one failure mode or limitation, and explain what evidence would change your conclusion.


### Week 02 — RPC, delivery semantics, retries and idempotency

**Lecture notes.** An RPC is a protocol exchange, not a local function call. The caller can time out after the server has committed an effect but before the reply arrives. Therefore the caller cannot infer non-execution from a timeout. At-most-once, at-least-once and effectively-once behavior are properties of a complete protocol, not a magic transport setting. Retries require bounded deadlines, exponential backoff, jitter, retry budgets and clear classification of retryable failures. A command should carry a stable operation identifier; the server records the result and side effect atomically so duplicate delivery returns the prior result. Retention, persistence and identity scope are part of the guarantee.


**Worked application.** A payment command with ID `op-42` times out after the server writes the payment. A retry with the same ID must return the original result, not charge again. If the deduplication record is stored separately from the effect, a crash between the two writes creates either a duplicate effect or a lost result. The correct boundary is one transaction or an equivalent durable state-machine transition.


**Practical / assessed work.** Extend the idempotency lab with a client deadline and retry policy. Test lost reply, duplicate request, concurrent duplicate requests, process restart and deduplication-record expiry. State exactly which guarantees survive restart.


**Checkpoint.** State the model assumptions, identify one failure mode or limitation, and explain what evidence would change your conclusion.


### Week 03 — Concurrency, happens-before and logical time

**Lecture notes.** Within a process, synchronization gives a partial order over events; across processes, message send and receive provide causal edges. Lamport’s happens-before relation is the transitive closure of local program order and send-before-receive. If a → b, then a Lamport clock must be smaller than b; the converse is false. Vector clocks add one component per process and can distinguish causality from concurrency: V(a) < V(b) component-wise means a causally precedes b; incomparable vectors represent concurrent events. Physical clocks remain useful for deadlines and human time, but clock skew and uncertainty mean they cannot establish causality by themselves.


**Worked application.** For two processes P and Q, events with vectors (2,1) and (1,2) are concurrent because neither vector is component-wise less than the other. A merge receives a message vector and takes component-wise maxima before incrementing its own component. A consistent snapshot is a cut closed under causality: it cannot include a receive without the corresponding send.


**Practical / assessed work.** Complete the clock lab. Construct one execution with a causal chain and one with concurrent writes. Implement vector comparison and test equality, strict precedence and incomparability; then discuss how a replicated register could resolve concurrent updates.


**Checkpoint.** State the model assumptions, identify one failure mode or limitation, and explain what evidence would change your conclusion.


### Week 04 — Failure detection, timeouts, leases and coordination

**Lecture notes.** A timeout is evidence of delay or failure, not proof that a process has crashed. An asynchronous system cannot always distinguish a slow process from a failed one. Practical failure detectors trade completeness (eventually suspect crashed processes) against accuracy (avoid suspecting healthy slow processes). Heartbeats, adaptive timeouts and phi-accrual suspicion help operationally but do not create a perfect detector. A lease is a time-bounded right to act; safe leases depend on clock-rate bounds, drift, expiry margins and fencing tokens. A distributed lock without fencing can permit a paused former owner to resume and write stale data after its lease expires.


**Worked application.** Client A receives lease epoch 17, pauses, and the lease expires. Client B acquires epoch 18 and writes. If A later resumes, the storage layer must reject epoch 17. A monotonically increasing fencing token lets the protected resource reject stale owners; a lock service alone cannot enforce this if the resource ignores the token.


**Practical / assessed work.** Simulate a delayed heartbeat and a long-paused lock holder. Demonstrate why a timeout-only lock is unsafe, then add monotonically increasing fencing epochs and test that stale writes are rejected.


**Checkpoint.** State the model assumptions, identify one failure mode or limitation, and explain what evidence would change your conclusion.


### Week 05 — Consistency models and histories

**Lecture notes.** A consistency model specifies which histories an implementation may expose. Linearizability requires each operation to appear to take effect at one instant between invocation and response and respects real-time precedence. Sequential consistency preserves one global order consistent with each process’s program order but need not respect real time. Causal consistency preserves causally related operations while permitting concurrent operations to be ordered differently. Eventual consistency promises convergence under stated quiescence and communication assumptions; it does not promise a read-your-writes result at every replica. Session guarantees such as monotonic reads and read-your-writes can improve usability but are weaker than global linearizability.


**Worked application.** Suppose write(x=1) completes before read(x) begins. A linearizable read cannot return 0. If the write and read overlap, either value may be legal depending on the linearization point. A history should be checked as a whole: identifying one stale read does not prove that all histories violate a model.


**Practical / assessed work.** Given three histories supplied in the lab worksheet, classify them against linearizability, sequential and causal consistency. Build a small history checker for real-time precedence and per-client order; document what it does not check.


**Checkpoint.** State the model assumptions, identify one failure mode or limitation, and explain what evidence would change your conclusion.


### Week 06 — Replication, quorums and replica repair

**Lecture notes.** Replication improves availability and read capacity, but introduces ordering and reconciliation problems. Primary-backup replication orders writes through one leader; state-machine replication requires deterministic commands applied in the same committed order. Quorum systems use intersecting read and write sets. With N replicas, read quorum R and write quorum W, R + W > N guarantees intersection in a simple fixed-replica model, while W > N/2 ensures write quorums intersect. Intersection alone does not guarantee freshness unless version selection, concurrent writes, membership changes and repair are handled. Discuss hinted handoff, anti-entropy, tombstones and the risk of resurrecting deleted data.


**Worked application.** For N=5, R=3 and W=3, any read quorum intersects any write quorum in at least one replica. The newest version is not automatically known if replicas are stale or clocks are unreliable; attach logical versions or use a protocol with a stronger ordering guarantee. Quorum availability also falls when enough replicas are unreachable.


**Practical / assessed work.** Simulate five replicas with configurable R/W and crash partitions. Enumerate quorum intersections, then add version metadata and read repair. Test the case where a deleted key reappears because a tombstone expires too early.


**Checkpoint.** State the model assumptions, identify one failure mode or limitation, and explain what evidence would change your conclusion.


### Week 07 — Consensus and Raft safety

**Lecture notes.** Consensus lets non-Byzantine processes agree on one value despite crash failures under an appropriate timing model. Separate safety (nothing bad happens) from liveness (something good eventually happens). In Raft, terms, leader election, log matching, leader completeness and state-machine safety are distinct invariants. A leader commits an entry by replication to a majority, subject to the current-term rule; a follower’s local append is not a committed operation. Elections use randomized timeouts to reduce collisions, and a candidate’s log must be sufficiently up to date. Understand the proof obligations before tuning timers.


**Worked application.** With five voters, a majority is three. Two disjoint majorities cannot exist, which supports agreement across terms. However, counting acknowledgements is not enough: a leader must apply the log’s term and index rules. A stale candidate must not win merely because it has a reachable majority if the voting rule is wrong.


**Practical / assessed work.** Read the MIT Raft lab specification, then implement a deterministic Raft-state simulator: terms, votes, log indices, append consistency and commit index. Inject partitions and message reordering. Treat full production Raft as an advanced extension, not a one-page exercise.


**Checkpoint.** State the model assumptions, identify one failure mode or limitation, and explain what evidence would change your conclusion.


### Week 08 — Atomic commit, distributed transactions and sagas

**Lecture notes.** A distributed transaction coordinates effects across independent participants. Two-phase commit has a prepare phase and a decision phase: participants promise they can commit, then follow the coordinator’s decision. The protocol can block if the coordinator fails after participants prepare and before they learn the decision. Three-phase commit requires stronger timing/availability assumptions and is not a universal cure. Sagas replace one global atomic transaction with a sequence of local commits and compensating actions. Compensation is a business-level reversal, not time travel: an email, physical action or external payment may not be exactly undoable. Define idempotency, retry, timeout and compensation semantics per step.


**Worked application.** A reservation workflow creates a booking, charges a card and allocates a delivery slot. If slot allocation fails, the system may void/refund the charge and cancel the booking. The compensation can fail too; therefore the saga needs durable state, retryable compensations and an operator-visible stuck state.


**Practical / assessed work.** Model a three-step order saga. Create a failure table for every forward and compensation action, and test duplicate messages, process restart and a compensation that fails twice.


**Checkpoint.** State the model assumptions, identify one failure mode or limitation, and explain what evidence would change your conclusion.


### Week 09 — Durable logs, snapshots and recovery

**Lecture notes.** Durability requires a defined persistence boundary. Write-ahead logging requires the log record describing a change to reach stable storage before the affected data page is flushed. Acknowledging a transaction before the required commit record is durable breaks the stated durability contract. Checkpoints bound recovery work but do not eliminate logs needed for crash recovery or archival. Snapshots and application-level backups are different: a snapshot may be crash-consistent but not application-consistent. Recovery should be tested by killing a process at multiple points, restarting from persisted state and checking invariants.


**Worked application.** If an update’s data page reaches disk before its corresponding WAL record, a crash can leave a state that cannot be reconstructed. The WAL rule prevents this order. A commit response is safe only after the commit record is durable under the storage system’s assumptions; filesystem and device write-cache behavior matter.


**Practical / assessed work.** Extend the key-value lab with an append-only log, replay and periodic snapshots. Kill the process before append, after append, after commit marker and after response; list the expected recovered state for each point.


**Checkpoint.** State the model assumptions, identify one failure mode or limitation, and explain what evidence would change your conclusion.


### Week 10 — Partitioning, consistent hashing and rebalancing

**Lecture notes.** Partitioning assigns keys or ranges to shards. Range partitioning supports ordered scans but can produce hot ranges. Hash partitioning spreads uniform keys but complicates range queries. Consistent hashing reduces key movement as membership changes; virtual nodes improve balance but increase placement metadata. Rebalancing is a protocol: define data-copy, dual-write/read, cutover, rollback and ownership epochs. A partition key that is convenient for developers can be poor for workload distribution or tenant isolation.


**Worked application.** With 100 equally spaced keys and 4 equal shards, a naive modulo hash can remap most keys when the shard count changes from 4 to 5. A ring with virtual nodes reduces movement to approximately the fraction of the ring owned by the joining node, assuming a balanced placement.


**Practical / assessed work.** Implement ring ownership with virtual nodes and measure key movement when one shard joins. Add an explicit hot-key test and discuss replication or request coalescing as separate mitigations.


**Checkpoint.** State the model assumptions, identify one failure mode or limitation, and explain what evidence would change your conclusion.


### Week 11 — Distributed data processing and stream semantics

**Lecture notes.** MapReduce separates a map stage that emits intermediate key/value pairs from a reduce stage that aggregates values by key. The framework can retry tasks, so user functions should be deterministic or side effects should be externalized safely. Streaming systems must reason about event time versus processing time, late data, windows, watermarks, replay and state retention. At-least-once delivery can duplicate aggregates unless updates are idempotent or deduplicated. Exactly-once claims must specify the source, state store, sink and transaction boundary.


**Worked application.** A five-minute event-time window may receive an event ten minutes late. The watermark policy decides whether to revise a previous result, send it to a late-data stream or drop it. A watermark is an estimate of event-time completeness, not a guarantee that no earlier event can arrive.


**Practical / assessed work.** Implement a word-count MapReduce simulator with retried map tasks. Add a streaming window aggregator with out-of-order events and duplicate delivery; compare an idempotent sink with an append-only sink.


**Checkpoint.** State the model assumptions, identify one failure mode or limitation, and explain what evidence would change your conclusion.


### Week 12 — Byzantine failures and distributed trust

**Lecture notes.** Crash-fault-tolerant consensus assumes failed nodes stop or omit messages; Byzantine systems allow arbitrary behavior, including equivocation. A classical partially synchronous Byzantine agreement model requires at least 3f+1 replicas to tolerate f Byzantine nodes and uses 2f+1-sized quorums under its protocol assumptions. Authentication prevents an outsider from impersonating a node but does not make a compromised node truthful. Safety also depends on key management, membership, message replay protection and a clearly stated synchrony assumption. Do not apply crash-fault quorum intuition to adversarial settings without re-deriving the protocol.


**Worked application.** For f=1, the classical bound is n≥4 replicas. Three replicas are insufficient for the usual Byzantine fault-tolerance guarantee because the protocol cannot distinguish some adversarial executions. This is a model-specific bound, not a universal minimum for every consensus construction.


**Practical / assessed work.** Construct an equivocation trace in which one faulty node sends two different values to different peers. Show how signed messages and quorum certificates help detect or limit it, and state what a compromised signing key defeats.


**Checkpoint.** State the model assumptions, identify one failure mode or limitation, and explain what evidence would change your conclusion.


### Week 13 — Operations, observability and reliability

**Lecture notes.** Operational correctness includes overload, recovery, upgrades and incident response. Define service-level indicators such as successful request ratio and latency percentiles, then define objectives over a time window. An error budget is the allowed unreliability implied by the SLO; it should drive risk decisions, not serve as a vanity metric. Logs, metrics and traces answer different questions. Measure saturation and queue depth, correlate traces across process boundaries, and ensure request IDs do not leak secrets. Fault injection is useful only when hypotheses, blast radius, stop conditions and rollback are explicit.


**Worked application.** A 99.9% availability SLO over a 30-day window allows approximately 0.001 × 30 × 24 × 60 = 43.2 minutes of unavailability under a simple time-based definition. A request-based SLO produces a different budget. Always define numerator, denominator, exclusions and measurement source.


**Practical / assessed work.** Run a controlled fault campaign: delay, dropped response, process crash and dependency outage. For each, capture traces, recovery time, error-budget impact and the exact assertion that determines experiment success.


**Checkpoint.** State the model assumptions, identify one failure mode or limitation, and explain what evidence would change your conclusion.


### Week 14 — Research critique and integrated distributed-system design

**Lecture notes.** A research paper is an argument supported by a model, design, experiments and limitations. Extract the problem statement, assumptions, mechanism, invariant, evaluation workload, baseline and threat to validity. Reproduce one key graph or experiment where possible. The final system design must select consistency, replication, sharding, recovery, security and operational guarantees deliberately. A design that claims high availability, strong consistency, no data loss and arbitrary partitions without qualification is internally inconsistent. Communicate rejected alternatives and the operational cost of each guarantee.


**Worked application.** For the water-tank telemetry service, telemetry samples may be eventually consistent while actuator commands require stronger ordering and idempotency. Separate data paths by safety consequence; do not make a convenience cache the authority for an actuator decision.


**Practical / assessed work.** Submit a design report, architecture diagram, failure matrix, consistency table, benchmark results, executable tests, paper critique and a 10-minute code-ownership defense.


**Checkpoint.** State the model assumptions, identify one failure mode or limitation, and explain what evidence would change your conclusion.


## Assessment design

| Component | Weight | Evidence expected |
|---|---:|---|
| Weekly problem sets and derivations | 20% | Correct reasoning, assumptions, units and worked calculations |
| Practical labs and reproducibility | 25% | Executable/model artefacts, tests, environment and results |
| Midterm assessment | 15% | Core concepts, derivations and design trade-offs |
| Individual cumulative project | 25% | Correct implementation/model, traceability and technical report |
| Final examination and oral defense | 15% | Transfer to unseen cases and explanation of submitted work |


## Minimum submission standard

Every practical report must include: objective; theory; assumptions; environment/tool versions; procedure; expected result; actual result; raw evidence; analysis; limitations; references. A screenshot alone is not proof of a model, test, or database property. Never label an external-tool lab as passed unless it was run in the named tool.


## Edition 3 advanced implementation extension — Raft protocol simulator

The earlier reader explains consensus, log matching and fault tolerance conceptually. Edition 3 adds a deterministic Go simulator in `labs/01-distributed/raftsim/`. It implements term/vote/log state, RequestVote and AppendEntries messages, conflict hints, quorum commit advancement, message loss/reordering, pairwise partitions, crash/restart and a state invariant checker. The implementation is small enough to inspect, but still forces the student to reason about the protocol state machine rather than simply call a consensus library.

**Important distinction:** the simulator's persistence map is not durable disk storage, and its network is a deterministic in-process queue rather than real RPC. It does not implement snapshots, dynamic cluster membership or Byzantine fault tolerance. A passing test suite demonstrates the selected schedules only. It is not a proof of Raft or production readiness.

Run `go test -race -count=1 ./...` and `go vet ./...` from the lab directory. Then complete all six exercises in its README, including the five-replica quorum experiment, dropped message retry, long uncommitted suffix repair, and a counterexample for the current-term commit rule. Submit the raw test output, a protocol trace, a safety argument, and a short code-ownership explanation.

For the full implementation benchmark, progress to the official [MIT 6.5840 Raft lab](https://pdos.csail.mit.edu/6.824/labs/lab-raft1.html) followed by the [replicated key/value service lab](https://pdos.csail.mit.edu/6.824/labs/lab-kvraft1.html). Those assignments add a real programming interface and a substantially larger test surface.


## Edition 3 lab annex — deterministic Raft simulator

Run the original simulator in `labs/01-distributed/raftsim/` with `go test -race -count=1 ./...` and `go vet ./...`. It models terms, votes, stale-log rejection, AppendEntries consistency, conflict repair, current-term majority commit and selected deterministic fault schedules. The nine tests pass in the current build. The simulator's persistence is an in-memory teaching abstraction: it does not implement sockets, filesystem durability, snapshots, joint-consensus membership changes or Byzantine behavior. The official advanced implementation route is the [MIT 6.5840 Spring 2026 Raft lab](https://pdos.csail.mit.edu/6.824/labs/lab-raft1.html), followed by its [fault-tolerant KV lab](https://pdos.csail.mit.edu/6.824/labs/lab-kvraft1.html) and [sharded KV lab](https://pdos.csail.mit.edu/6.824/labs/lab-shard1.html).

# Model-Based Systems Engineering (MBSE) — Expanded Course Reader (2026 Edition)

> **Level:** Advanced undergraduate / early graduate; introductory systems engineering, basic software/design modeling and engineering communication prerequisites.  
> **Duration:** 14 teaching weeks, 8–12 hours/week  
> **Status:** Self-study reader benchmarked against official 2026 university syllabi and primary documentation. It is not an accredited course or professional certification.

## Course outcomes

1. Define system boundaries, stakeholder needs, operational concepts and lifecycle context.

2. Transform needs into verifiable requirements and manage bidirectional traceability.

3. Create structural, behavioral, interface and parametric models using SysML v2 concepts and tools.

4. Use models to compare architectures, expose inconsistencies and assess change impact.

5. Explain model governance, tool limits, versioning and evidence needed for a credible digital thread.


## How to work through the course

For each week, read the concept notes, reproduce the derivation or model, complete the practical task, answer the challenge without looking at references, and record assumptions and evidence. A passing submission must include the exact environment, expected criterion, observed result and limitations. Use the weekly practical tasks as assessed work, not optional reading.


## Foundation reader retained from the first edition

The original first-edition chapter is preserved below for continuity. The expanded notes that follow add the missing depth, quantitative reasoning, labs and assessment structure identified in the academic audit.


---


# Course 2 — Model-Based Systems Engineering (MBSE)
**Level:** Upper-undergraduate / early graduate  
**Duration:** 14 teaching weeks  
**Expected workload:** 8–10 hours per week  
**Modeling baseline:** SysML v2 concepts, with explicit comparisons to SysML v1 where useful  
**Prerequisites:** Basic software/system architecture, requirements concepts, elementary algebra, and the ability to read block diagrams.

## Course description

Model-Based Systems Engineering (MBSE) is the disciplined use of structured, connected models to support systems engineering activities across a system's lifecycle. A model is more than a drawing. It is a representation of elements, relationships, properties, constraints, behavior, requirements and evidence, organized so engineers can ask questions and assess consequences.

Document-centric engineering commonly spreads requirements, architecture, interfaces, hazards, analysis and test evidence across separate files. These artifacts may contradict one another after repeated changes. MBSE seeks to make relationships explicit and queryable. It does not remove engineering judgment, guarantee correctness, or make a poor process effective merely because a modeling tool is installed.

This course teaches the thinking behind modeling, then the modeling work products used to describe a system. It uses a remote water-tank controller as a continuous example and includes a model-based capstone. The course is tool-neutral at the conceptual level. A SysML v2-capable environment such as Eclipse SysON may be used for practical work; the exact supported language subset depends on tool maturity and release.

## Learning outcomes

Students completing the course should be able to:
1. Define a system boundary, stakeholders, operational context and lifecycle concerns.
2. Translate stakeholder needs into validated, measurable and traceable requirements.
3. Decompose a system into functions, logical elements, physical elements and interfaces.
4. Represent structure, behavior, constraints and requirements using an appropriate modeling language.
5. Explain the difference between a model, a view, a diagram, a simulation and a digital twin.
6. Maintain traceability from needs through requirements, architecture, analyses and V&V.
7. Assess model quality, completeness, consistency and configuration.
8. Use models to support trade studies, interface reviews and change-impact analysis.
9. Build and review a coherent system model rather than a disconnected diagram collection.

---

## Week 1 — Systems thinking and the system boundary

### 1.1 System, environment and purpose

A system is a set of interacting elements organized to achieve a purpose in an environment. The definition is intentionally broad: elements can include hardware, software, people, facilities, data, procedures and external services. A boundary determines what is treated as part of the system and what is modeled as an external actor or dependency.

Boundary selection is a modeling decision, not a discovery of an objectively obvious line. If a cloud platform is external to a local controller project, its interface and assumptions still matter. Excluding an element from the design model does not remove the risk created by depending on it.

A good system definition identifies purpose, scope, environment, stakeholders, interfaces, operating modes, constraints and assumptions. The system context diagram shows external actors and exchanges. It should not be confused with a detailed component architecture.

### 1.2 Emergent properties

Some important properties belong to interactions rather than individual components. Safety, resilience, usability, performance and security are often emergent. A sensor may be accurate, a controller may be correct and a valve may work mechanically, yet the integrated system can still overfill a tank because the sensor is mounted incorrectly or the command path is delayed.

Systems thinking therefore asks how behavior emerges from relationships, feedback, delays, incentives and operating context. Local optimization may harm global performance. For example, maximizing telemetry frequency can overload a constrained network and delay the control-related messages that matter more.

### Worked example

Purpose: maintain water availability while preventing unsafe filling and allowing local operation during a network outage.

System boundary for the capstone includes the local controller, sensor interface, pump/valve interface, local panel, remote service, command API, event store and operator interface. The water supply, electrical supply, physical tank and Internet are external entities, but they remain explicit context dependencies.

### Laboratory

Create a context diagram. Label every exchanged item as command, measurement, status, power, human input or environmental influence. Identify at least five assumptions that would need stakeholder validation.

---

## Week 2 — Lifecycle, stakeholders and operational concepts

Systems engineering is lifecycle-oriented. A solution is conceived, developed, integrated, verified, validated, operated, maintained, upgraded and eventually retired. Decisions made early constrain later phases. A system that is easy to build but impossible to maintain is not a successful lifecycle solution.

Stakeholders are people or organizations that affect, are affected by, or have an interest in the system. Stakeholder analysis should identify their concerns, authority, success measures and operational context. A stakeholder need is not yet a technical requirement. It is usually expressed in outcome-oriented language, such as "operators must know when the tank is approaching its safe operating limit."

A Concept of Operations (ConOps) describes how the system is expected to be used in context. It should describe users, missions/tasks, operating modes, normal workflows, degraded modes, exceptions, training, maintenance and external dependencies. A good ConOps exposes requirements that would be missed by designing only for a normal day.

### Worked example: operating modes

```text
NORMAL_LOCAL
  - sensor measurements available
  - controller runs autonomous local rules
  - remote telemetry enabled when link is available

DEGRADED_NETWORK
  - local control continues
  - cloud commands are rejected or queued under policy
  - telemetry buffers locally

SENSOR_FAULT
  - controller enters defined safe state
  - alarm is raised locally
  - remote state is marked uncertain

MAINTENANCE
  - authorized technician controls permitted functions
  - safety interlocks remain active
```

The mode names are not themselves requirements. Each mode needs entry conditions, allowed actions, exit conditions and failure handling.

### Laboratory

Write one ConOps scenario for a normal fill cycle and another for a sensor fault plus network outage. Have a second reader role-play an operator and identify missing information.

---

## Week 3 — Requirements engineering for model-based work

### 3.1 Need, requirement and design

A stakeholder need explains a desired outcome. A requirement states a necessary, verifiable condition that the system or element must satisfy. A design decision describes how the solution will satisfy it. Confusing these creates premature design lock-in.

A good requirement is necessary, singular, unambiguous, feasible, consistent, traceable and verifiable. Use a subject, a required action or property, and a measurable condition. Avoid vague words such as fast, easy, robust, sufficient or user-friendly unless they are defined by measurable criteria.

Weak: "The system shall quickly detect overflow."  
Stronger: "When the level input indicates a value at or above the configured high-high threshold, the local controller shall command the inlet valve to its defined closed state within 250 ms."

The stronger statement still requires review: sensor sampling period, measurement uncertainty, valve response time and failure behavior must be considered. A number without a justified rationale is false precision.

### 3.2 Requirement attributes

Store more than the sentence. Useful attributes include identifier, text, rationale, source, owner, verification method, acceptance criterion, priority, status, version, assumptions, allocation and trace links. Bidirectional traceability allows engineers to ask both "what justifies this requirement?" and "what does this requirement affect?"

### Worked example

| ID | Requirement | Verification | Rationale |
|---|---|---|---|
| SYS-001 | The local controller shall continue autonomous level control during loss of the remote network connection. | Test | Cloud dependency must not remove local control. |
| SYS-002 | The controller shall close the inlet valve within 250 ms after a valid high-high input is sampled. | Test | Limit additional inflow after threshold detection. |
| SYS-003 | The remote API shall reject commands from unauthenticated callers. | Test + analysis | Prevent unauthenticated remote actuation. |

### Laboratory

Create 15 requirements. Mark each as stakeholder, system, subsystem, interface, performance, constraint or quality requirement. Reject or rewrite every requirement with no objective verification method.

---

## Week 4 — Modeling foundations: semantics, views and abstraction

A model is a purposeful abstraction of a system. It omits detail that is irrelevant to a question and preserves detail needed to answer it. An architecture view presents a system from a particular viewpoint for particular stakeholders. A diagram is a rendering of selected model information; a set of disconnected diagrams is not necessarily a coherent model.

Model semantics matter. A line between two boxes could mean data flow, physical connection, dependency, ownership or merely visual grouping. If its meaning is not defined by the language or modeling convention, readers may infer different relationships.

A model should support questions such as:
- Which requirement is allocated to the controller?
- Which interface carries a remote command?
- Which behavior occurs when sensor data becomes stale?
- Which tests verify the high-high response?
- What is affected if the valve interface changes?

### Modeling quality properties

- **Correctness:** elements and relations represent the intended system.
- **Completeness:** required aspects are represented at the necessary level.
- **Consistency:** no contradictory values or relationships.
- **Traceability:** links exist between related engineering artifacts.
- **Usability:** stakeholders can understand and query the model.
- **Configuration integrity:** the model has a controlled version and change history.

### Laboratory

Take a context diagram and create a second view for the local control subsystem. Keep the model elements consistent across both views. Record what is intentionally omitted from each view.

---

## Week 5 — Structural architecture and decomposition

Architecture defines major elements, their responsibilities, relationships, interfaces and constraints. Decomposition moves from a whole-system view into subsystems and components. There is no single universally correct decomposition. Functional decomposition groups what the system does; physical decomposition groups the elements that realize it. These views are related but not interchangeable.

A functional model may contain:
- acquire level measurement;
- validate measurement;
- determine control state;
- command actuator;
- publish telemetry;
- authenticate remote operator;
- record command and audit event.

A physical architecture may allocate these functions to a sensor module, local controller, actuator driver, gateway, cloud command service, identity service and database. A function can be allocated across multiple physical elements, and a physical element can support multiple functions.

Interfaces should identify exchanged items, direction, units, protocols, timing, ownership, failure behavior and constraints. "REST API" is not a complete interface definition. It omits operation semantics, schemas, authentication, error handling and version compatibility.

### Worked example

```mermaid
flowchart LR
  Sensor[Level Sensor] -->|measurement + validity| PLC[Local Controller]
  PLC -->|actuator command| Actuator[Pump / Valve]
  PLC -->|telemetry| Gateway[Gateway]
  Gateway -->|HTTPS events| Cloud[Remote Service]
  Operator[Operator] -->|authenticated command| Cloud
  Cloud -->|approved command| Gateway
  Cloud --> DB[(Event / Config DB)]
```

The local controller is the authority for local interlocks. The cloud service is not permitted to bypass those constraints.

### Laboratory

Build a functional decomposition and physical block architecture. Every element must have a named responsibility and every interface must identify at least one exchanged item.

---

## Week 6 — Behavior modeling: activities, states and sequences

Structure says what elements exist. Behavior says what happens, under what conditions, and in what order. Activity models represent workflows and transformations. State machines represent state-dependent behavior. Sequence diagrams show interactions over time between participants.

A state machine is useful when the response depends on current state, event and guard conditions. A state transition can be written:

\[
(q, e, g) \rightarrow (q', a)
\]

where \(q\) is the current state, \(e\) the triggering event, \(g\) the guard condition, \(q'\) the next state and \(a\) the action.

For the controller, `FILLING` should not transition to `IDLE` merely because a remote service sends a stop request. The controller must validate local conditions and the command's authority. Safety-related transitions should be designed so that a communication error cannot accidentally disable local protections.

### Worked example: simplified control states

```mermaid
stateDiagram-v2
  [*] --> IDLE
  IDLE --> FILLING: level below low threshold AND sensor valid
  FILLING --> IDLE: target reached
  FILLING --> SAFE_STOP: high-high OR sensor invalid
  IDLE --> SAFE_STOP: sensor invalid
  SAFE_STOP --> MAINTENANCE: authorized inspection
  MAINTENANCE --> IDLE: checks complete and reset authorized
```

The diagram is a teaching abstraction. Real control behavior must define hysteresis, debounce, sensor diagnostics, actuator feedback, reset conditions and fault response.

### Laboratory

Create a state machine with at least six states and ten transitions. For each transition, specify trigger, guard, action and trace to a requirement. Test unreachable states and ambiguous guards.

---

## Week 7 — SysML v2 concepts and requirements integration

SysML is a general-purpose systems modeling language for specifying, analyzing, designing and verifying systems that may combine hardware, software, information, people, procedures and facilities. SysML v2 was formally adopted by OMG in 2025; SysML v1 remains in use during the transition. A project should choose a language version based on its toolchain, exchange requirements and team capability.

SysML v2 emphasizes textual and graphical notations with a more explicit semantic foundation and standardized API/services. The important learning goal is not memorizing every keyword. It is understanding how model elements and relationships represent requirements, parts, actions, attributes, constraints, interfaces and verification-related work products.

A requirement element should be connected to its source, decomposition, allocation and verification. A diagram that displays requirement text without model relationships provides less value than a model that can answer traceability questions.

### Laboratory

Use a SysML v2-capable tool or a structured model repository. Create package organization, system definition, requirements, part definitions and relationships. Export a table showing each requirement and the model element responsible for satisfying it.

### Model fragment (conceptual, tool-neutral)

```text
Requirement SYS-001
  Text: Local control shall continue during remote network loss.
  Derived from: NEED-003
  Allocated to: LocalController
  Verified by: TEST-001, TEST-004

Part LocalController
  performs: ValidateMeasurement
  performs: DetermineControlState
  performs: CommandActuator
  connected to: LevelSensor
  connected to: ValveDriver
```

This is a readable model fragment, not a claim that the syntax is directly executable in a specific SysML tool.

---

## Week 8 — Interfaces, contracts and integration architecture

An interface is a boundary across which components exchange information, energy, material or control. The interface definition should include the contract: allowed operations, input/output schemas, units, timing, preconditions, postconditions, error states, security and versioning.

For software services, define API operations and event schemas. For physical interfaces, define electrical/mechanical characteristics and operating limits. For human-machine interfaces, define user roles, feedback, failure indications and prohibited actions. Interface mismatches are a major source of integration failure because each component may satisfy its own local specification while disagreeing with the neighboring component.

A contract should identify what the provider guarantees and what the consumer must ensure. Avoid ambiguous ownership of a field or state. For telemetry, define whether timestamps are event time or ingestion time, which component assigns sequence numbers, how invalid readings are represented and how duplicate events are handled.

### Laboratory

Create interface-control tables for sensor-to-controller, controller-to-valve, gateway-to-cloud and operator-to-command API. Include at least one failure case per interface. Review two interfaces as a team and record unresolved assumptions.

---

## Week 9 — Parametrics, constraints and performance reasoning

A parametric model expresses relationships among quantities. It can support sizing, sensitivity analysis, performance budgets and trade studies. A model is only as trustworthy as its assumptions, input data and validation against reality.

For a simple tank, volume may be approximated by \(V = A h\) for a vertical cylindrical tank with constant cross-sectional area \(A\) and level \(h\). If inflow is \(Q_{in}\) and outflow is \(Q_{out}\), then:

\[
\frac{dV}{dt} = Q_{in} - Q_{out}
\]

If area is constant, \(A\frac{dh}{dt}=Q_{in}-Q_{out}\). This simplified relation can estimate how quickly the level changes. It is not a substitute for a physical model when pipe losses, nonlinear geometry, compressibility or pump dynamics matter.

### Worked example

For \(A=2\,m^2\), net inflow \(Q_{in}-Q_{out}=0.01\,m^3/s\). Then \(dh/dt=0.01/2=0.005\,m/s\), or 5 mm/s. If the sample-to-actuation path takes 0.4 s, the level may rise approximately 2 mm during that delay, under the constant-flow approximation. The model tells us which parameter to measure; it does not by itself establish a safe margin.

### Laboratory

Construct a spreadsheet or model for tank level dynamics. Vary sensor delay, actuator delay, inflow and tank area. Plot sensitivity and explain which assumptions dominate the predicted level.

---

## Week 10 — Trade studies and architecture decisions

Architecture is a set of decisions under constraints, not a picture of boxes. A trade study compares alternatives against explicit criteria. First distinguish hard constraints from preferences. Then define criteria, weights (if using a weighted method), scoring scales, evidence and uncertainty.

A weighted sum can be useful:

\[
S_j = \sum_i w_i r_{ij}
\]

where \(w_i\) is the weight for criterion \(i\) and \(r_{ij}\) is the score for alternative \(j\). The resulting score is not an objective truth. The choice of criteria, weights and scores encodes judgment. Sensitivity analysis checks whether the preferred option changes when assumptions vary.

### Worked example

Compare local-only, cloud-centric and hybrid control. Criteria could include local safety autonomy, remote observability, network dependence, maintenance complexity, cost and cyber exposure. A cloud-centric design may score well for remote analytics but fail the hard constraint that local control must operate during network loss. A weighted sum must not override a non-negotiable constraint.

### Laboratory

Produce an architecture decision record with at least three alternatives, decision criteria, constraints, evidence, uncertainty, sensitivity test and selected option.

---

## Week 11 — Model verification, validation and quality assurance

A model itself needs assurance. Verification asks whether the model is syntactically and structurally well-formed and internally consistent. Validation asks whether it is an adequate representation of the real system for the intended use. A syntactically valid SysML model may still represent the wrong operating concept.

Model checks include duplicate identifiers, dangling relations, missing allocations, incomplete interface definitions, orphan requirements, conflicting property values and invalid state transitions. Reviews should inspect both the diagram and the underlying semantic model. Views can hide missing relationships if the reviewer treats the drawing as the whole model.

### Laboratory

Create automated checks or queries that report:
- requirements with no source;
- requirements with no allocated design element;
- requirements with no verification method;
- interface ports with no connected partner;
- state transitions with no defined guard/action;
- components with no assigned function.

Report false positives and limitations. A query that returns zero findings is not proof the model is correct.

---

## Week 12 — Model governance, configuration and change impact

A model is a lifecycle asset. It needs ownership, baselines, access control, naming rules, version history, review status and change management. Configuration management prevents an engineer from validating one model version and implementing a different one without detecting the difference.

Change-impact analysis follows model relations. If the valve response time changes, affected requirements may include shutdown latency, overflow margin, timing budget, safety analysis and verification tests. The model should help find these impacts, but a human engineer must assess whether the relation set is complete.

A model repository should distinguish approved baseline, working branch, proposed change, released version and archived version. Record why changes occurred and which evidence must be repeated after a change.

### Laboratory

Change the valve interface response from 250 ms to 400 ms. Produce an impact report listing affected requirements, calculations, hazards, design elements and test cases. Mark direct impacts separately from possible secondary impacts.

---

## Week 13 — MBSE across disciplines and digital engineering

MBSE provides a common structure for linking systems engineering to software, mechanical, electrical, safety, security, reliability, manufacturing and operations. Interoperability is not guaranteed simply because two tools support SysML. Data semantics, profiles, identifiers, units, versioning and transformations must be controlled.

A digital thread links lifecycle artifacts and their provenance. A digital twin is a model connected to a particular physical asset or operational data stream and used for defined purposes such as monitoring, prediction or control support. A static design model is not automatically a digital twin. A simulation is an execution or analysis of a model under defined assumptions; it does not automatically reproduce reality.

### Laboratory

Choose one model element and trace its identity from requirement to architecture, simulation, implementation and test evidence. Record where data is copied manually, where links are machine-maintained and where semantic transformations could lose information.

---

## Week 14 — Integrated model review and capstone

A model review should be organized around engineering questions, not diagram count. Review system purpose, boundary, stakeholder needs, requirements quality, functional decomposition, architecture, interfaces, behavior, constraints, safety/security connections, verification links, assumptions and model configuration.

### Final submission

Submit:
1. System context and stakeholder map.
2. ConOps with normal and degraded scenarios.
3. A uniquely identified requirement set with sources and verification methods.
4. Structural, functional and behavioral models.
5. Interface definitions.
6. Quantitative model or trade study with assumptions and sensitivity.
7. Traceability and model-quality reports.
8. Change-impact report.
9. Review log and model limitations.

### End-of-course problems

1. Why is a context diagram not a complete architecture?  
   **Solution:** It shows the system boundary and external interactions, but typically omits internal components, responsibilities, interfaces and behavior.

2. A requirement says "The controller shall react quickly." What makes it deficient?  
   **Solution:** "Quickly" is undefined, there is no operating condition or measurable response, and no acceptance criterion can be derived. Rewrite it with an event, condition, measurable time and defined system boundary.

3. A model is syntactically valid. Is it validated?  
   **Solution:** No. Syntax checks well-formedness. Validation requires evidence that the modeled system and behavior adequately represent the real system for the intended engineering purpose.

## Selected sources and further study

- NASA-HDBK-1009A, *NASA Systems Modeling Handbook for Systems Engineering* (active, 12 March 2025): https://standards.nasa.gov/standard/NASA/NASA-HDBK-1009
- OMG SysML official specifications: https://www.omg.org/sysml/
- OMG SysML v2 specification history and documents: https://www.omg.org/spec/SysML/About-SysML/
- NASA Systems Engineering Handbook: https://www.nasa.gov/reference/systems-engineering-handbook/
- SEBoK, Systems Engineering Body of Knowledge: https://sebokwiki.org/
- Eclipse SysON documentation and tutorials: https://doc.mbse-syson.org/
- Capella MBSE tool and training: https://mbse-capella.org/
- NASA Systems Engineering processes and requirements: https://nodis3.gsfc.nasa.gov/

The NASA MBSE handbook is a concrete worked reference for connecting models to stakeholder expectations, ConOps, technical requirements, verification and validation work products. SysML is a language; a sound method, governance process and engineering review are still required.


---

## Expanded 14-week lecture notes and practical sequence


### Week 01 — Systems thinking, purpose and boundaries

**Lecture notes.** A system is an arrangement of elements whose interactions produce outcomes that matter to stakeholders. Define purpose before decomposition. A boundary identifies what the team controls, what it observes and what it treats as external; boundary choices change risk, responsibility and verification scope. Emergent properties such as safety, availability and usability arise from interactions and may not be properties of any single component. Use context diagrams and stakeholder maps before drawing architecture. Distinguish system-of-interest, enabling systems, external actors and environment. Every model should name its viewpoint, intended decision and assumptions.


**Worked application.** For a remote tank monitor, the system-of-interest may include sensors, gateway, cloud service, operator UI and alarm path, but exclude the municipal power grid. Power loss is still an external condition that must be represented in the environment and hazard analysis. Boundary exclusion is not risk exclusion.


**Practical / assessed work.** Draw a context model with at least six external actors/interfaces. For every boundary crossing, state the information/energy/material exchanged, unit, direction, owner and failure behavior.


**Checkpoint.** State the model assumptions, identify one failure mode or limitation, and explain what evidence would change your conclusion.


### Week 02 — Lifecycle, stakeholders and ConOps

**Lecture notes.** MBSE is not merely drawing diagrams. It links a language, a method and a tool to lifecycle decisions. Capture stakeholder concerns using interviews, scenarios and operational environments. A Concept of Operations (ConOps) explains how the system is expected to be used, by whom, in what modes and under what constraints. Include nominal operation, degraded modes, maintenance, emergency and retirement. Use mission threads or use cases to derive capabilities and measure of effectiveness. Review the ConOps with stakeholders before freezing requirements; otherwise the model formalizes the wrong problem.


**Worked application.** A tank-monitoring system may operate in normal telemetry, communications-degraded, sensor-fault, maintenance and emergency-shutdown modes. In the communications-degraded mode the safe behavior may be local control with queued telemetry, not continued cloud-dependent actuation.


**Practical / assessed work.** Create a ConOps for a normal day and an abnormal event. Identify actors, preconditions, trigger, main flow, alternatives, exit state and measures of effectiveness.


**Checkpoint.** State the model assumptions, identify one failure mode or limitation, and explain what evidence would change your conclusion.


### Week 03 — Requirements engineering and quality

**Lecture notes.** A requirement is a necessary, singular, verifiable statement of what the system must do or constrain. Avoid solution leakage unless the requirement is intentionally a design constraint. A good requirement has a unique identifier, rationale, source, owner, priority, verification method, acceptance criterion, status and trace links. Quantify subject, condition, action, threshold, tolerance and measurement point. Separate functional, performance, interface, safety, security, environmental, usability and lifecycle requirements. Ambiguous terms such as fast, robust, user-friendly and secure are not acceptance criteria.


**Worked application.** Weak: ‘The gateway shall send data quickly.’ Stronger: ‘When a valid sample is received and the gateway has network connectivity, the gateway shall publish the sample to the broker within 2 s for at least 99% of samples during a 10-minute test at 1 sample/s.’ The threshold and measurement method must still be agreed with stakeholders.


**Practical / assessed work.** Write 20 requirements for the tank system. Mark each as test, analysis, inspection or demonstration; reject non-verifiable statements and provide measurable rewrites.


**Checkpoint.** State the model assumptions, identify one failure mode or limitation, and explain what evidence would change your conclusion.


### Week 04 — Modeling foundations and SysML v2

**Lecture notes.** A model is a purpose-built abstraction with syntax, semantics and rules for interpretation. Syntax correctness alone does not establish model adequacy. SysML v2 is the current OMG major revision, based on KerML and designed for more precise textual and graphical modeling and API-enabled interoperability. Teach concepts before tool clicks: definitions versus usages, namespaces, relationships, typing, multiplicity, metadata and constraints. Models should be consistent across views because diagrams are projections of shared model elements, not independent pictures. SysML v1 remains widely deployed while organizations transition; record the language version and tool implementation for every deliverable.


**Worked application.** A part definition describes a kind of component; a part usage places a typed component in a particular system. Confusing a definition with a usage creates ambiguity about instance-specific properties. A diagram can omit details for clarity, but it must not contradict the underlying model.


**Practical / assessed work.** Create a small package, part definition and part usage in SysON. Import/export the textual model, render a view and record tool version, validation warnings and any unsupported features.


**Checkpoint.** State the model assumptions, identify one failure mode or limitation, and explain what evidence would change your conclusion.


### Week 05 — Structural architecture and decomposition

**Lecture notes.** Functional decomposition describes what the system does; physical decomposition describes what elements realize those functions. Do not confuse a function with a component. Allocate functions to logical elements first, then map candidate physical elements while preserving interface contracts. Define ports, item flows, ownership, multiplicities and resource constraints. An interface definition should make payload, units, validity, timing, direction, failure states and versioning explicit. Use decomposition only when it reduces reasoning complexity; excessive decomposition can obscure emergent behavior and cross-boundary hazards.


**Worked application.** A ‘measure level’ function may be allocated to an ultrasonic sensor subsystem, gateway and cloud data service. The function is not owned by one box: calibration, filtering, transport and quality checks are distributed responsibilities that must be visible in the model.


**Practical / assessed work.** Build a context, logical decomposition and physical architecture. Add allocation relations and an interface register; demonstrate that every required function has an owner and every external exchange has a defined contract.


**Checkpoint.** State the model assumptions, identify one failure mode or limitation, and explain what evidence would change your conclusion.


### Week 06 — Behavior modeling: activities, states and interactions

**Lecture notes.** Behavior models capture ordering, decisions, concurrency, events and mode transitions. An activity view is suitable for control/data flow; a state model is suitable for event-driven lifecycle behavior; an interaction/sequence view clarifies message order between participants. Define guard conditions and effects explicitly. Distinguish a state invariant from a transition precondition. Model exceptional flows rather than treating them as footnotes. State machines are useful because their reachable states can later become model-based test scenarios or formal verification targets.


**Worked application.** The controller state machine may contain STARTUP, NORMAL, SENSOR_FAULT, COMMS_LOSS, HIGH_LEVEL_ALARM and SAFE_SHUTDOWN. A transition to SAFE_SHUTDOWN should be triggered by a defined safety condition; an ambiguous ‘error’ event is insufficient.


**Practical / assessed work.** Model the controller state machine and three sequence scenarios: normal sample, stale sensor value and lost gateway connection. Identify unreachable states and transitions with no recovery path.


**Checkpoint.** State the model assumptions, identify one failure mode or limitation, and explain what evidence would change your conclusion.


### Week 07 — Requirements traceability and model organization

**Lecture notes.** Traceability is a graph, not a spreadsheet column. A stakeholder need motivates one or more requirements; requirements constrain model elements; model elements realize functions; verification cases produce evidence. Forward traceability asks what satisfies a need. Backward traceability asks why a design element exists. Orphan requirements signal missing design or validation; orphan design elements may be unnecessary or undocumented. Avoid many-to-many links without rationale. In SysML v2, traceability should be modeled as explicit relationships or metadata supported by the toolchain, then checked for completeness and consistency.


**Worked application.** Need N-04 ‘detect a dangerous high level’ may derive requirements for sensor accuracy, sampling interval, alarm latency, communications failure behavior and operator notification. A single ‘alarm shall work’ requirement would not give sufficient verification coverage.


**Practical / assessed work.** Complete the traceability graph for 20 requirements. Generate orphan, missing-verification and unallocated-requirement reports; verify all safety/security requirements map to design elements and test evidence.


**Checkpoint.** State the model assumptions, identify one failure mode or limitation, and explain what evidence would change your conclusion.


### Week 08 — Interfaces, contracts and integration

**Lecture notes.** Integration failures often occur at boundaries: mismatched units, stale values, incompatible versions, ambiguous ownership and undocumented failure modes. Specify interface contracts using preconditions, postconditions, invariants, timing and error semantics. Use dimensional analysis: a volume in litres cannot be compared directly with a sensor distance in millimetres without a model transformation. Define sequence and timeout semantics for asynchronous interfaces. Distinguish data flow, control flow and physical flow. Allocate interface requirements to both sides of the boundary, including fault handling.


**Worked application.** A sensor reports distance from the tank top in millimetres while the application uses percentage full. The transformation requires calibrated tank geometry and a known reference height; a simple linear percentage is wrong for irregular tank cross-sections.


**Practical / assessed work.** Create an interface control document and modeled interface for sensor-to-gateway and gateway-to-cloud. Include schema version, units, valid range, quality flag, timestamp semantics and timeout behavior.


**Checkpoint.** State the model assumptions, identify one failure mode or limitation, and explain what evidence would change your conclusion.


### Week 09 — Parametrics, performance and uncertainty

**Lecture notes.** Parametric modeling binds values and constraints to architecture or behavior. It enables engineers to calculate timing, capacity, power, reliability and physical performance from model parameters. Distinguish parameter values from assumptions and measured estimates. Use dimensional analysis and uncertainty propagation; do not hide margins inside rounded values. A deterministic nominal calculation is not a worst-case guarantee. Identify tolerance stack-up, environmental ranges and sensitivity to uncertain inputs. Keep constraint equations transparent and test them against independent calculations.


**Worked application.** For a periodic sensor, end-to-end alarm delay is the sum of sampling wait, local processing, network delay, cloud processing and notification delay. Under independent bounded maxima, a conservative worst-case sum is used; if components are statistical, a percentile budget requires an explicit distribution and dependence assumptions.


**Practical / assessed work.** Create a parametric timing budget with nominal, worst-case and measured values. Propagate at least one uncertain input and identify the design parameter with the largest sensitivity.


**Checkpoint.** State the model assumptions, identify one failure mode or limitation, and explain what evidence would change your conclusion.


### Week 10 — Trade studies and architecture decisions

**Lecture notes.** A trade study compares feasible alternatives against criteria derived from stakeholder needs. Define alternatives, constraints, scoring scale, evidence and weights before scoring. Weighted sums are convenient but can hide compensating effects and subjective weights. Use a Pareto view when criteria conflict; perform sensitivity analysis to see whether small weight changes reverse the ranking. Record assumptions and the decision owner. Architecture Decision Records capture context, options, decision, consequences and revisit triggers. A preferred alternative is not ‘objectively best’ unless the evidence supports the claim under the defined decision model.


**Worked application.** Suppose a wired sensor costs more but has lower outage probability and maintenance burden than a low-power radio sensor. A weighted score is meaningful only after lifecycle cost, installation risk, battery service access and communication reliability are quantified or transparently estimated.


**Practical / assessed work.** Compare wired, Wi-Fi and low-power-radio alternatives. Publish a decision matrix, sensitivity analysis and an ADR; challenge one criterion for double-counting and revise the weights.


**Checkpoint.** State the model assumptions, identify one failure mode or limitation, and explain what evidence would change your conclusion.


### Week 11 — Model verification, validation and quality assurance

**Lecture notes.** Model verification asks whether the model is constructed correctly against its language, rules and internal consistency constraints. Model validation asks whether the model is an adequate representation for its intended engineering decision. Check completeness, consistency, traceability, typing, multiplicity, units, naming, constraint satisfiability and view-to-model consistency. A model can be syntactically valid and conceptually wrong. Use model queries and automated rules where possible; retain human review for interpretation, stakeholder adequacy and emergent behavior. Record the tool version because validators can differ.


**Worked application.** A constraint solver may show that a timing budget is satisfiable using a 300 ms network latency assumption. If field measurements show p99 latency of 1.4 s, the model may be internally valid but not validated for deployment. Validation requires comparison with reality and the decision context.


**Practical / assessed work.** Run the SysON model validation available in the installed version, inspect generated warnings, and conduct a peer model review using a checklist. Record every unresolved issue and its disposition.


**Checkpoint.** State the model assumptions, identify one failure mode or limitation, and explain what evidence would change your conclusion.


### Week 12 — Configuration, change and model governance

**Lecture notes.** A model baseline is a controlled set of model artefacts and metadata used as a reference for a decision or review. Manage branching, merging, model ownership, naming, permissions, change proposals and release evidence. A requirement change can propagate to model elements, tests, safety analyses, interface contracts and training material. Impact analysis should follow explicit trace links and then be confirmed by domain experts; graph traversal alone cannot infer semantic impact. Define who may approve changes and what triggers re-verification or revalidation.


**Worked application.** Changing the sampling interval from 10 s to 1 s affects network load, energy use, storage retention, alarm latency, retry behavior and database cost. A local parameter edit is not a complete change assessment.


**Practical / assessed work.** Create a baseline, submit a controlled change request and produce an impact report across requirements, architecture, safety, security, interfaces and verification. Include rollback criteria.


**Checkpoint.** State the model assumptions, identify one failure mode or limitation, and explain what evidence would change your conclusion.


### Week 13 — Digital engineering, interoperability and model APIs

**Lecture notes.** A digital thread is a controlled set of linked engineering information across lifecycle activities; it is not a single tool or an automatic promise of perfect traceability. SysML v2 introduces standardized textual notation and API/services intended to improve tool interoperability. In practice, support varies by implementation and feature maturity. Check import/export fidelity, identity preservation, units, relationships, validation and access control before relying on a toolchain integration. Store source models in version control and keep generated documents reproducible from a known baseline.


**Worked application.** An exported diagram may look identical even though a relationship or metadata field was lost during format conversion. Round-trip validation therefore needs semantic checks, not visual comparison alone.


**Practical / assessed work.** Export a model, re-import it into a clean project, compare element counts and trace links, and document unsupported features. Do not treat a screenshot as model evidence.


**Checkpoint.** State the model assumptions, identify one failure mode or limitation, and explain what evidence would change your conclusion.


### Week 14 — Integrated model review and capstone

**Lecture notes.** A credible MBSE package supports a decision. It includes stakeholder and operational context, requirements baseline, architecture, behavior, interface definitions, parametric analyses, trade decisions, traceability, model quality evidence and change history. A reviewer should be able to navigate from an operational need to a requirement, model element, allocated component and verification result. The model must expose unresolved assumptions and show how safety/security constraints shaped the architecture. Present model views for specific questions instead of exporting every diagram.


**Worked application.** The tank capstone should show how a high-level safety constraint (‘prevent overflow under stated faults’) is decomposed into sensor, controller, actuator, local fallback and operator requirements, then linked to FTA/STPA scenarios and test cases.


**Practical / assessed work.** Submit the model archive, exported views, traceability report, query/validation output, decision records and a 15-minute design review. Include a change-impact demonstration and a limitations statement.


**Checkpoint.** State the model assumptions, identify one failure mode or limitation, and explain what evidence would change your conclusion.


## Assessment design

| Component | Weight | Evidence expected |
|---|---:|---|
| Weekly problem sets and derivations | 20% | Correct reasoning, assumptions, units and worked calculations |
| Practical labs and reproducibility | 25% | Executable/model artefacts, tests, environment and results |
| Midterm assessment | 15% | Core concepts, derivations and design trade-offs |
| Individual cumulative project | 25% | Correct implementation/model, traceability and technical report |
| Final examination and oral defense | 15% | Transfer to unseen cases and explanation of submitted work |


## Minimum submission standard

Every practical report must include: objective; theory; assumptions; environment/tool versions; procedure; expected result; actual result; raw evidence; analysis; limitations; references. A screenshot alone is not proof of a model, test, or database property. Never label an external-tool lab as passed unless it was run in the named tool.


## Edition 3 advanced implementation extension — SysML v2 requirements and digital thread

Edition 3 replaces the empty requirements and traceability templates with an 18-requirement water-tank baseline, six stakeholder needs, ten model-element register entries, eighteen verification-case records, and twenty-two explicit trace links. The SysML v2 model contains component/port definitions, a control-cycle action and flows, requirement definitions/usages, satisfaction links, and a verification objective. Stable `M-*` identifiers in the model-element register are linked to names in the textual model; the validator checks the interchange layer rather than parsing the SysML file.

Run the standard-library quality check from `labs/02-mbse/`:

```bash
python traceability/validator.py .
pytest -q traceability/test_validator.py
```

A clean local result means that the register schemas and cross-references pass. It does **not** prove that the `.sysml` file parses, that the requirement constraints are semantically complete, that the model is an adequate real-world representation, or that a requirement is satisfied. All test cases remain `planned` until the learner runs and captures the required evidence.

Use [Johns Hopkins 645.631 (Fall 2026)](https://apps.ep.jhu.edu/syllabus/fall-2026/645.631.82) for the 14-module model-building and methodology sequence and [645.632 (Spring 2027)](https://apps.ep.jhu.edu/syllabus/spring-2027/645.632.81) for model queries, reports, configurations, trade studies and model verification/validation. The current [SysON v2026.11.0 manual](https://doc.mbse-syson.org/syson/v2026.11.0/) documents graphical views and import/export capabilities; record the exact release because feature support changes. The import/render/round-trip step remains an external workbench gate in this edition.

Complete the sample-period change request in `labs/02-mbse/change-impact/CR-001-sample-period.md`. The example is deliberately not a fully automated impact engine: explicit trace links identify direct dependencies, while engineers must reason about indirect effects such as power, throughput, storage, safety margins and operator response. See `labs/02-mbse/README.md` for the full deliverable set and marking rubric.


## Edition 3 lab annex — requirement/model/test traceability

The practical pack in `labs/02-mbse/` now includes six stakeholder needs, 18 measurable requirements, ten registered model elements, 18 planned verification cases, 22 trace links, a trade study, change-impact example and an expanded SysML v2 textual model. Run `python validator.py ..` and `pytest -q test_validator.py` from `labs/02-mbse/traceability/`. The validator checks CSV identifiers, links, test coverage and evidence-path containment; it does **not** parse or semantically validate the SysML file. The SysML text must still be imported, rendered and re-exported using [Eclipse SysON v2026.11.0 documentation](https://doc.mbse-syson.org/syson/v2026.11.0/), then reviewed against the [OMG SysML v2 specification](https://www.omg.org/spec/SysML/2.0/Language/PDF). Those external tool steps are not recorded as completed in this edition.

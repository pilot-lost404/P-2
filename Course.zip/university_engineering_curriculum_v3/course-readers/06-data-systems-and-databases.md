# Data Systems and Databases — Expanded Course Reader (2026 Edition)

> **Level:** Advanced undergraduate / early graduate; data structures, algorithms, programming, discrete mathematics and introductory SQL prerequisites.  
> **Duration:** 14 teaching weeks, 8–12 hours/week  
> **Status:** Self-study reader benchmarked against official 2026 university syllabi and primary documentation. It is not an accredited course or professional certification.

## Course outcomes

1. Design relational schemas using keys, constraints, functional dependencies and normalization.

2. Express and analyze queries using relational algebra and SQL; reason about plans, cost and indexes.

3. Explain and implement storage pages, buffer management, indexes, query execution and transaction control.

4. Analyze isolation anomalies, locking, MVCC, logging, recovery and distributed database trade-offs.

5. Build a data-backed application with migration, backup/restore, quality, security and operational evidence.


## How to work through the course

For each week, read the concept notes, reproduce the derivation or model, complete the practical task, answer the challenge without looking at references, and record assumptions and evidence. A passing submission must include the exact environment, expected criterion, observed result and limitations. Use the weekly practical tasks as assessed work, not optional reading.


## Foundation reader retained from the first edition

The original first-edition chapter is preserved below for continuity. The expanded notes that follow add the missing depth, quantitative reasoning, labs and assessment structure identified in the academic audit.


---


# Course 6 — Data Systems and Databases
**Level:** Upper-undergraduate / early graduate  
**Duration:** 14 teaching weeks  
**Expected workload:** 8–10 hours per week  
**Practical platform:** PostgreSQL 18 or another current relational database; optional implementation exercises in C++/Rust/Go  
**Prerequisites:** Programming, data structures, discrete mathematics and basic command-line use.

## Course description

A database system is not merely a place to store rows. It is a software system that models information, enforces integrity, processes queries, coordinates concurrent transactions, persists state, recovers from failure and exposes interfaces to applications. Data systems engineering extends this foundation to replication, partitioning, streaming, analytical workloads, data governance and distributed storage.

This course covers the relational model, conceptual/logical/physical design, relational algebra, SQL, normalization, storage engines, indexes, query processing, transaction semantics, concurrency control, recovery, migration, data quality and distributed database trade-offs. It uses PostgreSQL for concrete experiments and links database behavior to the remote tank platform.

The course deliberately distinguishes logical correctness from physical performance. A schema can be normalized but slow for a workload; an index can improve one query and degrade writes; a transaction can be atomic locally but not across independent services.

## Learning outcomes

Students should be able to:
1. Explain the relational model, keys, constraints and relational algebra.
2. Transform an ER model into relations and assess normalization.
3. Write SQL queries using joins, grouping, subqueries and window functions.
4. Explain storage pages, records, buffer pools, indexes and query plans.
5. Analyze ACID properties, transaction schedules and isolation anomalies.
6. Compare locking, timestamp ordering, optimistic concurrency and MVCC.
7. Explain write-ahead logging, checkpoints, backups and point-in-time recovery.
8. Design safe schema migrations and data-quality controls.
9. Evaluate replication, sharding, consistency and distributed database trade-offs.
10. Design and benchmark a database-backed application with reproducible evidence.

---

## Week 1 — Data models and database system architecture

A data model defines the structure of information and the constraints on it. Common models include relational, document, key-value, graph and column-family models. The choice depends on access patterns, integrity requirements, query needs, scale, operational skills and consistency requirements. A fashionable model is not automatically the right model.

A database management system (DBMS) typically includes a query processor, optimizer, execution engine, storage manager, buffer manager, transaction manager, concurrency-control subsystem, log/recovery subsystem and catalog. The application submits logical queries; the DBMS chooses a physical plan and coordinates access to stored data.

Separate three design levels:
- **Conceptual model:** business entities, relationships and rules.
- **Logical model:** relations, keys, attributes and constraints.
- **Physical model:** data types, indexes, partitions, storage parameters and deployment.

The distinction makes change easier to reason about. A physical index should not redefine the business meaning of an entity.

### Worked example

For the tank platform, conceptual entities include Facility, Tank, Sensor, Measurement, Command, User, Role and AuditEvent. The logical design identifies primary and foreign keys. The physical design chooses partitioning for time-series measurements, indexes for facility/time queries and retention rules.

### Laboratory

Draw a conceptual ER model with cardinalities and optionality. Do not choose data types or indexes until the business relationships and integrity rules are clear.

---

## Week 2 — Relational model, keys and integrity

A relation is a set of tuples over attributes. In the practical SQL model, tables can contain duplicate rows unless constraints prevent them, so designers should explicitly identify keys and integrity rules.

A candidate key is a minimal set of attributes that uniquely identifies a tuple. A primary key is the chosen candidate key. A foreign key enforces a referential relationship. A superkey uniquely identifies rows but may contain unnecessary attributes. Natural keys have domain meaning; surrogate keys are generated identifiers. The decision should consider stability, uniqueness, privacy and integration behavior.

Integrity constraints include domain constraints, NOT NULL, UNIQUE, CHECK, primary-key and foreign-key constraints. Enforcing integrity in the database protects against bugs in multiple application clients. Application validation improves user feedback, but it should not replace critical database constraints.

### Worked example

```sql
CREATE TABLE facility (
    facility_id bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    name text NOT NULL,
    timezone text NOT NULL
);

CREATE TABLE tank (
    tank_id bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    facility_id bigint NOT NULL REFERENCES facility(facility_id),
    tank_code text NOT NULL,
    capacity_litres numeric(12,2) NOT NULL CHECK (capacity_litres > 0),
    UNIQUE (facility_id, tank_code)
);
```

The composite unique constraint prevents duplicate tank codes within a facility while allowing the same code at another facility. The foreign key prevents a tank from referencing a nonexistent facility.

### Laboratory

Implement a schema with primary, foreign, unique and check constraints. Attempt invalid inserts and confirm that the database—not only the application—rejects them.

---

## Week 3 — Functional dependencies and normalization

A functional dependency \(X \rightarrow Y\) means that for any two rows, if their X values are equal, their Y values must also be equal. It describes a constraint of the domain, not merely a pattern observed in sample data.

Normalization reduces undesirable redundancy and update anomalies:
- 1NF requires attribute values to be atomic within the chosen relational model.
- 2NF requires non-prime attributes to depend on the whole candidate key, not part of a composite key.
- 3NF requires non-prime attributes not to depend transitively on a candidate key; formally, for every non-trivial FD \(X \rightarrow A\), either X is a superkey or A is prime.
- BCNF requires every determinant of a non-trivial functional dependency to be a superkey.

Normalization can reduce insertion, update and deletion anomalies. It does not mean that every table must contain one column or that all denormalization is wrong. Denormalization can be a justified performance decision when the duplicated facts have clear ownership and a reliable update strategy.

### Worked example

Consider `Enrollment(student_id, course_id, student_name, course_title, grade)` with key `(student_id, course_id)`. Dependencies include `student_id -> student_name`, `course_id -> course_title`, and `(student_id, course_id) -> grade`. The table has partial dependencies on parts of the composite key. Decompose into Student, Course and Enrollment. Each fact then has one authoritative location.

### Laboratory

Given a relation and a list of functional dependencies, identify candidate keys, find violations of 2NF/3NF/BCNF and produce a lossless decomposition. Explain whether dependency preservation is achieved.

---

## Week 4 — Relational algebra and SQL

Relational algebra provides operations that express queries over relations. Selection filters tuples; projection chooses attributes; union combines compatible relations; difference subtracts tuples; Cartesian product pairs tuples; joins combine related tuples. These ideas help explain how a DBMS can transform and optimize queries.

SQL is declarative: the user states the desired result, and the DBMS chooses a plan. SQL includes DDL (schema definition), DML (data manipulation), DQL (querying) and transaction control. A SQL query is not necessarily executed in the textual order in which clauses appear.

### Worked query

```sql
SELECT f.name,
       count(m.measurement_id) AS readings,
       avg(m.level_percent) AS avg_level
FROM facility AS f
JOIN tank AS t ON t.facility_id = f.facility_id
JOIN measurement AS m ON m.tank_id = t.tank_id
WHERE m.measured_at >= now() - interval '24 hours'
GROUP BY f.facility_id, f.name
HAVING count(m.measurement_id) >= 100
ORDER BY avg_level DESC;
```

The query joins facilities to tanks to measurements, filters the time range, groups by facility, filters groups with at least 100 readings, then orders the result. The `HAVING` condition applies after grouping. `WHERE` filters input rows before aggregation.

Understand NULL semantics. `NULL` means unknown or missing, not zero or an empty string. Comparisons with NULL produce unknown; use `IS NULL` and `IS NOT NULL`. Aggregates usually ignore NULL values except `COUNT(*)`, which counts rows.

### Laboratory

Write queries for: recent high-level alerts, daily average per tank, tanks with no telemetry, users who issued commands, and facilities whose number of active alarms exceeds a threshold. Explain how NULL values affect each query.

---

## Week 5 — Storage engines and physical data layout

A DBMS maps logical records to pages or blocks on storage. It may use heap files, sorted files, log-structured storage or other layouts. The buffer pool caches pages in memory. A page-oriented system reads and writes blocks rather than treating each row as an independent disk operation.

A table scan reads the relevant pages and checks rows. A sequential scan can be optimal when a large fraction of a table is needed. An index supports targeted lookup but adds storage and write overhead. Physical design depends on workload selectivity, data distribution, locality, row width, update patterns and cache behavior.

Write-ahead logging records changes needed for recovery. A common rule is that the log record describing a data-page change must become durable before the modified data page is written. This allows recovery to redo committed changes and undo or ignore incomplete changes according to the DBMS's protocol.

### Laboratory

Create a table with a million generated telemetry records. Measure table size, insert rate and sequential scan time. Observe how row width and data volume affect performance.

---

## Week 6 — Indexing and query optimization

An index is an auxiliary data structure that helps locate rows. B+ trees support ordered lookup and range queries. Hash indexes support equality lookup under the supported DBMS semantics. Bitmap and inverted indexes serve particular workloads. Indexes are not free: they consume storage, slow writes, require maintenance and may be ignored by the optimizer.

A query optimizer estimates the cost of candidate plans using statistics such as table cardinality, value distribution and selectivity. It may choose nested-loop, hash or merge joins, along with scans and index access. Bad estimates can lead to bad plans, especially with correlated columns, skew and stale statistics.

Use `EXPLAIN` to inspect the plan and `EXPLAIN ANALYZE` to compare estimates with actual execution. `EXPLAIN ANALYZE` executes the statement; be careful with data-modifying queries and production data.

### Worked example

An index on `(tank_id, measured_at)` can support a query that filters by tank and time range. An index on `measured_at` alone may be more useful for queries that scan all tanks for a time range. The best index depends on query patterns, cardinality and write frequency.

### Laboratory

Run the same query with and without a composite index. Capture execution plans, actual rows, estimated rows, execution time and buffer activity. Explain whether the index helps and why.

---

## Week 7 — ACID transactions and transaction boundaries

A transaction groups operations into a unit with ACID properties:
- Atomicity: all operations of the transaction take effect or none do.
- Consistency: constraints that are defined for the database are preserved by committed transactions.
- Isolation: concurrent transactions behave according to the isolation guarantee.
- Durability: committed changes survive the failure model promised by the system.

ACID does not automatically make business logic correct. A transaction can atomically commit an invalid state if the application failed to express the intended constraint. Consistency means the database's declared invariants are maintained; it does not mean every domain requirement was correctly declared.

A transaction should cover a coherent unit of work, avoid unnecessary duration and use appropriate constraints and locking. Long transactions can increase contention, delay vacuum/cleanup and complicate recovery.

### Worked example

```sql
BEGIN;

UPDATE tank
SET target_percent = 75
WHERE tank_id = 42;

INSERT INTO audit_event(event_type, object_id, actor_id)
VALUES ('TARGET_CHANGED', 42, 17);

COMMIT;
```

The target change and audit event commit together if both are part of the same database transaction. If the audit store is an external service, this local transaction does not make the cross-service operation atomic; use an outbox or another explicit coordination design.

### Laboratory

Implement a transaction that changes configuration and writes an audit record. Force an error between the statements. Demonstrate rollback and then test concurrent updates.

---

## Week 8 — Isolation anomalies and concurrency control

Concurrent transactions can interfere. Common anomalies include:
- dirty read: observing uncommitted data;
- non-repeatable read: reading the same row twice and observing different committed values;
- phantom: a repeated predicate query returns a different set;
- lost update: one update overwrites another without incorporating it;
- write skew: concurrent transactions make individually valid decisions that jointly violate a constraint.

Isolation levels specify which behaviors are prevented. Exact implementations vary by DBMS. PostgreSQL uses MVCC: a statement sees a snapshot, reducing read/write blocking. Its `READ COMMITTED`, `REPEATABLE READ` and `SERIALIZABLE` behavior should be studied from PostgreSQL's own documentation, including serialization failures that the application must handle.

Concurrency-control methods include two-phase locking (2PL), timestamp ordering, optimistic concurrency control and MVCC. 2PL acquires locks and has a growing phase followed by a shrinking phase; strict 2PL holds write locks until commit/abort. Optimistic concurrency control allows work to proceed and validates before commit. MVCC maintains versions so readers can observe snapshots.

### Worked example: write skew

Two operators each check that at least one of two pumps remains enabled. Transaction A sees pump 1 and pump 2 enabled, then disables pump 1. Transaction B sees the same original state, then disables pump 2. If both transactions commit under an isolation mode that permits the anomaly, the final state has no pump enabled. The rule must be enforced using an appropriate serializable transaction, explicit locking, a constraint on a shared row or another correct design.

### Laboratory

Open two database sessions. Reproduce a lost update or write skew under a permissive isolation level. Repeat under serializable isolation and handle serialization failure with a bounded retry strategy.

---

## Week 9 — Recovery, backups and durability

Recovery restores a database to a consistent state after crash or corruption. Write-ahead logging records changes so the system can recover durable transactions. Checkpoints limit recovery work by establishing a known point from which log replay can proceed.

A backup is not proven useful until restoration has been tested. Distinguish full, incremental and differential backups; physical and logical backups; and point-in-time recovery. Recovery objectives include Recovery Point Objective (RPO), the maximum tolerable data loss measured in time, and Recovery Time Objective (RTO), the target time to restore service.

A replica is not a backup: corruption or malicious deletion can replicate. A backup is not a high-availability solution: restoration may take too long for the service objective. Use backups, replicas, archival retention and tested recovery procedures for different needs.

### Worked example

If the service requires an RPO of five minutes, the backup/log-archiving strategy must ensure that the recoverable point is no more than five minutes before the incident under the defined failure assumptions. If restoration takes two hours but the service's RTO is 30 minutes, the design is insufficient even if the data is preserved.

### Laboratory

Create a backup, modify or delete test records, restore to a separate database and compare row counts and integrity checks. Record actual restore time and recoverable timestamp. Do not label a backup system "tested" based only on successful backup creation.

---

## Week 10 — Migrations and schema evolution

A schema evolves as requirements change. A migration must coordinate application versions, database versions, data transformation, rollback strategy, availability and compatibility. Large blocking migrations can cause outages. A safer pattern is often expand–migrate–contract:
1. Add the new structure while retaining compatibility.
2. Deploy code that can read/write the compatible form.
3. Backfill or transform data in bounded batches.
4. Switch reads to the new representation.
5. Remove the old structure only after all consumers have migrated.

Migrations should be versioned, repeatable where possible, reviewed, tested on representative data and observable during execution. A migration that works on a 100-row development table may fail on a production table with millions of rows and concurrent writes.

### Laboratory

Rename a field through an expand–migrate–contract process. Demonstrate compatibility between old and new application versions. Add a migration test and a rollback/forward-recovery decision.

---

## Week 11 — Data quality, governance, lineage and retention

Data quality can be assessed through accuracy, completeness, consistency, timeliness, validity, uniqueness and fitness for purpose. These dimensions are not interchangeable. A measurement may be syntactically valid but physically implausible. A missing value may be correct if a sensor was offline; replacing it with zero creates false information.

Enforce quality at multiple layers: input validation, database constraints, domain checks, deduplication, reconciliation, monitoring and human review. Preserve provenance: source, event time, ingestion time, transformations, schema version and correction history. Data lineage records where data came from and how it was transformed.

Governance defines ownership, access, classification, retention, deletion, legal constraints, data-sharing rules and audit responsibilities. Retention must be justified by operational, legal, safety and privacy needs. Do not retain sensitive data indefinitely simply because storage is cheap.

### Laboratory

Define quality rules for telemetry: valid range, timestamp freshness, sensor identity, duplicate event ID, missing sequence and plausible rate of change. Implement SQL checks and generate a data-quality report.

---

## Week 12 — Distributed databases: replication, sharding and consistency

Distributed databases partition and/or replicate data across nodes. Replication can improve availability and read locality, but introduces replica lag, conflict resolution, write coordination and recovery complexity. Sharding distributes data and load, but complicates joins, transactions, rebalancing and global constraints.

Synchronous replication waits for acknowledgements according to a defined durability policy; asynchronous replication may lose recent acknowledged writes during failover depending on the design. A read from a lagging replica may return stale data. The API should specify whether it offers read-your-writes, monotonic reads, causal guarantees or linearizability.

The CAP theorem concerns the impossibility of guaranteeing both linearizability and availability to every request during a network partition. It does not mean all databases must choose two properties permanently. Partition behavior depends on the operation and consistency guarantee. PACELC adds the observation that systems make latency/consistency trade-offs when there is no partition as well.

### Laboratory

Run a primary/replica setup or a simulator. Introduce replication lag and compare read results. Design a sharding key for telemetry and measure skew. Explain which queries become cross-shard operations.

---

## Week 13 — Analytical data systems and event-driven architectures

Online Transaction Processing (OLTP) systems support many small, concurrent state changes with strong integrity requirements. Online Analytical Processing (OLAP) systems support large scans and aggregations across historical data. Their storage and query patterns differ. Row-oriented storage is often useful for transactional access; columnar storage can be efficient for scans over a subset of columns.

A data warehouse integrates data for analysis. A data lake stores large volumes of data in varied formats, but without governance it can become a data swamp. A lakehouse combines aspects of data lake storage with table metadata and transaction features. Architectural labels do not replace explicit consistency, schema, ownership, retention and quality definitions.

Event-driven data systems use logs or messaging platforms to decouple producers and consumers. Events describe facts that happened; commands request actions. Event schemas need versioning. Consumers must handle duplicate delivery, delayed events, ordering scope, poison messages and replay. A data pipeline should preserve lineage and make reprocessing safe.

### Laboratory

Create an event pipeline that ingests sensor events, stores raw records and builds daily aggregates. Reprocess a date range and compare results. Document how schema changes and duplicate events are handled.

---

## Week 14 — Database design review and capstone

A database design review asks:
- What entities and facts are represented?
- Which constraints protect integrity?
- What are the critical query patterns?
- Which indexes support those patterns and what do they cost?
- What isolation level supports each transaction?
- How are deadlocks and serialization failures handled?
- What is the durability boundary?
- What are the backup, restore and retention guarantees?
- How do schema changes roll out?
- What happens during replication lag, partition and failover?

### Final submission

Submit an ER diagram, normalized logical schema, SQL DDL, migration history, representative queries, query plans, transaction/anomaly experiment, backup/restore evidence, data-quality report, distributed architecture note and performance analysis.

### End-of-course problems

1. What is the difference between a superkey and a candidate key?  
   **Solution:** A superkey uniquely identifies rows but may contain unnecessary attributes. A candidate key is a minimal superkey.

2. Why is a read replica not a backup?  
   **Solution:** Incorrect updates, malicious deletion and corruption may be replicated. A backup preserves a recoverable historical state under a separate retention and access model.

3. Why can a transaction pass at READ COMMITTED but fail under SERIALIZABLE?  
   **Solution:** A serializable engine may detect that concurrent transactions cannot be ordered as a valid serial execution. It aborts one transaction to preserve the guarantee. The application must handle the serialization failure.

4. Does adding an index always improve performance?  
   **Solution:** No. It adds storage and write/maintenance costs, may not be selective, may not match the query predicate/order, and may be slower than a sequential scan for large result fractions.

## Selected sources and further study

- CMU 15-445/645 Intro to Database Systems (Fall 2026): https://15445.courses.cs.cmu.edu/fall2026/
- CMU Database Group course catalogue: https://db.cs.cmu.edu/courses/
- PostgreSQL 18 documentation: https://www.postgresql.org/docs/18/
- PostgreSQL MVCC and concurrency control: https://www.postgresql.org/docs/18/mvcc.html
- PostgreSQL transaction isolation: https://www.postgresql.org/docs/18/transaction-iso.html
- MIT 6.5830 Database Systems: https://dsg.csail.mit.edu/6.5830/
- *Database System Concepts*, Silberschatz, Korth and Sudarshan: https://www.db-book.com/
- *Designing Data-Intensive Applications*, 2nd ed. (2026): https://martin.kleppmann.com/2026/03/24/designing-data-intensive-applications-2e.html
- SQLite documentation for a lightweight second DBMS comparison: https://www.sqlite.org/docs.html

CMU's course provides particularly strong coverage of database internals and programming projects. PostgreSQL documentation should be used for precise engine-specific behavior; do not generalize PostgreSQL's implementation details to every DBMS.


---

## Expanded 14-week lecture notes and practical sequence


### Week 01 — Database architecture and data models

**Lecture notes.** A DBMS separates logical data representation from physical storage and access. Its major concerns include query processing, storage, buffer management, concurrency, recovery, catalog metadata and transaction interfaces. The relational model represents relations as sets of tuples under a schema; SQL adds practical features such as duplicates and NULL semantics that require care. Compare relational, document, key-value, graph and columnar models by access pattern and integrity needs, not by popularity. Workload characteristics—OLTP, OLAP, event processing and mixed workloads—shape architecture.


**Worked application.** A sensor reading has a time, tank ID, value, unit and quality state. A relational model is useful when referential integrity and transactions matter; a time-series or columnar store may be more appropriate for high-volume scans. Hybrid architectures are common, but data ownership and consistency must be explicit.


**Practical / assessed work.** Classify five workloads and choose a data model with a rationale. Draw the client, query processor, buffer manager, storage manager, log and catalog paths for a transaction.


**Checkpoint.** State the model assumptions, identify one failure mode or limitation, and explain what evidence would change your conclusion.


### Week 02 — Relational model, keys, constraints and SQL semantics

**Lecture notes.** A candidate key uniquely identifies a tuple and is minimal; a primary key is the selected candidate key. Foreign keys express referential constraints. CHECK, NOT NULL, UNIQUE and exclusion constraints move invariants into the database boundary. SQL uses three-valued logic: comparisons with NULL may be UNKNOWN, and WHERE retains only TRUE. `COUNT(*)` differs from `COUNT(column)`. Joins and aggregates can multiply rows unexpectedly. Design constraints to protect correctness under concurrent clients, not only in application validation.


**Worked application.** If two transactions concurrently attempt to insert the same idempotency key, an application-level ‘check then insert’ can race. A UNIQUE constraint serializes the conflict at the database boundary. The application must handle the uniqueness violation and return the prior result safely.


**Practical / assessed work.** Write schema DDL with primary/foreign keys, uniqueness, checks and NOT NULL. Add queries that demonstrate NULL, duplicate rows, outer joins and aggregate-count differences.


**Checkpoint.** State the model assumptions, identify one failure mode or limitation, and explain what evidence would change your conclusion.


### Week 03 — Functional dependencies, normalization and decomposition

**Lecture notes.** A functional dependency X→Y states that tuples agreeing on X must agree on Y. Candidate keys determine the attributes of a relation. 1NF removes non-atomic repeating groups under the chosen domain; 2NF removes partial dependency of non-prime attributes on a proper subset of a candidate key; 3NF requires for every nontrivial X→A that X is a superkey or A is prime; BCNF requires X be a superkey for every nontrivial dependency. Decomposition should be lossless and, where possible, dependency-preserving. Normalization addresses update anomalies, not every performance concern.


**Worked application.** For R(Student,Course,Instructor) with dependencies (Student,Course)→Instructor and Course→Instructor, the key may be (Student,Course), but Course→Instructor violates BCNF because Course is not a superkey. Decomposing into Course-Instructor and Student-Course can be lossless under the relevant dependency, while dependency preservation must be checked explicitly.


**Practical / assessed work.** Find candidate keys and normal forms for three schemas. Prove losslessness using the chase or binary decomposition test and identify whether dependencies remain enforceable without joins.


**Checkpoint.** State the model assumptions, identify one failure mode or limitation, and explain what evidence would change your conclusion.


### Week 04 — Relational algebra, SQL and query reasoning

**Lecture notes.** Relational algebra gives a mathematical basis for query transformations: selection, projection, product, join, union, difference and rename. Selection pushdown can reduce intermediate data if predicates are semantically safe. Projection pushdown can reduce tuple width but must retain attributes required by joins and outputs. SQL query semantics should be reasoned about before optimization; optimizer rewrites must preserve duplicates, NULL behavior and outer join semantics. Use common table expressions, window functions and subqueries where they improve clarity, then inspect execution plans rather than assuming the written query determines the physical algorithm.


**Worked application.** A filter on the right table in a WHERE clause after a LEFT JOIN may eliminate NULL-extended rows and behave like an inner join. Moving the predicate into the ON clause can preserve unmatched left rows. Query rewrites must be checked for semantic equivalence.


**Practical / assessed work.** Translate queries into relational algebra trees. Rewrite a multi-join query with safe predicate pushdown, then compare results on data containing duplicates and NULLs.


**Checkpoint.** State the model assumptions, identify one failure mode or limitation, and explain what evidence would change your conclusion.


### Week 05 — Physical storage, pages and buffer pools

**Lecture notes.** A DBMS maps logical tuples to pages on persistent storage. Page-oriented designs amortize I/O and permit sequential access. Slotted pages store a header, slot directory and tuple bytes, supporting variable-length records and tuple movement within a page. A buffer pool caches disk pages in memory; it tracks page IDs, pin counts, dirty state and replacement metadata. A pinned page cannot be evicted. Dirty pages require logging/recovery discipline before flush. Page identifiers and record identifiers must remain valid under the storage manager’s movement and compaction rules.


**Worked application.** A 4 KiB page with a 64-byte header and 8-byte slot entries has less space available for tuple payload than 4096 bytes. The usable capacity depends on alignment, free-space fragmentation, tuple length and reserved metadata; an average row-size estimate is not a guarantee.


**Practical / assessed work.** Implement a slotted-page simulator with insert, delete, free-space accounting and compaction. Add a small buffer pool with pin/unpin and dirty-page eviction invariants.


**Checkpoint.** State the model assumptions, identify one failure mode or limitation, and explain what evidence would change your conclusion.


### Week 06 — Indexes: B+ trees, hashing and filters

**Lecture notes.** An index trades storage and write amplification for faster access. A B+ tree keeps keys ordered and supports point and range search; internal pages guide traversal while leaves hold data references or records and are commonly linked for scans. Splits and merges maintain occupancy and separator-key invariants. Hash indexes target equality search but do not naturally support range predicates. Bloom filters can reject many absent keys with no false negatives under correct construction but may have false positives. Index selection should follow selectivity, data distribution, workload and maintenance cost.


**Worked application.** For a range query `timestamp BETWEEN t1 AND t2`, an ordered B+ tree can seek to t1 and scan to t2. A hash index cannot supply that ordering. A low-selectivity Boolean column may not benefit from a conventional B+ tree, depending on the query and data layout.


**Practical / assessed work.** Implement B+ tree insert/search/range operations or use a teaching storage engine. Validate splits at root and leaf, duplicate keys and sorted leaf traversal. Compare with a hash-index workload.


**Checkpoint.** State the model assumptions, identify one failure mode or limitation, and explain what evidence would change your conclusion.


### Week 07 — Query execution and cost-based optimization

**Lecture notes.** A logical plan describes relational operations; a physical plan chooses scans, joins, sorts, aggregation and data movement. Nested-loop join is attractive when one side is small or indexed; hash join is effective for equi-joins when build-side memory fits; sort-merge join exploits ordered inputs and can support range-like conditions. Cost estimates depend on cardinality, selectivity, tuple width, page count, memory and I/O behavior. Statistics can be stale or miss correlations, skew and heavy hitters. EXPLAIN shows estimated plans; EXPLAIN ANALYZE executes and measures, which can change data if the statement writes. Use rollback for controlled DML experiments.


**Worked application.** A nested-loop join over N outer rows and M inner rows can require O(NM) comparisons without an index. A hash join is expected O(N+M) for suitable hashing and memory, but skew, spilling and hash partitioning alter cost. Big-O alone is not a cost model.


**Practical / assessed work.** Load a reproducible data set in PostgreSQL 18. Compare sequential scan and indexed scan, then nested-loop/hash join plans. Report estimated vs actual rows, buffers and the effect of skew.


**Checkpoint.** State the model assumptions, identify one failure mode or limitation, and explain what evidence would change your conclusion.


### Week 08 — Transactions, serializability and locking

**Lecture notes.** A transaction groups operations under atomicity, consistency, isolation and durability goals. Conflict serializability can be checked using a precedence graph: a cycle implies the schedule is not conflict-serializable. Two-phase locking separates lock acquisition and release; strict 2PL holds write locks to commit/abort, simplifying recovery. Deadlocks arise from cycles in wait-for graphs and can be handled by detection/abort or prevention policies. Lock granularity trades concurrency for overhead. A successful SQL transaction can still violate application invariants if the isolation level and constraint design are inadequate.


**Worked application.** Two transactions each read a row and update a different row based on the combined state. They may produce write skew under snapshot isolation even though no write-write conflict occurs. Serializable execution or a redesigned constraint/locking strategy is required when the invariant demands it.


**Practical / assessed work.** Construct schedules for dirty read, lost update, non-repeatable read, phantom and write skew. Draw precedence and wait-for graphs; demonstrate a strict-2PL schedule and a deadlock resolution.


**Checkpoint.** State the model assumptions, identify one failure mode or limitation, and explain what evidence would change your conclusion.


### Week 09 — MVCC, isolation levels and PostgreSQL specifics

**Lecture notes.** Multi-Version Concurrency Control gives transactions snapshots of row versions. This reduces reader/writer blocking but creates vacuum and version-retention concerns. Isolation-level names are not perfectly portable across products. PostgreSQL 18 uses MVCC; its READ COMMITTED level obtains a new snapshot per command, REPEATABLE READ retains a transaction snapshot and prevents some anomalies, and SERIALIZABLE uses Serializable Snapshot Isolation to detect dangerous structures and abort transactions. PostgreSQL’s documented behavior for phantom reads and serialization anomalies must not be generalized to every DBMS. Applications must retry serialization failures safely.


**Worked application.** A transaction running at REPEATABLE READ may not observe a concurrent commit after its snapshot is established. Under PostgreSQL SERIALIZABLE, a transaction may be aborted with a serialization failure to preserve serializable behavior. The client retry must rerun the whole transaction, not only the final statement.


**Practical / assessed work.** Use two PostgreSQL sessions to reproduce snapshot behavior and write skew. Compare READ COMMITTED, REPEATABLE READ and SERIALIZABLE; record SQLSTATE and retry behavior.


**Checkpoint.** State the model assumptions, identify one failure mode or limitation, and explain what evidence would change your conclusion.


### Week 10 — Write-ahead logging, checkpoints and crash recovery

**Lecture notes.** Write-ahead logging records changes before dirty data pages are flushed. A commit is durable only when the required log state is safely persisted under the platform’s storage assumptions. Checkpoints bound recovery scan but can create I/O spikes. ARIES is a classic recovery algorithm structured around analysis, redo and undo, using log sequence numbers and compensation log records. PostgreSQL’s implementation differs in important details; learn WAL concepts generally and PostgreSQL behavior from its own documentation. Backup and restore must include required base backups and WAL continuity, and recovery must be tested to a defined recovery point objective.


**Worked application.** If a crash occurs after a data page is written but before the log record is durable, recovery may be impossible. WAL ordering prevents this. A checkpoint does not mean all earlier log segments are safe to delete unless archiving and recovery requirements are satisfied.


**Practical / assessed work.** Draw an ARIES-style crash timeline and classify records that need redo or undo. In PostgreSQL, take a backup, restore into a clean instance and verify data plus recovery target; record RPO and RTO.


**Checkpoint.** State the model assumptions, identify one failure mode or limitation, and explain what evidence would change your conclusion.


### Week 11 — Distributed databases, replication and partitioning

**Lecture notes.** Distributed databases trade locality, scale and availability against coordination and consistency. Replication, partitioning and distributed transactions solve different problems. Synchronous replication affects commit latency and availability; asynchronous replication creates a replication lag window and possible data loss on failover. Sharding introduces routing, cross-shard joins, rebalancing and hot-key concerns. Distributed SQL systems may provide stronger transaction guarantees through consensus and coordination, but with latency and operational costs. CAP is about behavior under network partition for a distributed data store; it is not a slogan saying databases choose only two of three properties at all times.


**Worked application.** If the primary acknowledges writes before replicas persist them, a failover to a lagging replica can lose acknowledged data. If a commit waits for a quorum, availability can decline when the quorum is unreachable. The correct policy follows the data-loss and availability requirements.


**Practical / assessed work.** Design a 3-replica database deployment for the tank system. Compare synchronous and asynchronous replication, define failover fencing and quantify the acknowledged-write loss window.


**Checkpoint.** State the model assumptions, identify one failure mode or limitation, and explain what evidence would change your conclusion.


### Week 12 — Analytical systems, streams and data architecture

**Lecture notes.** OLTP workloads emphasize short transactions, concurrency and point reads/writes; OLAP emphasizes scans, aggregations and analytical joins. Row stores favor retrieving complete records; column stores can reduce I/O for a subset of columns and compress repeated values. Data warehouses and lakehouses introduce ingestion, transformation, partitioning, schema evolution, lineage and quality challenges. Event-driven systems need event identity, ordering, replay, schema versions and idempotent consumers. Materialized views and denormalization improve read performance but create refresh and consistency obligations.


**Worked application.** A dashboard aggregating 18 months of telemetry by hour may suit a columnar analytical engine better than the transactional database. The operational database remains the source of authoritative commands and configuration; the analytics copy is often eventually consistent.


**Practical / assessed work.** Design an OLTP schema and an analytical star schema for telemetry. Define ingestion latency, late-data behavior, data quality rules, lineage and retention requirements.


**Checkpoint.** State the model assumptions, identify one failure mode or limitation, and explain what evidence would change your conclusion.


### Week 13 — Migrations, governance, security and operations

**Lecture notes.** Schema changes are production protocols. Expand-and-contract migrations allow old and new application versions to coexist while a column or relation changes. Backfill is a workload with locks, I/O and failure modes. Data governance covers ownership, definitions, classification, lineage, quality, retention and deletion. Database security requires least privilege, row/resource scope, secret management, encryption, audit and tested backup isolation. Operational readiness includes monitoring, capacity planning, vacuum/index maintenance, replication lag, restore rehearsals and incident runbooks. A migration is not complete until rollback or forward-recovery strategy and evidence exist.


**Worked application.** Renaming a column in one deployment can break old application instances during a rolling upgrade. First add the new column, dual-write/read as needed, backfill, validate, switch clients, then remove the old column after the compatibility window.


**Practical / assessed work.** Write an expand/backfill/contract migration plan and run it against a disposable PostgreSQL instance. Test interrupted backfill, rerun idempotency and rollback/forward recovery.


**Checkpoint.** State the model assumptions, identify one failure mode or limitation, and explain what evidence would change your conclusion.


### Week 14 — Database implementation project and design review

**Lecture notes.** The final project connects schema design with internals and operations. A database design must show logical constraints, normalization rationale, query workload, indexes, transaction/isolation assumptions, recovery design, security roles, migration plan, backup/restore evidence and performance measurements. For an implementation project, build a small page manager, buffer pool, index and transaction schedule simulator; do not copy proprietary course assignments. Use a project rubric that rewards correctness and invariant reasoning over raw feature count. A code-owner review should require the learner to explain and modify the submitted implementation.


**Worked application.** For the tank system, store telemetry append-only with retention, but keep actuator commands, command outcomes and configuration changes transactionally linked. A single generic event table may be useful for audit but should not replace domain constraints where correctness requires them.


**Practical / assessed work.** Submit executable SQL, schema rationale, query plan analysis, concurrency experiment, migration, backup/restore evidence, threat model, performance report and an oral code-ownership walkthrough.


**Checkpoint.** State the model assumptions, identify one failure mode or limitation, and explain what evidence would change your conclusion.


## Assessment design

| Component | Weight | Evidence expected |
|---|---:|---|
| Weekly problem sets and derivations | 20% | Correct reasoning, assumptions, units and worked calculations |
| Practical labs and reproducibility | 25% | Executable/model artefacts, tests, environment and results |
| Midterm assessment | 15% | Core concepts, derivations and design trade-offs |
| Individual cumulative project | 25% | Correct implementation/model, traceability and technical report |
| Final examination and oral defense | 15% | Transfer to unseen cases and explanation of submitted work |


## Minimum submission standard

Every practical report must include: objective; theory; assumptions; environment/tool versions; procedure; expected result; actual result; raw evidence; analysis; limitations; references. A screenshot alone is not proof of a model, test, or database property. Never label an external-tool lab as passed unless it was run in the named tool.


## Edition 3 implementation laboratory — build the storage core

The PostgreSQL experiments above demonstrate the behavior of a mature DBMS. They do not teach how a DBMS implements pages, memory caching, indexes or write-ahead recovery. The additional `labs/06-data-systems/diskdb/` project closes part of that gap with an original, small disk-backed engine.

The implementation is intentionally cumulative: first validate fixed-size pages and checksums; next implement a bounded LRU buffer pool with pin/unpin and dirty-page eviction; then add a monotonic checksummed WAL and a redo-only recovery procedure; finally construct a persistent B+ tree with recursive splits, separator keys, a linked leaf chain, point reads and inclusive range scans. The engine uses full-page after-images and fsyncs COMMIT before applying the data pages. It does not implement ARIES, undo, deletion/rebalancing, SQL, query execution, MVCC, concurrent transactions or production-grade power-loss safety.

**Commands** (from the curriculum root):

```bash
PYTHONPATH=labs/06-data-systems/diskdb pytest -q labs/06-data-systems/diskdb
PYTHONPATH=labs/06-data-systems/diskdb python labs/06-data-systems/diskdb/benchmark.py --inserts 500 --order 8
```

**Required evidence:** show the page format and CRC; demonstrate that a pinned page cannot be evicted; prove WAL flush occurs before data-page write; recover committed after-images but ignore uncommitted ones; run recovery twice; validate B+ tree invariants after each insertion order; compare point/range results against a reference dictionary; and close/reopen the files to prove persistence. Save the raw test output, Python/runtime version, seed, database/WAL sizes and measured timings. A passing unit test is not a proof against real power loss or storage-device failure.


## Edition 3 practical annex — disk-backed storage and index implementation

Use `labs/06-data-systems/diskdb/` to implement fixed 4 KiB pages with CRC32 metadata, a bounded LRU buffer pool with pins and dirty-page tracking, a checksummed monotonic WAL, write-ahead fsync, redo-only committed full-page replay, and a persistent B+ tree with recursive splits and linked-leaf range scans. Run `PYTHONPATH=labs/06-data-systems/diskdb pytest -q labs/06-data-systems/diskdb` and `PYTHONPATH=labs/06-data-systems/diskdb python labs/06-data-systems/diskdb/benchmark.py --inserts 500 --order 8`. The tests compare index histories with a reference dictionary and close/reopen the files. This is a small teaching engine, not BusTub/PostgreSQL: no SQL, delete/merge, concurrent transactions, MVCC, full ARIES UNDO, checkpoints, query optimizer or power-loss certification. Separately execute the PostgreSQL 18 scripts in a disposable PostgreSQL instance; that database validation is not available in this build environment. The implementation progression is benchmarked against [CMU 15-445 Fall 2026 projects](https://15445.courses.cs.cmu.edu/fall2026/syllabus.html): [buffer pool](https://15445.courses.cs.cmu.edu/fall2026/project1/), [B+ tree](https://15445.courses.cs.cmu.edu/fall2026/project2/), [query execution](https://15445.courses.cs.cmu.edu/fall2026/project3/) and [MVCC/concurrency control](https://15445.courses.cs.cmu.edu/fall2026/project4/).

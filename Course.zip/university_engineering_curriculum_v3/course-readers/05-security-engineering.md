# Security Engineering — Expanded Course Reader (2026 Edition)

> **Level:** Advanced undergraduate / early graduate; programming, operating systems, networking, web/API and basic cryptography prerequisites.  
> **Duration:** 14 teaching weeks, 8–12 hours/week  
> **Status:** Self-study reader benchmarked against official 2026 university syllabi and primary documentation. It is not an accredited course or professional certification.

## Course outcomes

1. Model assets, trust boundaries, attackers, attack surfaces and security objectives at system level.

2. Derive testable security requirements from risk and recognized assurance frameworks.

3. Design authentication, authorization, cryptographic use, API controls, data protection and secure operations.

4. Implement and test secure coding controls and analyze common vulnerability classes in authorized labs.

5. Integrate security into architecture, supply chain, verification, incident response and lifecycle decisions.


## How to work through the course

For each week, read the concept notes, reproduce the derivation or model, complete the practical task, answer the challenge without looking at references, and record assumptions and evidence. A passing submission must include the exact environment, expected criterion, observed result and limitations. Use the weekly practical tasks as assessed work, not optional reading.


## Foundation reader retained from the first edition

The original first-edition chapter is preserved below for continuity. The expanded notes that follow add the missing depth, quantitative reasoning, labs and assessment structure identified in the academic audit.


---


# Course 5 — Security Engineering
**Level:** Upper-undergraduate / early graduate  
**Duration:** 14 teaching weeks  
**Expected workload:** 8–10 hours per week  
**Practical environment:** Local lab applications, containers, OWASP Juice Shop or another intentionally vulnerable training system  
**Prerequisites:** Programming, HTTP/API basics, databases, operating systems and networking.

## Course description

Security engineering is the discipline of engineering systems so that assets and missions remain protected under realistic threats and operational constraints. It is broader than adding authentication, installing a scanner or performing a penetration test. Security must shape requirements, architecture, implementation, procurement, operation, maintenance and retirement.

This course develops a systems view of security. It covers security objectives, assets, adversaries, trust boundaries, threat modeling, security requirements, identity, authentication, authorization, cryptographic services, application and API security, data protection, secure development, supply-chain risk, testing, monitoring and incident response. The recurring tank-control platform makes consequences concrete: a remote command endpoint is not just a web route; it is a pathway to a physical effect.

All offensive exercises must be performed only in intentionally vulnerable labs or systems for which the student has explicit authorization. The goal is to learn to identify and prevent weaknesses, not to access real systems without permission.

## Learning outcomes

Students should be able to:
1. Define security objectives and identify assets, trust boundaries and adversaries.
2. Build data-flow threat models and apply STRIDE or another justified method.
3. Convert threats and protection needs into verifiable security requirements.
4. Distinguish identification, authentication, authorization and accountability.
5. Design session, token and access-control mechanisms with explicit assumptions.
6. Explain confidentiality, integrity, authenticity, signatures, key exchange and password hashing.
7. Analyze common web/API vulnerabilities and identify root causes.
8. Apply secure data handling, secrets management and secure configuration.
9. Integrate security into requirements, architecture, code review, CI/CD and operations.
10. Design security tests and incident-response evidence without overclaiming assurance.

---

## Week 1 — Security objectives, assets and threat models

### 1.1 What is being protected?

Security engineering begins by identifying assets and the consequences of their compromise. An asset may be data, a service, a physical process, a credential, a safety function, an identity, an operational capability or an organization's ability to deliver a mission.

The CIA triad—confidentiality, integrity and availability—is a starting vocabulary:
- Confidentiality: prevent unauthorized disclosure.
- Integrity: prevent or detect unauthorized or accidental alteration.
- Availability: preserve timely access to authorized users.

Other properties commonly matter: authenticity, accountability, non-repudiation, privacy, safety and resilience. These properties can conflict. Strong authentication may increase operator friction; broad availability may increase attack surface; detailed logging may improve accountability but expose sensitive data.

### 1.2 Asset and adversary analysis

Identify who may threaten the system, their capability, access, motivation and constraints. Threats may be malicious, accidental or environmental. A curious unauthorized user, compromised supplier, malicious insider, ransomware operator and faulty integration partner are not interchangeable threat actors.

For the tank service, assets include: control authority, configuration thresholds, operator identities, command records, telemetry, audit logs, signing keys, database availability and the integrity of local safety constraints.

### Worked example

An attacker who steals an operator token may issue an authorized-looking command. A network attacker may replay a valid command. A database administrator may alter the audit trail. A compromised gateway may publish false telemetry. Each scenario affects different assets and requires different controls.

### Laboratory

Create an asset register with owner, business/safety consequence, confidentiality requirement, integrity requirement, availability target, dependencies and recovery priority. List at least five adversary types and explain what they can plausibly do.

---

## Week 2 — Trust boundaries and data-flow threat modeling

Threat modeling is a structured process for asking how a design could be attacked or misused, what the consequences would be, and which controls are justified. It should be performed early and repeated as the design changes.

A data-flow diagram should show external entities, processes, data stores, data flows and trust boundaries. The trust boundary marks a change in authority or security assumptions—for example, the boundary between the public Internet and a cloud API, or between a cloud service and a local controller network.

STRIDE categorizes threat classes:
- Spoofing identity;
- Tampering with data or code;
- Repudiation of actions;
- Information disclosure;
- Denial of service;
- Elevation of privilege.

STRIDE is a prompting technique, not a risk score. It helps ensure that reviewers consider different threat types. A threat model should record the specific scenario, affected asset, attack preconditions, impact, existing control, proposed mitigation, owner and verification evidence.

### Worked example

Data flow: Operator browser → public API → command service → gateway → local controller. Trust boundaries exist at browser/API, service/gateway and gateway/controller. Potential threats include stolen session (spoofing), command modification (tampering), missing audit record (repudiation), leaked telemetry (information disclosure), request flooding (DoS) and a low-privilege user changing system-wide thresholds (elevation of privilege).

### Laboratory

Draw the capstone data-flow diagram. Apply STRIDE to each process, store and flow. Record at least 12 concrete threat scenarios; avoid writing generic labels without a plausible attack path.

---

## Week 3 — Risk assessment and security requirements

Security risk combines the likelihood of a threat scenario and its impact, but both estimates are context-dependent. A risk register should preserve the scenario and rationale instead of hiding everything in a single score. Vulnerability severity, exploitability, asset criticality, exposure and business impact are related but distinct concepts. CVSS is a vulnerability severity framework; it is not by itself a complete business risk assessment.

A security requirement should be testable and traceable. Example:
`SEC-004: The command API shall authorize each command against the authenticated principal's role and the target facility's ownership relationship before accepting the command.`

This requirement is stronger than "the API shall be secure." It identifies the operation and the decision criteria. It still needs test cases for valid owner, non-owner, revoked user, stale identity state, missing facility, guessed object ID and privileged role misuse.

Security design principles include least privilege, complete mediation, defense in depth, fail-safe defaults, separation of duties, secure by default, minimize attack surface, economy of mechanism and assume breach. Treat them as design reasoning aids, not slogans.

### Laboratory

Write 15 security requirements for the command platform. Trace each requirement to one or more threats, design elements and verification tests. Include negative authorization cases.

---

## Week 4 — Identity, authentication and session management

Identification states who a principal claims to be. Authentication verifies that claim. Authorization determines what the authenticated principal may do. Accountability records actions and decisions sufficiently to support investigation and governance. These are distinct control stages.

Authentication factors are commonly grouped into knowledge (something known), possession (something held) and inherence (something inherent). Multi-factor authentication requires independent factor categories; two passwords are not two factors. Phishing-resistant authentication uses mechanisms designed to bind authentication to the legitimate service, such as WebAuthn/FIDO2 in suitable contexts.

Passwords should not be stored in plaintext or with a fast general-purpose hash. Use a password-hashing function designed to resist offline guessing, with a unique salt and work factor appropriate to the deployment. Argon2id is a common modern choice; scrypt, bcrypt or PBKDF2 may be selected where compatibility or policy requires them. Parameters must be benchmarked and revisited as hardware improves.

Sessions and tokens require expiration, revocation strategy, secure transport, audience/scope restrictions, protection from theft and safe storage. A signed JWT is not automatically encrypted, revocable or safe to trust indefinitely. Validate issuer, audience, expiry, signature algorithm and key lifecycle; do not accept attacker-controlled algorithm choices or unvalidated claims.

### Laboratory

Run `labs/05-security/secure_service/`. Inspect the scrypt verifier and per-user salt; test generic failure responses, an attacker-supplied pre-login `sid`, fresh session creation, expiry, logout invalidation and per-source rate limiting. Explain the trade-off in an IP-based rate limit when users share a NAT address. The local user and session store are in-memory teaching fixtures, not a production identity provider.

---

## Week 5 — Authorization and access-control models

Authorization determines whether a subject may perform an action on an object under a defined context. Role-Based Access Control (RBAC) assigns permissions to roles. Attribute-Based Access Control (ABAC) evaluates subject, object, action and environmental attributes. Relationship-based access control checks relationships such as ownership, membership or delegation.

Role checks alone often fail at the resource level. An operator role may be allowed to read telemetry, but only for facilities assigned to that operator. The server must verify object-level authorization on every request. Hiding a button in the UI is not authorization.

A policy should specify default deny, permitted operations, scope, delegation, privilege escalation controls, separation of duties and audit requirements. Administrative paths should be deliberately designed because administrators have the potential to bypass normal controls.

### Worked example

Let `canIssueCommand(user, facility, command)` require:
1. user is authenticated;
2. account is active;
3. user has `OPERATOR` or `SUPERVISOR` permission;
4. user is assigned to the facility;
5. command is within the user's operational scope;
6. no higher-priority local safety interlock prohibits the action.

Each condition should have a separate test. The UI may help users understand permissions, but the authoritative decision belongs at the server-side enforcement point and the local controller retains its own safety authority.

### Laboratory

Build an RBAC plus resource-ownership policy. Run the secure-service owner/supervisor/tenant tests: create an object as `alice` in tenant A, change only the ID and request it as `bob` in tenant B, and attempt tenant-B access as a tenant-A supervisor. Expected result is `404` for out-of-scope records. Produce an authorization matrix and explain why authentication is not resource authorization.

---

## Week 6 — Cryptography for system engineers

Cryptography provides mechanisms; it does not define a complete security architecture.

- A cryptographic hash maps input to a fixed-size digest. It supports integrity checks and constructions such as digital signatures. It does not authenticate the sender by itself.
- A message authentication code (MAC) provides integrity and authenticity to parties sharing a secret key.
- Symmetric encryption uses a shared secret key and is efficient for bulk data.
- Asymmetric cryptography uses a key pair and supports key exchange and digital signatures.
- A digital signature lets a verifier check that a message was signed by the holder of a private key and was not altered, subject to key trust and algorithm assumptions.
- Authenticated encryption (for example, an AEAD mode) provides confidentiality and integrity together when used correctly.

Key management is often harder than choosing an algorithm. Define key generation, storage, access, rotation, revocation, backup, compromise response and destruction. Never embed long-lived secrets in source code or container images. Prefer managed secret stores or hardware-backed key protection where justified.

Transport Layer Security (TLS) protects communication when correctly configured and certificates are validated. It does not fix an application that trusts the wrong user or authorizes access to the wrong record.

### Laboratory

Use the secure-service `AuditLog` to compare an unkeyed digest with a keyed HMAC chain. Modify a synthetic event and test detection; then load the corrupted chain and verify it refuses further appends. Explain key storage, checkpointing and why a local HMAC-protected file is tamper-evident but not immutable against a host administrator. The example uses HMAC for log integrity, not as a substitute for modern key management or digital signatures.

---

## Week 7 — Input handling and common application vulnerabilities

Many application vulnerabilities arise when untrusted input crosses an interpreter or authority boundary. SQL injection occurs when data is interpreted as SQL syntax. Use parameterized queries rather than string concatenation. Cross-site scripting (XSS) occurs when untrusted data is interpreted as executable browser content; use context-sensitive output encoding and safe templating. Cross-site request forgery (CSRF) exploits a browser's ambient credentials; use appropriate anti-CSRF defenses and SameSite cookie controls according to the application design.

Other important classes include path traversal, unsafe file handling, server-side request forgery (SSRF), insecure deserialization, command injection, memory-safety errors, race conditions and insecure defaults. Validate inputs at trust boundaries, but do not rely on validation alone. Encode outputs for their destination context and use APIs that preserve data/code separation.

### Worked example: injection

Unsafe:
```python
sql = "SELECT * FROM users WHERE email = '" + email + "'"
```

Safer:
```python
cursor.execute(
    "SELECT * FROM users WHERE email = %s",
    (email,)
)
```

The parameterized form sends the value separately from the SQL syntax. It still requires correct authorization and error handling; it does not make every database operation safe automatically.

### Laboratory

Use OWASP Juice Shop or another intentionally vulnerable lab. Identify one injection flaw and one access-control flaw. Write a regression test for each fix. Do not test public systems without written authorization.

---

## Week 8 — API security and distributed command authority

APIs expose operations and data to callers. Secure API design requires authentication, authorization, input validation, schema control, rate limiting, replay protection where needed, safe error handling, auditability and versioning. Treat every identifier supplied by the client as untrusted. A resource ID is not proof of ownership.

Commands that affect physical or financial state need stronger semantics than read-only queries. Use unique command identifiers, expiration or freshness constraints, target binding, audit records and local policy enforcement. A valid cryptographic token should not allow a remote command to bypass a local emergency stop or other safety interlock.

Rate limits should be defined by principal, resource, operation and system capacity. Overly broad limits can allow one client to block another. Backpressure, quotas, request-size limits and queue controls help protect availability.

### Laboratory

Create a command API threat test plan. In the secure-service API, test CSRF missing/wrong tokens, out-of-scope object IDs, unknown fields, duplicate JSON keys, oversized bodies, malformed JSON, stale record versions and per-IP rate limiting. Verify the local controller rejects commands that violate local constraints even when authenticated by a cloud service.

---

## Week 9 — Data protection, privacy and secrets

Classify data by sensitivity, integrity and retention requirements. Collect only the data needed for a defined purpose. Minimize copies, control access, encrypt sensitive information in transit and at rest where required, and define deletion and backup-expiration behavior. Encryption at rest protects against some storage disclosure scenarios; it does not stop an authorized application process from exposing the data.

Logs can become a high-value attack target. Do not log passwords, access tokens, private keys or unnecessary personal data. Protect audit records against unauthorized modification and deletion, separate operational logs from security audit trails when appropriate, synchronize clocks, and restrict access.

Secrets include passwords, API keys, database credentials, signing keys, certificates and recovery codes. A secret lifecycle includes creation, distribution, storage, access, rotation, revocation and destruction. Rotating a leaked secret without investigating its use may leave an attacker with an active session or copied data.

### Laboratory

Create a data-classification table and retention policy. Scan a test repository for deliberately planted secrets. Replace hard-coded values with environment/secret-store configuration and document rotation steps.

---

## Week 10 — Secure architecture and defense in depth

Security architecture defines trust boundaries, enforcement points, privilege separation, data flows and failure behavior. Defense in depth uses multiple controls so that one control's failure does not automatically expose the asset. Multiple controls are useful only when their failure modes are sufficiently independent.

A local control system may use network segmentation, mutual authentication, least-privilege service identities, command authorization, local allowlists, signed updates and physical controls. The local controller should validate the command's scope and retain local interlocks. A remote cloud service should not become an unrestricted bridge into a physical control network.

Secure defaults matter: disable unused services, remove default credentials, restrict management interfaces, validate certificates, pin supported protocol versions through configuration and avoid exposing debug endpoints. A secure architecture should describe what happens when authentication services, DNS, certificate validation or centralized logging become unavailable.

### Laboratory

Produce a deployment diagram with zones and conduits. For every trust boundary, identify controls, owner, allowed flows, denied flows and failure behavior. Review whether a compromised cloud account can directly disable local safety functions.

---

## Week 11 — Secure development lifecycle and supply-chain security

Security is integrated into each development activity:
- requirements: identify security/privacy needs and threat assumptions;
- design: perform threat modeling and architecture review;
- implementation: apply safe APIs, code review and secure configuration;
- build: protect toolchains, dependencies, secrets and artifact provenance;
- test: run static, dynamic, dependency and targeted security tests;
- release: sign artifacts, record versions and approve known risks;
- operations: monitor, patch, investigate and recover.

SAST analyzes source or compiled code without executing the deployed application. DAST tests a running system from an external perspective. Software composition analysis (SCA) identifies known risks in dependencies. Fuzzing explores unexpected inputs. Manual review identifies design and business-logic problems that tools may not understand. None of these proves the system secure.

Supply-chain threats include malicious packages, compromised build systems, exposed CI credentials, unsigned artifacts, dependency confusion, typosquatting and compromised maintainers. Use dependency pinning, provenance, signatures, least-privilege CI, reproducible builds where feasible and an inventory such as an SBOM.

### Laboratory

Set up a small CI pipeline with static analysis, dependency scanning, unit tests and secret detection. Review the output manually. Identify false positives, false negatives and controls that require human assessment.

---

## Week 12 — Security testing and assurance

Security testing begins with a threat model and security requirements. Tests should cover both allowed and forbidden behavior. A penetration test can demonstrate that an attack path exists; it cannot prove that no vulnerabilities exist. Negative results are bounded by scope, test knowledge, environment and time.

OWASP ASVS provides versioned requirements for application security verification. Reference the version alongside requirement IDs to avoid ambiguity when identifiers change. Use the ASVS as a security requirement and testing baseline, tailoring it to the application risk and architecture.

A good finding includes affected asset, preconditions, reproducible steps in the authorized test environment, impact, evidence, severity rationale, remediation and regression test. Avoid exaggerating a scanner alert into confirmed exploitation without evidence.

### Laboratory

Map at least 15 ASVS 5.0.0 requirements to the capstone. Select five controls and create negative test cases. Record pass/fail evidence and explain what the tests do not prove.

---

## Week 13 — Monitoring, incidents and cyber resilience

Preventive controls cannot guarantee that compromise never occurs. Detection and response are therefore essential. A security incident process identifies events, triages impact, contains the threat, preserves evidence, eradicates persistence, restores service and performs lessons learned.

Monitoring should focus on meaningful signals: anomalous login patterns, privilege changes, unusual command rates, policy denials, unexpected configuration changes, failed integrity checks, unusual data access and suspicious dependency behavior. Alert design should minimize noise and ensure someone owns the response.

Resilience includes the ability to maintain critical functions, isolate compromised elements, recover trusted state and restore service safely. A system should define how it behaves when identity, cloud control, database, network, DNS, time source or update service is unavailable. Availability under attack does not mean accepting every command.

### Laboratory

Write an incident playbook for a compromised operator account and another for a suspected gateway compromise. Include containment authority, evidence preservation, credential rotation, safe local operating mode and restoration criteria.

---

## Week 14 — Integrated security review and capstone

The final security assessment should connect each threat scenario to an asset, requirement, architectural control, implementation mechanism, test and operational owner. It should also document residual risk and unresolved assumptions.

### Final submission

Submit asset and data classification registers, DFD with trust boundaries, threat register, security requirements, identity and authorization model, cryptographic/key-management design, secure deployment diagram, CI security checks, test evidence and two incident playbooks.

### End-of-course problems

1. A user is authenticated. Does that imply they may issue a command to every facility?  
   **Solution:** No. Authentication establishes identity; authorization must evaluate role, resource ownership, scope and contextual restrictions.

2. Why is a signed JWT not necessarily confidential?  
   **Solution:** A typical signed JWT provides integrity/authenticity of claims, not encryption. Its payload can be readable by anyone who obtains the token unless an encryption format is used.

3. Why does a penetration test with no findings not prove the system is secure?  
   **Solution:** The result is bounded by test scope, methods, coverage, assumptions and time. It demonstrates that the chosen tests did not reveal a flaw, not that no flaw exists.

## Selected sources and further study

- NIST SP 800-160 Vol. 1 Rev. 1, *Engineering Trustworthy Secure Systems*: https://csrc.nist.gov/pubs/sp/800/160/v1/r1/final
- NIST SP 800-218, Secure Software Development Framework (SSDF): https://csrc.nist.gov/pubs/sp/800/218/final
- OWASP Application Security Verification Standard 5.0.0: https://owasp.org/www-project-application-security-verification-standard/
- OWASP Cheat Sheet Series: https://cheatsheetseries.owasp.org/
- OWASP Juice Shop: https://owasp.org/www-project-juice-shop/
- PortSwigger Web Security Academy: https://portswigger.net/web-security
- MITRE ATT&CK: https://attack.mitre.org/
- CWE: https://cwe.mitre.org/
- NIST Cybersecurity Framework 2.0: https://www.nist.gov/cyberframework
- Ross Anderson, *Security Engineering*, 3rd ed. author site: https://www.cl.cam.ac.uk/archive/rja14/book.html

Use standards and versioned checklists as controlled baselines. The NIST and OWASP documents are not substitutes for jurisdiction-specific privacy, safety, sector or contractual requirements.


---

## Expanded 14-week lecture notes and practical sequence


### Week 01 — Security objectives and threat modeling foundations

**Lecture notes.** Security engineering begins with assets, safety/business consequences, trust assumptions and adversary capabilities. CIA—confidentiality, integrity and availability—is a useful starting point, not a complete taxonomy. Add authenticity, accountability, privacy, non-repudiation and resilience as needed. Identify attack surfaces, trust boundaries, privileged operations and data flows. Threat modeling is iterative: establish scope, diagram the system, enumerate threats, prioritize risk, select mitigations and validate them. STRIDE is a brainstorming classification, not a complete risk model or severity calculator. Define what an attacker can control and observe.


**Worked application.** For the water-tank service, assets include actuator command authority, operator credentials, telemetry integrity, facility configuration, audit logs and availability. A compromised telemetry pipeline may create a safety hazard even if no confidential data is stolen.


**Practical / assessed work.** Create a system context and data-flow diagram with process, data store, external entity and trust-boundary labels. Build an asset register and attacker capability table.


**Checkpoint.** State the model assumptions, identify one failure mode or limitation, and explain what evidence would change your conclusion.


### Week 02 — Threat analysis and security architecture

**Lecture notes.** Threat analysis should consider spoofing, tampering, repudiation, information disclosure, denial of service and elevation of privilege, plus abuse cases not captured neatly by a category. Model data at rest, in transit and in use. Identify identity providers, secrets, service accounts, update channels, admin planes and third-party dependencies. Threats become actionable only when linked to affected asset, precondition, attack path, impact, existing control and residual risk. Prioritize by exploitability and impact, not by a severity number detached from context.


**Worked application.** If a gateway accepts unsigned commands from any network peer, the risk is not merely ‘spoofing’: an attacker may alter valve state, disrupt availability or trigger an unsafe action. Trace the whole sequence from entry point to protected operation.


**Practical / assessed work.** Complete 15 threat scenarios using attack trees or STRIDE. For each, state preconditions, privilege required, impact, mitigation, owner and verification evidence.


**Checkpoint.** State the model assumptions, identify one failure mode or limitation, and explain what evidence would change your conclusion.


### Week 03 — Security requirements and assurance levels

**Lecture notes.** A security requirement should describe a control and acceptance condition. Map system risk to requirements for identity, authorization, cryptography, logging, resilience, secure configuration, data handling, recovery and supply chain. NIST SP 800-160 provides a systems-security-engineering lifecycle framing; OWASP ASVS 5.0 provides testable application security requirements for web applications and services. These are complementary scopes, not interchangeable checklists. Select assurance depth based on data sensitivity, exposure, threat and consequence. A standard’s level is not a certification unless the relevant assessment process is actually followed.


**Worked application.** ‘The system shall be secure’ is not actionable. ‘Every actuator command shall be authenticated, authorized for the owning facility and logged with principal, command ID, timestamp and decision outcome’ provides a verifiable security objective; test it with missing/expired identities and cross-facility access attempts.


**Practical / assessed work.** Map your API to relevant OWASP ASVS requirements and NIST lifecycle activities. Create traceable requirements with acceptance tests and residual-risk owners.


**Checkpoint.** State the model assumptions, identify one failure mode or limitation, and explain what evidence would change your conclusion.


### Week 04 — Identity, authentication and sessions

**Lecture notes.** Authentication establishes which principal is acting; authorization determines what that principal may do. Use established identity protocols rather than inventing credential exchanges. Passwords should be stored with dedicated password-hashing functions and salts, not fast general hashes. Multi-factor authentication improves resistance to credential theft. Session handling requires secure cookies or tokens, rotation on privilege change, expiry, revocation strategy, CSRF protection where applicable and careful reset flows. Rate-limit authentication without enabling easy account lockout denial of service. Do not log secrets, bearer tokens or password material.


**Worked application.** An access token is a bearer credential: anyone holding it may be able to act as the user until expiry/revocation. JWT signature verification is not enough; validate issuer, audience, expiry, not-before, algorithm policy and the authorization state needed for the operation.


**Practical / assessed work.** Implement an authentication threat checklist for the sample service. Test expired, malformed, revoked, wrong-audience and wrong-issuer tokens; verify secrets never appear in logs.


**Checkpoint.** State the model assumptions, identify one failure mode or limitation, and explain what evidence would change your conclusion.


### Week 05 — Authorization, RBAC, ABAC and ownership

**Lecture notes.** Authorization is a server-side policy decision at every protected operation. RBAC assigns permissions to roles; ABAC evaluates attributes such as tenant, facility, resource owner, time and context. A role check alone often misses object-level access control. Enforce deny-by-default, least privilege, explicit ownership and separation of duties. Centralize policy decisions or share a well-tested policy library; avoid scattered checks. Apply authorization after canonicalizing the resource identity but before exposing data or mutating state. Test vertical and horizontal privilege escalation, direct object references, revoked users and cross-tenant access.


**Worked application.** A SUPERVISOR may have permission to view a facility’s sensor but not another facility’s sensor. The effective rule is role AND facility ownership, not role OR ownership. The database query should scope records by authorized tenant where possible, reducing the risk of a missed post-fetch check.


**Practical / assessed work.** Implement role plus facility ownership policy. Add tests for operator, supervisor, admin, revoked principal, unknown role, cross-facility read and cross-facility actuator command.


**Checkpoint.** State the model assumptions, identify one failure mode or limitation, and explain what evidence would change your conclusion.


### Week 06 — Cryptography and key lifecycle

**Lecture notes.** Use vetted cryptographic libraries and protocols. A cryptographic hash provides a digest, not confidentiality. Password hashing must be deliberately expensive and salted; general-purpose hashes such as SHA-256 are not password storage. Authenticated encryption with associated data protects confidentiality and integrity under correct nonce/key use. Digital signatures provide verifiable origin/integrity under key assumptions; they do not prove the signer was authorized or honest. Key management includes generation, distribution, storage, rotation, revocation, backup, compromise response and destruction. Never design a custom cipher or hard-code production keys.


**Worked application.** AES-GCM nonce reuse under the same key can catastrophically undermine security. A correct library call does not remove the requirement to ensure nonce uniqueness and enforce key rotation limits. Cryptographic agility should be deliberate, not an excuse to accept attacker-controlled algorithms.


**Practical / assessed work.** Review a sample cryptographic design. Identify primitive, mode, nonce, key source, lifetime, authenticated context, rotation trigger and compromise procedure. Replace any homemade password hash with a modern password-hashing library in the controlled lab.


**Checkpoint.** State the model assumptions, identify one failure mode or limitation, and explain what evidence would change your conclusion.


### Week 07 — Input handling and application vulnerability classes

**Lecture notes.** Treat input as untrusted even after authentication. SQL injection is prevented by parameterized queries, not string escaping alone. Contextual output encoding prevents many XSS cases; sanitization is a separate, carefully scoped operation. CSRF protection depends on browser credential behavior and request context. SSRF defenses need destination allowlists, DNS/IP resolution checks, redirect control and network egress policy. Path traversal requires canonicalization and safe path resolution. Deserialization and template evaluation can create code execution risks. Validate business invariants server-side; client validation is only usability support.


**Worked application.** A search endpoint that parameterizes the SQL query can still be vulnerable to business-logic abuse if a user can request another tenant’s records. Injection and authorization are distinct control classes and need independent tests.


**Practical / assessed work.** Use OWASP Juice Shop or PortSwigger Web Security Academy only in the intended training environment. Reproduce one issue, identify the root cause, implement a fix and add a regression test; do not test third-party targets.


**Checkpoint.** State the model assumptions, identify one failure mode or limitation, and explain what evidence would change your conclusion.


### Week 08 — API, network and distributed-system security

**Lecture notes.** APIs need authenticated transport, strong identity, scoped authorization, schema validation, rate limits, replay controls and safe error handling. TLS protects a channel under certificate and endpoint-validation assumptions; it does not replace application authorization. mTLS can authenticate workloads but does not determine what a workload may do. Protect against replay with nonces, timestamps, sequence numbers or idempotency records as appropriate. Treat webhooks as untrusted input and verify signatures over the exact canonical payload and freshness window. Design network segmentation and egress controls around trust boundaries.


**Worked application.** A signed webhook with a valid signature may still be a replay of an old authorized command. Include event identity and freshness, and ensure processing is idempotent. Clock-based freshness checks need a skew allowance and a replay cache or durable event ID.


**Practical / assessed work.** Create a threat model for device-to-gateway and gateway-to-cloud APIs. Test invalid certificates, stale signatures, duplicate command IDs, rate-limit behavior and malformed payloads.


**Checkpoint.** State the model assumptions, identify one failure mode or limitation, and explain what evidence would change your conclusion.


### Week 09 — Data protection, privacy and secrets

**Lecture notes.** Data protection starts with classification and minimization. Collect only what is needed, define retention and deletion, restrict access, encrypt sensitive data and manage keys separately from data. Encryption at rest does not prevent misuse by an authorized compromised process. Logs can become a secondary data store and must be included in retention and access policy. Secrets belong in a secret manager or protected runtime injection mechanism, not source control, images or command-line history. Backups contain sensitive data and need access controls, encryption and restore testing. Privacy requirements should be traced to architecture and verification.


**Worked application.** Telemetry may appear low-risk but reveal facility occupancy or usage patterns. Aggregate and retain only what the operational purpose requires. A backup that cannot be restored is not a resilience control; a backup that can be downloaded by every operator is a security problem.


**Practical / assessed work.** Build a data inventory and retention matrix. Scan the demo repository for synthetic secrets, add safe secret injection, and verify logs redact credentials and tokens.


**Checkpoint.** State the model assumptions, identify one failure mode or limitation, and explain what evidence would change your conclusion.


### Week 10 — Secure architecture, infrastructure and cloud

**Lecture notes.** Defense in depth uses multiple controls with different failure modes; duplicating the same weak control does not create meaningful independence. Secure defaults, least privilege, segmentation, hardened configuration, resource limits and patch management reduce attack paths. Containers share a host kernel and are not a complete isolation boundary. Cloud IAM policies should scope resource, action and condition. Infrastructure-as-code changes need review, state protection and drift detection. Device security includes secure boot/update, firmware authenticity, debug-port controls, physical access and recovery. Model shared dependencies and common-cause compromise explicitly.


**Worked application.** Two application replicas with the same long-lived cloud admin key do not provide independent security. A stolen key compromises both. Separate workload identities and constrain each to the resources/actions it needs.


**Practical / assessed work.** Produce a secure deployment architecture and threat model for the tank system. Include network zones, identities, secret storage, update path, backup access and dependency boundaries.


**Checkpoint.** State the model assumptions, identify one failure mode or limitation, and explain what evidence would change your conclusion.


### Week 11 — Secure development lifecycle and supply chain

**Lecture notes.** Security is a lifecycle property. Integrate threat modeling, security requirements, code review, SAST, DAST, software composition analysis, secret scanning, fuzzing, dependency pinning, provenance and patching. No tool catches every vulnerability. Use SBOMs to inventory components and policy gates to handle known vulnerabilities, but evaluate exploitability and reachability. Reproducible builds and signed provenance improve confidence in what was built and deployed. Protect CI identities and build secrets because the pipeline can become a high-value supply-chain target. Record exceptions with owner and expiry.


**Worked application.** A dependency vulnerability scanner finding does not prove that a flaw is exploitable in the deployed configuration; absence of a finding does not prove safety. The engineering action is risk triage, patching, reachability analysis and evidence-backed exception handling.


**Practical / assessed work.** Create a secure pipeline checklist for the labs. Add dependency lockfiles, static checks and secret scan; produce an SBOM and document how a critical dependency advisory would be triaged.


**Checkpoint.** State the model assumptions, identify one failure mode or limitation, and explain what evidence would change your conclusion.


### Week 12 — Security testing and assurance

**Lecture notes.** Security testing should be derived from threats and requirements. Combine code review, static analysis, dynamic testing, fuzzing, configuration review, penetration testing in authorized scope and abuse-case testing. Test authorization at object and function levels, session revocation, error behavior, input parsing, resource exhaustion, cryptographic configuration and update verification. Map results to ASVS requirements or a comparable assurance catalogue. Keep test scope, permission and environment explicit. A vulnerability scan is not a complete penetration test, and a penetration test is not proof that no vulnerabilities remain.


**Worked application.** A 200 response from a protected endpoint is not proof of authorization. Verify the returned object belongs to the requesting principal. Similarly, a 403 response is not sufficient if the server has already performed a protected side effect.


**Practical / assessed work.** Build a threat-to-test matrix and run `pytest -q labs/05-security/secure_service`. Map controls to `ASVS-WSTG-MATRIX.csv`; add at least five negative tests of your own. Produce findings with reproducible steps, severity rationale, fix, regression test and residual limitation. Test only this local course service or another explicitly authorized target.


**Checkpoint.** State the model assumptions, identify one failure mode or limitation, and explain what evidence would change your conclusion.


### Week 13 — Monitoring, incident response and resilience

**Lecture notes.** Security operations depend on meaningful telemetry, detection rules, incident roles, evidence preservation, communication and recovery. Log security-relevant events with principal, action, resource, result and correlation ID while avoiding secrets and unnecessary personal data. Define incident severity and escalation, containment, eradication, recovery and lessons learned. Backups must be isolated against destructive access and restore-tested. Rotate compromised credentials and revoke sessions. Availability controls include rate limiting, dependency isolation, graceful degradation and tested failover. A resilient system should fail into a bounded, well-understood state.


**Worked application.** If a gateway signing key is compromised, merely changing the key on the server is incomplete. Identify affected devices, revoke trust, issue replacements, rotate dependent credentials, examine command history and determine whether the actuator state requires manual inspection.


**Practical / assessed work.** Run a tabletop incident: leaked service credential plus suspicious actuator commands. Produce an event timeline, containment decision, credential rotation plan, recovery verification and post-incident actions.


**Checkpoint.** State the model assumptions, identify one failure mode or limitation, and explain what evidence would change your conclusion.


### Week 14 — Integrated secure-system design review

**Lecture notes.** The final security review connects system context, threat model, security requirements, architecture, implementation, test evidence, operational controls and residual risk. Explain how each high-priority threat is prevented, detected or contained; identify controls that share dependencies. Include secure update, secrets, identity, logging, backup and incident response. Report unmitigated risks and assumptions. Reviewers should be able to trace from asset and threat to requirement, design control, test and operational owner. Do not label the system ‘secure’; define the assessed version, threat model and assurance boundary.


**Worked application.** For the tank controller, actuator commands require authenticated identity, facility-scoped authorization, anti-replay and audit evidence. Local safe behavior must remain available when cloud identity or network services fail; availability and safety trade-offs must be explicit.


**Practical / assessed work.** Submit the threat model, ASVS mapping, architecture, authorization implementation, secure-service test report, SBOM, incident tabletop and residual-risk register. Include the exact test command/output, Python version, service configuration, redacted HTTP transcript, audit-chain verification and remaining gaps. Defend one rejected mitigation and its rationale.


**Checkpoint.** State the model assumptions, identify one failure mode or limitation, and explain what evidence would change your conclusion.


## Assessment design

| Component | Weight | Evidence expected |
|---|---:|---|
| Weekly problem sets and derivations | 20% | Correct reasoning, assumptions, units and worked calculations |
| Practical labs and reproducibility | 25% | Executable/model artefacts, tests, environment and results |
| Midterm assessment | 15% | Core concepts, derivations and design trade-offs |
| Individual cumulative project | 25% | Correct implementation/model, traceability and technical report |
| Final examination and oral defense | 15% | Transfer to unseen cases and explanation of submitted work |


## Minimum submission standard

Every practical report must include: objective; theory; assumptions; environment/tool versions; procedure; expected result; actual result; raw evidence; analysis; limitations; references. A screenshot alone is not proof of a model, test, or database property. Never label an external-tool lab as passed unless it was run in the named tool.


## End-to-end application security lab — secure-service implementation

`labs/05-security/secure_service/` is the primary local implementation project for this course. It is a standard-library WSGI JSON API, intentionally bound to loopback only. It implements password derivation with per-user scrypt salts, server-side opaque sessions, expiry/logout, login session rotation, CSRF-protected write operations, role/resource authorization, tenant isolation, request-size and schema validation, per-source rate limiting, response security headers, optimistic record versioning, and an HMAC-linked JSONL audit chain. Its test suite exercises both positive and negative cases.

The ASVS/WSTG matrix maps controls to test evidence; the guided lab provides safe local exercises for session handling, CSRF, IDOR, rate limiting, audit integrity and headers. The service is not a production identity provider: user/session state is in memory, its local development server is plain HTTP, it omits MFA/federation/password recovery/distributed sessions/key-rotation services and it has no independent security assessment. The test suite does not establish ASVS compliance or absence of vulnerabilities. The application should never be bound to a LAN/public interface or tested with real credentials/data.


## Edition 3 lab annex — local secure-service implementation

`labs/05-security/secure_service/` now provides a loopback-only WSGI training service with scrypt password verifiers, opaque server-side sessions, expiry/rotation/logout, CSRF-protected writes, per-IP rate limiting, tenant/object authorization, strict bounded JSON, optimistic version checks, security headers and an HMAC-linked fsynced audit log. Run `PYTHONPATH=labs/05-security/secure_service pytest -q labs/05-security/secure_service` from the curriculum root; use `python labs/05-security/secure_service/run.py` to launch the local service. A live loopback smoke test returned login 200, session 200, create 201 and cross-tenant read 404. The service is process-local and is **not production-ready**: no TLS termination, MFA, federated identity, distributed sessions, external key custody, scanner certification or formal ASVS assessment is claimed. Map test cases to [OWASP ASVS 5.0](https://asvs.owasp.org/) and [WSTG](https://owasp.org/www-project-web-security-testing-guide/latest/), and use [Juice Shop](https://owasp.org/projects/juice-shop) only as a deliberately vulnerable local training target.

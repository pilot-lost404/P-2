# Safety, Reliability and Risk Analysis — Expanded Course Reader (2026 Edition)

> **Level:** Advanced undergraduate / early graduate; probability, statistics, calculus, basic systems engineering and engineering design prerequisites.  
> **Duration:** 14 teaching weeks, 8–12 hours/week  
> **Status:** Self-study reader benchmarked against official 2026 university syllabi and primary documentation. It is not an accredited course or professional certification.

## Course outcomes

1. Distinguish hazards, losses, accidents, failure modes, risk, reliability and safety constraints.

2. Perform qualitative and quantitative FMEA/FMECA, FTA, ETA, RBD and STPA with explicit assumptions.

3. Calculate reliability, availability, failure probability, cut-set contribution and uncertainty bounds.

4. Develop testable safety requirements, causal scenarios and structured safety arguments.

5. Explain the limitations of risk matrices, independence assumptions and rare-event estimates.


## How to work through the course

For each week, read the concept notes, reproduce the derivation or model, complete the practical task, answer the challenge without looking at references, and record assumptions and evidence. A passing submission must include the exact environment, expected criterion, observed result and limitations. Use the weekly practical tasks as assessed work, not optional reading.


## Foundation reader retained from the first edition

The original first-edition chapter is preserved below for continuity. The expanded notes that follow add the missing depth, quantitative reasoning, labs and assessment structure identified in the academic audit.


---


# Course 3 — Safety and Risk Analysis
**Level:** Upper-undergraduate / early graduate  
**Duration:** 14 teaching weeks  
**Expected workload:** 8–10 hours per week  
**Prerequisites:** Basic systems engineering, probability, block diagrams, requirements and elementary control concepts.

## Course description

Safety engineering aims to prevent unacceptable losses arising from system behavior. It considers the system as a whole: hardware, software, operators, procedures, maintenance, organizations, environment and interactions among them. A component can operate exactly as specified while the overall system remains unsafe. For this reason, safety analysis cannot be reduced to finding defective parts or assigning a risk score to each component.

This course introduces hazard analysis, Failure Modes and Effects Analysis (FMEA/FMECA), Fault Tree Analysis (FTA), Event Tree Analysis (ETA), System-Theoretic Process Analysis (STPA), safety requirements, barriers, assurance cases and lifecycle safety management. It emphasizes the strengths and limitations of each technique. A remote water-tank controller provides a consistent example, but the material is educational and does not constitute a certified safety assessment.

## Learning outcomes

Students should be able to:
1. Distinguish loss, hazard, failure, fault, error, accident and risk.
2. Define system-level safety constraints and operating assumptions.
3. Conduct a structured FMEA and explain its limitations.
4. Construct qualitative and simple quantitative fault trees.
5. Use event trees to analyze possible consequence paths.
6. Apply the core STPA steps to software-intensive control systems.
7. Derive safety requirements and allocate them to design elements.
8. Evaluate independent protection layers, human factors and common-cause failures.
9. Construct a structured safety argument supported by evidence.
10. Maintain a hazard log and reassess risk when the design or operating context changes.

---

## Week 1 — Safety engineering foundations

### 1.1 Loss, hazard, accident and risk

A **loss** is an unacceptable outcome for a stakeholder, such as injury, environmental damage, major property damage, mission failure or loss of essential service. A **hazard** is a system state or set of conditions that, together with a particular environment, can lead to a loss. An **accident** is an undesired event or sequence resulting in a loss. A **failure** is the inability of an element to perform a required function; a hazard can exist without a component failure.

For the tank example:
- Loss L-1: a person is injured by electrical or mechanical equipment.
- Loss L-2: water causes unacceptable property damage.
- Hazard H-1: tank water level exceeds the safe physical limit.
- Hazard H-2: pump is energized while the relevant isolation condition is not satisfied.
- Hazard H-3: the controller fails to provide a required shutdown when the level input is unsafe or invalid.

Risk is often treated as a combination of likelihood and consequence, but the meaning of each quantity must be explicit. A numerical score is not a substitute for identifying the scenario, assumptions and uncertainty. Low estimated frequency can coexist with intolerable consequences or weak evidence.

### 1.2 Safety as a system property

A safety problem may arise from unsafe control action, incorrect feedback, timing, inadequate process model, misunderstood displays, maintenance error or conflicting goals. An operator may issue a valid command under a misleading display; the software may accept the request; the actuator may work; the combined result can still be hazardous.

### 1.3 Analysis boundary

Define the system, environment, users, lifecycle stage and losses before selecting an analysis technique. Include maintenance, test, startup, degraded operation and disposal when relevant. State assumptions about sensor accuracy, power quality, actuator response, operator availability and external dependencies.

### Laboratory

Write a one-page safety scope. Identify at least three losses, five hazards, key assumptions and the stakeholders authorized to accept residual risk. Do not assign scores yet.

---

## Week 2 — Hazard identification and preliminary hazard analysis

Hazard identification asks what system states or interactions could create unacceptable losses. It should be performed early and revisited as the architecture evolves. Techniques include structured brainstorming, checklists, functional hazard analysis, guide-word analysis, scenario analysis, interface analysis, operating experience and STPA.

A preliminary hazard analysis (PHA) records hazards before detailed design is complete. A useful record includes hazard ID, description, causes or scenarios, potential losses, operating modes, initial risk rationale, constraints, owner, evidence needed and status. Avoid writing a hazard as a component failure only. "Sensor failed" is not a system hazard statement; "controller uses an invalid level measurement and continues filling" is more informative.

### Worked example

| Hazard | Operating context | Potential loss | Initial constraint |
|---|---|---|---|
| H-1: tank above safe level | filling / unattended | property damage, injury | filling must be stopped before physical overflow |
| H-2: pump remains energized when dry-run prohibited | low supply / sensor fault | equipment damage | pump operation must be inhibited under defined low-water condition |
| H-3: unsafe remote command accepted | remote operation | injury / damage | local safety interlocks must dominate remote commands |

The constraint is at system level; later requirements allocate it to components and interfaces.

### Laboratory

Produce a PHA for normal fill, manual override, sensor fault, network loss, power restoration, maintenance and calibration. For every hazard, identify at least two plausible scenarios.

---

## Week 3 — Failure Mode and Effects Analysis (FMEA)

FMEA is a bottom-up, structured technique. It starts with an item or function, identifies how it could fail, and analyzes local, next-higher-level and system effects. A typical row includes item/function, failure mode, cause, local effect, end effect, detection, existing controls, severity, occurrence, recommended action and responsible owner.

A **failure mode** describes how a function or item fails: stuck open, stuck closed, incorrect output, intermittent operation, loss of output or out-of-tolerance behavior. A **cause** explains why. An **effect** explains what happens at local and system levels. Good FMEA does not stop at the component boundary.

### 3.1 RPN and its limits

Some organizations use a Risk Priority Number:

\[
RPN = S \times O \times D
\]

where S is a severity rating, O an occurrence rating, and D a detectability rating (often a higher D means harder to detect). This is a ranking aid, not a calibrated probability or universal risk metric. Different combinations can yield the same RPN while representing very different safety concerns. A catastrophic severity score must not be hidden by low occurrence or easy detection. Use severity categories and mandatory action rules in addition to any RPN.

### Worked example

A valve can fail stuck open. Assume a teaching scale S=9, O=3, D=6. RPN=162. Another failure has S=4, O=9, D=4, also RPN=144. These numbers do not prove the first event is "only slightly riskier"; the severity difference may dominate the decision. The team should examine the physical scenario, evidence and independent protections.

### Laboratory

Complete an FMEA with at least eight rows covering sensor, controller, communication path, pump, valve, power supply and operator interface. Include system effect, detection method and a recommended action. Explain which rows require escalation regardless of the RPN.

---

## Week 4 — FMECA, criticality and prioritization

FMECA extends FMEA by adding a criticality assessment. Quantitative criticality calculations require defensible failure-rate data, mission time, failure-mode fractions, operating profiles and assumptions. When data is unavailable, a qualitative criticality matrix may be more honest than fabricated numerical precision.

The analysis should identify single-point failures, common-cause failures, latent failures, diagnostic coverage, repair time and exposure duration. A single-point failure is particularly important when no independent protection prevents the hazard. A latent failure is present but not detected until a second event or demand exposes it.

A fault tree and FMECA are complementary. FMECA follows components or functions upward to effects; a fault tree starts with a defined top event and decomposes the combinations that can produce it. Neither replaces the other.

### Worked example

Suppose a high-level sensor can become stuck low. If a separate independent high-high switch exists, the hazard may still be prevented—provided it does not share the same power supply, wiring route, sensing principle, maintenance error or software path in a way that defeats independence. Independence must be argued, not assumed from separate labels.

### Laboratory

Identify single-point and common-cause failure candidates from the prior FMEA. Add a criticality rationale and specify what evidence would be required to treat a protective channel as independent.

---

## Week 5 — Fault Tree Analysis (FTA)

FTA is a top-down deductive analysis. Begin with a precisely defined top event, then use logical gates to express combinations of lower-level events. An OR gate means any input event can cause the parent event; an AND gate means all input events are required. Basic events may be component failures, human actions, environmental conditions or external events.

```mermaid
flowchart TD
  TOP["TOP: Tank overflows"]
  TOP --> OR1{{"OR"}}
  OR1 --> A["Inlet remains open"]
  OR1 --> B["Inflow exceeds safe capacity"]
  A --> OR2{{"OR"}}
  OR2 --> C["Valve stuck open"]
  OR2 --> D["Controller fails to close valve"]
  D --> AND1{{"AND"}}
  AND1 --> E["High-level detection unavailable"]
  AND1 --> F["No effective independent shutdown"]
```

The tree must reflect the actual system boundary, time window and operating conditions. Avoid mixing incompatible event definitions. If "sensor unavailable" already includes disconnected wiring and failed power, do not count those causes again below it without a carefully defined structure.

### 5.1 Minimal cut sets

A cut set is a combination of basic events sufficient to cause the top event. A minimal cut set is one where no proper subset is sufficient. Cut sets help identify critical combinations and single-point vulnerabilities.

### 5.2 Simple probability calculation

If A and B are independent basic events with probabilities 0.01 and 0.02, and the top event requires both (AND), then \(P(A \cap B)=0.01 \times 0.02=0.0002\). If the top event occurs when either A or B occurs (OR), then \(P(A \cup B)=P(A)+P(B)-P(A)P(B)=0.0298\). Independence must be justified; common-cause failure invalidates the simple product.

### Laboratory

Construct a fault tree for "water level exceeds the physical safe limit." Identify minimal cut sets. State whether each independence assumption is credible and identify common-cause paths.

---

## Week 6 — Event Tree Analysis (ETA) and barriers

ETA is an inductive technique. Start with an initiating event and branch through the success or failure of protective functions to identify possible outcomes. The branches describe scenario progression; they do not automatically assign probabilities.

Example initiating event: inlet valve fails open. Barriers may include high-level alarm, independent high-high switch, automatic isolation and operator response. The event tree should consider barrier failure, delayed response, power loss and whether a barrier is truly independent.

Barrier management asks:
- What is the safety function?
- What demand activates it?
- What performance is required?
- How is it tested and maintained?
- How can it be defeated by common cause or human action?
- What evidence proves it is available when demanded?

A backup system is not independent if it shares the same faulty sensor, power source, code path or maintenance procedure.

### Laboratory

Build an event tree beginning with a valve stuck-open event. Include at least three barriers and four distinct consequence paths. Explain which barrier has the greatest influence on the outcome and what evidence supports that claim.

---

## Week 7 — STPA: system-theoretic safety analysis

STPA is a hazard analysis method based on systems theory and control. It is particularly useful for software-intensive systems where unsafe behavior can arise from interactions among correctly functioning components. It does not require a component failure to be the initiating cause.

The core process is:
1. Define losses, hazards and system-level safety constraints.
2. Model the safety control structure, including controllers, controlled processes, actuators, sensors, feedback and external influences.
3. Identify unsafe control actions (UCAs).
4. Identify causal scenarios that could lead to each UCA and derive constraints or requirements.

Four general UCA categories are commonly examined:
- A required control action is not provided.
- An unsafe control action is provided.
- A control action is provided too early, too late or in the wrong order.
- A control action lasts too long or stops too soon.

For the tank system, "command close valve" can be unsafe if issued too late, omitted during a high-high condition, issued when the valve must remain open for a safe purge, or held for an incorrect duration. Context determines safety.

### Laboratory

Draw a control structure. Identify at least six UCAs and map each to a safety constraint. For each UCA, produce two causal scenarios involving feedback, process model, actuator, sensor, operator or coordination.

---

## Week 8 — Causal scenarios, control loops and software

A control loop depends on the controller's process model: what it believes about the controlled process, current state, capabilities and environment. Inaccurate or delayed feedback can make a reasonable control algorithm issue an unsafe command. Software can create hazards through incorrect timing, mode confusion, stale data, incorrect assumptions or unsafe interactions—even if it contains no traditional hardware fault.

A scenario should explain a causal path, not merely repeat the hazard. Example: the sensor reports a plausible but stale low level; the controller's validity logic does not detect staleness; the controller believes the tank is below target; the valve remains open; the independent high-high switch shares the sensor's power feed and is also unavailable. This scenario suggests requirements for freshness, plausibility, diagnostics, independent power and proof testing.

### Laboratory

Write five causal scenarios for one UCA. At least one must involve maintenance, one communication delay, one misleading feedback signal, one human-machine interface and one common-cause failure.

---

## Week 9 — Human factors and operational safety

Human action should be analyzed in context rather than treated as a generic "operator error." Consider workload, display design, alarms, procedures, training, fatigue, authority, incentives, maintenance access and handover. An alarm can be technically correct but operationally useless if it is ambiguous, repeated excessively or arrives after the response window.

Mode confusion occurs when the operator believes the system is in one mode while it is in another. A safe design makes mode and authority visible, prevents ambiguous state transitions and ensures critical controls have clear feedback. Procedures should be tested with representative users and realistic interruptions.

Safety analysis must include test, calibration, configuration, cleaning, bypass, degraded mode and repair. A control that is safe during normal operation may be unsafe during maintenance when interlocks are bypassed.

### Laboratory

Conduct a task analysis for an operator acknowledging a high-level alarm and entering maintenance mode. Identify slips, mistakes, mode confusion and organizational conditions. Propose design changes, not only training.

---

## Week 10 — Safety requirements and risk controls

Hazard analysis becomes useful when it produces design constraints and verifiable requirements. A safety requirement should identify the required behavior, triggering condition, timing, operating context and acceptance criteria. Requirements should be allocated to design elements and linked to verification evidence.

Use the hierarchy of controls carefully. Prefer eliminating a hazard through design where feasible; otherwise reduce risk through engineering controls, independent protective functions, administrative controls and warnings. Warnings and procedures are not equivalent to inherently safer design.

A safety requirement may be:
`SAFE-014: When the high-high channel detects a level above its trip threshold, the independent shutdown path shall de-energize the inlet valve within 300 ms, independent of the remote service.`

The exact threshold, trip logic, valve safe state and timing budget must be derived from physical and operational analysis. The requirement is an educational example, not an approved safety specification.

### Laboratory

For each high-severity hazard, derive one prevention constraint, one detection requirement, one mitigation requirement and one test or analysis. Trace them to system elements.

---

## Week 11 — Safety cases and assurance arguments

A safety case is a structured argument that a system is acceptably safe for a defined application and context, supported by evidence. It is not a document that asserts safety by listing completed analyses. A common structure is Goal Structuring Notation (GSN): claims, strategies, subclaims, contexts, assumptions, justifications and evidence.

Example top-level claim: "The tank control system is acceptably safe for unattended operation within the specified operating envelope." This claim must be decomposed into arguments about overflow prevention, electrical isolation, sensor fault handling, local autonomy, maintenance and operator response. Evidence may include analysis reports, test results, inspection records, operating data and independent review.

An argument can be invalid even when its evidence is real. For example, a successful software unit test does not prove the physical valve closes within the required time. Evidence must support the claim at the same abstraction level and operating context.

### Laboratory

Create a GSN-style assurance argument with one top claim, at least four subclaims, explicit context, assumptions, strategies and evidence references. Mark any claim for which evidence is missing.

---

## Week 12 — Functional safety standards and lifecycle integration

Safety standards define lifecycle processes and evidence expectations for particular domains. IEC 61508 is a foundational generic functional safety standard for electrical/electronic/programmable electronic safety-related systems. Sector standards such as ISO 26262 or IEC 61511 tailor principles to particular industries. Applicability depends on product, jurisdiction, contract and intended use.

A standard should not be treated as a recipe that makes a system safe by compliance alone. The engineering team must identify applicable editions, scope, lifecycle responsibilities, independence requirements, competence expectations and evidence. Standards may be copyrighted; use official publisher or library access rather than unauthorized copies.

Risk reduction may involve design changes, protective functions, procedures or operating limitations. Safety integrity levels (SILs) are not generic labels to add to a design. They involve specific allocation and lifecycle methods defined by applicable standards, with quantitative and qualitative requirements.

### Laboratory

Prepare a standards applicability memo for the educational tank controller. Identify which standard families might be relevant in an actual industrial context, what information is missing to determine applicability, and why no SIL claim is justified from the exercise.

---

## Week 13 — Change, operations and continuous safety management

Safety is not frozen at design release. Equipment ages, software is updated, suppliers change, operators learn workarounds, operating environments shift and maintenance practices evolve. A change must be assessed for new hazards and for changes to existing assumptions, failure rates, diagnostic coverage and safety functions.

Maintain a hazard log with status, owner, decision, rationale, evidence and review date. Record accepted residual risk and who has the authority to accept it. Track safety-significant anomalies, proof-test results, overrides, bypass duration, recurring alarms and incidents. Leading indicators can reveal weakening controls before a loss occurs.

### Laboratory

A valve manufacturer changes the actuator model and response time. Perform a change impact review: requirements, timing budgets, hazard analysis, common-cause assumptions, proof-test procedure, maintenance parts and verification evidence.

---

## Week 14 — Integrated safety assessment

The final safety review should connect:
- defined losses and hazards;
- constraints and safety requirements;
- FMEA/FMECA findings;
- fault-tree and event-tree results;
- STPA control actions and causal scenarios;
- protection architecture and independence argument;
- verification procedures and results;
- residual risk acceptance;
- safety-case claims and evidence;
- assumptions and unresolved issues.

### Final submission

Submit the system definition, hazard log, FMEA, fault tree, event tree, STPA control structure and UCA table, safety requirements, safety-case argument and a review report. The analysis must distinguish known facts, estimates, assumptions and unresolved uncertainty.

### End-of-course problems

1. Is "level sensor failed" a hazard?  
   **Solution:** Not by itself. It is a failure mode. A hazard describes the unsafe system state or condition, such as continued filling while the level is unknown or invalid.

2. Why can two separate shutdown channels still share a common-cause failure?  
   **Solution:** They may share power, sensor physics, wiring, environmental exposure, software, maintenance procedure, configuration data or human oversight.

3. Why is RPN not a probability?  
   **Solution:** S, O and D are typically ordinal ratings. Multiplying them creates a ranking number, not a calibrated probability of loss. Different score combinations can hide different severity profiles.

## Selected sources and further study

- MIT STAMP Institute, STPA and CAST handbooks: https://www.mit.stamp-institute.com/handbooks
- Nancy Leveson, *Engineering a Safer World* (MIT Press): https://mitpress.mit.edu/9780262533690/engineering-a-safer-world/
- NASA Systems Engineering Handbook: https://www.nasa.gov/reference/systems-engineering-handbook/
- NASA Systems Safety and Mission Assurance resources: https://sma.nasa.gov/
- IEC functional safety standards catalogue: https://www.iec.ch/functional-safety
- UK HSE, risk assessment and safety management guidance: https://www.hse.gov.uk/risk/
- SEBoK safety engineering knowledge area: https://sebokwiki.org/

The STPA handbook is especially useful for worked control-structure examples. The NASA handbook provides lifecycle context. Formal standards should be consulted in their controlled official editions for regulated work.


---

## Expanded 14-week lecture notes and practical sequence


### Week 01 — Safety concepts, losses, hazards and risk

**Lecture notes.** Safety is a system property: unsafe outcomes can emerge from interactions even when every component operates within its local specification. Define losses (what must not happen), hazards (system states or conditions that can lead to losses), constraints and accidents. Risk involves uncertainty about consequence and likelihood; a single matrix cell is a prioritization aid, not a physically meaningful probability. Define system boundary, operating modes, exposure, severity categories and risk acceptance authority. Distinguish safety from reliability: a highly reliable system can consistently perform an unsafe function, while a system can fail safely yet be unavailable.


**Worked application.** A valve that remains open may be a failure mode. ‘Tank overflows while people are in the area’ is a hazard/loss scenario. The safety constraint might require independent high-level protection or a verified shutdown path under specified sensor and power faults.


**Practical / assessed work.** Write a loss table, hazard log and initial safety constraints for the tank system. For each hazard, identify operating modes, causal factors and stakeholders affected.


**Checkpoint.** State the model assumptions, identify one failure mode or limitation, and explain what evidence would change your conclusion.


### Week 02 — Hazard identification and preliminary analysis

**Lecture notes.** Start hazard analysis before detailed design. Use checklists, What-If, HAZID, HAZOP guidewords, interface review, energy analysis and operational scenario walkthroughs. Preliminary Hazard Analysis identifies hazards, causes, effects, existing controls, initial severity/likelihood judgement and recommended actions. Avoid turning the PHA into a list of component failures only. Include software state, operator action, maintenance, environmental conditions, common cause and foreseeable misuse. Document the scope of the analysis and what was not examined.


**Worked application.** For ‘no level measurement’, causes include sensor open circuit, blocked transducer, wrong tank geometry, frozen timestamp, loss of gateway power and invalid calibration. Different causes may require different detection and mitigation; ‘sensor failure’ is too broad to support design.


**Practical / assessed work.** Perform a HAZID/What-If review across normal, startup, maintenance, cleaning, power-loss and communication-loss modes. Create a hazard register with owner and action status.


**Checkpoint.** State the model assumptions, identify one failure mode or limitation, and explain what evidence would change your conclusion.


### Week 03 — FMEA and FMECA

**Lecture notes.** Failure Mode and Effects Analysis reasons from a failure mode through local, next-higher and system effects. Record item/function, failure mode, cause, effects, detection, current controls, action and verification evidence. Severity, occurrence and detectability scales are ordinal judgements; multiplying them into an RPN assumes numerical properties that the scales do not possess. Two very different risk profiles can yield the same RPN. Use criticality analysis only when the probability basis and exposure model are credible, and retain severity as a separate decision dimension. FMEA is complementary to, not a replacement for, hazard analysis.


**Worked application.** If a sensor’s ‘stuck-at-low’ mode is severe but difficult to detect, a high RPN is a prompt to investigate, not a calibrated probability of harm. A rare catastrophic failure should not be hidden by a low occurrence score.


**Practical / assessed work.** Complete at least 15 failure modes for sensor, gateway, actuator, cloud service, power and operator interface. Show the evidence behind each occurrence estimate and separate recommended actions from verified closures.


**Checkpoint.** State the model assumptions, identify one failure mode or limitation, and explain what evidence would change your conclusion.


### Week 04 — Reliability mathematics and lifetime models

**Lecture notes.** For a constant failure rate λ under an exponential lifetime model, reliability is R(t)=exp(−λt), failure probability is F(t)=1−R(t), and MTTF=1/λ. The constant-hazard assumption is not generally valid across infant mortality, useful life and wear-out. A Weibull model has R(t)=exp[−(t/η)^β], where β<1 suggests decreasing hazard, β=1 constant hazard and β>1 increasing hazard. For repairable systems, distinguish MTBF, MTTR and operational availability A≈MTBF/(MTBF+MTTR) under steady-state assumptions. State whether rate data are per hour, demand, cycle or mission.


**Worked application.** With λ=2×10⁻⁵ h⁻¹, the exponential model gives R(1000)=exp(−0.02)≈0.9802. This is a model-based estimate, not a guarantee that 98.02% of a real fleet will survive 1000 h unless the population, censoring, failure definition and constant-rate assumption are justified.


**Practical / assessed work.** Implement the reliability-calculation lab. Compare exponential and Weibull curves for β=0.7, 1 and 2; explain why a single MTTF can hide different time-dependent risks.


**Checkpoint.** State the model assumptions, identify one failure mode or limitation, and explain what evidence would change your conclusion.


### Week 05 — Reliability block diagrams and availability

**Lecture notes.** Reliability Block Diagrams (RBDs) represent success paths. For independent components in series, system reliability is the product of component reliabilities. For independent parallel components, reliability is one minus the probability that all fail. These formulae rely on independence, correct success-path modeling and common mission time. Common-cause failures, shared power, environmental stress, maintenance errors and latent failures invalidate a naive parallel redundancy claim. Standby systems additionally need switching reliability, proof-test interval, dormant failure and repair assumptions. Reliability is not the same as availability because repair and restoration matter.


**Worked application.** Two independent parallel sensors with R₁=R₂=0.9 have R=1−(0.1×0.1)=0.99. If a shared power supply fails with probability 0.03, the real system reliability is bounded by the common-cause path and cannot be reported as 0.99 without modeling that dependency.


**Practical / assessed work.** Draw RBDs for series, active parallel and standby protection. Add a common-cause event and compare naive versus dependency-aware estimates.


**Checkpoint.** State the model assumptions, identify one failure mode or limitation, and explain what evidence would change your conclusion.


### Week 06 — Fault Tree Analysis and minimal cut sets

**Lecture notes.** Fault Tree Analysis starts with a defined top event and decomposes it through Boolean gates. OR gates require any input event; AND gates require all input events. Minimal cut sets are smallest combinations of basic events sufficient to produce the top event. Under independent rare-event assumptions, OR probability is approximated by the sum of small event probabilities, while an AND gate probability is the product; exact expressions should be used when probabilities are not small. A tree is not complete unless the analyst checks boundary conditions, common causes, dependencies, latent conditions and event definitions.


**Worked application.** For T=A OR (B AND C), with independent P(A)=0.01, P(B)=0.1 and P(C)=0.2, P(T)=P(A)+P(B)P(C)−P(A)P(B)P(C)=0.01+0.02−0.0002=0.0298. Minimal cut sets are {A} and {B,C}.


**Practical / assessed work.** Construct the overflow top event, calculate minimal cut sets, and compute both exact and rare-event estimates. Document independence assumptions and identify any shared utility or common-cause event.


**Checkpoint.** State the model assumptions, identify one failure mode or limitation, and explain what evidence would change your conclusion.


### Week 07 — Event Tree Analysis, barriers and escalation

**Lecture notes.** Event Tree Analysis begins with an initiating event and follows success/failure branches through barriers or safety functions. Each branch probability is conditional on the preceding path; multiplying unconditional rates can be wrong. The final sequence frequencies depend on the initiating event frequency and conditional barrier failure probabilities. Model barrier dependencies, common causes, test coverage, bypass states and operator response time. Use event trees to expose escalation paths and where risk reduction is possible. Do not count one barrier twice if the same sensor or power source supports multiple branches.


**Worked application.** If the initiating event frequency is 0.02 per year and two independent protection layers fail on demand with probabilities 0.1 and 0.05, the simplified hazardous sequence frequency is 0.02×0.1×0.05=0.0001 per year. If they share a sensor, independence is not justified and the estimate is optimistic.


**Practical / assessed work.** Build an ETA for valve stuck-open, with high-level switch, controller shutdown and operator intervention branches. Add one common-cause dependency and quantify its impact.


**Checkpoint.** State the model assumptions, identify one failure mode or limitation, and explain what evidence would change your conclusion.


### Week 08 — Bayesian updating, uncertainty and Monte Carlo

**Lecture notes.** Risk estimates are uncertain because data are sparse, systems change, and expert judgements vary. Separate aleatory variability from epistemic uncertainty. Bayesian updating combines prior beliefs with data under an explicit likelihood. For a Bernoulli success probability p with Beta(α,β) prior and s successes/f failures, the posterior is Beta(α+s,β+f). Monte Carlo simulation propagates distributions through a model but does not repair a wrong model or invented inputs. Report quantiles, credible/confidence intervals and sensitivity; avoid false precision for rare events.


**Worked application.** With a uniform Beta(1,1) prior and 8 successful demands out of 10, the posterior is Beta(9,3) with mean 9/12=0.75. The posterior distribution still has substantial uncertainty; reporting only 0.75 conceals it. The model also assumes exchangeable Bernoulli trials and a stable underlying probability.


**Practical / assessed work.** Use the Python lab to update a demand-failure estimate and simulate an RBD with uncertain component reliability. Plot median and 5th/95th percentiles; identify the input dominating output variance.


**Checkpoint.** State the model assumptions, identify one failure mode or limitation, and explain what evidence would change your conclusion.


### Week 09 — STPA and control-theoretic safety analysis

**Lecture notes.** STPA analyzes unsafe control rather than only component failure. Define losses, system-level hazards and safety constraints; draw the control structure with controllers, controlled processes, actuators, sensors, feedback and process models. For each control action, identify unsafe cases: not provided when needed, provided when unsafe, provided too early/late or out of order, or applied too long/stopped too soon. Generate causal scenarios from flawed process models, inadequate feedback, control algorithm flaws, coordination, time delays, component behavior and environmental conditions. Translate scenarios into constraints, requirements and test cases.


**Worked application.** A controller may issue ‘close valve’ correctly, but the actuator may be stuck or feedback may falsely indicate closure. Another UCA occurs when the controller omits a shutdown command because a stale sensor value looks normal. Both can occur without a traditional random hardware failure.


**Practical / assessed work.** Create a STPA control structure and UCA table for overflow prevention. Derive at least 10 causal scenarios and trace each to a constraint and verification case.


**Checkpoint.** State the model assumptions, identify one failure mode or limitation, and explain what evidence would change your conclusion.


### Week 10 — Human factors, software and operational context

**Lecture notes.** Human actions are shaped by interface design, workload, training, procedures, alarms, organizational pressure and available feedback. Avoid assigning ‘operator error’ as a root cause without examining system conditions. Software can create unsafe states through incorrect assumptions, stale data, timing faults, mode confusion and inconsistent control authority. Analyze alarms for priority, timing, acknowledgment, suppression and overload. Evaluate maintenance bypasses, degraded modes, calibration and handover. Safety analysis must include automation and human control interactions, not merely human reliability numbers.


**Worked application.** A high-level alarm that is technically correct but appears among 80 low-priority notifications may not change operator action. The hazard control is not ‘train the operator’ alone; it may require alarm prioritization, redundancy, response window and verified escalation.


**Practical / assessed work.** Conduct a human-factors review of three alarm scenarios. Measure time-to-detect, interpretation errors and recovery actions in a tabletop simulation; record participant limitations.


**Checkpoint.** State the model assumptions, identify one failure mode or limitation, and explain what evidence would change your conclusion.


### Week 11 — Safety requirements and risk controls

**Lecture notes.** Safety requirements should be derived from hazards and causal scenarios, allocated to architecture elements and verified. A requirement must define trigger, response, timing, safe state, degraded behavior and test conditions. Risk controls can eliminate hazards, reduce exposure, prevent initiating events, detect unsafe states, mitigate consequences or improve recovery. Order controls by effectiveness rather than defaulting to warnings/training. Verify independence assumptions for protective layers and consider common power, sensor, software and maintenance causes. A risk matrix is not a substitute for a safety requirements argument.


**Worked application.** ‘The system shall prevent overflow’ is not testable. A stronger set specifies high-high threshold, sensor validity, response latency, actuator closure behavior, local fallback and proof-test evidence. The acceptable residual risk must be approved by the authorized decision-maker.


**Practical / assessed work.** Map every hazard to one or more safety requirements and controls. For each requirement define objective evidence and a negative test that would fail if the control is absent.


**Checkpoint.** State the model assumptions, identify one failure mode or limitation, and explain what evidence would change your conclusion.


### Week 12 — Safety cases, assurance and standards

**Lecture notes.** A safety case is a structured argument that a system is acceptably safe for a defined context, supported by evidence and explicit assumptions. Separate claims, arguments and evidence; an attractive diagram is not proof. A claim about acceptable risk requires a scope, operating envelope, hazards covered, evidence quality, residual uncertainty and decision authority. NASA system-safety material provides a public worked framework for integrating safety analysis with systems engineering and risk-informed reviews. Standards such as IEC 61508 and sector-specific standards are controlled publications; use official standards-body catalogues for applicability and legal access, and do not redistribute the text.


**Worked application.** A top-level claim ‘overflow risk is controlled’ should decompose into claims about hazard identification, independent detection, shutdown performance, failure response and operational controls. Evidence should include analyses, tests, model inspections and unresolved anomalies.


**Practical / assessed work.** Write a five-level safety argument for the tank case. Identify defeaters, assumptions, evidence gaps and what new test result would invalidate the claim.


**Checkpoint.** State the model assumptions, identify one failure mode or limitation, and explain what evidence would change your conclusion.


### Week 13 — Integrated safety assessment and review

**Lecture notes.** The final assessment combines PHA/FMEA, quantitative reliability, FTA/ETA, STPA, requirements, architecture controls, verification evidence and safety-case reasoning. Reconcile contradictions: a high RPN with a low fault-tree contribution, an STPA scenario without a component failure, or a protective layer that shares a common utility. Prioritize by consequence, exposure, uncertainty and decision context. State residual risk and the conditions under which the conclusion remains valid. Safety is continuously managed across design changes, operations, incidents and retirement.


**Worked application.** A design may reduce calculated random failure probability but increase common-cause vulnerability by consolidating multiple sensors onto one gateway. The safety case must capture the new dependency, not simply reuse the prior component reliability calculation.


**Practical / assessed work.** Submit a hazard log, FMEA, RBD, fault tree with cut sets, event tree, STPA package, uncertainty analysis, safety requirements and assurance case. Include a peer challenge of the top three assumptions.


**Checkpoint.** State the model assumptions, identify one failure mode or limitation, and explain what evidence would change your conclusion.


### Week 14 — Safety assurance in operation, maintenance and change

**Lecture notes.** Safety assurance does not end at design release. Operational evidence includes proof-test results, inspection/maintenance intervals, bypass control, training, event reporting, configuration status and leading indicators. Changes in software, supplier, sensor calibration, environment or procedure can invalidate assumptions in the hazard analysis and safety case. Define change triggers, re-analysis thresholds and authority to accept residual risk. Monitor incidents and near misses without treating low event counts as proof of low risk. Maintain a hazard log with owners, due dates, closure evidence and reopening criteria.


**Worked application.** Changing the sensor firmware may alter filtering delay and stale-data semantics. The assurance argument must be reviewed because the previous response-time evidence may no longer apply even when the sensor part number is unchanged.


**Practical / assessed work.** Create a safety-management plan for one year of simulated operation. Define proof-test evidence, bypass authorization, change-impact triggers, incident escalation, safety performance indicators and criteria for reopening a closed hazard.


**Checkpoint.** State the model assumptions, identify one failure mode or limitation, and explain what evidence would change your conclusion.


## Assessment design

| Component | Weight | Evidence expected |
|---|---:|---|
| Weekly problem sets and derivations | 20% | Correct reasoning, assumptions, units and worked calculations |
| Practical labs and reproducibility | 25% | Executable/model artefacts, tests, environment and results |
| Midterm assessment | 15% | Core concepts, derivations and design trade-offs |
| Individual cumulative project | 25% | Correct implementation/model, traceability and technical report |
| Final examination and oral defense | 15% | Transfer to unseen cases and explanation of submitted work |


## Minimum submission standard

Every practical report must include: objective; theory; assumptions; environment/tool versions; procedure; expected result; actual result; raw evidence; analysis; limitations; references. A screenshot alone is not proof of a model, test, or database property. Never label an external-tool lab as passed unless it was run in the named tool.


## Edition 3 advanced quantitative extension — common cause and uncertainty

The original calculator assumed independent basic events. That assumption is often unsafe for redundant channels that share a power supply, environment, design defect, maintenance procedure, communications gateway or common operator action. Edition 3 therefore adds a separate, explicitly limited beta-factor approximation. For identical channels with per-channel failure probability \(q\), common-cause fraction \(eta\), and \(n\) channels, the teaching model uses:

\[
Q_{sys}pprox eta q+((1-eta)q)^n
\]

For \(q=0.01\), \(eta=0.20\), and two channels, independent failure gives \(q^2=0.0001\); the beta-factor approximation gives \(0.002064\). The shared-cause term dominates. This calculation is a simplified static approximation, not a general time-dependent dependent-failure model.

The upgraded lab also separates epistemic from aleatory uncertainty. `beta_posterior_interval()` gives an equal-tail Bayesian credible interval for an unknown event probability. `fault_tree_parameter_uncertainty()` propagates independent Beta posteriors through a small exact fault tree. `monte_carlo_fault_tree_probability()` estimates aleatory top-event frequency for fixed inputs and reports a Wilson interval for Monte Carlo sampling error. Those intervals answer different questions and must not be interchanged. `fault_tree_sensitivity()` computes Birnbaum importance, which measures local absolute influence but does not include consequence or mitigation cost.

Run:

```bash
cd labs/03-safety/reliability_lab
python -m pytest -q
python analysis_example.py
```

The worked example is fully reproducible under seed `2026`; its probabilities and Beta posteriors are hypothetical teaching inputs. The added tests verify common-cause boundaries, deterministic credible intervals, posterior propagation, Monte Carlo agreement with exact enumeration, Wilson interval behavior and sensitivity ranking. They do not validate any real plant, component population, mission profile or safety case.

The source progression now includes the University of Maryland ENRE602 reliability-analysis course (fault trees, reliability block diagrams, FMEA and event trees), University of Southampton FEEG6006 systems reliability (including Monte Carlo methods), and NASA's System Safety Handbook. Complete the external course readings, then redo the top three risk contributors using actual exposure and failure data before making an engineering recommendation.


## Edition 3 lab annex — quantitative reliability and uncertainty

The original calculator is extended in `labs/03-safety/reliability_lab/` with a simplified beta-factor common-cause approximation, Bayesian Beta posterior intervals, propagation of independent parameter posteriors through small fault trees, seeded Monte Carlo with Wilson sampling intervals and Birnbaum sensitivity ranking. Run `python -m pytest -q` and `python analysis_example.py` from that directory. The sample data are hypothetical. The beta-factor model is a simplified identical-channel approximation and the posterior model assumes independent parameter posteriors; neither is a validated probabilistic risk assessment for an operational system. Compare the curriculum against [UMD ENRE602](https://me.umd.edu/course-schedule/course/ENRE602), [Southampton FEEG6006](https://southampton.ac.uk/courses/modules/feeg6006.page) and NASA's [System Safety Handbook Vol. 2](https://ntrs.nasa.gov/archive/nasa/casi.ntrs.nasa.gov/20150015500.pdf).

# Edition 3 Open Issue Register

| ID | Severity | Course | Finding / limitation | Closure evidence | Status |
|---|---|---|---|---|---|
| V3-01 | Critical gate | MBSE | `water-tank-v3.sysml` has not been parsed/imported/rendered with a SysML v2 tool | SysON version, parser output, rendered diagrams, export/re-import and independent model review | Open — external tool |
| V3-02 | Critical gate | V&V | TLA+ safe/unsafe specs have not been executed with TLC | TLC CLI run output: safe spec completes without violations; unsafe spec gives expected counterexample | Open — official jar unavailable in build |
| V3-03 | Critical gate | Data Systems | PostgreSQL 18 schema/plan/isolation/restore experiments not executed | PostgreSQL version, SQLSTATE, EXPLAIN BUFFERS plans, concurrent session transcript, restore evidence and RPO/RTO | Open — psql/Docker unavailable |
| V3-04 | High | Distributed Systems | Raft implementation remains a deterministic in-process simulator | Separate-process RPC cluster, durable storage, snapshotting and failure-injection report | Open — implementation extension |
| V3-05 | High | Data Systems | DiskDB is a redo-only teaching engine; no SQL executor/MVCC/ARIES/merge-delete | Staged DBMS extension and invariant/recovery tests | Open — implementation extension |
| V3-06 | High | Security | No Ruff/Bandit/Semgrep/dependency scanner or external ASVS test evidence | Scanner reports, targeted WSTG/ASVS verification and independent security review | Open — tools/review |
| V3-07 | High | All | No independent subject-expert review or learner pilot | Signed/dated review, findings closed, learner effort/completion/assessment data | Open — external review |
| V3-08 | Medium | V&V | Hypothesis library was not installed; stateful tests use deterministic generated histories | Optional pinned Hypothesis suite if dependency approved/available | Open — optional extension |
| V3-09 | Medium | Safety | Reliability example uses hypothetical parameters and simplified beta-factor assumptions | Calibrated domain data and qualified reliability engineer review | Open — data/subject review |
| V3-10 | Medium | Assessment | No moderated timed final examinations with sample scripts/grade boundaries | Two timed examinations per course and moderation record | Open — assessment extension |

This register is intentionally not a generic backlog. Each open item prevents a specific higher-strength claim or full-credit rubric award. See `REMEDIATION-ROADMAP-V3.md` for the closure sequence.

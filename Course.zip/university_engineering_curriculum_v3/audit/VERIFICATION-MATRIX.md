# Edition 2 Verification Matrix

| Artifact | Verification performed | Result | Limitation / next action |
|---|---|---|---|
| `tools/build_course_readers.py` | Executed to generate six V2 readers from the retained first-edition source files | Completed; six files written | Regenerate after content changes and review diffs manually |
| Go logical-clock lab | `go test -race -count=1 ./...` | PASS | Small logical-clock exercise, not full distributed consensus |
| Go logical-clock lab | `go vet ./...` | PASS | Static checks do not prove protocol correctness |
| Go idempotency lab | `go test -race -count=1 ./...` | PASS | In-memory, process-local behavior only; not durable/distributed |
| Go idempotency lab | `go vet ./...` | PASS | Static checks do not prove crash consistency |
| Python reliability lab | `pytest -q labs/03-safety/reliability_lab` | PASS — included in 29-test suite | Independent basics assumed; tree enumerator is exponential and educational |
| Python finite-state checker | `pytest -q labs/04-vv/modelcheck_lab` | PASS — included in 29-test suite | Explicit finite graph checker only; no temporal/probabilistic model checking |
| Python authorization lab | `pytest -q labs/05-security/authorization_lab` | PASS — included in 29-test suite | Policy model only; no authentication/API/crypto/persistence implementation |
| Python labs | `python -m compileall -q ...` | PASS | Syntax compilation is not complete security/correctness analysis |
| SysML v2 starter model | Static content and instructions reviewed | PRESENT; NOT TOOL-VALIDATED | Import into SysON or another SysML v2 tool; capture parser output and model validation report |
| In-memory B+ tree lab | `pytest -q labs/06-data-systems/tinydb` | PASS — 8 tests (included in 29-test aggregate) | In-memory unique-key index only; no disk/page manager, concurrency or WAL |
| PostgreSQL schema/seed/query | Static content review | PRESENT; NOT DATABASE-EXECUTED | Run on PostgreSQL 18; verify schema, seed rerun, constraints, query plans and SQLSTATE |
| PostgreSQL MVCC experiment | Two-session scripts and run order reviewed | PRESENT; NOT DATABASE-EXECUTED | Run concurrent sessions; save actual behavior and serialization error output |
| PostgreSQL backup/restore | Commands and acceptance checks documented | PRESENT; NOT EXECUTED | Restore into isolated target and measure RPO/RTO |
| Problem sets and solutions | Six course sections, five worked problems per course, arithmetic/formula check by author | PRESENT; AUTHOR-REVIEWED | Independent instructor moderation/solution review still needed |
| Weekly problem bank | Counted 14 questions and worked checkpoints in each of six course sections | PASS — 84 questions (14 per course) | Author solution checkpoints; independent moderation still needed |
| Integrated capstone | Requirements, work packages, milestones, 20 acceptance tests and 100-point rubric reviewed | PRESENT; AUTHOR-REVIEWED | Execute as a student project and have a separate assessor mark it |
| Research/source library | Exa, Firecrawl, TinyFish, Context7 and FMHY research notes; primary sources recorded | COMPLETED WITH SCOPE LIMITS | Course pages/standards can change; recheck before later term |
| Python aggregate | `pytest -q labs/03-safety/reliability_lab labs/04-vv/modelcheck_lab labs/05-security/authorization_lab labs/06-data-systems/tinydb` | PASS — 29 passed | Local teaching labs only; not a substitute for subject-matter validation |
| Course structure | Counted expanded-week headings in all six V2 readers and weekly reading maps | 14/14 weeks in all six readers; 14/14 rows in all six maps | A week count proves structure, not that a university has awarded credit |
| Score aggregation | Recomputed six course totals from CSV | PASS — arithmetic mean 86.83/100 | Editorial author self-score; no independent assessor participated |
| Remediation plan | `REMEDIATION-ROADMAP-V2.md` cross-checked against Edition 2 audit gaps | PRESENT; OPEN ITEMS IDENTIFIED | Complete each gate and re-audit before any 100/100 claim |
| ZIP integrity | `unzip -t` and SHA-256 manifest verification | PASS — final archive tested; see release notes | Archive contains only the curriculum files and the verified checksum manifest |

## Environment constraints recorded

- Go 1.23.2 linux/amd64, Python 3.13.5 and pytest 9.0.2 available in the build runtime.
- `psql` not available.
- Docker executable not available.
- No SysML v2 model workbench or parser available.

No pass is claimed for external PostgreSQL or SysML tool actions that could not be run in this environment.

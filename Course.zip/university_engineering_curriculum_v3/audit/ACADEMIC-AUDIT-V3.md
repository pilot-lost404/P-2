# Academic Audit — Edition 3

**Research/build snapshot:** 21 November 2026  
**Result:** **91.00/100** (author self-audit using the unchanged Edition 2 quality contract)  
**Readiness:** Strong advanced undergraduate / early graduate self-study material. Not accreditation, certification or a faculty-approved university course.

## Executive finding

Edition 3 closes most of the implementation-depth gaps identified in the 86.83/100 Edition 2 audit. It adds a deterministic Raft teaching simulator, an expanded and traceable SysML v2 model pack, quantitative common-cause and uncertainty analysis, bounded safe/unsafe model-checking examples, a local secure HTTP training service, and a disk-backed storage/WAL/recovery/B+ tree project. These are integrated into the six course readers and source maps.

The current score is 91.00/100. The remaining evidence gaps are not cosmetic: SysML v2 must be run through a real tool; TLC must execute the provided specifications; PostgreSQL 18 SQL/MVCC/backup exercises must be run against an actual instance; and the material still requires independent subject-expert review and a learner pilot. Therefore 100/100 is **not** achieved or claimed.

## Scores

| Course | V2 score | V3 score | Main improvement | Material remaining gap |
|---|---:|---:|---|---|
| Distributed Systems | 88 | 91.5 | Raft elections, replication, log repair, quorum commit and deterministic fault schedules | Simulator is single-process and omits network RPC, real disk durability, snapshots and complete KV/shard service |
| Model-Based Systems Engineering | 84 | 87 | 18 measurable requirements, model-element registry, 22 trace links, 18 planned verification cases and validator tests | SysML v2 syntax/semantics and graphics are not validated in SysON |
| Safety and Risk Analysis | 88 | 91.5 | Common-cause beta-factor approximation, Bayesian parameter uncertainty, Monte Carlo interval and sensitivity | No operational failure data, tool-qualified PRA, independent hazard-data review or safety authority acceptance |
| Verification and Validation | 88 | 90.5 | Safe/unsafe quorum models, bounded state exploration, shortest counterexamples and TLA+ artifacts | TLC was not executed; model scope remains bounded and not linked to a production implementation proof |
| Security Engineering | 87 | 93.5 | Loopback-only service with sessions, CSRF, tenant authorization, rate limiting, security headers and tamper-evident audit | External scanner results, full ASVS verification, independent penetration test and production deployment controls remain external |
| Data Systems and Databases | 86 | 92 | Fixed-page file, buffer pool, WAL, redo recovery, persistent B+ tree and differential tests | PostgreSQL 18 not executed; no query processor, MVCC/concurrency implementation, delete/merge or full ARIES |

Score detail is in [`COURSE-SCORECARD-V3.csv`](COURSE-SCORECARD-V3.csv). The score is the simple arithmetic mean of the six course totals, not a course-credit-weighted average.

## Rubric applied

The original 100-point contract is unchanged: teaching depth 30, technical correctness 20, practical reproducibility 20, assessment/solutions 15, sources/traceability 10 and course coherence 5. Each course retains 14 weekly units, worked checkpoints, five longer worked problems and mapped primary resources. The practical dimension is not awarded full marks merely because a starter lab exists: it reflects what actually executed and the boundaries of the implementation.

## Evidence inspected

- All six V3 readers and six week-by-week reading maps.
- All 84 weekly problem/checkpoint entries, 30 longer worked problems and capstone rubric.
- 94 Python lab tests across MBSE, reliability, model checking, authorization/security and database-index/storage projects.
- Go Raft simulator tests with `-race`, plus `go vet`.
- Python compilation of the lab trees.
- MBSE CSV traceability validation (zero errors and zero warnings in the sample register).
- Loopback HTTP smoke test: login 200, authenticated session 200, record create 201, cross-tenant object read 404.
- Database B+ tree differential histories and close/reopen persistence.
- Local B+ tree benchmark with environment, seed, timings and file sizes captured.
- Research source register and current university/standard/tool references.

## Remaining non-negotiable evidence gates

1. Import, parse, render, re-export and independently inspect `labs/02-mbse/water-tank-v3.sysml` using a recorded SysON version.
2. Run TLC with the pinned official TLA+ Tools release against both safe and deliberately unsafe `.tla` specifications, retaining the invariant pass and counterexample output.
3. Execute all PostgreSQL 18 schema, SQL, EXPLAIN, two-session isolation and backup/restore exercises on a disposable instance; save version, configuration, raw output, SQLSTATE, row checks, RPO/RTO and plans.
4. Extend the distributed simulator toward a separate-process/networked replicated KV service and evaluate more failure schedules.
5. Extend the database engine with deletion/merge, iterator tests, page scheduler, concurrency, MVCC and a proper recovery algorithm (or document why a narrower scope is appropriate for the course's prerequisites).
6. Run external static analysis/security tests and an independent ASVS-based assessment; do not equate 23 unit tests with ASVS compliance.
7. Obtain dated independent subject-expert reviews of all six readers, solutions and lab claims; close findings.
8. Pilot the course with learners, measure weekly effort and completion, review assessment clarity/discrimination and revise.

The external work is itemized in [`REMEDIATION-ROADMAP-V3.md`](REMEDIATION-ROADMAP-V3.md). The author should not award themselves full marks for the independent-review or learner-pilot gates.

## Limitations of this audit

This is an evidence-based author self-audit; it is not independent moderation. Unit tests provide evidence for tested inputs and code paths, not proofs of correctness or absence of defects. A deterministic Raft simulator is not a distributed cluster. A CSV traceability validator is not a SysML parser. A Python state explorer is not TLC. A redo-only full-page-image WAL is not ARIES or PostgreSQL WAL. The secure local API is not production-ready. A reliability approximation is not a certified PRA. These distinctions constrain the score.

# Course Quality Contract — Applies to Editions 2 and 3

**Status:** Unchanged acceptance criteria used for the V2 and V3 self-study audits; not an accreditation standard.

## Scorecard rubric

| Dimension | Weight | Evidence required for full marks |
|---|---:|---|
| Teaching depth and rigor | 30 | Complete coherent learning outcomes, prerequisites, 14 taught units, definitions, derivations, worked examples, edge cases and limitations |
| Technical correctness | 20 | Checked equations, versioned tool behavior, assumptions stated, primary references, no contradictions or unsupported guarantees |
| Practical reproducibility | 20 | Runnable or importable labs, complete setup, deterministic instructions, expected outcomes, tests and limitations stated |
| Assessment and solutions | 15 | Problem sets across topics, worked solutions, exam blueprint, project rubric and individual ownership check |
| Sources and traceability | 10 | Primary sources mapped to topics, versions/dates/access, requirements-to-model-to-test links |
| Course design and coherence | 5 | Prerequisites, workload, weekly progression, assessment balance and integrated project |

## Readiness interpretation

- 90–100: Excellent self-study course package; external verification remains required for tools and claims not executable in this environment.
- 80–89: Strong course package with a small number of material gaps.
- 70–79: Minimum acceptable university-level self-study baseline; notable improvements still needed.
- 50–69: Introductory draft or incomplete course.
- Below 50: Not ready for independent university-level study.

## Non-negotiable gates

A course cannot receive 90+ if it lacks any one of: substantive weekly instruction, worked solutions, a practical lab with expected evidence, a cumulative assessment, or primary-source traceability. A package cannot be called 100/100 if an essential external lab has not been run, correctness is not independently reviewed, or the score is self-awarded without evidence.

## Audit method

This is a rubric-based editorial self-audit. It is not institutional accreditation, an external examiner's review, formal verification, a safety certification or a guarantee of employment/professional competence. Where a tool could not be invoked in the runtime, mark the task as “not locally executed” rather than awarding execution credit.

# Remediation Roadmap — University-Level Readiness

This roadmap follows the academic audit. It is the required work to reach the pass criteria; it is not a claim that these revisions have been completed.

## Phase 0 — Freeze the baseline
- [ ] Preserve the current six readers as baseline version 1.
- [ ] Preserve the audit report and scorecard.
- [ ] Set the target level: advanced undergraduate, with selected graduate-level extensions.
- [ ] Establish a controlled source register and chapter-citation standard.
- [ ] Define the weekly chapter template and minimum lab specification.

## Phase 1 — Rebuild all 84 weekly units
For every week of every course:
- [ ] Define measurable learning outcomes.
- [ ] Add prerequisite review where needed.
- [ ] Develop the concept from definitions to reasoning and limitations.
- [ ] Add equations, derivations, algorithm traces or formal notation.
- [ ] Add at least one detailed worked example.
- [ ] Add a diagram/model where useful.
- [ ] Add common errors, trade-offs and critical discussion.
- [ ] Add assigned readings with page/section references.
- [ ] Add practice questions with fully explained solutions.

## Phase 2 — Practical sequences

### Distributed Systems
- [ ] RPC and concurrent server.
- [ ] Failure detector and controllable network faults.
- [ ] Primary-backup replication.
- [ ] Raft implementation and correctness/failure tests.
- [ ] Replicated key-value store and sharding.
- [ ] Snapshot/recovery or stream-processing project.

### MBSE
- [ ] Tool setup and SysML v1/v2 orientation.
- [ ] Stakeholder needs and ConOps model.
- [ ] Requirements and traceability model.
- [ ] Structural, behavioral and interface model.
- [ ] Parametric analysis and trade study.
- [ ] Model validation, queries, baselines and change-impact project.

### Safety and Risk
- [ ] PHA and hazard log.
- [ ] Quantitative FMEA/FMECA with defensible data.
- [ ] Fault tree, cut sets and reliability block diagram.
- [ ] Event tree and barrier analysis.
- [ ] STPA control structure, UCA register and causal scenarios.
- [ ] Safety requirements, verification evidence and assurance case.

### Verification and Validation
- [ ] Requirements verification and testability review.
- [ ] Black-box test design and boundary/decision/state coverage.
- [ ] Structural testing, coverage and mutation.
- [ ] Integration and end-to-end automated tests.
- [ ] Formal verification/model checking lab.
- [ ] Performance/statistical testing and final V&V report.

### Security Engineering
- [ ] Asset/threat model and trust-boundary review.
- [ ] Authentication and authorization implementation.
- [ ] Secure input/data handling and cryptographic configuration.
- [ ] Network/API/OS/database security lab.
- [ ] SAST, DAST, fuzzing and authorized penetration test.
- [ ] Incident-response and security assurance project.

### Data Systems and Databases
- [ ] Relational schema, SQL and normalization problem set.
- [ ] Page layout, record manager and buffer pool.
- [ ] Heap storage and B+ tree index.
- [ ] Query execution, joins and optimizer.
- [ ] Transactions, concurrency control and isolation anomaly lab.
- [ ] WAL, checkpoints, recovery and distributed data project.

## Phase 3 — Assessments
- [ ] Weekly quizzes/problem sets for each course.
- [ ] Two substantial exams per course: midterm and final.
- [ ] Three to six practical assignments/labs per course.
- [ ] One progressive semester project per course.
- [ ] Explicit grading rubrics and model answers.
- [ ] Oral/code/model defense to check student understanding.

## Phase 4 — Integrated capstone
- [ ] Make the water-tank case a runnable local simulation, not a production-control system.
- [ ] Integrate local controller, gateway, API, identity, database and telemetry.
- [ ] Integrate MBSE model, hazard log, threat model and verification matrix.
- [ ] Execute network failure, duplicate command, stale telemetry, sensor fault and restore scenarios.
- [ ] Produce traceable safety/security arguments and V&V evidence.
- [ ] Grade each discipline's deliverable and the integrated system separately.

## Phase 5 — Re-audit
- [ ] Recount and inspect all 84 weekly units.
- [ ] Verify each lab from a clean environment.
- [ ] Run all code, SQL, model checks and test procedures.
- [ ] Verify links, versions, citations and licenses.
- [ ] Score each course using the original rubric.
- [ ] Do not declare readiness unless every course passes the defined threshold.

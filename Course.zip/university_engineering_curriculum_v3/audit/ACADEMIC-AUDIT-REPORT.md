# Academic Verification Audit — Six Engineering Courses

**Audit date:** 21 November 2026  
**Audit type:** Option B — full academic audit  
**Baseline:** The existing six 14-week course readers, capstone, labs, problem sets and source library  
**Target benchmark:** Upper-undergraduate university course, with selected early-graduate depth

## 1. Clear verdict

**The curriculum does not currently meet a university-level self-study course standard.**

It is an introductory course-reader pack with a coherent syllabus outline, useful topic coverage, several sound explanations, a shared capstone and a modest set of exercises. It is not yet six complete semester courses.

**Overall audit score: 46/100 — NOT READY.**

All six courses fall below the 70/100 minimum readiness threshold used in this audit. The principal problem is not the topic selection. It is insufficient teaching depth, practical implementation and assessment for the claimed semester workload.

The honest current description is: **introductory course-reader draft**, not completed university-level textbooks.

## 2. Measured baseline

| Measure | Finding |
|---|---:|
| Standalone courses | 6 |
| Weeks per course | 14 |
| Words across the six course files | 21,603 |
| Average words per week across 84 weekly units | 257 |
| Typical weekly unit | Approximately 150–300 words |
| Solved end-of-course problems per course | 3–4 |
| Runnable implementation labs | 1 Go lab |
| Database lab assets | PostgreSQL schema, seed data and queries |
| Other lab assets | MBSE, safety, V&V and security worksheets/templates |
| Integrated capstone | Design starter pack; no complete integrated implementation |

The files contain six 14-week headings, but most weekly units are short explanations or summaries. The Verification and Validation course averages about 218 words per weekly unit; Safety and Risk Analysis averages about 237. A heading for a lab is not a lab specification, and a worksheet is not a completed worked practical.

The course guide states an expected workload of roughly 8–10 hours per week. That claim is not supported by the current reader. For comparison, Johns Hopkins' Fall 2026 introductory MBSE course describes 8–12 hours per week, including readings, lectures and several hours of modeling work; its follow-on course has weekly modeling assignments and a progressive semester project. The existing MBSE reader has no comparable model artifact or staged model submissions.

**Correction to the previous delivery description:** the six standalone subject files contain 21,603 words in total. The earlier claim of 55,112 words should not be treated as a verified count of unique subject teaching.

## 3. Scoring method

Each course is scored across six dimensions. The score assesses the current files, not the potential of each subject.

| Dimension | Weight | Test |
|---|---:|---|
| Teaching depth and academic rigor | 30 | Detailed explanations, derivations, formal models, worked examples and progression |
| Technical correctness and precision | 20 | Accurate definitions, equations, assumptions, limits and engineering reasoning |
| Practical work and reproducibility | 20 | Substantial labs, implementation/model artifacts, setup, expected results, failure cases and reports |
| Assessment and worked solutions | 15 | Weekly practice, problem sets, exams, projects, rubrics and explanatory solutions |
| Academic sources and traceability | 10 | Authoritative sources, current editions, chapter citations and reading alignment |
| Course design and coherence | 5 | Prerequisites, outcomes, progression, workload realism and integration |

**Readiness threshold:** 70/100 overall, with no critical weakness in technical correctness or practical work. This is an editorial audit scale, not a university accreditation scale.

### Overall scorecard

| Course | Depth /30 | Correctness /20 | Practical /20 | Assessment /15 | Sources /10 | Design /5 | Total /100 | Verdict |
|---|---:|---:|---:|---:|---:|---:|---:|---|
| Distributed Systems | 13 | 16 | 5 | 4 | 7 | 4 | **49** | Not ready |
| Model-Based Systems Engineering | 10 | 15 | 3 | 4 | 8 | 4 | **44** | Not ready |
| Safety and Risk Analysis | 9 | 15 | 2 | 3 | 8 | 4 | **41** | Not ready |
| Verification and Validation | 10 | 15 | 3 | 4 | 8 | 4 | **44** | Not ready |
| Security Engineering | 11 | 15 | 3 | 4 | 8 | 4 | **45** | Not ready |
| Data Systems and Databases | 12 | 16 | 6 | 4 | 8 | 4 | **50** | Not ready |
| **Average** | **10.8** | **15.3** | **3.7** | **3.8** | **7.8** | **4.0** | **45.5 ≈ 46** | **Not ready** |

Accuracy scores are relatively stronger because the introductory explanations are broadly sound in the content inspected. They do not mean every claim has been formally proved or independently validated. The low overall scores are driven by insufficient depth, practical implementation and assessment.

---

## 4. Course-by-course findings

### 4.1 Distributed Systems — 49/100

**What is good:** The reader covers partial failure, RPC, retries, idempotency, Lamport and vector clocks, replication, consistency, CAP, FLP, Raft, durable logs, transactions, sharding, data processing and operations. The Go idempotency example correctly labels itself as process-local, not durable or distributed.

**What is missing:**
- A systematic concurrency foundation: interleavings, mutual exclusion, condition synchronization, deadlock, liveness, race conditions and memory models.
- Important distributed topics: distributed snapshots, reliable broadcast, message ordering, distributed mutual exclusion, naming, Byzantine fault tolerance, CRDTs, P2P/DHTs and deeper storage case studies.
- Formal algorithm treatment: pseudocode, invariants, safety/liveness properties, failure traces, correctness arguments and message/latency complexity.
- A complete RPC, replication, Raft or sharded key-value implementation lab.
- The one runnable lab demonstrates an in-memory idempotency map, not a distributed protocol.

**University benchmark:** MIT 6.5840 Spring 2026 has multiple programming labs, paper questions, lab check-offs, midterm and final exams, plus an optional project. Its schedule covers MapReduce, RPC/threads, GFS, Paxos, Raft, distributed transactions, Spanner, chain replication, optimistic concurrency, distributed-system verification and Byzantine fault tolerance. Its grading includes 40% labs, 20% midterm, 20% final, 15% lab check-offs and 5% paper questions. The present reader has one small runnable Go lab and four solved end-of-course problems.

**Required upgrade:** Teach concurrency and distributed algorithms formally, then add staged implementations: RPC/key-value server, primary-backup replication, Raft, replicated KV, sharding/rebalancing and fault-injection tests. Add correctness traces, complexity questions, paper critiques, midterm and final design/implementation assessment.

**Verdict:** Reasonable topic selection; theoretical and practical depth are far below a semester-level distributed-systems course.

### 4.2 Model-Based Systems Engineering — 44/100

**What is good:** The reader covers system boundaries, stakeholders, ConOps, requirements, model semantics, architecture, functions, behavior, interfaces, parametrics, trade studies, traceability, configuration and change impact. It correctly identifies SysML v2 as the newer standard while acknowledging the transition from SysML v1.

**What is missing:**
- Concrete SysML modeling is not taught sufficiently; there is no end-to-end textual or graphical model built by the learner.
- Package, structural, behavior, parametric, requirement and allocation modeling features are not developed as a practical workflow.
- No actual model-tool lab, setup, import/export, model queries, validation rules or generated reports.
- No progressively developed model artifact with submissions, baselines and model reviews.
- OOSEM or another explicit modeling method is not taught as a complete repeatable method.
- The capstone has diagrams and CSV templates, but no SysML project/model file.

**University benchmark:** Johns Hopkins' Fall 2026 MBSE course covers SysML package, structural and behavior diagrams; parametrics, profiles/stereotypes, requirements and allocations; stakeholder analysis; traceability; architecture and tradeoffs. It uses a modeling tool and model artifacts. Its applied follow-on adds model queries, verification, variation, parametric analysis and OOSEM customization, with a progressive semester model project.

**Required upgrade:** Choose a supported modeling environment and method. Build one complete SysML model from stakeholder needs through requirements, structure, behavior, interfaces, parametrics, trade study, V&V and change impact. Include actual model files, weekly model changes, traceability queries, baselines, reviews and a final model-defense exercise.

**Verdict:** Currently an introduction to MBSE concepts, not a practical university MBSE course.

### 4.3 Safety and Risk Analysis — 41/100

**What is good:** The reader introduces loss/hazard/failure distinctions, PHA, FMEA/FMECA, fault trees, event trees, STPA, human factors, safety requirements and safety cases. It correctly warns that RPN is a ranking aid rather than a calibrated probability.

**What is missing:**
- Quantitative safety and reliability mathematics.
- Reliability block diagrams, failure-rate estimation, MTTF/MTBF calculations, repairable-system models and availability models.
- Bayesian parameter estimation, rare-event estimation, uncertainty propagation and sensitivity analysis.
- Substantial cut-set analysis, common-cause modeling, data uncertainty and worked numerical cases.
- A complete STPA control structure, UCA register and causal scenario set.
- A completed worked safety analysis; the FMEA and hazard-log assets are blank templates.
- Functional-safety lifecycle, integrity allocation, software safety assessment and sector-specific application.

**University benchmark:** Johns Hopkins' Fall 2026 Reliability Engineering and Analysis course is an adjacent reliability/risk benchmark, not an exact match to system safety. It includes reliability mathematics, FTA, reliability block diagrams, FMEA, ETA, Bayesian parameter estimation, repairable-system reliability, probabilistic risk assessment, uncertainty, human reliability, software reliability and reliability testing. It includes quantitative problem sets, a project and three exams. The current reader has three solved end-of-course problems and no completed quantitative case study.

**Required upgrade:** Separate system-safety methods from reliability/probabilistic-risk methods, then teach their integration. Add quantitative probability and reliability chapters; complete FMEA, FTA, ETA and STPA worked cases; uncertainty and common-cause analysis; safety-requirement allocation; and an evidence-backed safety case.

**Verdict:** Good introductory safety-method overview; not adequate as a university-level safety/risk course.

### 4.4 Verification and Validation — 44/100

**What is good:** The reader explains verification versus validation, the V-model, testability, analysis/inspection/demonstration/test, boundary testing, integration, acceptance, reproducibility, performance, safety/security testing, model-based testing, automation, coverage, traceability and release decisions.

**What is missing:**
- Formal verification is only briefly described; no proof methods, invariants, Hoare logic, temporal properties, model checking or worked proof.
- Structural testing is not developed in depth: statement/branch/condition coverage, MC/DC, path coverage and mutation testing.
- Test design needs complete worked problems involving equivalence partitions, decision tables, combinatorial testing, state transitions and test oracles.
- Statistical testing and reliability estimation are not developed beyond a short rule-of-three example.
- No complete test suite with code, test data, logs, failure reproduction and defect closure.
- The V&V matrix and test-case template are blank artifacts, not a demonstrated end-to-end verification package.
- Only three solved end-of-course problems; no full midterm/final question bank or marking rubric.

**University benchmark:** UTDallas Fall 2026 SE 4367 includes code inspections, program proofs, unit/system testing, statistical testing and reliability models. Its outcomes cover functional, structural, GUI and security-related testing and effective testing-tool use. RPI's Software Verification course develops proof methods, proofs about data types and algorithms, model checking, symbolic testing, temporal logic and proofs for concurrent programs, with proof assignments, exams and a project. NASA's V&V plan guidance covers roles, verification methods, validation methods, certification and acceptance testing.

**Required upgrade:** Build a complete V&V workflow against one system baseline. Include test-design calculations, executable test suites, code inspection, static/dynamic analysis, formal verification, reliability statistics, risk-based selection, traceability, anomaly handling and reproducible final reports.

**Verdict:** Sound introductory guide to V&V terminology and process; not a complete V&V course.

### 4.5 Security Engineering — 45/100

**What is good:** The reader covers assets, CIA, threat actors, data-flow diagrams, STRIDE, security requirements, authentication, authorization, password hashing, JWT caveats, cryptography, common application vulnerabilities, API security, secrets, secure architecture, supply-chain security and incident response.

**What is missing:**
- The course is weighted toward introductory application security. It does not sufficiently cover the wider systems-security scope implied by its title.
- Network security, protocols, operating-system/host security, database security, cloud security and IoT security need deeper treatment.
- Cryptography is mostly descriptive; students need protocol walkthroughs, threat assumptions, key lifecycle exercises and analysis of common design failures.
- No substantial secure implementation lab exists. A link to Juice Shop or PortSwigger is a pointer, not a complete lab with steps, evidence and remediation.
- Static analysis, dynamic analysis, fuzzing, penetration testing and vulnerability assessment are named but not implemented or assessed.
- No full threat-model-to-test project or security metrics exercise.

**University benchmark:** RIT's Engineering Secure Software course includes security requirements, secure design, risk analysis, threat modeling, cryptography, defensive coding, penetration testing, fuzzing, static analysis and security assessment. It assesses an input-handling project, a case study, a web-application fuzzer project, quizzes and exams. Johns Hopkins' information-assurance course additionally covers network attacks/countermeasures, OS security, database security, cloud, IoT, cryptography and enterprise risk.

**Required upgrade:** Decide whether this is systems security engineering or secure software engineering, or deliberately cover both. Add network/OS/cloud/database security, secure protocol analysis, practical vulnerability labs, secure-code changes, fuzzing/SAST/DAST exercises, metrics and a complete threat-model/security-verification project.

**Verdict:** A useful security-awareness reader, but insufficient for a university Security Engineering course.

### 4.6 Data Systems and Databases — 50/100

**What is good:** The reader covers database architecture, relational theory, keys, constraints, normalization, relational algebra, SQL, storage layouts, indexes, query optimization, ACID, isolation, MVCC, recovery, backup/restore, migration, data quality, distributed databases and analytics. It contains the strongest runnable database starter material in the pack.

**What is missing:**
- No DBMS storage engine is implemented.
- Page layout, record organization, buffer-pool management, heap files and B+ tree operations are described only briefly.
- Query-processing operators and cost estimation are not derived or implemented in depth.
- Join algorithms, sorting/aggregation implementation and optimizer plan selection need detailed worked examples.
- Concurrency control needs full transaction schedules, 2PL, deadlocks, timestamp ordering, OCC and MVCC comparisons.
- Recovery needs a concrete write-ahead log, checkpoint and crash-recovery exercise.
- The PostgreSQL lab is application-schema/SQL oriented, not a database-internals project.
- Four solved end-of-course problems, but no weekly problem sets or two-exam assessment sequence.

**University benchmark:** CMU 15-445/645 Fall 2026 teaches data and storage models, heaps, log-structured storage, indexes, ACID, concurrency control, logging/checkpoints, joins, sorting, aggregation, query optimization and parallel architectures. Its outcomes include implementing a disk-oriented storage manager with heaps and indexes, concurrency control and recovery algorithms. Programming projects form 40% of the course, alongside homework, a midterm and a final.

**Required upgrade:** Retain PostgreSQL for SQL and applied database labs, but add a staged teaching DBMS project: page/record layer, buffer pool, heap table, B+ tree, query operators/joins, optimizer estimates, transaction/concurrency module and recovery. Add SQL, normalization, concurrency and recovery problem sets with worked answers.

**Verdict:** Strongest course in the pack, but it is an introductory database guide plus a schema lab—not a full university database systems subject.

---

## 5. Cross-course findings

### Strengths to preserve
- All six subjects have coherent 14-week topic sequences.
- The water-tank case connects systems, data, safety and security.
- The local-control authority boundary is a useful recurring engineering principle.
- The sources are generally credible: MIT, CMU, NASA, NIST, OMG, OWASP and university syllabi.
- Several explanations correctly state their limits, including process-local idempotency, the limits of RPN and the difference between passing tests and proving absence of defects.

### Shared deficiencies
1. Most weekly chapters are short notes, not full teaching chapters.
2. There is no weekly reading plan. References are collected at the end rather than mapped to chapters, outcomes and assignments.
3. Worked examples are insufficient. Most chapters have one short example; problem sets contain only three or four worked questions per subject.
4. Assessment design is incomplete: no proper weekly quizzes, midterms, finals, marking schemes or subject-specific grading rubrics.
5. Labs are uneven. One runnable Go sample and one PostgreSQL schema/query set exist; other course labs are mainly worksheets.
6. The capstone is not implemented. It has an architecture and starter schema, but no full system, model, security/safety evidence set or executed V&V results.
7. Source traceability is weak. The reference lists are useful, but most chapter statements are not cited at point of use.
8. The stated weekly workload is unsupported by the current material.

### Technical and execution checks
- The introductory explanations inspected are broadly sound.
- The Go idempotency lab is correctly documented as process-local, not durable or distributed.
- A fresh `go test -count=1 -race ./...` run passed.
- `go vet ./...` returned no diagnostics.
- Neither `psql` nor Docker was installed in the audit environment. PostgreSQL SQL was inspected as text but not executed.
- No complete SysML, security or V&V practical workflow exists to execute.

### Source freshness note
The source library lists NIST SP 800-218 Version 1.1 as the final SSDF publication. NIST's publications index also lists SP 800-218 Rev. 1 Version 1.2 as a draft dated 17 December 2025. Version 1.1 remains the final publication in the cited index, but the draft should be tracked and labeled as a draft.

---

## 6. Research and tools used

| Route | Audit use |
|---|---|
| Exa | Search/fetch university syllabi, learning outcomes and official documents |
| Firecrawl | Search/scrape JHU syllabi, NASA safety/assurance pages, university course pages and standards references |
| TinyFish | Independent search for university course pages and syllabi |
| Context7 | Go, PostgreSQL 18, SysON and OWASP implementation documentation |
| FMHY | Educational directory reviewed as a discovery index only |

FMHY includes both reputable educational directories and mixed downloading links. It was used to discover legitimate resources such as MIT OpenCourseWare, Class Central, OpenLearn, Saylor, OpenHPI and Yale Open Courses—not as an academic quality authority. Torrent or unauthorized textbook/course copies were not used.

The audit prioritizes official university course pages, primary standards registries and official technical documentation over search rankings or directory entries.

---

## 7. Required remediation

### P0 — Mandatory
1. Expand every weekly unit into real teaching material: definitions, motivation, derivations, detailed explanations, worked examples, diagrams, limitations and further reading.
2. Add weekly exercises and detailed worked solutions; add a midterm and final examination for each subject.
3. Replace worksheet-only labs with at least four to six substantial labs per course, each with prerequisites, setup, tasks, expected results, tests, failure cases, deliverables and marking criteria.
4. Build a course-specific progressive project for each subject and integrate them in the capstone.
5. Map every learning outcome to chapters, exercises, labs and assessment evidence.
6. Add chapter-level citations and weekly readings from university and primary sources.

### P1 — Discipline-specific

| Course | Required additions |
|---|---|
| Distributed Systems | Formal concurrency foundation; snapshots and broadcast; additional consistency/replication models; correctness proofs; RPC, Raft and sharded-KV implementation; failure injection and case studies |
| MBSE | SysML v1/v2 notation and semantics; explicit method such as OOSEM; tool-based modeling; model queries, validation, variation and reporting; staged model submissions |
| Safety and Risk | Quantitative reliability/probability; reliability block diagrams; uncertainty/Bayesian analysis; common-cause analysis; full FTA/ETA/STPA case; safety-case evidence |
| V&V | Structural and functional test design; MC/DC and coverage; formal proofs/model checking; statistical testing; executable tests, defect lifecycle and reproducible reports |
| Security Engineering | Network/OS/cloud/database security; cryptographic protocol reasoning; defensive coding labs; SAST/DAST/fuzz/authorized penetration testing; security metrics |
| Data Systems | Page/storage manager; buffer pool; heap files; B+ tree; joins/query execution; optimizer costs; 2PL/OCC/MVCC; WAL/recovery implementation |

### P2 — Finish quality
- Add assessment weights and grading rubrics per course.
- Add chapter-to-source and outcome-to-assessment matrices.
- Add reproducibility manifests with tested tool versions.
- Execute and validate SQL, SysML, security and V&V labs.
- Run an independent technical review after revisions.

## 8. Pass criteria for the next audit

A course should not be marked ready until it:
- scores at least 70/100 on the same rubric;
- has no major unsupported or technically incorrect claim;
- has substantive instruction and a corresponding exercise/assessment in all 14 weeks;
- has at least four substantial, reproducibly checked labs/projects;
- has worked solutions that explain reasoning;
- has midterm and final assessments covering the stated outcomes;
- has a progressive project with rubric;
- has authoritative, current references mapped to chapters;
- documents and tests required software/lab prerequisites;
- contributes demonstrable work products to the integrated capstone.

**Final decision:** Keep the six readers as starting outlines. Do not present them as six complete university-level courses yet. Rebuild depth, labs and assessments, then repeat this audit against the same criteria.

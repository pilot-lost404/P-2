# Edition 3 Verification Matrix

**Runtime:** Python 3.13.5, Go toolchain available on Linux x86_64. Run outputs below were observed in this build environment on 21 November 2026.

## Executed verification

| Artifact | Command / method | Result | Limitations |
|---|---|---|---|
| Distributed Raft simulator | `cd labs/01-distributed/raftsim && go test -race -count=1 ./...` | PASS — 9 tests | In-process deterministic simulator; no actual RPC/network process or disk fsync |
| Distributed Raft simulator | `cd labs/01-distributed/raftsim && go vet ./...` | PASS — exit 0, no diagnostics | Static analysis is not protocol proof |
| MBSE requirements/traceability validator | `cd labs/02-mbse/traceability && python validator.py ..` | PASS — 0 errors, 0 warnings; 18 requirements, 6 needs, 10 model elements, 18 planned verification cases, 22 trace links | Validator checks CSV registers/links and file paths, not SysML grammar or semantics |
| MBSE validator tests | `pytest -q labs/02-mbse/traceability` | PASS — 6 tests | Fixtures and tests do not establish the adequacy of a real engineered system model |
| Reliability lab | `pytest -q labs/03-safety/reliability_lab` | PASS — 19 tests | Hypothetical rates and simplified common-cause/parameter independence assumptions |
| V&V explicit graph checker | `PYTHONPATH=labs/04-vv/modelcheck_lab pytest -q labs/04-vv/modelcheck_lab` | PASS — 4 tests | Finite Python graph exploration only |
| V&V quorum/property model | `PYTHONPATH=labs/04-vv/modelcheck_lab pytest -q labs/04-vv/quorum_model` | PASS — 11 tests | Bounded three-node/one-term model; not TLC or unbounded proof |
| Security authorization reference model | `pytest -q labs/05-security/authorization_lab` | PASS — 6 tests | Policy/reference model only |
| Security training service | `pytest -q labs/05-security/secure_service` | PASS — 23 tests | Local WSGI test service; external scanners and full ASVS assessment not run |
| Security live HTTP smoke | Local loopback test: login, session, create and cross-tenant read | PASS — 200, 200, 201, 404 respectively | Local loopback only; no TLS, deployment, external client or penetration test |
| Security startup boundary | `run.py --host 0.0.0.0` with disposable test args | PASS — rejected non-loopback bind, exit 2 | Does not certify all deployment/network configurations |
| Security audit tampering | Alter audit log then run server | PASS — startup refuses to serve, exit 2 | Local key and log share host; not immutable or non-repudiable |
| In-memory B+ tree | `pytest -q labs/06-data-systems/tinydb` | PASS — 10 tests | In-memory teaching data structure, no persistence/WAL |
| Disk-backed DBMS lab | `PYTHONPATH=labs/06-data-systems/diskdb pytest -q labs/06-data-systems/diskdb` | PASS — 15 tests | Redo-only full-page images; no SQL, delete/merge, MVCC, concurrency, ARIES or power-loss qualification |
| Python aggregate | `PYTHONPATH=labs/04-vv/modelcheck_lab pytest -q labs/02-mbse/traceability labs/03-safety/reliability_lab labs/04-vv/modelcheck_lab labs/04-vv/quorum_model labs/05-security/authorization_lab labs/05-security/secure_service labs/06-data-systems/tinydb labs/06-data-systems/diskdb` | PASS — 94 tests | Tested unit and integration scope only |
| Python compilation | `python -m compileall -q labs/02-mbse labs/03-safety labs/04-vv labs/05-security labs/06-data-systems` | PASS | Syntax compilation does not establish semantic or security correctness |
| Disk B+ tree microbenchmark | `PYTHONPATH=labs/06-data-systems/diskdb python labs/06-data-systems/diskdb/benchmark.py --inserts 250 --order 8` | PASS; benchmark observations below | Ephemeral Linux VM, one run, fsync dominated; do not generalize timings |

### Observed diskdb benchmark

- Python 3.13.5; Linux 6.18.57 x86_64; seed 2026; 250 shuffled inserts; order 8.
- Insert total 0.382173 s; mean 1.5283 ms; p95 2.3739 ms.
- Lookup mean 0.0222 ms; p95 0.0329 ms.
- 250-key range scan 0.000749 s.
- Page file 217,088 bytes; WAL 140,751 bytes.
- These values are a reproducible sample of a local teaching implementation, not a performance claim or comparison to PostgreSQL/BusTub.

## Not executed / external gate

| Artifact | Required tool/action | Why no result is claimed | Evidence needed |
|---|---|---|---|
| SysML v2 model | Import `water-tank-v3.sysml` into SysON v2026.11.0; parse, render required diagrams, export and re-import | SysON workbench was not available in the build runtime | Exact version, parser diagnostics, four rendered views, export/import comparison, semantic review |
| TLA+ specifications | Run TLC from official TLA+ Tools v1.8.0 release using Java 11+ | GitHub DNS/download path unavailable; model checker JAR not present | CLI transcript for safe model with no violations and unsafe mutant counterexample |
| PostgreSQL 18 labs | Execute schema, seed, plans, two-session MVCC, backup/restore | `psql` and Docker are not installed | Server version/config, SQL output/SQLSTATEs, `EXPLAIN (ANALYZE, BUFFERS)`, two-session schedule, row checks, restore logs and measured RPO/RTO |
| Security scanners | Run Ruff/Bandit/Semgrep/dependency audit and guided WSTG/ASVS test set | Scanners were not installed in the build environment | Versions, rulesets, findings, triage and fix verification |
| Independent moderation | External faculty/domain expert reviews six readers, solutions and evidence | No independent reviewer took part | Dated review, findings, corrections, conflict/approval log |
| Learner pilot | Run with prerequisite-qualified learners | No pilot cohort or instrumented course platform | Completion/workload data, assessment feedback and revisions |

## Reproduction command from curriculum root

```bash
PYTHONPATH=labs/04-vv/modelcheck_lab pytest -q \
  labs/02-mbse/traceability \
  labs/03-safety/reliability_lab \
  labs/04-vv/modelcheck_lab \
  labs/04-vv/quorum_model \
  labs/05-security/authorization_lab \
  labs/05-security/secure_service \
  labs/06-data-systems/tinydb \
  labs/06-data-systems/diskdb

python -m compileall -q labs/02-mbse labs/03-safety labs/04-vv labs/05-security labs/06-data-systems

(cd labs/01-distributed/raftsim && go test -race -count=1 ./... && go vet ./...)
```

## Aggregate counts

| Suite | Tests |
|---|---:|
| MBSE validator | 6 |
| Safety/reliability | 19 |
| V&V explicit graph model | 4 |
| V&V quorum/property model | 11 |
| Security policy model | 6 |
| Secure service | 23 |
| In-memory B+ tree | 10 |
| Disk-backed database lab | 15 |
| **Python aggregate** | **94** |
| Go Raft simulator | 9 |

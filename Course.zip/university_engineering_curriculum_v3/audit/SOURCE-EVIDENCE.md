# Audit Evidence and Benchmark Sources

**Audit snapshot:** 21 November 2026. The course files were inspected locally; external sources below establish the academic comparison standard.

## Distributed Systems
- MIT 6.5840 Spring 2026: https://pdos.csail.mit.edu/6.5840/
- MIT 6.5840 general information, labs, grading and check-offs: https://pdos.csail.mit.edu/6.5840/general.html
- MIT 6.5840 schedule: https://pdos.csail.mit.edu/6.5840/schedule.html
- Cambridge Concurrent and Distributed Systems 2025–26: https://www.cl.cam.ac.uk/teaching/2526/ConcDisSys/
- Harvard CS 2620 Distributed Systems 2026: https://read.seas.harvard.edu/cs2620/2026/

## Model-Based Systems Engineering
- Johns Hopkins 645.631 Introduction to MBSE, Fall 2026: https://apps.ep.jhu.edu/syllabus/fall-2026/645.631.81
- Johns Hopkins 645.632 Applied Analytics for MBSE, Spring 2026: https://apps.ep.jhu.edu/syllabus/spring-2026/645.632.81
- NASA-HDBK-1009A registry (active; document date 12 March 2025): https://standards.nasa.gov/standard/NASA/NASA-HDBK-1009
- OMG SysML official specifications: https://www.omg.org/sysml/
- SysON SysML v2 hands-on tutorials: https://doc.mbse-syson.org/syson/v2025.10.0/user-manual/hands-on/tutorials/

## Safety and Risk
- Johns Hopkins 675.761 Reliability Engineering and Analysis, Fall 2026: https://apps.ep.jhu.edu/syllabus/fall-2026/675.761.8VL
- MIT STPA/CAST handbooks: https://www.mit.stamp-institute.com/handbooks
- NASA System Safety: https://sma.nasa.gov/sma-disciplines/system-safety
- NASA Software Assurance and Software Safety: https://sma.nasa.gov/sma-disciplines/software-assurance-and-software-safety

## Verification and Validation
- UTDallas SE 4367 Software Testing, Verification, Validation and Quality Assurance, Fall 2026: https://dox.utdallas.edu/syl171354
- RPI Software Verification 2025: https://www.cs.rpi.edu/academics/courses/fall25/csci4964/
- NASA V&V plan outline: https://www.nasa.gov/reference/appendix-i-verification-and-validation-plan-outline/

## Security Engineering
- RIT SWEN 331 Engineering Secure Software: https://www.se.rit.edu/~swen-331/syllabus/
- RIT web application fuzzer project: https://www.se.rit.edu/~swen-331/projects/fuzzer/
- Johns Hopkins Foundations of Information Assurance, Fall 2026: https://apps.ep.jhu.edu/syllabus/fall-2026/695.601.81
- NIST SP 800-160 Vol. 1 Rev. 1 final: https://csrc.nist.gov/pubs/sp/800/160/v1/r1/final
- NIST SSDF publications index: https://csrc.nist.gov/Projects/ssdf/publications
- OWASP ASVS: https://owasp.org/www-project-application-security-verification-standard/

## Data Systems and Databases
- CMU 15-445/645 Intro to Database Systems, Fall 2026: https://15445.courses.cs.cmu.edu/fall2026/
- CMU 15-445/645 syllabus: https://15445.courses.cs.cmu.edu/fall2026/syllabus.html
- PostgreSQL 18 transaction isolation: https://www.postgresql.org/docs/18/transaction-iso.html
- PostgreSQL 18 serialization failure handling: https://www.postgresql.org/docs/18/mvcc-serialization-failure-handling.html

## Current implementation documentation checked with Context7
- Go official documentation: https://go.dev/doc/
- Go fuzzing guide: https://go.dev/doc/security/fuzz/
- Go race detector: https://go.dev/doc/articles/race_detector
- PostgreSQL 18: https://www.postgresql.org/docs/18/
- SysON v2025.10 documentation: https://doc.mbse-syson.org/syson/v2025.10.0/
- OWASP Developer Guide: https://owasp.org/www-project-developer-guide/

## FMHY
- FMHY educational directory: https://fmhy.net/educational
- Used as a discovery directory only, not as evidence of academic quality or licensing. Legitimate routes include MIT OpenCourseWare, Class Central, OpenLearn, Saylor, OpenHPI and Yale Open Courses.

## Research method
Exa, Firecrawl and TinyFish were used for the requested EFT research sequence and cross-check. Context7 was used for implementation documentation. The benchmark judgments prioritize official university course pages, standards publishers and official technical documentation over directories or search rank.

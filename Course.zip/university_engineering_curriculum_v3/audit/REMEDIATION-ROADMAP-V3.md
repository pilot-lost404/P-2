# Edition 3 Remediation Roadmap — Work Still Required for 100/100

**Current author self-audit:** 91.00/100  
**Target:** full marks under `COURSE-QUALITY-CONTRACT.md`  
**Status:** open; no independent moderation has been conducted.

## P0 — Complete external execution gates

| Course | Work | Required evidence | Current status |
|---|---|---|---|
| MBSE | Parse/import, render, export and re-import the expanded SysML v2 model in current SysON | Exact tool version; all diagnostics; structure, interface, activity and requirement views; exported model; clean re-import; semantic review | Not executed here |
| V&V | Run both TLA+ specs with official TLC v1.8.0 | Safe model completes without invariant violation; unsafe mutant returns a counterexample; retain trace and state count | Not executed here |
| Data Systems | Run PostgreSQL 18 scripts and restore experiment | Schema/seed outputs, SQLSTATE, plans and buffers, two-session anomalies, backup restore, row comparisons, RPO/RTO | Not executed here |
| Security | Install scanners and complete a targeted ASVS/WSTG review of the loopback service | Scanner versions/configuration, findings, triage, fixed regression tests and a human-reviewed test report | Not executed here |

## P1 — Extend implementation scope

| Course | Extension | Acceptance criteria |
|---|---|---|
| Distributed Systems | Separate-process RPC transport and KV service over Raft; snapshot/compaction; deterministic network fault injector; optional sharded KV | Crash/restart, dropped/duplicated/reordered messages and partitions; linearizability histories; safety invariants; race and stress results |
| MBSE | Validate SysML model content and add model queries/reports/parametric calculations and configuration/variation workflow | Actual tool parse; required views; exported requirements/trace matrix; unresolved element report; change-impact reproduction |
| Safety | Validate data/calculation model with an independent reliability engineer; introduce common-cause and repair/maintenance data models | Data provenance, model assumptions, uncertainty method, sensitivity report and external technical review |
| V&V | TLC model execution plus one stronger concurrent protocol or temporal property model | Counterexample and pass output; explicit bounds/fairness assumptions; code/model traceability; independent review |
| Security | Add CSP/headers verification, ASVS subset automation, DAST/fuzzing and broader auth/session/key lifecycle test cases | Reproducible authorized scan; no unresolved critical/high findings within the declared subset; external security review |
| Data Systems | Add B+ tree deletion/merge, iterators, concurrency/latches, MVCC, query execution, checkpointing and a justified recovery algorithm | Invariant/property test suite, restart/recovery injection, query/transaction behavior, independent implementation review |

## P2 — Course moderation and learner validation

1. Have an independent specialist review every course's 14 weekly teaching units, derivations, examples, 84 weekly solutions/checkpoints, 30 extended solutions and lab specifications.
2. Add two timed exams per course with marking keys, grade boundaries and moderated sample responses.
3. Run a learner pilot with people who meet the published prerequisites. Track actual weekly effort, completion, topic errors, assessment clarity and where learners need scaffolding.
4. Rework weak material; record all review findings and re-run the complete verification command set.
5. Publish a versioned course syllabus with explicit academic-integrity, accessibility, copyright, citation and AI-assistance guidance.

## Scoring rule

No score uplift is awarded for a written tool procedure alone. An external gate is only closed by tool output and a reproducible artifact. Independent review and a learner pilot cannot be self-certified by the author. Recompute the score using the same rubric; do not lower requirements to manufacture 100.

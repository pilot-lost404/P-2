# Academic Audit — Edition 2

**Audit date:** 21 November 2026  
**Result:** 86.83/100 average of rubric-weighted course scores across six readers  
**Readiness threshold:** 70/100  
**Target:** 100/100; not achieved  
**Audit type:** Author self-audit against a published editorial rubric; no independent examiner or accrediting body participated.

## Executive verdict

The Edition 2 pack has moved from introductory draft to a substantially complete advanced-undergraduate / early-graduate self-study package. It now contains six expanded 14-week readers, a research-backed source library, practical starter labs with locally executed tests, 84 weekly problems with worked checkpoints, 30 longer worked problems, a comprehensive integrated capstone, and explicit verification records.

**The pack is not honestly scoreable at 100/100 yet.** The current score is 86.83/100. All six course scores exceed the 70/100 readiness threshold, but several meaningful gaps remain: no actual SysML tool import/render validation, no execution of the PostgreSQL 18 schema/query/isolation/restore labs in this environment, no full consensus/Raft implementation, no full database-engine implementation, and no independent faculty/subject-matter-expert review.

The target is now a clear engineering backlog rather than an unexplained wish to add more content.

## Rubric

| Dimension | Weight | What is assessed |
|---|---:|---|
| Teaching depth and rigor | 30 | Learning outcomes, prerequisites, 14-week progression, definitions, derivations, worked examples, limits |
| Technical correctness | 20 | Equations, protocol claims, versioned tool behavior, assumptions and primary-source grounding |
| Practical reproducibility | 20 | Lab completeness, starter artifacts, tests, setup, expected evidence and execution status |
| Assessment and solutions | 15 | Problem-set breadth, worked solutions, exam blueprint, project milestones and marking rubrics |
| Sources and traceability | 10 | Course and standards benchmarks, source mapping, versions/dates and artifact traceability |
| Course design and coherence | 5 | Prerequisites, workload, sequencing, assessment balance and capstone integration |

See `COURSE-QUALITY-CONTRACT.md` for full-credit evidence gates.

## Course-by-course results

### 1. Distributed Systems — 88/100

**Improved:** 14 expanded weeks cover model assumptions, RPC delivery semantics, idempotency, logical time/vector clocks, failure detectors, leases/fencing, consistency, quorum replication, Raft invariants, transactions, durable logs, sharding, BFT and operations. The Go logical-clock lab has unit tests and race-detector evidence; the existing idempotency lab is retained with its process-local/durability limitations clearly stated. Worked problems cover vector-clock reasoning, crash windows, quorum intersections, Raft election safety and Little's Law.

**Remaining gap:** the pack does not yet include a complete student-built Raft implementation, replicated key-value service, distributed filesystem or end-to-end cluster project. The logical-clock lab is intentionally small. The MIT 6.5840 benchmark includes staged labs and exams at a level of implementation that should be the next upgrade.

### 2. Model-Based Systems Engineering — 84/100

**Improved:** expanded coverage of systems lifecycle, ConOps, stakeholder needs, testable requirements, SysML v2, structural/behavioral/parametric modeling, allocation, interfaces, trade studies, traceability, model QA and configuration. A water-tank SysML v2 textual starter, requirements register, traceability matrix, full lab sequence, model interchange assignment and capstone are now included. The 14-module JHU 645.631 Fall 2026 sequence was used as a university benchmark.

**Remaining gap:** the starter model has not been imported into a live SysML v2 tool in this runtime. No complete `.sysml` model export, parser validation report, rendered model review or tool-specific assessment is claimed. Model-level semantic validation and independent MBSE review are still needed.

### 3. Safety and Risk Analysis — 88/100

**Improved:** qualitative hazard analysis is supplemented with exponential/Weibull reliability, series/parallel RBD calculations, fault trees and overlapping cut sets, Beta-Binomial updates, Monte Carlo extension, FMEA/FMECA, ETA, STPA, safety constraints and safety-case reasoning. A tested Python calculator covers validated numeric functions and an exact small-tree calculation; five worked problems target calculation and method selection.

**Remaining gap:** the calculator is a teaching tool and assumes independent basic events. It does not provide full-scale PRA, dynamic fault trees, common-cause parameter estimation, human reliability analysis or validated safety-analysis tooling. Domain specialist review remains necessary for real system decisions.

### 4. Verification and Validation — 88/100

**Improved:** test design, equivalence partitioning, boundaries, test oracles, MC/DC, mutation, static/dynamic/formal methods, integration/system/acceptance testing, statistical reasoning, concurrency/fault injection, Hoare logic, temporal logic and model checking are covered. A Python explicit-state checker is executable and tested; it returns shortest counterexample paths. A finite tank-controller model assignment and full evidence standard are included.

**Remaining gap:** there is no industrial-grade model checker, theorem prover, requirements management system, coverage tool or independent IV&V campaign configured. The explicit-state checker is a small finite graph engine, not a general formal verification platform. High-assurance domain needs tool qualification and independent review.

### 5. Security Engineering — 87/100

**Improved:** security architecture and lifecycle, threat modeling, security requirements, role/facility scope, authentication and authorization, cryptography/key lifecycle, web/API vulnerabilities, cloud/supply chain, incident response and verification are covered. A deny-by-default facility-scoped reference policy has six automated tests; problem sets cover STRIDE, IDOR/tenant boundaries, password storage, key management and traceability.

**Remaining gap:** the reference policy is not a complete application and does not implement authentication, token verification, cryptography, persistent audit, network controls, cloud IAM or CI scanning. Full guided ASVS/DAST/fuzzing exercises and independent penetration testing remain necessary.

### 6. Data Systems and Databases — 86/100

**Improved:** relational theory, normalization, query algebra, SQL, storage, indexes, query planning, transactions, schedules, MVCC, WAL, backups, migrations, distributed data and analytics are covered. A tested in-memory B+ tree supports insertion, point lookup, range scans and invariants. The PostgreSQL 18 lab includes a relational schema, rerunnable seed, workload generation, plan comparisons, two-session write-skew experiment and backup/restore instructions.

**Remaining gap:** PostgreSQL tools were unavailable here, so SQL execution, query plans, actual locking behavior and restore evidence remain unverified. The B+ tree is an in-memory index exercise; no complete disk-backed engine (page manager, buffer pool, query executor, concurrency-control manager and recovery) is included. This remains a major distinction from CMU 15-445/645.

## Research benchmark and why the structure changed

The course architecture was compared to public university syllabi and primary documentation:

- MIT 6.5840 Spring 2026 gives distributed systems substantial programming labs in MapReduce, key-value service, Raft, Raft-backed KV and sharding, plus exams and optional project.
- CMU 15-445/645 Fall 2026 emphasizes DBMS internals, storage/index/query processing/concurrency/recovery and cumulative BusTub projects.
- Johns Hopkins 645.631 Fall 2026 includes a 14-module sequence for SysML diagrams, model setup, stakeholder analysis, requirements, logical/physical architecture and trade studies.
- RPI CSCI 4964/6964 Software Verification provides an additional university course benchmark for proof-based software verification; the course also uses TLA+ and primary formal-methods documentation.
- NASA, OMG, NIST, OWASP, Go and PostgreSQL primary documents provide the lifecycle, SysML, security, language and DBMS behavior reference layer.

Full citations, version snapshots and caveats are in `../09-SOURCE-LIBRARY.md`. FMHY was treated as a discovery directory only, not as an academic authority or licence guarantee.

## Verification evidence

The assessment count was checked from the files: 84 weekly questions (14 per course) with solution checkpoints, 30 longer worked problems (five per course), and 20 capstone acceptance tests. These are author-created learning assets; independent moderation is still outstanding.


See `VERIFICATION-MATRIX.md`. In brief:

- Go clock lab: `go test -race -count=1 ./...` passed; `go vet ./...` passed.
- Go idempotency lab: `go test -race -count=1 ./...` passed; `go vet ./...` passed.
- Python reliability, model-checking and authorization labs: 29 tests passed across the Python reliability, model-checking, authorization and B+ tree labs; compileall passed.
- PostgreSQL and SysML external workflows: not executed here; environment lacked `psql`, Docker and a SysML workbench.
- All external course pages, standards and documentation are references; the curriculum is not an authorized distribution of their protected contents.

## Priority work to reach the next quality tier

1. Build and test a complete replicated key-value service using Raft (or a formally scoped consensus exercise), with crash/restart and network partition fault injection.
2. Complete the database-engine implementation lab: page layout, buffer pool, B+ tree, iterator query engine, concurrency control and recovery.
3. Execute the SysML v2 model in SysON, export/re-import it, capture parser/model-quality reports and have an MBSE reviewer assess the result.
4. Execute the PostgreSQL 18 lab on a clean container, save all plan/isolation/backup/restore evidence and document observed engine-specific behavior.
5. Add a complete guided security testing lab with ASVS mapping, SAST/DAST, fuzzing and negative API tests in a local authorized application.
6. Obtain independent faculty or domain-expert review of the six readers and assessment keys; correct all findings and rerun the rubric.

## Final decision

**Ready for advanced self-study, with external execution and peer-review requirements. Not 100/100, not accredited, and not a substitute for domain authority approval.** The materials are materially stronger than the first edition and now have verifiable local lab evidence. Complete the six priority items above before claiming top-tier university course completeness.

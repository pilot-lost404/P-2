# Edition 2 Remediation Roadmap — Evidence Required to Reach 100/100

**Current author score:** 86.83/100  
**Target:** 100/100 under `COURSE-QUALITY-CONTRACT.md`  
**Status:** Open; the current audit is not an independent grade.

A score of 100 requires every rubric dimension to be supported by evidence, not merely a longer reader. The actions below are ordered by the size of the current evidence gap and the extent to which they unlock other work.

## Gate 1 — Execute the external labs and capture primary evidence

| Course | Required work | Evidence needed for closure |
|---|---|---|
| MBSE | Import `labs/02-mbse/water-tank.sysml` into a current SysML v2 tool such as SysON; repair syntax/tool-support issues; build the full model and export/re-import it | Tool/version record, import/export logs, parser/model diagnostics, four or more rendered views, complete requirement/model/test traceability, independent modeling review |
| Data systems | Run all PostgreSQL 18 scripts in a disposable instance; run the two-session isolation schedule, query-plan comparisons and logical backup/restore | Version/configuration manifest, raw SQL outputs and SQLSTATEs, `EXPLAIN (ANALYZE, BUFFERS)` output, row-count checks, restore validation and measured RPO/RTO |
| V&V | Run model-checker/formal exercises with a maintained external tool (e.g. TLA+ or an approved equivalent) | Model, tool/version, invariant/property definitions, counterexample or proof output, limits and independent interpretation |

**Exit condition:** each external task has reproducible evidence and has been reviewed by someone other than the author. No score uplift is awarded for a written procedure alone.

## Gate 2 — Build the missing systems implementation depth

| Course | Required implementation | Acceptance evidence |
|---|---|---|
| Distributed systems | Complete staged replicated key-value service: deterministic state machine, Raft leader election/log replication, persistence/snapshotting, client retry semantics and sharding | Deterministic fault-injection tests for crash/restart, message loss/delay/duplication, partition and leader replacement; safety/liveness invariants; race and stress results; architecture explanation |
| Data systems | Extend the B+ tree exercise into a disk-backed storage/index component with page format, buffer pool, pin/unpin, dirty-page policy, iterator interface and crash-safe persistence | Structural/page invariants, eviction and I/O tests, restart/recovery test, benchmarks, failure-injection report and student code-ownership review |
| Security | Build an intentionally local, vulnerable training service and a guided defensive lab mapped to a pinned OWASP ASVS 5.0 subset | Authentication/session tests, object-level authorization and tenant-isolation tests, input-validation tests, SAST/DAST and dependency scan, limited fuzzing, remediation evidence and explicit scope |
| Safety | Extend reliability exercises with parameter uncertainty, common-cause analysis and sensitivity/Monte Carlo calculations | Validated input data assumptions, reproducible simulation seed, uncertainty intervals, sensitivity ranking, model limitations and expert review |
| V&V | Add property-based/stateful tests and a small real formal model for safety invariants and concurrent behaviors | Executable properties, independent counterexample review, coverage reports with limitations and traceability to requirements/hazards |

**Exit condition:** code and models execute in a clean environment, all test outputs are captured, and claims are limited to the tested model/system boundary.

## Gate 3 — Strengthen assessment and course moderation

1. Have an independent instructor or subject specialist review every weekly reader, all 84 weekly problem checkpoints and all 30 longer worked solutions.
2. Add two full-length timed examinations per course with marking schemes, grade boundaries, sample high/medium/low responses and moderation notes.
3. Assess each student's ability to derive, modify and defend the work in oral/code/model ownership checks.
4. Run a pilot with learners who meet the stated prerequisites; measure workload, completion rates, confusing explanations and assessment discrimination.
5. Correct every critical/important review finding, update traceability, and rerun all automated checks.

**Exit condition:** dated external review records, pilot feedback with changes made, final assessment pack and a closed findings log.

## Gate 4 — Re-audit using the same scoring contract

For every course, the reviewer must inspect the 14-week content, worked derivations, lab execution evidence, assessment validity, primary-source mappings and project outputs. Recompute every dimension from the evidence. A score of 100 is permitted only when all full-credit gates in `COURSE-QUALITY-CONTRACT.md` are met and no external validation or peer review remains outstanding.

## Current blockers that prevent 100/100

- No SysML v2 parser/import/render evidence exists in this build runtime.
- No PostgreSQL 18 execution, query plan, isolation trace or restore evidence exists in this build runtime.
- No complete Raft-backed service or disk-backed database engine has been implemented in the pack.
- The security lab is a reference authorization policy, not a full security test application.
- The safety calculator is deliberately small and assumes independent basic events in its exact enumeration model.
- The formal checker is a small finite explicit-state graph search, not an industrial model checker or theorem prover.
- No independent faculty/domain-expert moderation or learner pilot has occurred.

These are concrete evidence gates. Do not convert an unfinished task into a score claim by adding links, increasing word count or changing the rubric.

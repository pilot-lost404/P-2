# Integrated Capstone — Remote Water-Tank Monitoring and Control Platform
**Purpose:** A single engineering problem through which all six courses are applied.  
**Status:** Educational case study only. Not a deployable industrial-control design. Do not connect student code to real pumps, valves, electrical equipment or public networks.

## 1. Problem statement

A facility operator wants a system that monitors the level of a water tank, controls filling locally, records measurements and alarms, and provides remote visibility. Authorized operators may request a change to the target level. The system must continue its local control function during loss of the remote network. It must provide clear feedback when measurements are stale or invalid and retain an auditable history of remote commands.

The project is intentionally small enough for a student team but rich enough to expose systems-engineering concerns. It includes a physical process, sensor, controller, actuator, gateway, network, API, identity service, database, operator interface and operating procedures.

### 1.1 Educational boundary

The student implementation is a simulation or mock environment. Physical safety constraints, actuator performance and sensor behavior are represented by software models and test fixtures. Any actual industrial deployment would require domain-specific engineering, hazard analysis, applicable standards, qualified personnel, independent review and formal acceptance by the responsible authority.

## 2. Stakeholders and needs

| ID | Stakeholder | Concern / need |
|---|---|---|
| STK-01 | Facility operator | Know current tank state and receive actionable alarms. |
| STK-02 | Maintenance technician | Diagnose sensor, actuator, network and power faults safely. |
| STK-03 | Facility owner | Avoid overflow, equipment damage and service interruption. |
| STK-04 | Security administrator | Ensure only authorized people and services can issue commands. |
| STK-05 | Safety authority | Ensure local safeguards remain effective in degraded conditions. |
| STK-06 | Data analyst | Obtain traceable, time-stamped telemetry and alarm history. |

### 2.1 Concept of Operations (ConOps)

**Normal operation:** The sensor samples tank level. The local controller validates measurement quality, updates its operating state and controls the simulated pump/valve within configured limits. A gateway sends telemetry to a remote service. The service stores readings and presents current/historical status. A remote operator may submit a target-level command; the service authenticates and authorizes it, records the command, and forwards it to the gateway. The local controller independently validates command freshness, authority and safety constraints before applying it.

**Network outage:** Local sensing and control continue. The gateway buffers telemetry within a defined capacity and marks the remote connection degraded. Cloud-originated commands are unavailable or rejected according to explicit policy. Recovery does not replay stale commands blindly. Buffered telemetry is uploaded with original event timestamps and stable event identifiers.

**Sensor fault:** The controller detects invalid, stale, implausible or missing data. It enters the defined safe/degraded state, prevents unsafe automatic filling and raises an alarm. Recovery requires valid measurements and the specified reset conditions.

**Maintenance:** An authorized technician may inspect and calibrate the system. Maintenance mode must be visible, controlled and auditable. It does not silently remove independent safety constraints.

## 3. System boundary and architecture

```mermaid
flowchart LR
  subgraph Local["Local control zone"]
    S[Level sensor simulator] --> C[Local controller]
    C --> A[Pump / valve simulator]
    P[Local operator panel] <--> C
    C <--> G[Gateway + durable buffer]
  end

  subgraph Remote["Remote service zone"]
    API[Command / telemetry API]
    IAM[Identity and authorization]
    DB[(PostgreSQL)]
    UI[Operator dashboard]
    AUD[Audit service]
    API <--> IAM
    API <--> DB
    API --> AUD
    UI <--> API
  end

  G <-->|Authenticated messages| API
  ENV[Physical tank model / environment] <--> A
```

### 3.1 Authority boundaries

The local controller is authoritative for local actuator interlocks and safe-state behavior. The cloud service is authoritative for user identity, remote authorization, audit records and data presentation. The gateway transports messages and buffers telemetry; it must not be able to override local safety constraints. The database is authoritative for the persisted command and telemetry history, but current physical state may be unknown when telemetry is stale.

### 3.2 Interface contract summary

| Interface | Data | Key contract elements |
|---|---|---|
| Sensor → controller | level, sample time, quality | units, range, sequence, freshness, invalid-state representation |
| Controller → actuator | target state, command reason | allowed states, local interlocks, command response, feedback |
| Controller → gateway | telemetry event | unique event ID, event time, sequence, schema version |
| Gateway → API | telemetry / command acknowledgement | authenticated channel, retry, duplicate handling, backpressure |
| Operator → API | target-level command | authenticated principal, facility scope, idempotency key, audit |
| API → database | events and configuration | transaction boundary, retention, constraints, recovery behavior |

## 4. Requirements baseline

Requirements below are illustrative teaching requirements. Students must challenge, refine and verify the criteria; the values are not certified engineering limits.

| ID | Requirement | Primary discipline | Proposed verification |
|---|---|---|---|
| SYS-001 | The local controller shall continue its defined autonomous control behavior during loss of the remote network. | Systems / distributed | Fault-injection test |
| SYS-002 | The controller shall mark a measurement invalid when its age exceeds the configured freshness limit. | Data / safety | Boundary test |
| SYS-003 | An invalid measurement shall not authorize automatic filling. | Safety | State-transition test |
| SYS-004 | A high-high level condition shall cause the defined local shutdown response within the allocated response time. | Safety | Timed test + analysis |
| SYS-005 | The remote API shall reject a command from an unauthenticated principal. | Security | Negative API test |
| SYS-006 | The API shall authorize commands against both role and facility scope. | Security | Authorization matrix |
| SYS-007 | Repeated requests with the same command identifier shall not create repeated business effects. | Distributed / data | Duplicate-request test |
| SYS-008 | Accepted telemetry events shall have unique event identifiers and preserved event timestamps. | Data | Constraint + integration test |
| SYS-009 | The service shall record the actor, target, command ID, request time and decision for every remote command. | Security / V&V | Audit verification |
| SYS-010 | The service shall expose the age and quality of the latest telemetry. | Data / validation | API and user test |
| SYS-011 | The database shall preserve referential integrity between facilities, tanks, sensors and measurements. | Data | Constraint test |
| SYS-012 | The system shall retain a defined recoverable data point and restore service within approved RPO/RTO objectives. | Data / reliability | Restore exercise |
| SYS-013 | The operator dashboard shall distinguish current, stale and unavailable telemetry. | Validation / UX | Scenario-based validation |
| SYS-014 | Every system requirement shall trace to a design element and verification evidence. | MBSE / V&V | Traceability audit |
| SYS-015 | Every identified safety hazard and high-priority security threat shall have an owner, treatment and closure rationale. | Safety / security | Review |

A complete requirement record also stores source, rationale, assumption, owner, status, version, verification method and acceptance criterion. Do not treat a requirement table as complete merely because every row contains a sentence.

## 5. Distributed-systems design

### 5.1 Event identity and deduplication

Each telemetry event has:
- `event_id`: stable unique identifier generated at the source;
- `sensor_id`: source identity;
- `sequence_no`: monotonically increasing sequence within the defined source epoch;
- `event_time`: time the measurement was made;
- `received_at`: time the service received it;
- `schema_version`: interpretation of the payload;
- `quality`: valid, stale, out-of-range, disconnected or unknown.

The API may receive an event more than once. The database should enforce uniqueness on `event_id` or a documented composite key. A retry should return an acknowledgement without inserting a second logical measurement. Duplicate detection is not the same as discarding all records with the same value: two equal readings at different times are distinct observations.

### 5.2 Command protocol

A remote command should contain:
- command ID / idempotency key;
- target facility and tank;
- desired target value;
- authenticated principal context (derived server-side, not trusted from body fields);
- creation time and expiration;
- schema version;
- reason / operator note where required.

The server validates identity, authorization, range and command policy before persisting the command. It records the decision and an outbox event in one database transaction. The gateway retries delivery with the same command ID. The local controller checks command freshness, target identity, range, operating mode and interlocks before acting. The controller returns a result referencing the same command ID.

### 5.3 Failure behavior

| Failure | Required behavior to define and test |
|---|---|
| API unavailable | Local control continues; gateway buffers telemetry within limit. |
| Response lost after database commit | Client retries same command ID; service returns recorded result. |
| Duplicate telemetry | Unique event ID prevents duplicate logical insertion. |
| Gateway restart | Persisted buffer is recovered without corrupting sequence/order. |
| Clock drift | Freshness policy uses defined clock assumptions; stale status is visible. |
| Database failover | API reports command state as pending/unknown until durable outcome is established. |
| Old command replay | Expiration, command ID and local policy reject unsafe replay. |

Do not claim end-to-end exactly-once delivery. State the narrower guarantee: for a defined command ID and retention horizon, the application ensures at most one accepted business transition, subject to durable storage and controller deduplication assumptions.

## 6. Safety analysis starter pack

### 6.1 Losses and hazards

| ID | Loss | ID | Hazard |
|---|---|---|---|
| L-01 | Injury or property damage | H-01 | Tank level exceeds safe physical limit. |
| L-02 | Equipment damage | H-02 | Pump runs in a prohibited dry/unsafe condition. |
| L-03 | Loss of service | H-03 | Controller cannot determine a safe local state. |
| L-04 | Unauthorized physical effect | H-04 | Remote command changes actuator behavior outside allowed authority. |

### 6.2 Preliminary FMEA

| Item/function | Failure mode | System effect | Detection/control question |
|---|---|---|---|
| Level sensor | stuck low | controller may continue filling | freshness, plausibility, independent limit |
| Level sensor | stale but plausible | incorrect process model | timestamp age and sequence checks |
| Controller | wrong state transition | unsafe actuator command | independent review and state tests |
| Valve | stuck open | inflow continues | independent shutdown path and feedback |
| Network | partition | cloud view becomes stale | local autonomy and stale indicator |
| Gateway | duplicate replay | repeated command/event | stable IDs and deduplication |
| Operator panel | misleading mode indication | operator acts on false belief | mode annunciation and usability test |

### 6.3 STPA starter analysis

Control action: `Close inlet valve`.

Potential unsafe control actions:
1. Not provided when high-high condition exists.
2. Provided when closure would create another defined hazard (context-dependent; e.g., unsafe process transient).
3. Provided too late after high-high detection.
4. Applied for insufficient duration or released too early.

Potential causal scenarios:
- controller's process model contains stale measurement;
- high-high sensor shares power with failed primary sensor;
- maintenance mode bypass remains active after maintenance;
- a network command changes a threshold without adequate local validation;
- alarm flood hides the critical high-level alert.

Students must expand each scenario into a control structure, feedback path, causal factors, safety constraint and verifiable requirement.

## 7. Security analysis starter pack

### 7.1 Assets

Control authority, account credentials, facility ownership mapping, target configuration, event history, audit logs, signing keys, gateway identity, sensor identity and service availability.

### 7.2 Trust boundaries

Public browser ↔ API; API ↔ identity service; cloud ↔ gateway; gateway ↔ local controller; application ↔ database; administrator ↔ deployment pipeline.

### 7.3 Illustrative threats

| Threat | STRIDE category | Mitigation direction | Verification |
|---|---|---|---|
| Stolen operator session | Spoofing | MFA, session expiry, revocation | stolen/revoked session test |
| Cross-facility command | Elevation of privilege | object-level authorization | negative ownership test |
| Replayed old command | Tampering / replay | expiry, stable ID, local sequence policy | replay test |
| Altered telemetry | Tampering | authenticated channel, source identity, integrity | message tamper test |
| Audit deletion | Repudiation | restricted append-only audit path, backup | audit integrity review |
| API flooding | Denial of service | rate limits, quotas, backpressure | load/flood test |
| Leaked database secret | Information disclosure | secret manager, least privilege, rotation | repository scan and rotation drill |

Risk should be ranked using scenario-specific evidence. STRIDE categories are prompts, not severity ratings.

## 8. Logical data model

```mermaid
erDiagram
  FACILITY ||--o{ TANK : contains
  TANK ||--o{ SENSOR : monitored_by
  SENSOR ||--o{ MEASUREMENT : produces
  FACILITY ||--o{ USER_FACILITY : grants_scope
  APP_USER ||--o{ USER_FACILITY : assigned
  APP_USER ||--o{ COMMAND : issues
  TANK ||--o{ COMMAND : target
  COMMAND ||--o{ AUDIT_EVENT : records
  TANK ||--o{ ALARM_EVENT : generates
```

### 8.1 PostgreSQL schema starter

```sql
CREATE TABLE facility (
    facility_id bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    name text NOT NULL,
    timezone text NOT NULL,
    created_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE tank (
    tank_id bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    facility_id bigint NOT NULL REFERENCES facility(facility_id),
    tank_code text NOT NULL,
    capacity_litres numeric(12,2) NOT NULL CHECK (capacity_litres > 0),
    target_percent numeric(5,2) NOT NULL
      CHECK (target_percent >= 0 AND target_percent <= 100),
    UNIQUE (facility_id, tank_code)
);

CREATE TABLE sensor (
    sensor_id bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    tank_id bigint NOT NULL REFERENCES tank(tank_id),
    sensor_code text NOT NULL,
    enabled boolean NOT NULL DEFAULT true,
    UNIQUE (tank_id, sensor_code)
);

CREATE TABLE measurement (
    measurement_id bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    event_id uuid NOT NULL UNIQUE,
    sensor_id bigint NOT NULL REFERENCES sensor(sensor_id),
    sequence_no bigint NOT NULL CHECK (sequence_no >= 0),
    event_time timestamptz NOT NULL,
    received_at timestamptz NOT NULL DEFAULT now(),
    level_percent numeric(6,3),
    quality text NOT NULL CHECK
      (quality IN ('VALID','STALE','OUT_OF_RANGE','DISCONNECTED','UNKNOWN')),
    schema_version integer NOT NULL CHECK (schema_version > 0),
    UNIQUE (sensor_id, sequence_no)
);

CREATE INDEX measurement_sensor_time_idx
    ON measurement(sensor_id, event_time DESC);

CREATE TABLE app_user (
    user_id bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    email text NOT NULL UNIQUE,
    password_verifier text NOT NULL,
    active boolean NOT NULL DEFAULT true
);

CREATE TABLE user_facility (
    user_id bigint NOT NULL REFERENCES app_user(user_id),
    facility_id bigint NOT NULL REFERENCES facility(facility_id),
    role text NOT NULL CHECK (role IN ('OPERATOR','SUPERVISOR','ADMIN')),
    PRIMARY KEY (user_id, facility_id)
);

CREATE TABLE command (
    command_id uuid PRIMARY KEY,
    tank_id bigint NOT NULL REFERENCES tank(tank_id),
    requested_by bigint NOT NULL REFERENCES app_user(user_id),
    requested_target_percent numeric(5,2) NOT NULL
      CHECK (requested_target_percent >= 0 AND requested_target_percent <= 100),
    created_at timestamptz NOT NULL DEFAULT now(),
    expires_at timestamptz NOT NULL,
    status text NOT NULL CHECK
      (status IN ('PENDING','ACCEPTED','REJECTED','APPLIED','EXPIRED','FAILED')),
    result_detail text,
    CHECK (expires_at > created_at)
);

CREATE TABLE audit_event (
    audit_id bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    command_id uuid REFERENCES command(command_id),
    actor_user_id bigint REFERENCES app_user(user_id),
    event_type text NOT NULL,
    event_time timestamptz NOT NULL DEFAULT now(),
    detail jsonb NOT NULL DEFAULT '{}'::jsonb
);
```

This schema is a starting point, not a complete production design. A serious design must consider partitioning and retention for telemetry, append-only audit controls, time synchronization, tenant isolation, RLS or equivalent access patterns, data deletion rules, indexes, migration behavior and backup/restore.

## 9. Verification and validation matrix starter

| Requirement | Method | Test/evidence |
|---|---|---|
| SYS-001 local autonomy | Test | disconnect gateway/network; verify simulated local controller still transitions correctly |
| SYS-002 freshness | Test | test age just below, at and above threshold |
| SYS-003 invalid sensor behavior | Test | inject null, stale and implausible values |
| SYS-004 high-high shutdown | Timed test + analysis | measure detection-to-command delay and actuator model response |
| SYS-005 authentication | Test | missing, malformed, expired and revoked credential |
| SYS-006 facility scope | Test | attempt command against unassigned facility |
| SYS-007 idempotency | Integration test | submit same command ID repeatedly; inspect state and audit records |
| SYS-008 telemetry uniqueness | Database test | insert duplicate event ID and duplicate source sequence |
| SYS-009 audit | Inspection + test | compare command decisions against audit events |
| SYS-012 recovery | Demonstration | restore backup to clean environment and measure RPO/RTO |
| SYS-013 operator understanding | Validation | scenario test with representative users |
| SYS-014 traceability | Analysis | automated trace query and manual review |
| SYS-015 risk closure | Review | inspect hazard/threat owner, evidence and disposition |

Verification confirms specified requirements. Validation asks whether the resulting system supports the actual operating concept. A passing automated test suite cannot substitute for a representative operator validation session.

## 10. Suggested semester project milestones

| Milestone | Work package | Review question |
|---|---|---|
| M1 | Stakeholders, boundary, ConOps, assumptions | Is the problem and operating context understood? |
| M2 | Requirements and architecture model | Are needs translated into testable requirements and allocated? |
| M3 | Hazard analysis | Are losses, hazards, UCAs and causal scenarios covered? |
| M4 | Threat model | Are assets, trust boundaries and abuse paths identified? |
| M5 | Database and API implementation | Are integrity, idempotency and authorization enforced? |
| M6 | Distributed failure tests | Does the system behave coherently during partitions and retries? |
| M7 | V&V execution | Is every critical requirement tied to reproducible evidence? |
| M8 | Final safety/security/architecture review | Are residual risks and limitations explicit? |

## 11. Marking rubric

| Criterion | Weight | Excellent evidence |
|---|---:|---|
| System definition and requirements | 15% | clear boundary, complete needs, measurable traceable requirements |
| MBSE model and architecture | 15% | consistent structure/behavior/interface models with usable traceability |
| Safety analysis | 15% | correct FMEA/FTA/STPA use, causal reasoning, justified controls |
| Security engineering | 15% | meaningful threat scenarios, least privilege, tested mitigations |
| Distributed behavior | 15% | explicit failure model, safe retries, consistency and recovery reasoning |
| Data systems | 10% | normalized schema, constraints, transaction and recovery evidence |
| V&V and evidence quality | 10% | reproducible tests, configuration capture, anomaly closure |
| Technical communication | 5% | precise claims, clear diagrams, candid limitations |

### Critical deductions

- Claiming "exactly once" without defining the boundary and mechanism.
- Treating a role check as sufficient object-level authorization.
- Treating a backup as proven without a restore.
- Using an RPN as if it were a probability.
- Claiming a diagram is a complete MBSE model without semantic relations.
- Treating passing verification tests as proof of stakeholder validation.
- Claiming a penetration test proves the absence of vulnerabilities.
- Using cloud connectivity as the only path for a critical local safety function.

## 12. Final review checklist

- [ ] System boundary, stakeholders, environment and assumptions are explicit.
- [ ] Every requirement is uniquely identified, measurable and has an acceptance criterion.
- [ ] Requirement-to-model-to-test traceability is bidirectional.
- [ ] Normal, degraded, maintenance and fault modes are represented.
- [ ] Every hazard has a scenario, control, owner and disposition.
- [ ] Every high-priority threat maps to a mitigation and verification evidence.
- [ ] Database constraints enforce the important integrity rules.
- [ ] Command retries reuse the same operation identifier.
- [ ] Local control behavior is independent of remote network availability.
- [ ] Recovery has been demonstrated from a backup.
- [ ] Test configurations, anomalies and results are recorded.
- [ ] Residual risk, assumptions and limitations are visible in the final report.

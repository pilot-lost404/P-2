# Course 4 — Verification and Validation (V&V)
**Level:** Upper-undergraduate / early graduate  
**Duration:** 14 teaching weeks  
**Expected workload:** 8–10 hours per week  
**Prerequisites:** Software engineering, requirements engineering, basic programming and systems concepts.

## Course description

Verification and validation are evidence-producing engineering processes. Verification asks whether a product or work product satisfies its specified requirements. Validation asks whether the resulting product fulfills its intended purpose in its intended context. The activities may use similar methods—test, analysis, inspection or demonstration—but they answer different questions.

A system may pass every test derived from an incomplete specification and still fail the user's real need. Conversely, a system may appear useful in a demonstration while violating a critical performance, security or safety requirement. V&V therefore begins before implementation: requirements, architecture, testability, acceptance criteria and evidence plans must be designed together.

This course covers requirements quality, V&V planning, test design, levels of testing, integration, automation, model-based testing, formal analysis, performance, safety/security testing, traceability, anomaly management and acceptance. NASA's systems engineering guidance is used as a systems-level reference; software testing methods are taught as complementary techniques.

## Learning outcomes

Students should be able to:
1. Distinguish verification, validation, qualification, acceptance and regression testing.
2. Assess whether a requirement is objectively verifiable.
3. Select test, analysis, inspection or demonstration based on the claim being made.
4. Design tests using equivalence classes, boundaries, decision tables, state transitions and pairwise coverage.
5. Plan unit, integration, system, acceptance and operational tests.
6. Use traceability and coverage measures without confusing coverage with correctness.
7. Design reliable test environments, test data and test oracles.
8. Apply automation, continuous integration, mutation testing and defect analysis appropriately.
9. Verify safety and security requirements with suitable evidence.
10. Produce a reproducible V&V report and support a release decision.

---

## Week 1 — Foundations and the V-model

The V-model is a lifecycle representation that pairs decomposition and specification activities on the left with integration and verification activities on the right. It is a planning aid, not a claim that all projects must follow a waterfall sequence. Early validation and continuous verification can occur throughout iterative development.

At the top, stakeholder needs and operational concepts are validated. System requirements are derived and verified for quality. Architecture and subsystem requirements are decomposed. Implementation follows. On the right, components are verified against their allocated requirements, subsystems are integrated and verified, and the complete system is validated against stakeholder needs and intended operational use.

### Verification vs validation

- **Verification:** evidence that specified requirements are met. "Did we build the product correctly against its approved specification?"
- **Validation:** evidence that the product is suitable for its intended use. "Did we build the right product for its users and mission?"

NASA describes verification as proof of compliance with requirements and validation as proof that the product accomplishes its intended purpose in the intended environment. This distinction should be preserved even when the same test produces evidence for both.

### Worked example

Requirement: `The API shall respond to 95% of valid status requests within 300 ms under 100 requests per second for a 10-minute test.` Verification needs a controlled test environment, request distribution, measurement boundary and pass criterion. Validation asks whether this service level is adequate for operators making decisions. Passing the requirement does not prove the chosen 300 ms threshold is useful.

### Laboratory

Create a V-model for the tank platform. Map each left-side work product to one or more right-side verification activities. Identify at least two validation activities that should occur before the final system is built.

---

## Week 2 — Requirements quality and testability

A requirement is verifiable when objective evidence can determine whether it has been satisfied. The requirement must define the relevant condition, system boundary, stimulus, required response and acceptable range. An untestable adjective is not made testable by writing a test that interprets it arbitrarily.

Weak: "The system shall reliably store telemetry."  
Improved: "For accepted telemetry events, the service shall durably commit the event and return an acknowledgement only after the database transaction commits."  
The improved form is more testable, but its storage durability semantics, failure model and acknowledgement boundary still need definition.

A good verification method is selected during requirements development. Not every requirement should be tested by executing software. A physical dimension may be inspected; a mathematical limit may be verified by analysis; an operator workflow may be demonstrated; a timing requirement may require a controlled test.

### Requirement verification record

For each requirement, capture: ID, exact baseline version, verification level, method, procedure, environment, equipment, sample size, acceptance criteria, result, anomaly ID, evidence URI and approver. This allows a reviewer to reconstruct what was verified and against which product configuration.

### Laboratory

Review 20 requirements. Mark each as verifiable, ambiguous, unverifiable or conflicting. Rewrite at least ten and document the evidence method before writing test cases.

---

## Week 3 — Verification methods and evidence planning

Four common methods are:

- **Test:** operate an end product or representative article to collect measured data.
- **Analysis:** use mathematical reasoning, models, simulation or engineering calculations.
- **Inspection:** examine an item, document, code, physical characteristic or configuration.
- **Demonstration:** show that an item performs a function, typically without the detailed data collection of a formal test.

Method selection depends on requirement type, risk, lifecycle stage, available article, uncertainty and cost. A test is not automatically stronger than analysis. A badly controlled test may provide weaker evidence than a validated analytical model. A demonstration may show a function works once but not establish statistical reliability.

### Worked example

- "Valve body material shall be stainless steel grade X" — inspection of certificates/marking and, where necessary, material test.
- "Valve shall close within 300 ms" — measured test with defined timing boundaries.
- "Network throughput shall not exceed a specified safe utilization in a fixed scenario" — analysis plus load test.
- "Operator can acknowledge alarm using the local panel" — demonstration with representative users, supplemented by usability validation.

### Laboratory

For every capstone requirement, select a method and justify why the method produces sufficient evidence. Identify cases where a combination of methods is required.

---

## Week 4 — Test design: partitions, boundaries and decision tables

Equivalence partitioning divides an input domain into classes expected to behave similarly. Boundary-value analysis concentrates on edges where defects often occur. For a permitted tank threshold of 10%–90%, test below the minimum, at the minimum, just above, typical interior values, just below the maximum, at the maximum and above the maximum. Include invalid units, missing values, overflow and numeric precision where relevant.

Decision tables test combinations of conditions. For example, a command may be accepted only if the user is authenticated, authorized for the facility, the controller is online, the command is within the allowed range and the interlock does not prohibit it. The table exposes combinations that one-condition-at-a-time tests miss.

State-transition testing checks state/event pairs, including invalid transitions. It is especially useful for authentication sessions, maintenance mode, controller states, retry logic and recovery workflows.

### Worked example

Input class for `level_percent`:
- invalid: less than 0;
- lower boundary: 0;
- valid low: 0–10;
- normal: 10–80;
- high: 80–100;
- upper boundary: 100;
- invalid: greater than 100;
- malformed: null, string, NaN, infinity.

The partition boundaries must match domain rules; overlapping classes should be resolved explicitly.

### Laboratory

Build a decision table for remote command acceptance. Derive a minimal test set that covers every rule and every boundary. Include invalid user, valid user without resource ownership, stale controller and active safety interlock.

---

## Week 5 — Unit, component and integration testing

Unit tests verify a small unit in isolation. They are fast and local but may miss interface mismatches, environmental assumptions and distributed failure behavior. Component tests exercise a subsystem with controlled collaborators. Integration tests examine actual interactions across component boundaries.

Test doubles are useful but can lie. A mock can encode the same mistaken assumption as the implementation. Use real dependencies selectively for integration tests, contract tests for interfaces, and fakes for deterministic control of rare failure conditions. The test pyramid is a heuristic about feedback speed and scope, not a universal mandate for a fixed ratio.

Integration strategies include top-down, bottom-up, sandwich and incremental integration. Big-bang integration delays feedback and makes fault localization difficult. Incremental integration reveals interface defects earlier.

### Worked example

The command service writes a command to PostgreSQL and publishes a message. A unit test can verify command validation. An integration test must verify transaction plus outbox behavior. A consumer contract test must verify the event schema. An end-to-end test must prove that an authorized command reaches the controller and local interlocks still dominate.

### Laboratory

Implement tests for one command path at three levels: unit, database integration and API end-to-end. Force the process to crash after database commit but before message publication; demonstrate the outbox recovery.

---

## Week 6 — System, acceptance and operational validation

System testing evaluates the integrated system against system requirements. Acceptance testing determines whether the product is acceptable under the agreed acceptance criteria. Validation assesses suitability for stakeholder use in realistic operational conditions.

A validation scenario should include a user goal, realistic constraints, environment, expected outcome and observation method. A feature demo is not necessarily validation. Ask whether representative users can complete real tasks safely and effectively under normal and degraded conditions.

The ConOps is a useful validation anchor. It describes how the system is intended to be used, including operator roles, mission sequences, training, maintenance and exceptions. If test scenarios cover only the ideal workflow, they cannot validate the actual operating concept.

### Laboratory

Run a scenario-based validation exercise with a representative operator. Include network loss, stale telemetry, conflicting command and maintenance mode. Record task success, time, errors, workarounds and user interpretation of system state.

---

## Week 7 — Test environments, data and reproducibility

A test result is only meaningful when the test configuration is known. Record software revision, hardware, database schema, dependency versions, configuration, environment variables, test data, instrumentation, network profile and time source. If the same test produces materially different outcomes in the same stated conditions, investigate nondeterminism or hidden environmental dependence.

Test data should be representative but safe. Use synthetic or sanitized data; control secrets; avoid production personal information unless a formal approved process exists. Test environments should model the behaviors relevant to the claim, not imitate every production detail blindly.

For distributed systems, deterministic clocks, controllable schedulers, network fault injection and repeatable state initialization make testing more effective. Time-dependent tests should avoid relying on arbitrary sleeps when explicit synchronization or controlled clocks are available.

### Laboratory

Create a reproducible test environment using containers or documented scripts. Run the same tests twice from a clean state. Produce a manifest of versions, data and configuration.

---

## Week 8 — Non-functional verification: performance and reliability

Non-functional requirements are still requirements and need measurable criteria. Performance testing may include load, stress, spike, endurance and capacity testing. Measure latency distribution, throughput, saturation, queue depth, resource consumption, error rate and recovery time.

Reliability testing examines failure behavior over time and under defined conditions. Availability is not identical to reliability. A highly available architecture may recover quickly from component failure; a reliable component may rarely fail but take a long time to repair.

Statistical interpretation matters. If zero failures occur in \(n\) independent trials, the failure probability is not proven to be zero. A rough "rule of three" gives an approximate 95% upper bound of \(3/n\) on the failure probability when zero failures are observed, under suitable independent Bernoulli assumptions. With 1000 failure-free trials, the bound is about 0.003, not zero.

### Laboratory

Load-test the telemetry API at gradually increasing rates. Report p50, p95, p99 latency, throughput, error rate, resource saturation and queue behavior. Run an endurance test and identify memory/resource drift.

---

## Week 9 — Security and safety verification

Security testing should be driven by threat models and security requirements. Test authentication, authorization, object ownership, input validation, session lifecycle, cryptographic configuration, secrets handling, logging and dependency integrity. Include negative tests: a user who is not allowed to act must be denied, and one user's resource must not be accessible through another user's identifier.

Safety verification must test the required safety functions and fault responses. Test normal, degraded and fault states; check timing, independence assumptions and safe-state behavior. A test that disables all safety interlocks for convenience is not a valid demonstration of safe operation.

No finite test suite proves the absence of vulnerabilities or hazards. Testing provides bounded evidence under specified conditions. Analysis, inspection, formal reasoning, operational monitoring and independent review complement it.

### Laboratory

Create one safety verification and one security verification package. Include traceability to the relevant requirement, expected result, negative test, evidence artifact and residual limitation.

---

## Week 10 — Model-based testing and formal verification

Model-based testing derives tests from a behavioral model such as a state machine, activity model or protocol automaton. It can improve transition coverage and reveal missing behaviors. The model itself must be reviewed; incorrect models generate systematic but misleading tests.

Formal methods use mathematical representations to prove properties under explicit assumptions. Examples include invariants, temporal logic, model checking, theorem proving and refinement. A proof applies to the model and assumptions, not automatically to the deployed physical system. The abstraction gap must be considered.

An invariant is a property that must hold in every reachable state. For the control system, one candidate is: `if sensor_valid = false then actuator_enable = false`, provided that this is the intended policy and the actuator is controllable. A temporal property may express that a high-high condition eventually leads to a close command within a time bound. Temporal logic notation should be learned only after the event/state semantics are unambiguous.

### Laboratory

Generate tests from a simple controller state model. Add a model checker or property-based test for an invariant. Deliberately alter a guard so a test exposes an unsafe transition.

---

## Week 11 — Automation, CI and regression

Automated tests provide fast, repeatable feedback, but automation has costs: maintenance, flaky tests, false confidence, environment drift and slow pipelines. Automate stable, valuable checks; retain human review where judgment or context is essential.

A CI pipeline should separate formatting/static analysis, unit tests, component tests, integration tests, security checks and longer system suites. Each stage should produce clear evidence and preserve the failing artifact. Flaky tests should be treated as defects in the test system, not ignored by rerunning until green.

Regression testing evaluates whether changes broke previously working behavior. Select regression tests based on risk and impact, not simply by rerunning every test without analysis. Mutation testing changes code in small ways to assess whether the suite detects behavior changes. It measures test sensitivity for the chosen mutations, not overall test quality.

### Laboratory

Create a CI workflow that runs formatting, linting, unit tests, SQL migration checks and an integration test suite. Add one deliberately introduced defect and demonstrate that the pipeline fails.

---

## Week 12 — Traceability, coverage and defect management

Traceability connects needs, requirements, architecture, code/model elements, tests, results, hazards, threats and anomalies. A verification matrix records which method and evidence demonstrate each requirement. Coverage measures help identify untested areas, but coverage is not proof of correctness.

Common measures include requirement coverage, statement coverage, branch coverage, condition coverage, transition coverage, interface coverage and risk-based scenario coverage. Each answers a different question. 100% statement coverage does not mean every decision outcome, input class or hazard scenario was tested.

An anomaly report should include observed behavior, expected behavior, environment, reproducible steps, evidence, severity, impact, frequency and suspected scope. Triage distinguishes defect, test defect, requirement defect, configuration issue and accepted limitation.

### Laboratory

Create a bidirectional traceability matrix. Calculate requirement verification coverage and identify orphan requirements, orphan tests and tests with no clear objective. Create three anomaly reports with reproducible evidence.

---

## Week 13 — V&V planning, evidence and release decisions

A V&V plan defines objectives, scope, organization, responsibilities, methods, environments, sequence, entry/exit criteria, configuration control, evidence records, reporting and risk handling. It should be baselined before formal verification begins.

A verification report identifies the requirement baseline, product configuration, procedure revision, tools/equipment, operating conditions, results, anomalies and decisions. A pass/fail result without configuration information is difficult to reproduce and may not apply to the delivered build.

Release readiness is a risk-informed decision. Open defects should be assessed against severity, probability, user impact, mitigations, operational constraints and evidence. "All tests pass" is not a sufficient release argument if required tests were omitted, test data was unrepresentative or the test suite does not address major threats and hazards.

### Laboratory

Write a V&V plan and a sample verification report. Include a requirements baseline, test configuration, test cases, evidence, anomaly disposition and release recommendation.

---

## Week 14 — Integrated V&V assessment

The final review should show the chain:

```text
Stakeholder need
      -> validated requirement
      -> architecture allocation
      -> verification method and acceptance criterion
      -> approved procedure
      -> reproducible result
      -> anomaly disposition
      -> verification conclusion

ConOps + representative user
      -> validation scenario
      -> observed operational outcome
      -> stakeholder acceptance / corrective action
```

### Final submission

Submit a requirements quality report, V&V plan, verification matrix, validation plan, test design specification, automated test suite, test environment manifest, executed test report, anomaly log and release decision.

### End-of-course problems

1. A service meets all specified requirements but operators cannot use it under realistic conditions. Is it verified? Validated?  
   **Solution:** It may be verified against its stated requirements but has failed validation. The stakeholder needs or ConOps may be incomplete, or the requirements may not adequately represent actual operations.

2. Does 100% line coverage prove correctness?  
   **Solution:** No. It only indicates executed lines under the coverage tool's measurement. It does not prove correct assertions, adequate input classes, branch outcomes, timing, security or requirement coverage.

3. Why record the tested software version and requirement baseline?  
   **Solution:** Evidence applies to a specific configuration. Without both versions, the reviewer cannot determine which product and specification were assessed.

## Selected sources and further study

- NASA Systems Engineering Handbook: https://www.nasa.gov/reference/systems-engineering-handbook/
- NASA distinction between verification and validation: https://www.nasa.gov/reference/2-4-distinctions-between-product-verification-and-product-validation/
- NASA product verification methods: https://www.nasa.gov/reference/5-3-product-verification/
- NASA V&V plan outline: https://www.nasa.gov/reference/appendix-i-verification-and-validation-plan-outline/
- ISTQB Certified Tester Foundation Level syllabus: https://www.istqb.org/certifications/certified-tester-foundation-level
- Google Testing Blog: https://testing.googleblog.com/
- Hypothesis property-based testing: https://hypothesis.readthedocs.io/
- TLA+ resources: https://lamport.azurewebsites.net/tla/tla.html
- OWASP ASVS 5.0.0: https://owasp.org/www-project-application-security-verification-standard/

NASA's systems-level V&V guidance is particularly useful for method selection and evidence structure. Use software-testing references for detailed test design and automation; do not confuse tool reports with engineering conclusions.

# Expected protocol trace — three replicas

This is a logical trace, not a capture from real sockets. The node IDs are 0, 1 and 2; the majority is 2.

## Initial election

| Event | Node 0 | Node 1 | Node 2 |
|---|---|---|---|
| Initial | Follower, term 0 | Follower, term 0 | Follower, term 0 |
| Node 0 timeout | Candidate, term 1, votes for self | Follower, term 0 | Follower, term 0 |
| RequestVote delivered | Candidate, term 1 | Grants vote in term 1 | Grants vote in term 1 |
| Vote responses delivered | Leader, term 1 | Follower, term 1 | Follower, term 1 |
| Initial AppendEntries | Sends heartbeat / current log | Matches prefix | Matches prefix |

## Commit one command

1. The leader appends `(term=1, command="set x=7")` to its local log. It is **not yet committed**.
2. The leader sends `AppendEntries` to both followers.
3. A follower verifies `(prevLogIndex, prevLogTerm)`, stores the new entry and responds with `matchIndex=1`.
4. Once the leader's own match plus one follower's match reaches the quorum of two, the leader advances `commitIndex` to 1.
5. The leader sends another `AppendEntries` with `leaderCommit=1`; followers advance their local `commitIndex` to 1.

## Partitioned leader

If the leader is isolated from both followers, a new local append may exist in the leader's log, but its `matchIndex` is only known to the leader. One acknowledgement is not a quorum in a three-replica cluster. `commitIndex` must remain unchanged. The other two replicas may elect a higher-term leader.

## Restart and conflict repair

After restart, the old node reloads term, vote and log from the simulator's persistence map; its volatile `commitIndex` starts at zero. When the new leader contacts it, a higher term makes it step down. `AppendEntries` verifies the prefix; if the same index has a different term, the old uncommitted suffix is truncated and the new leader's entry is appended. The new leader's commit index is then propagated.

A real implementation must make the persistence and apply boundaries durable and ordered. This simulator does not test filesystem flush ordering or torn writes.

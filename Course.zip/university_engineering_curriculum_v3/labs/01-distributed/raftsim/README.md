# Raft Protocol and Replicated Log — Deterministic Teaching Simulator

**Course:** Distributed Systems, weeks 7–9 and capstone integration  
**Language/runtime:** Go 1.23+; standard library only  
**Status:** Executed locally with unit tests, race detector and `go vet`

## Learning outcomes

By completing this lab, you should be able to:

1. Implement term-based leader election and the one-vote-per-term rule.
2. Explain how candidate log freshness participates in election safety.
3. implement `AppendEntries` consistency checks, conflict repair and leader commit advancement.
4. Distinguish a locally appended entry from an entry committed by a majority.
5. Explain why a leader cannot commit a prior-term entry merely by counting replicas; a current-term entry must first be committed.
6. Reproduce a leader crash/restart, a partition, a lost message and a reordered delivery in a controlled test.
7. State what the simulator omits and why a green test suite is not a proof of the full Raft protocol.

## Run it

From this directory:

```bash
go test -count=1 -v ./...
go test -race -count=1 ./...
go vet ./...
```

Expected result: all nine tests pass; race detector and `go vet` produce no diagnostics. The tests are intentionally deterministic and use no network, timers, sleeping or third-party dependencies.

## Simulator model

The simulator contains three or more node state machines. It models:

- `term`, `votedFor`, and a persistent replicated log;
- follower, candidate and leader roles;
- `RequestVote` / vote responses;
- `AppendEntries` / append responses;
- leader `nextIndex` and `matchIndex` bookkeeping;
- majority commit of entries from the leader's current term;
- a deterministic message queue that can be dropped, reordered or partitioned;
- crash/restart by reconstructing volatile node state from a stored term/vote/log snapshot.

The message queue is not a socket or transport stack. `Advance()` advances deterministic logical ticks; `DeliverAll()` delivers currently queued messages in FIFO order; `Drop()` removes one queued message; `ReversePending()` reverses the current queue; `Partition()` and `Heal()` block and restore a bidirectional node link. The simulation checks state after each controlled schedule.

## Protocol reasoning required in your report

### Election safety

A node grants at most one vote in a term, and only to a candidate whose last log is at least as up-to-date (lexicographically by last-log term, then index) as its own. Any two majorities intersect. Your report must explain why these properties prevent two different candidates from each collecting a majority in the same term under the crash-fault model.

### Log matching and repair

An `AppendEntries` request is accepted only if the follower has the supplied previous index and term. A conflicting uncommitted suffix is truncated before the leader's entries are appended. Committed entries must never be overwritten. When a follower rejects a request, it returns a conflict hint; the leader backs up `nextIndex` and retries.

### Commit rule

The leader commits index `N` only if a majority's `matchIndex` is at least `N` **and** the entry at `N` belongs to the leader's current term. Earlier-term entries become committed indirectly when a current-term entry commits.

### Persistence

The simulator's `disk` map is a pedagogical persistence abstraction. `persist()` copies the current term, vote and log into that map; restart rebuilds a node from that copy. It does not use a real filesystem, force writes, checksums, or model torn writes. Do not describe this as a crash-durable implementation.

## Required exercises

1. Change a node's election timeout and predict the leader before running tests. Explain why deterministic timeouts are useful for teaching but dangerous as a general production timing strategy.
2. Increase the cluster to five replicas. Calculate the quorum size and show that a two-node partition cannot commit.
3. Drop an `AppendEntries` request and then allow a later heartbeat. Capture the retry sequence and show which response updates `matchIndex`.
4. Extend the tests to create a follower with a long uncommitted suffix. Elect a new leader with a shorter log, reconnect the follower and demonstrate suffix repair.
5. Change the implementation to permit a leader to commit an old-term entry based solely on majority replication. Write the smallest schedule that demonstrates why the current-term condition exists; revert the incorrect code after the experiment.
6. Add structured protocol events (election started, vote granted, leader elected, append rejected, conflict repaired, commit advanced) and compare the trace against the invariants.

## Assessment rubric (100 points)

| Criterion | Points | Evidence |
|---|---:|---|
| Election and vote freshness | 15 | One vote per term; stale candidate rejected; no two leaders in one term |
| AppendEntries and log matching | 20 | Prev-log checks, suffix conflict repair and committed-entry protection |
| Quorum commit rule | 15 | No commit without majority; current-term condition implemented |
| Failure schedules | 20 | Drop, reorder, partition, crash, restart, reconnect tests |
| Correctness argument | 15 | Safety properties, quorum intersection and assumptions explained |
| Reproducibility and code ownership | 15 | Exact commands, outputs, state trace and oral explanation |

## Limitations — read before claiming results

This is a single-process protocol simulator, not a multi-process RPC implementation. It omits real disk I/O and crash durability, real timers and clocks, network serialization, snapshot compaction, dynamic membership, Byzantine faults, read-index/lease reads, pre-vote, check-quorum, leadership transfer and production observability. Its controlled tests cover selected schedules, not all executions. `ValidateSafety()` is an assertion checker over the current in-memory state; it is not a proof and does not establish liveness under arbitrary timing.

For a full implementation assignment, use the official [MIT 6.5840 Spring 2026 Raft lab](https://pdos.csail.mit.edu/6.824/labs/lab-raft1.html) and then the [fault-tolerant KV lab](https://pdos.csail.mit.edu/6.824/labs/lab-kvraft1.html). Do not copy private student solutions. The lab structure here is original and uses a different, intentionally smaller API.

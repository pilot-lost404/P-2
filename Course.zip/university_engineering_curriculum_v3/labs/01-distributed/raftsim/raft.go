// Package raftsim is an intentionally small, deterministic, single-process
// teaching simulator for the core Raft leader-election and replicated-log
// protocol. It is not a production consensus implementation.
package raftsim

import (
	"errors"
	"fmt"
	"sort"
)

const NoVote = -1

type Role uint8

const (
	Follower Role = iota
	Candidate
	Leader
)

func (r Role) String() string {
	switch r {
	case Follower:
		return "follower"
	case Candidate:
		return "candidate"
	case Leader:
		return "leader"
	default:
		return "unknown"
	}
}

type Entry struct {
	Term    int    `json:"term"`
	Command string `json:"command"`
}

type MessageKind uint8

const (
	RequestVote MessageKind = iota + 1
	VoteResponse
	AppendEntries
	AppendResponse
)

// Message is a deliberately explicit wire envelope. It is copied when queued
// so a caller cannot mutate an in-flight message by modifying its log slice.
type Message struct {
	Kind          MessageKind
	From          int
	To            int
	Term          int
	LastLogIndex  int
	LastLogTerm   int
	Granted       bool
	PrevLogIndex  int
	PrevLogTerm   int
	Entries       []Entry
	LeaderCommit  int
	Success       bool
	MatchIndex    int
	ConflictIndex int
	ConflictTerm  int
}

func cloneEntries(src []Entry) []Entry {
	return append([]Entry(nil), src...)
}

func cloneMessage(m Message) Message {
	m.Entries = cloneEntries(m.Entries)
	return m
}

type persistedState struct {
	Term     int
	VotedFor int
	Log      []Entry
}

type NodeStatus struct {
	ID          int
	Role        Role
	Term        int
	VotedFor    int
	Alive       bool
	CommitIndex int
	Log         []Entry
}

type edge struct{ a, b int }

func makeEdge(a, b int) edge {
	if a > b {
		a, b = b, a
	}
	return edge{a: a, b: b}
}

type Cluster struct {
	nodes    map[int]*Node
	disk     map[int]persistedState
	pending  []Message
	blocked  map[edge]bool
	maxSteps int
}

func NewCluster(size int) (*Cluster, error) {
	if size < 1 {
		return nil, errors.New("cluster size must be at least one")
	}
	c := &Cluster{
		nodes:    make(map[int]*Node, size),
		disk:     make(map[int]persistedState, size),
		blocked:  make(map[edge]bool),
		maxSteps: 10000,
	}
	for id := 0; id < size; id++ {
		peers := make([]int, 0, size-1)
		for other := 0; other < size; other++ {
			if other != id {
				peers = append(peers, other)
			}
		}
		n := &Node{
			id:              id,
			peers:           peers,
			cluster:         c,
			role:            Follower,
			term:            0,
			votedFor:        NoVote,
			log:             []Entry{{Term: 0, Command: ""}},
			alive:           true,
			electionTimeout: 5 + 2*id,
			heartbeatPeriod: 2,
			nextIndex:       map[int]int{},
			matchIndex:      map[int]int{},
		}
		c.nodes[id] = n
		n.persist()
	}
	return c, nil
}

func (c *Cluster) Size() int    { return len(c.nodes) }
func (c *Cluster) Pending() int { return len(c.pending) }

func (c *Cluster) Status(id int) (NodeStatus, bool) {
	n, ok := c.nodes[id]
	if !ok {
		return NodeStatus{}, false
	}
	return NodeStatus{
		ID:          id,
		Role:        n.role,
		Term:        n.term,
		VotedFor:    n.votedFor,
		Alive:       n.alive,
		CommitIndex: n.commitIndex,
		Log:         cloneEntries(n.log),
	}, true
}

func (c *Cluster) send(m Message) {
	if _, ok := c.nodes[m.From]; !ok {
		return
	}
	if _, ok := c.nodes[m.To]; !ok {
		return
	}
	c.pending = append(c.pending, cloneMessage(m))
}

func (c *Cluster) Partition(a, b int) {
	if a == b {
		return
	}
	c.blocked[makeEdge(a, b)] = true
}

func (c *Cluster) Heal(a, b int) {
	delete(c.blocked, makeEdge(a, b))
}

func (c *Cluster) linkAllowed(a, b int) bool {
	return !c.blocked[makeEdge(a, b)]
}

func (c *Cluster) Crash(id int) {
	if n, ok := c.nodes[id]; ok {
		n.alive = false
		n.role = Follower
		n.votes = nil
	}
}

// Restart rebuilds volatile protocol state from the persisted term, vote and
// log. commitIndex is intentionally volatile and resets to zero, as in Raft.
func (c *Cluster) Restart(id int) error {
	old, ok := c.nodes[id]
	if !ok {
		return fmt.Errorf("unknown node %d", id)
	}
	if old.alive {
		return fmt.Errorf("node %d is already alive", id)
	}
	p, ok := c.disk[id]
	if !ok {
		return fmt.Errorf("node %d has no persisted state", id)
	}
	n := &Node{
		id:              id,
		peers:           append([]int(nil), old.peers...),
		cluster:         c,
		role:            Follower,
		term:            p.Term,
		votedFor:        p.VotedFor,
		log:             cloneEntries(p.Log),
		alive:           true,
		electionTimeout: 5 + 2*id,
		heartbeatPeriod: 2,
		nextIndex:       map[int]int{},
		matchIndex:      map[int]int{},
	}
	c.nodes[id] = n
	return nil
}

// Drop removes the pending message at index without delivering it. It is used
// to model message loss in deterministic lab tests.
func (c *Cluster) Drop(index int) bool {
	if index < 0 || index >= len(c.pending) {
		return false
	}
	c.pending = append(c.pending[:index], c.pending[index+1:]...)
	return true
}

// ReversePending makes network delivery order adversarial and reproducible.
func (c *Cluster) ReversePending() error {
	for i, j := 0, len(c.pending)-1; i < j; i, j = i+1, j-1 {
		c.pending[i], c.pending[j] = c.pending[j], c.pending[i]
	}
	return nil
}

func (c *Cluster) DeliverOne(index int) error {
	if index < 0 || index >= len(c.pending) {
		return fmt.Errorf("message index %d out of range", index)
	}
	m := cloneMessage(c.pending[index])
	c.pending = append(c.pending[:index], c.pending[index+1:]...)
	from, fromOK := c.nodes[m.From]
	to, toOK := c.nodes[m.To]
	if !fromOK || !toOK || !from.alive || !to.alive || !c.linkAllowed(m.From, m.To) {
		return nil // A crashed endpoint or partitioned link drops the message.
	}
	to.handle(m)
	return nil
}

func (c *Cluster) DeliverAll(maxMessages int) error {
	if maxMessages <= 0 {
		maxMessages = c.maxSteps
	}
	for delivered := 0; len(c.pending) > 0; delivered++ {
		if delivered >= maxMessages {
			return fmt.Errorf("delivery limit %d reached; possible protocol message loop", maxMessages)
		}
		if err := c.DeliverOne(0); err != nil {
			return err
		}
	}
	return nil
}

func (c *Cluster) Advance(ticks int) error {
	if ticks < 0 {
		return errors.New("ticks must not be negative")
	}
	ids := make([]int, 0, len(c.nodes))
	for id := range c.nodes {
		ids = append(ids, id)
	}
	sort.Ints(ids)
	for tick := 0; tick < ticks; tick++ {
		for _, id := range ids {
			c.nodes[id].tick()
		}
		if err := c.DeliverAll(c.maxSteps); err != nil {
			return err
		}
	}
	return nil
}

func (c *Cluster) Propose(leaderID int, command string) bool {
	n, ok := c.nodes[leaderID]
	if !ok || !n.alive || n.role != Leader {
		return false
	}
	n.log = append(n.log, Entry{Term: n.term, Command: command})
	n.persist()
	n.matchIndex[n.id] = n.lastLogIndex()
	n.advanceCommit()
	n.broadcastAppend()
	return true
}

type Node struct {
	id               int
	peers            []int
	cluster          *Cluster
	role             Role
	term             int
	votedFor         int
	log              []Entry
	commitIndex      int
	lastApplied      int
	votes            map[int]bool
	alive            bool
	electionElapsed  int
	electionTimeout  int
	heartbeatElapsed int
	heartbeatPeriod  int
	nextIndex        map[int]int
	matchIndex       map[int]int
}

func (n *Node) lastLogIndex() int { return len(n.log) - 1 }
func (n *Node) lastLogTerm() int  { return n.log[n.lastLogIndex()].Term }
func (n *Node) majority() int     { return (len(n.peers)+1)/2 + 1 }

func (n *Node) persist() {
	n.cluster.disk[n.id] = persistedState{Term: n.term, VotedFor: n.votedFor, Log: cloneEntries(n.log)}
}

func (n *Node) tick() {
	if !n.alive {
		return
	}
	if n.role == Leader {
		n.heartbeatElapsed++
		if n.heartbeatElapsed >= n.heartbeatPeriod {
			n.heartbeatElapsed = 0
			n.broadcastAppend()
		}
		return
	}
	n.electionElapsed++
	if n.electionElapsed >= n.electionTimeout {
		n.startElection()
	}
}

func (n *Node) startElection() {
	n.role = Candidate
	n.term++
	n.votedFor = n.id
	n.electionElapsed = 0
	n.votes = map[int]bool{n.id: true}
	n.persist()
	for _, peer := range n.peers {
		n.cluster.send(Message{
			Kind:         RequestVote,
			From:         n.id,
			To:           peer,
			Term:         n.term,
			LastLogIndex: n.lastLogIndex(),
			LastLogTerm:  n.lastLogTerm(),
		})
	}
	if len(n.votes) >= n.majority() {
		n.becomeLeader()
	}
}

func (n *Node) becomeFollower(term int) {
	if term > n.term {
		n.term = term
		n.votedFor = NoVote
		n.persist()
	}
	n.role = Follower
	n.votes = nil
	n.electionElapsed = 0
}

func (n *Node) becomeLeader() {
	if n.role != Candidate {
		return
	}
	n.role = Leader
	n.votes = nil
	n.heartbeatElapsed = 0
	last := n.lastLogIndex()
	for _, peer := range n.peers {
		n.nextIndex[peer] = last + 1
		n.matchIndex[peer] = 0
	}
	n.matchIndex[n.id] = last
	n.broadcastAppend()
	if n.majority() == 1 {
		n.advanceCommit()
	}
}

func (n *Node) broadcastAppend() {
	if n.role != Leader || !n.alive {
		return
	}
	for _, peer := range n.peers {
		n.sendAppend(peer)
	}
}

func (n *Node) sendAppend(peer int) {
	next := n.nextIndex[peer]
	if next < 1 {
		next = 1
		n.nextIndex[peer] = next
	}
	if next > n.lastLogIndex()+1 {
		next = n.lastLogIndex() + 1
		n.nextIndex[peer] = next
	}
	prev := next - 1
	entries := cloneEntries(n.log[next:])
	n.cluster.send(Message{
		Kind:         AppendEntries,
		From:         n.id,
		To:           peer,
		Term:         n.term,
		PrevLogIndex: prev,
		PrevLogTerm:  n.log[prev].Term,
		Entries:      entries,
		LeaderCommit: n.commitIndex,
	})
}

func (n *Node) handle(m Message) {
	if !n.alive {
		return
	}
	switch m.Kind {
	case RequestVote:
		n.handleRequestVote(m)
	case VoteResponse:
		n.handleVoteResponse(m)
	case AppendEntries:
		n.handleAppendEntries(m)
	case AppendResponse:
		n.handleAppendResponse(m)
	}
}

func (n *Node) handleRequestVote(m Message) {
	if m.Term < n.term {
		n.cluster.send(Message{Kind: VoteResponse, From: n.id, To: m.From, Term: n.term, Granted: false})
		return
	}
	if m.Term > n.term {
		n.becomeFollower(m.Term)
	}
	upToDate := m.LastLogTerm > n.lastLogTerm() ||
		(m.LastLogTerm == n.lastLogTerm() && m.LastLogIndex >= n.lastLogIndex())
	granted := upToDate && (n.votedFor == NoVote || n.votedFor == m.From)
	if granted {
		n.votedFor = m.From
		n.role = Follower
		n.electionElapsed = 0
		n.persist()
	}
	n.cluster.send(Message{Kind: VoteResponse, From: n.id, To: m.From, Term: n.term, Granted: granted})
}

func (n *Node) handleVoteResponse(m Message) {
	if m.Term > n.term {
		n.becomeFollower(m.Term)
		return
	}
	if n.role != Candidate || m.Term != n.term || !m.Granted {
		return
	}
	n.votes[m.From] = true
	if len(n.votes) >= n.majority() {
		n.becomeLeader()
	}
}

func (n *Node) handleAppendEntries(m Message) {
	if m.Term < n.term {
		n.cluster.send(Message{Kind: AppendResponse, From: n.id, To: m.From, Term: n.term, Success: false, ConflictIndex: n.lastLogIndex() + 1, ConflictTerm: -1})
		return
	}
	if m.Term > n.term {
		n.becomeFollower(m.Term)
	} else if n.role != Follower {
		n.role = Follower
		n.votes = nil
	}
	n.electionElapsed = 0
	if m.PrevLogIndex < 0 || m.PrevLogIndex >= len(n.log) {
		n.cluster.send(Message{Kind: AppendResponse, From: n.id, To: m.From, Term: n.term, Success: false, ConflictIndex: len(n.log), ConflictTerm: -1})
		return
	}
	if n.log[m.PrevLogIndex].Term != m.PrevLogTerm {
		conflictTerm := n.log[m.PrevLogIndex].Term
		first := m.PrevLogIndex
		for first > 0 && n.log[first-1].Term == conflictTerm {
			first--
		}
		n.cluster.send(Message{Kind: AppendResponse, From: n.id, To: m.From, Term: n.term, Success: false, ConflictIndex: first, ConflictTerm: conflictTerm})
		return
	}
	changed := false
	for i, incoming := range m.Entries {
		index := m.PrevLogIndex + 1 + i
		if index < len(n.log) {
			if n.log[index].Term != incoming.Term {
				if index <= n.commitIndex {
					n.cluster.send(Message{Kind: AppendResponse, From: n.id, To: m.From, Term: n.term, Success: false, ConflictIndex: n.commitIndex + 1, ConflictTerm: -1})
					return
				}
				n.log = n.log[:index]
				changed = true
			}
		}
		if index >= len(n.log) {
			n.log = append(n.log, incoming)
			changed = true
		}
	}
	if changed {
		n.persist()
	}
	if m.LeaderCommit > n.commitIndex {
		last := n.lastLogIndex()
		n.commitIndex = min(m.LeaderCommit, last)
		if n.commitIndex > n.lastApplied {
			n.lastApplied = n.commitIndex
		}
	}
	match := m.PrevLogIndex + len(m.Entries)
	n.cluster.send(Message{Kind: AppendResponse, From: n.id, To: m.From, Term: n.term, Success: true, MatchIndex: match})
}

func (n *Node) handleAppendResponse(m Message) {
	if m.Term > n.term {
		n.becomeFollower(m.Term)
		return
	}
	if n.role != Leader || m.Term != n.term {
		return
	}
	peer := m.From
	if m.Success {
		if m.MatchIndex > n.matchIndex[peer] {
			n.matchIndex[peer] = m.MatchIndex
		}
		n.nextIndex[peer] = n.matchIndex[peer] + 1
		if n.advanceCommit() {
			n.broadcastAppend()
		}
		return
	}
	candidate := m.ConflictIndex
	if m.ConflictTerm >= 0 {
		for i := n.lastLogIndex(); i >= 1; i-- {
			if n.log[i].Term == m.ConflictTerm {
				candidate = i + 1
				break
			}
		}
	}
	if candidate < 1 {
		candidate = 1
	}
	if candidate >= n.nextIndex[peer] && n.nextIndex[peer] > 1 {
		candidate = n.nextIndex[peer] - 1
	}
	n.nextIndex[peer] = candidate
	n.sendAppend(peer)
}

func (n *Node) advanceCommit() bool {
	if n.role != Leader {
		return false
	}
	for candidate := n.lastLogIndex(); candidate > n.commitIndex; candidate-- {
		if n.log[candidate].Term != n.term {
			continue // Raft commits prior-term entries only indirectly.
		}
		votes := 0
		for _, match := range n.matchIndex {
			if match >= candidate {
				votes++
			}
		}
		if votes >= n.majority() {
			n.commitIndex = candidate
			if n.commitIndex > n.lastApplied {
				n.lastApplied = n.commitIndex
			}
			return true
		}
	}
	return false
}

// ValidateSafety checks invariants over the current simulator state. It is a
// diagnostic assertion helper for tests and learners, not a formal proof.
func (c *Cluster) ValidateSafety() error {
	leadersByTerm := make(map[int]int)
	ids := make([]int, 0, len(c.nodes))
	for id := range c.nodes {
		ids = append(ids, id)
	}
	sort.Ints(ids)
	for _, id := range ids {
		n := c.nodes[id]
		if len(n.log) == 0 {
			return fmt.Errorf("node %d has an empty log", id)
		}
		if n.log[0].Term != 0 || n.log[0].Command != "" {
			return fmt.Errorf("node %d has an invalid log sentinel", id)
		}
		if n.commitIndex < 0 || n.commitIndex > n.lastLogIndex() {
			return fmt.Errorf("node %d commit index %d is outside its log", id, n.commitIndex)
		}
		if n.lastApplied < 0 || n.lastApplied > n.commitIndex {
			return fmt.Errorf("node %d lastApplied %d exceeds commit index %d", id, n.lastApplied, n.commitIndex)
		}
		if n.votedFor != NoVote {
			if _, ok := c.nodes[n.votedFor]; !ok {
				return fmt.Errorf("node %d voted for unknown node %d", id, n.votedFor)
			}
		}
		for i := 1; i < len(n.log); i++ {
			if n.log[i].Term < n.log[i-1].Term {
				return fmt.Errorf("node %d log term decreases at index %d", id, i)
			}
		}
		if n.alive && n.role == Leader {
			leadersByTerm[n.term]++
			if leadersByTerm[n.term] > 1 {
				return fmt.Errorf("multiple live leaders in term %d", n.term)
			}
		}
	}
	for i := 0; i < len(ids); i++ {
		a := c.nodes[ids[i]]
		for j := i + 1; j < len(ids); j++ {
			b := c.nodes[ids[j]]
			common := min(a.lastLogIndex(), b.lastLogIndex())
			for index := 1; index <= common; index++ {
				if index <= a.commitIndex && index <= b.commitIndex && a.log[index] != b.log[index] {
					return fmt.Errorf("committed-prefix divergence at index %d between nodes %d and %d", index, a.id, b.id)
				}
				if a.log[index].Term == b.log[index].Term && a.log[index].Term > 0 {
					for prefix := 1; prefix <= index; prefix++ {
						if a.log[prefix] != b.log[prefix] {
							return fmt.Errorf("log-matching violation at index %d between nodes %d and %d", index, a.id, b.id)
						}
					}
				}
			}
		}
	}
	return nil
}

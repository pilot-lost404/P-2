package raftsim

import "testing"

func newThreeNodeCluster(t *testing.T) *Cluster {
	t.Helper()
	c, err := NewCluster(3)
	if err != nil {
		t.Fatal(err)
	}
	return c
}

func leaderIDs(c *Cluster) []int {
	var ids []int
	for id := 0; id < c.Size(); id++ {
		if s, ok := c.Status(id); ok && s.Alive && s.Role == Leader {
			ids = append(ids, id)
		}
	}
	return ids
}

func advanceUntilLeader(t *testing.T, c *Cluster) int {
	t.Helper()
	for i := 0; i < 30 && len(leaderIDs(c)) == 0; i++ {
		if err := c.Advance(1); err != nil {
			t.Fatal(err)
		}
	}
	leaders := leaderIDs(c)
	if len(leaders) != 1 {
		t.Fatalf("expected exactly one leader, got %v; pending=%d", leaders, c.Pending())
	}
	return leaders[0]
}

func TestElectionSafetyOneLeaderPerTerm(t *testing.T) {
	c := newThreeNodeCluster(t)
	for i := 0; i < 30; i++ {
		if err := c.Advance(1); err != nil {
			t.Fatal(err)
		}
		seen := map[int]int{}
		for id := 0; id < c.Size(); id++ {
			if s, ok := c.Status(id); ok && s.Alive && s.Role == Leader {
				seen[s.Term]++
			}
		}
		for term, count := range seen {
			if count > 1 {
				t.Fatalf("election safety violated: %d leaders in term %d", count, term)
			}
		}
	}
	if len(leaderIDs(c)) != 1 {
		t.Fatalf("expected one stable leader, got %v", leaderIDs(c))
	}
}

func TestMajorityCommitReplicatesToFollowers(t *testing.T) {
	c := newThreeNodeCluster(t)
	leader := advanceUntilLeader(t, c)
	if !c.Propose(leader, "set x=7") {
		t.Fatal("leader rejected a proposal")
	}
	if err := c.DeliverAll(1000); err != nil {
		t.Fatal(err)
	}
	for id := 0; id < c.Size(); id++ {
		s, _ := c.Status(id)
		if s.CommitIndex != 1 {
			t.Fatalf("node %d commit index = %d, want 1", id, s.CommitIndex)
		}
		if len(s.Log) != 2 || s.Log[1].Command != "set x=7" {
			t.Fatalf("node %d log = %#v, want committed command", id, s.Log)
		}
	}
}

func TestIsolatedLeaderCannotCommitWithoutMajority(t *testing.T) {
	c := newThreeNodeCluster(t)
	leader := advanceUntilLeader(t, c)
	for id := 0; id < c.Size(); id++ {
		if id != leader {
			c.Partition(leader, id)
		}
	}
	if !c.Propose(leader, "must-not-commit") {
		t.Fatal("isolated leader should accept the local append before quorum is known")
	}
	if err := c.DeliverAll(1000); err != nil {
		t.Fatal(err)
	}
	s, _ := c.Status(leader)
	if s.CommitIndex != 0 {
		t.Fatalf("isolated leader committed index %d without quorum", s.CommitIndex)
	}
	if len(s.Log) != 2 {
		t.Fatalf("isolated leader should retain its uncommitted entry, log=%#v", s.Log)
	}
}

func TestLeaderCrashRestartAndConflictRepair(t *testing.T) {
	c := newThreeNodeCluster(t)
	oldLeader := advanceUntilLeader(t, c)
	if !c.Propose(oldLeader, "old-uncommitted") {
		t.Fatal("expected initial proposal to be accepted")
	}
	// Isolate the old leader before its append can reach a quorum.
	for id := 0; id < c.Size(); id++ {
		if id != oldLeader {
			c.Partition(oldLeader, id)
		}
	}
	if err := c.DeliverAll(1000); err != nil {
		t.Fatal(err)
	}
	c.Crash(oldLeader)
	// Keep the old leader down while the two remaining replicas elect a new
	// leader and commit a different entry.
	newLeader := -1
	for i := 0; i < 40; i++ {
		if err := c.Advance(1); err != nil {
			t.Fatal(err)
		}
		for _, id := range leaderIDs(c) {
			if id != oldLeader {
				newLeader = id
			}
		}
		if newLeader >= 0 {
			break
		}
	}
	if newLeader < 0 {
		t.Fatal("remaining replicas failed to elect a leader")
	}
	if !c.Propose(newLeader, "new-committed") {
		t.Fatal("new leader rejected proposal")
	}
	if err := c.DeliverAll(2000); err != nil {
		t.Fatal(err)
	}
	if err := c.Restart(oldLeader); err != nil {
		t.Fatal(err)
	}
	for id := 0; id < c.Size(); id++ {
		if id != oldLeader {
			c.Heal(oldLeader, id)
		}
	}
	if err := c.Advance(3); err != nil {
		t.Fatal(err)
	}
	if err := c.DeliverAll(2000); err != nil {
		t.Fatal(err)
	}
	for id := 0; id < c.Size(); id++ {
		s, _ := c.Status(id)
		if s.CommitIndex < 1 || len(s.Log) < 2 || s.Log[1].Command != "new-committed" {
			t.Fatalf("node %d failed to converge after restart: term=%d commit=%d log=%#v", id, s.Term, s.CommitIndex, s.Log)
		}
	}
}

func TestDroppedAndReorderedMessagesDoNotViolateCommittedPrefix(t *testing.T) {
	c := newThreeNodeCluster(t)
	leader := advanceUntilLeader(t, c)
	if !c.Propose(leader, "first") {
		t.Fatal("proposal rejected")
	}
	if c.Pending() > 0 {
		c.Drop(0)
	}
	if err := c.ReversePending(); err != nil {
		t.Fatal(err)
	}
	if err := c.DeliverAll(1000); err != nil {
		t.Fatal(err)
	}
	if err := c.Advance(3); err != nil {
		t.Fatal(err)
	}
	if err := c.DeliverAll(2000); err != nil {
		t.Fatal(err)
	}
	leaderStatus, _ := c.Status(leader)
	if leaderStatus.CommitIndex < 1 {
		t.Fatalf("leader did not make progress after retry, commit=%d", leaderStatus.CommitIndex)
	}
	for id := 0; id < c.Size(); id++ {
		s, _ := c.Status(id)
		if s.CommitIndex >= 1 && (len(s.Log) < 2 || s.Log[1].Command != "first") {
			t.Fatalf("committed prefix diverged on node %d: %#v", id, s.Log)
		}
	}
}

func TestVoteRequiresUpToDateLog(t *testing.T) {
	c := newThreeNodeCluster(t)
	upToDate := c.nodes[2]
	upToDate.log = append(upToDate.log, Entry{Term: 2, Command: "newer"})
	upToDate.term = 3
	upToDate.votedFor = NoVote
	upToDate.persist()
	c.nodes[0].term = 3
	c.nodes[0].votedFor = 0
	c.nodes[0].persist()
	c.nodes[2].handle(Message{Kind: RequestVote, From: 0, To: 2, Term: 3, LastLogIndex: 0, LastLogTerm: 0})
	if len(c.pending) == 0 {
		t.Fatal("expected a vote response")
	}
	m := c.pending[len(c.pending)-1]
	if m.Kind != VoteResponse || m.Granted {
		t.Fatalf("stale candidate received vote: %#v", m)
	}
}

func TestSingleNodeClusterCanElectAndCommit(t *testing.T) {
	c, err := NewCluster(1)
	if err != nil {
		t.Fatal(err)
	}
	leader := advanceUntilLeader(t, c)
	if leader != 0 {
		t.Fatalf("single node leader = %d, want 0", leader)
	}
	if !c.Propose(leader, "solo") {
		t.Fatal("single node leader rejected proposal")
	}
	s, _ := c.Status(0)
	if s.CommitIndex != 1 {
		t.Fatalf("single node commit index = %d, want 1", s.CommitIndex)
	}
}

func TestSafetyInspectorAcceptsValidStateAndRejectsDivergentCommittedPrefix(t *testing.T) {
	c := newThreeNodeCluster(t)
	leader := advanceUntilLeader(t, c)
	if !c.Propose(leader, "same") {
		t.Fatal("proposal rejected")
	}
	if err := c.DeliverAll(1000); err != nil {
		t.Fatal(err)
	}
	if err := c.ValidateSafety(); err != nil {
		t.Fatalf("valid state rejected: %v", err)
	}
	other := (leader + 1) % c.Size()
	c.nodes[other].log[1].Command = "different"
	c.nodes[other].commitIndex = 1
	if err := c.ValidateSafety(); err == nil {
		t.Fatal("safety inspector accepted divergent committed entry")
	}
}

func TestHigherTermAppendForcesOldLeaderToStepDown(t *testing.T) {
	c := newThreeNodeCluster(t)
	oldLeader := advanceUntilLeader(t, c)
	other := (oldLeader + 1) % c.Size()
	third := (oldLeader + 2) % c.Size()
	c.Partition(oldLeader, other)
	c.Partition(oldLeader, third)
	if err := c.Advance(20); err != nil {
		t.Fatal(err)
	}
	newLeader := -1
	for _, id := range leaderIDs(c) {
		if id != oldLeader {
			newLeader = id
		}
	}
	if newLeader < 0 {
		t.Fatal("majority partition did not elect a replacement leader")
	}
	c.Heal(oldLeader, other)
	c.Heal(oldLeader, third)
	if err := c.Advance(3); err != nil {
		t.Fatal(err)
	}
	if err := c.DeliverAll(2000); err != nil {
		t.Fatal(err)
	}
	s, _ := c.Status(oldLeader)
	if s.Role != Follower {
		t.Fatalf("old leader role = %s, want follower", s.Role)
	}
	if err := c.ValidateSafety(); err != nil {
		t.Fatal(err)
	}
}

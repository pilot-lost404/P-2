module curriculum/raftsim

go 1.23

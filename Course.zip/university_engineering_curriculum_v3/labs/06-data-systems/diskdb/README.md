# Disk-backed database internals lab — Edition 3

This is a compact, inspectable implementation exercise for the internals covered in the database reader. It is intentionally much smaller than CMU BusTub and is not a production database.

## What you implement

| Component | Implementation | Evidence |
|---|---|---|
| Fixed-page file | 4 KiB pages, page IDs, LSNs, CRC32, truncation/corruption detection | `test_storage.py` |
| Buffer pool | bounded LRU frames, pin counts, dirty pages, WAL-before-data eviction | `test_storage.py` |
| WAL | monotonic LSN records, checksums, torn terminal-record truncation, explicit fsync | `test_wal.py` |
| Recovery | redo committed full-page after-images; ignore uncommitted writes; skip pages already at/after the record LSN | `test_wal.py` |
| B+ tree | persistent integer keys, JSON values, recursive splits, parent separators, leaf sibling chain, point/range lookup | `test_btree.py` |

## Runtime and commands

Requires Python 3.11+ and uses only the standard library at runtime. `pytest` is needed for tests.

```bash
PYTHONPATH=labs/06-data-systems/diskdb \
  pytest -q labs/06-data-systems/diskdb

PYTHONPATH=labs/06-data-systems/diskdb \
  python labs/06-data-systems/diskdb/benchmark.py --inserts 500 --order 8
```

The database file and WAL must be kept together. Reopening a tree replays committed page images from the WAL before loading the metadata page. The tests deliberately simulate a crash after COMMIT is durable but before any data page is written, then verify recovery.

## Inspectable contracts

- A physical page is exactly 4096 bytes. Its header records magic, page number, page LSN, payload length and CRC32. The checksum covers the identifying metadata and payload.
- A WAL record contains magic, monotonically increasing LSN, transaction ID, record kind, page number, payload length, CRC32 and, for WRITE, a full page after-image.
- COMMIT is appended and fsynced before the recovery manager writes the associated data pages. That is the lab's write-ahead invariant.
- Recovery replays only transactions with a COMMIT record. A page whose stored LSN is already at least the WAL write's LSN is not replayed a second time.
- The B+ tree stores JSON-compatible values and integer keys. Its tree is persistent across close/reopen. Validation checks key order, child/separator relationships, equal leaf depth, page references, leaf links and metadata entry count.

## Important limitations

This is a teaching engine, not BusTub and not PostgreSQL. It has no SQL parser, query planner/executor, delete/merge operations, concurrent transactions, lock manager, MVCC, snapshots, checkpointing, log truncation, page compaction, full ARIES analysis/redo/undo, multi-process file locking, checksummed WAL segment headers, power-loss certification or qualified storage-device assumptions. Recovery uses redo-only full-page after-images and applies writes only after COMMIT is durable; uncommitted data pages therefore should not have been written by this engine. The WAL and page file are separate files and the exercise does not solve atomic creation/rename of both files as a single filesystem transaction.

A CRC detects many accidental corruptions; it is not an authentication mechanism. A page checksum failure is detected and surfaced; the current recovery manager does not reconstruct an already-corrupted/torn data page from its WAL image, and a page-file read can stop recovery. Power-loss/torn-page repair is an extension exercise, not a completed guarantee. The LRU pool is single-process teaching code, not thread-safe. This lab must only be used on disposable files.

## Experiments

1. **Page corruption:** flip one payload byte and confirm `PageCorruptionError`.
2. **Buffer pressure:** set capacity to one, pin page zero and attempt to fetch page one. The pool must refuse eviction rather than invalidate the live guard.
3. **WAL ordering:** dirty page zero at LSN 9; evict it. Verify `flush_up_to(9)` happens before its page image is persisted.
4. **Torn tail:** append fewer bytes than a complete WAL header to the terminal end. Reopen and confirm truncation to the previous validated record boundary. A complete record with a bad checksum must raise `WALCorruptionError`.
5. **Crash/recovery:** commit a transaction using `apply=False`, append an uncommitted WRITE for the same page, and run recovery. Only the committed after-image should reach the page file.
6. **Idempotence:** run recovery twice. The second run should not rewrite already-applied page LSNs.
7. **Tree structure:** insert in ascending, descending and shuffled orders; call `validate()` after each operation and compare lookups/range scans to a Python dictionary.
8. **Persistence:** close and reopen both files; all committed key/value pairs must remain accessible.

## Extension assignments

- Add B+ tree deletion with redistribution, merge, root contraction and leaf-link tests.
- Replace JSON node encoding with fixed-width binary slotted pages and measure fan-out.
- Add a disk scheduler and a second buffer-pool replacement strategy (Clock or ARC).
- Add a transaction schedule simulator and strict two-phase locking; do not claim it is integrated into this storage engine until it is.
- Design (but do not silently claim to implement) ARIES analysis, redo, undo and compensation log records. State-stepping tests should include crashes at every log/data flush boundary.

## Reference benchmark

`benchmark.py` prints observed elapsed times and environment details. Results vary by storage device, filesystem, Python version, page size and fsync cost. Do not compare runs without recording those conditions; the benchmark is an educational microbenchmark, not a product performance claim.

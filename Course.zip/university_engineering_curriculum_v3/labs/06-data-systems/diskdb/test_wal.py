from __future__ import annotations

import pytest

from storage import PageFile
from wal import WAL, RecoveryManager, WALCorruptionError


def test_wal_round_trip_and_lsn_monotonicity(tmp_path):
    wal = WAL(tmp_path / "db.wal")
    begin = wal.append(1, "BEGIN")
    write = wal.append(1, "WRITE", page_no=2, payload=b"page-image")
    commit = wal.append(1, "COMMIT")
    assert begin.lsn < write.lsn < commit.lsn
    assert [record.kind for record in wal.scan()] == ["BEGIN", "WRITE", "COMMIT"]


def test_torn_final_wal_record_is_ignored_and_truncated_on_open(tmp_path):
    path = tmp_path / "db.wal"
    wal = WAL(path)
    wal.append(1, "BEGIN")
    valid_size = path.stat().st_size
    with path.open("ab") as stream:
        stream.write(b"WAL1\x00\x00\x00")
    assert path.stat().st_size > valid_size
    reopened = WAL(path)
    assert [record.kind for record in reopened.scan()] == ["BEGIN"]
    assert path.stat().st_size == valid_size


def test_wal_detects_corrupted_complete_record(tmp_path):
    path = tmp_path / "db.wal"
    wal = WAL(path)
    wal.append(1, "BEGIN")
    with path.open("r+b") as stream:
        stream.seek(-1, 2)
        byte = stream.read(1)
        stream.seek(-1, 2)
        stream.write(bytes([byte[0] ^ 0x01]))
    with pytest.raises(WALCorruptionError):
        WAL(path)


def test_recovery_redoes_committed_page_images_and_ignores_uncommitted(tmp_path):
    page_path = tmp_path / "pages.db"
    wal_path = tmp_path / "db.wal"
    with PageFile(page_path) as pages:
        wal = WAL(wal_path)
        recovery = RecoveryManager(wal, pages)
        recovery.commit(1, {0: b"committed-meta", 1: b"committed-page"}, apply=False)
        wal.append(2, "BEGIN")
        wal.append(2, "WRITE", page_no=1, payload=b"uncommitted-overwrite")
        report = recovery.recover()
        assert report["replayed_writes"] == 2
        assert pages.read_page(0).payload == b"committed-meta"
        assert pages.read_page(1).payload == b"committed-page"


def test_recovery_is_idempotent_using_page_lsn(tmp_path):
    with PageFile(tmp_path / "pages.db") as pages:
        wal = WAL(tmp_path / "db.wal")
        recovery = RecoveryManager(wal, pages)
        recovery.commit(1, {0: b"meta"}, apply=True)
        first_lsn = pages.read_page(0).lsn
        report = recovery.recover()
        assert report["replayed_writes"] == 0
        assert pages.read_page(0).lsn == first_lsn


def test_wal_flushes_commit_before_data_page_application(tmp_path):
    class RecordingPageFile(PageFile):
        def __init__(self, path, wal):
            super().__init__(path)
            self.wal = wal
            self.flush_seen_at_write = []

        def write_page(self, page_no, payload, lsn=0):
            self.flush_seen_at_write.append(self.wal.durable_lsn)
            return super().write_page(page_no, payload, lsn)

    wal = WAL(tmp_path / "db.wal")
    pages = RecordingPageFile(tmp_path / "pages.db", wal)
    recovery = RecoveryManager(wal, pages)
    recovery.commit(1, {0: b"meta"}, apply=True)
    assert pages.flush_seen_at_write[-1] >= wal.commit_lsn(1)
    pages.close()

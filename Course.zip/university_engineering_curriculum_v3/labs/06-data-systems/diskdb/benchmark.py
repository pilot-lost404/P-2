from __future__ import annotations

import argparse
import os
import platform
import random
import statistics
import tempfile
import time
from pathlib import Path

from btree import DiskBPlusTree


def percentile(values: list[float], p: float) -> float:
    ordered = sorted(values)
    if not ordered:
        return 0.0
    index = min(len(ordered) - 1, max(0, int(round((len(ordered) - 1) * p))))
    return ordered[index]


def main() -> int:
    parser = argparse.ArgumentParser(description="Microbenchmark the teaching disk B+ tree")
    parser.add_argument("--inserts", type=int, default=250)
    parser.add_argument("--order", type=int, default=8)
    parser.add_argument("--seed", type=int, default=2026)
    args = parser.parse_args()
    if args.inserts < 1 or args.order < 3:
        parser.error("--inserts must be positive and --order must be at least 3")

    rng = random.Random(args.seed)
    keys = list(range(args.inserts))
    rng.shuffle(keys)
    insert_times: list[float] = []
    lookup_times: list[float] = []
    with tempfile.TemporaryDirectory(prefix="diskdb-bench-") as directory:
        db_path = Path(directory) / "bench.db"
        tree = DiskBPlusTree(db_path, order=args.order, buffer_pool_capacity=16)
        started = time.perf_counter()
        for key in keys:
            t0 = time.perf_counter()
            tree.insert(key, {"value": key * 7})
            insert_times.append(time.perf_counter() - t0)
        insert_elapsed = time.perf_counter() - started

        probes = list(range(args.inserts))
        rng.shuffle(probes)
        for key in probes:
            t0 = time.perf_counter()
            actual = tree.get(key)
            lookup_times.append(time.perf_counter() - t0)
            if actual != {"value": key * 7}:
                raise RuntimeError(f"wrong value for key {key}: {actual!r}")
        scan_start = time.perf_counter()
        scanned = tree.range_scan(0, args.inserts - 1)
        scan_elapsed = time.perf_counter() - scan_start
        if len(scanned) != args.inserts:
            raise RuntimeError("range scan returned wrong number of entries")
        if not tree.validate():
            raise RuntimeError("B+ tree invariants failed")
        tree.close()
        file_bytes = db_path.stat().st_size
        wal_bytes = Path(str(db_path) + ".wal").stat().st_size

    print(f"python={platform.python_version()} platform={platform.platform()}")
    print(f"seed={args.seed} inserts={args.inserts} order={args.order}")
    print(f"insert_total_seconds={insert_elapsed:.6f} insert_mean_ms={statistics.mean(insert_times)*1000:.4f} insert_p95_ms={percentile(insert_times, .95)*1000:.4f}")
    print(f"lookup_mean_ms={statistics.mean(lookup_times)*1000:.4f} lookup_p95_ms={percentile(lookup_times, .95)*1000:.4f}")
    print(f"range_scan_seconds={scan_elapsed:.6f} entries={len(scanned)}")
    print(f"page_file_bytes={file_bytes} wal_bytes={wal_bytes}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

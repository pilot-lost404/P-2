"""Small fixed-page storage manager and LRU buffer pool for the course DBMS lab.

This is teaching code, not a production storage engine. Page writes are fixed-size,
checksummed and fsynced, but the process does not provide cross-process locking.
"""
from __future__ import annotations

from collections import OrderedDict
from dataclasses import dataclass
import os
from pathlib import Path
import struct
import zlib
from typing import Any

PAGE_SIZE = 4096
_PAGE_HEADER_PREFIX = struct.Struct(">4sIQI")
_PAGE_HEADER = struct.Struct(">4sIQII")
PAGE_HEADER_SIZE = _PAGE_HEADER.size
PAGE_MAGIC = b"PG01"
MAX_PAGE_PAYLOAD = PAGE_SIZE - PAGE_HEADER_SIZE


class PageCorruptionError(ValueError):
    """Raised when a page has an invalid header, length, or checksum."""


class BufferPoolFull(RuntimeError):
    """Raised when every resident frame is pinned and cannot be evicted."""


@dataclass(frozen=True)
class Page:
    page_no: int
    payload: bytes
    lsn: int = 0


class PageFile:
    """Fixed-size page file. Every physical page includes a CRC-protected header."""

    def __init__(self, path: str | os.PathLike[str]):
        self.path = Path(path)
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self.path.touch(exist_ok=True)
        size = self.path.stat().st_size
        if size % PAGE_SIZE:
            raise PageCorruptionError(
                f"file length {size} is not a multiple of page size {PAGE_SIZE}"
            )
        self._closed = False

    def __enter__(self) -> "PageFile":
        self._ensure_open()
        return self

    def __exit__(self, exc_type: Any, exc: Any, tb: Any) -> None:
        self.close()

    def _ensure_open(self) -> None:
        if self._closed:
            raise ValueError("page file is closed")

    @property
    def page_count(self) -> int:
        self._ensure_open()
        size = self.path.stat().st_size
        if size % PAGE_SIZE:
            raise PageCorruptionError("page file became truncated after opening")
        return size // PAGE_SIZE

    @staticmethod
    def _encode(page_no: int, payload: bytes, lsn: int) -> bytes:
        if isinstance(page_no, bool) or not isinstance(page_no, int) or page_no < 0:
            raise ValueError("page_no must be a non-negative integer")
        if isinstance(lsn, bool) or not isinstance(lsn, int) or lsn < 0:
            raise ValueError("lsn must be a non-negative integer")
        if not isinstance(payload, bytes):
            raise TypeError("payload must be bytes")
        if len(payload) > MAX_PAGE_PAYLOAD:
            raise ValueError(f"page payload exceeds {MAX_PAGE_PAYLOAD} bytes")
        prefix = _PAGE_HEADER_PREFIX.pack(PAGE_MAGIC, page_no, lsn, len(payload))
        checksum = zlib.crc32(prefix + payload) & 0xFFFFFFFF
        header = _PAGE_HEADER.pack(PAGE_MAGIC, page_no, lsn, len(payload), checksum)
        return header + payload + bytes(PAGE_SIZE - len(header) - len(payload))

    def _decode(self, raw: bytes, expected_page_no: int) -> Page:
        if len(raw) != PAGE_SIZE:
            raise PageCorruptionError(f"page {expected_page_no} has invalid physical length")
        magic, page_no, lsn, payload_len, checksum = _PAGE_HEADER.unpack(raw[:PAGE_HEADER_SIZE])
        if magic != PAGE_MAGIC:
            raise PageCorruptionError(f"page {expected_page_no} has invalid magic")
        if page_no != expected_page_no:
            raise PageCorruptionError(
                f"page id mismatch: requested {expected_page_no}, stored {page_no}"
            )
        if payload_len > MAX_PAGE_PAYLOAD:
            raise PageCorruptionError(f"page {page_no} has invalid payload length")
        payload = raw[PAGE_HEADER_SIZE:PAGE_HEADER_SIZE + payload_len]
        prefix = _PAGE_HEADER_PREFIX.pack(magic, page_no, lsn, payload_len)
        actual = zlib.crc32(prefix + payload) & 0xFFFFFFFF
        if actual != checksum:
            raise PageCorruptionError(f"page {page_no} checksum mismatch")
        return Page(page_no=page_no, payload=payload, lsn=lsn)

    def ensure_page_exists(self, page_no: int) -> None:
        self._ensure_open()
        if isinstance(page_no, bool) or not isinstance(page_no, int) or page_no < 0:
            raise ValueError("page_no must be a non-negative integer")
        count = self.page_count
        if page_no < count:
            return
        with self.path.open("ab") as stream:
            for new_page in range(count, page_no + 1):
                stream.write(self._encode(new_page, b"", 0))
            stream.flush()
            os.fsync(stream.fileno())

    def read_page(self, page_no: int) -> Page:
        self._ensure_open()
        if isinstance(page_no, bool) or not isinstance(page_no, int) or page_no < 0:
            raise ValueError("page_no must be a non-negative integer")
        if page_no >= self.page_count:
            raise IndexError(f"page {page_no} does not exist")
        with self.path.open("rb") as stream:
            stream.seek(page_no * PAGE_SIZE)
            raw = stream.read(PAGE_SIZE)
        return self._decode(raw, page_no)

    def write_page(self, page_no: int, payload: bytes, lsn: int = 0) -> None:
        self._ensure_open()
        if page_no >= 0:
            self.ensure_page_exists(page_no)
        raw = self._encode(page_no, payload, lsn)
        with self.path.open("r+b") as stream:
            stream.seek(page_no * PAGE_SIZE)
            stream.write(raw)
            stream.flush()
            os.fsync(stream.fileno())

    def sync(self) -> None:
        self._ensure_open()
        with self.path.open("r+b") as stream:
            stream.flush()
            os.fsync(stream.fileno())

    def close(self) -> None:
        self._closed = True


@dataclass
class _Frame:
    page: Page
    pin_count: int = 0
    dirty: bool = False
    dirty_lsn: int = 0
    last_used: int = 0


class PageGuard:
    """Pinned page handle. The frame is unpinned exactly once on context exit."""

    def __init__(self, pool: "BufferPool", page_no: int, frame: _Frame):
        self._pool = pool
        self.page_no = page_no
        self._frame = frame
        self._released = False

    @property
    def page(self) -> Page:
        if self._released:
            raise ValueError("page guard has been released")
        return self._frame.page

    def replace(self, payload: bytes, lsn: int = 0) -> None:
        if self._released:
            raise ValueError("page guard has been released")
        # Validate the encoding before changing the frame, so a bad payload does
        # not leave a resident page in a partially modified state.
        PageFile._encode(self.page_no, payload, lsn)
        self._frame.page = Page(self.page_no, payload, lsn)
        self._frame.dirty = True
        self._frame.dirty_lsn = max(self._frame.dirty_lsn, lsn)
        self._pool._touch(self._frame)

    def mark_dirty(self, lsn: int = 0) -> None:
        if self._released:
            raise ValueError("page guard has been released")
        if lsn < 0:
            raise ValueError("lsn must be non-negative")
        self._frame.dirty = True
        self._frame.dirty_lsn = max(self._frame.dirty_lsn, lsn)

    def release(self) -> None:
        if self._released:
            return
        self._released = True
        self._pool._unpin(self.page_no, self._frame)

    def __enter__(self) -> "PageGuard":
        if self._released:
            raise ValueError("page guard has been released")
        return self

    def __exit__(self, exc_type: Any, exc: Any, tb: Any) -> None:
        self.release()


class BufferPool:
    """Thread-local teaching LRU pool with pin counts and WAL-before-data flush."""

    def __init__(self, page_file: PageFile, capacity: int, wal: Any | None = None):
        if isinstance(capacity, bool) or not isinstance(capacity, int) or capacity < 1:
            raise ValueError("capacity must be a positive integer")
        self.page_file = page_file
        self.capacity = capacity
        self.wal = wal
        self._frames: OrderedDict[int, _Frame] = OrderedDict()
        self._clock = 0
        self._closed = False

    def _ensure_open(self) -> None:
        if self._closed:
            raise ValueError("buffer pool is closed")

    def _touch(self, frame: _Frame) -> None:
        self._clock += 1
        frame.last_used = self._clock

    def fetch(self, page_no: int) -> PageGuard:
        self._ensure_open()
        if page_no < 0:
            raise ValueError("page_no must be non-negative")
        frame = self._frames.get(page_no)
        if frame is None:
            if len(self._frames) >= self.capacity:
                candidates = [
                    (candidate.last_used, key, candidate)
                    for key, candidate in self._frames.items()
                    if candidate.pin_count == 0
                ]
                if not candidates:
                    raise BufferPoolFull("all buffer frames are pinned")
                _, victim_page, victim = min(candidates, key=lambda item: item[0])
                self._flush_frame(victim_page, victim)
                del self._frames[victim_page]
            page = self.page_file.read_page(page_no)
            frame = _Frame(page)
            self._frames[page_no] = frame
        frame.pin_count += 1
        self._touch(frame)
        return PageGuard(self, page_no, frame)

    def _unpin(self, page_no: int, frame: _Frame) -> None:
        current = self._frames.get(page_no)
        if current is not frame or frame.pin_count < 1:
            raise RuntimeError("buffer-pool pin accounting is inconsistent")
        frame.pin_count -= 1
        self._touch(frame)

    def _flush_frame(self, page_no: int, frame: _Frame) -> None:
        if not frame.dirty:
            return
        if frame.pin_count:
            raise RuntimeError("cannot flush a pinned frame for eviction")
        if self.wal is not None and frame.dirty_lsn:
            self.wal.flush_up_to(frame.dirty_lsn)
        self.page_file.write_page(page_no, frame.page.payload, lsn=frame.page.lsn)
        frame.dirty = False
        frame.dirty_lsn = 0

    def flush_page(self, page_no: int) -> None:
        self._ensure_open()
        frame = self._frames.get(page_no)
        if frame is not None:
            self._flush_frame(page_no, frame)

    def flush_all(self) -> None:
        self._ensure_open()
        for page_no, frame in list(self._frames.items()):
            if frame.pin_count:
                raise RuntimeError(f"cannot flush pinned page {page_no}")
            self._flush_frame(page_no, frame)

    def invalidate_all(self) -> None:
        self._ensure_open()
        if any(frame.pin_count for frame in self._frames.values()):
            raise RuntimeError("cannot invalidate buffer pool while pages are pinned")
        self._frames.clear()

    def close(self) -> None:
        if self._closed:
            return
        self.flush_all()
        self._frames.clear()
        self._closed = True

from __future__ import annotations

import os

import pytest

from storage import BufferPool, BufferPoolFull, PAGE_HEADER_SIZE, PAGE_SIZE, PageCorruptionError, PageFile


class FakeWAL:
    def __init__(self):
        self.flushed = 0

    def flush_up_to(self, lsn: int) -> None:
        self.flushed = max(self.flushed, lsn)


def test_page_file_round_trip_preserves_payload_page_id_and_lsn(tmp_path):
    path = tmp_path / "pages.db"
    with PageFile(path) as file:
        file.write_page(0, b"meta", lsn=7)
        page = file.read_page(0)
        assert page.page_no == 0
        assert page.payload == b"meta"
        assert page.lsn == 7
        assert file.page_count == 1


def test_page_file_extends_with_valid_blank_pages(tmp_path):
    with PageFile(tmp_path / "pages.db") as file:
        file.ensure_page_exists(3)
        assert file.page_count == 4
        assert file.read_page(3).payload == b""


def test_page_checksum_detects_payload_corruption(tmp_path):
    path = tmp_path / "pages.db"
    with PageFile(path) as file:
        file.write_page(0, b"known payload", lsn=1)
    with path.open("r+b") as raw:
        raw.seek(PAGE_HEADER_SIZE + 2)
        byte = raw.read(1)
        raw.seek(PAGE_HEADER_SIZE + 2)
        raw.write(bytes([byte[0] ^ 0xFF]))
    with PageFile(path) as file:
        with pytest.raises(PageCorruptionError):
            file.read_page(0)


def test_page_file_rejects_truncated_partial_page(tmp_path):
    path = tmp_path / "pages.db"
    path.write_bytes(b"partial")
    with pytest.raises(PageCorruptionError):
        PageFile(path)


def test_buffer_pool_evicts_lru_unpinned_page_and_flushes_wal_first(tmp_path):
    with PageFile(tmp_path / "pages.db") as file:
        file.write_page(0, b"zero")
        file.write_page(1, b"one")
        wal = FakeWAL()
        pool = BufferPool(file, capacity=1, wal=wal)
        with pool.fetch(0) as guard:
            guard.replace(b"zero changed", lsn=9)
        with pool.fetch(1) as guard:
            assert guard.page.payload == b"one"
        assert wal.flushed == 9
        assert file.read_page(0).payload == b"zero changed"
        pool.close()


def test_buffer_pool_refuses_to_evict_a_pinned_frame(tmp_path):
    with PageFile(tmp_path / "pages.db") as file:
        file.write_page(0, b"zero")
        file.write_page(1, b"one")
        pool = BufferPool(file, capacity=1)
        with pool.fetch(0):
            with pytest.raises(BufferPoolFull):
                pool.fetch(1)
        pool.close()

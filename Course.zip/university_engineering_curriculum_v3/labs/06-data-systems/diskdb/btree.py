"""Persistent integer-key B+ tree built on the course page/WAL primitives.

Values are JSON-serializable. This implementation supports insert/update, point
lookup and inclusive range scans. Deletion, concurrent transactions and recovery
of uncommitted data pages are deliberately outside this lab's scope.
"""
from __future__ import annotations

import bisect
import json
import os
from pathlib import Path
from typing import Any

from storage import BufferPool, PageCorruptionError, PageFile
from wal import RecoveryManager, WAL


def _encode_json(value: Any) -> bytes:
    try:
        return json.dumps(value, ensure_ascii=False, allow_nan=False,
                          sort_keys=True, separators=(",", ":")).encode("utf-8")
    except (TypeError, ValueError) as exc:
        raise ValueError(f"B+ tree values must be finite JSON values: {exc}") from exc


def _decode_json(payload: bytes) -> Any:
    try:
        return json.loads(payload.decode("utf-8"))
    except (UnicodeDecodeError, json.JSONDecodeError) as exc:
        raise PageCorruptionError(f"invalid JSON in B+ tree page: {exc}") from exc


class DiskBPlusTree:
    """A small disk-oriented B+ tree with full-page-image transactions."""

    def __init__(self, path: str | os.PathLike[str], order: int = 4,
                 wal_path: str | os.PathLike[str] | None = None,
                 buffer_pool_capacity: int = 8):
        if isinstance(order, bool) or not isinstance(order, int) or order < 3:
            raise ValueError("order must be an integer >= 3")
        if isinstance(buffer_pool_capacity, bool) or not isinstance(buffer_pool_capacity, int) or buffer_pool_capacity < 1:
            raise ValueError("buffer_pool_capacity must be a positive integer")
        self.path = Path(path)
        self.order = order
        self.page_file = PageFile(self.path)
        self.wal = WAL(wal_path if wal_path is not None else str(self.path) + ".wal")
        self.recovery = RecoveryManager(self.wal, self.page_file)
        # Recovery must run before any logical page is read into the cache.
        self.recovery.recover()
        self.buffer_pool = BufferPool(self.page_file, capacity=buffer_pool_capacity)
        self._closed = False
        if self.page_file.page_count == 0:
            meta = {"kind": "meta", "root": 1, "next_page_id": 2,
                    "order": self.order, "size": 0}
            root = {"kind": "leaf", "keys": [], "values": [], "next": None}
            self.recovery.commit(self.wal.next_txid,
                                 {0: _encode_json(meta), 1: _encode_json(root)}, apply=True)
        self._meta = self._read_json_page(0)
        if self._meta.get("kind") != "meta":
            raise PageCorruptionError("page 0 is not a B+ tree metadata page")
        if self._meta.get("order") != self.order:
            raise ValueError(
                f"tree was created with order {self._meta.get('order')}; requested {self.order}"
            )
        if not isinstance(self._meta.get("root"), int) or not isinstance(self._meta.get("next_page_id"), int):
            raise PageCorruptionError("invalid B+ tree metadata fields")

    def _ensure_open(self) -> None:
        if self._closed:
            raise ValueError("B+ tree is closed")

    def _read_json_page(self, page_no: int) -> dict[str, Any]:
        self._ensure_open()
        with self.buffer_pool.fetch(page_no) as guard:
            value = _decode_json(guard.page.payload)
        if not isinstance(value, dict):
            raise PageCorruptionError(f"page {page_no} must contain a JSON object")
        return value

    def _read_node(self, page_no: int, changes: dict[int, dict[str, Any]] | None = None) -> dict[str, Any]:
        if changes is not None and page_no in changes:
            return changes[page_no]
        node = self._read_json_page(page_no)
        if node.get("kind") not in {"leaf", "internal"}:
            raise PageCorruptionError(f"page {page_no} is not a B+ tree node")
        return node

    def __len__(self) -> int:
        self._ensure_open()
        return int(self._meta["size"])

    def get(self, key: int, default: Any = None) -> Any:
        self._ensure_open()
        self._validate_key(key)
        page_no = self._meta["root"]
        while True:
            node = self._read_node(page_no)
            keys = node["keys"]
            if node["kind"] == "leaf":
                index = bisect.bisect_left(keys, key)
                return node["values"][index] if index < len(keys) and keys[index] == key else default
            page_no = node["children"][bisect.bisect_right(keys, key)]

    @staticmethod
    def _validate_key(key: int) -> None:
        if isinstance(key, bool) or not isinstance(key, int):
            raise TypeError("B+ tree keys must be integers (bool is not accepted)")

    def _allocate_page(self, meta: dict[str, Any]) -> int:
        page_no = meta["next_page_id"]
        meta["next_page_id"] += 1
        return page_no

    def insert(self, key: int, value: Any) -> None:
        self._ensure_open()
        self._validate_key(key)
        value_bytes = _encode_json(value)  # Fail before any log/page modification.
        del value_bytes  # validation only; final values are encoded with their pages
        changes: dict[int, dict[str, Any]] = {}
        meta = dict(self._meta)
        inserted_new_key = False

        def insert_recursive(page_no: int) -> tuple[int | None, int | None, bool]:
            nonlocal inserted_new_key
            node = dict(self._read_node(page_no, changes))
            keys = list(node["keys"])
            if node["kind"] == "leaf":
                values = list(node["values"])
                idx = bisect.bisect_left(keys, key)
                if idx < len(keys) and keys[idx] == key:
                    values[idx] = value
                else:
                    keys.insert(idx, key)
                    values.insert(idx, value)
                    inserted_new_key = True
                node["keys"], node["values"] = keys, values
                if len(keys) <= self.order:
                    changes[page_no] = node
                    return None, None, False
                split_at = (len(keys) + 1) // 2
                right_page = self._allocate_page(meta)
                right = {"kind": "leaf", "keys": keys[split_at:],
                         "values": values[split_at:], "next": node.get("next")}
                node["keys"], node["values"], node["next"] = (
                    keys[:split_at], values[:split_at], right_page)
                changes[page_no] = node
                changes[right_page] = right
                return right["keys"][0], right_page, False

            children = list(node["children"])
            child_idx = bisect.bisect_right(keys, key)
            separator, right_child, _ = insert_recursive(children[child_idx])
            if separator is not None and right_child is not None:
                keys.insert(child_idx, separator)
                children.insert(child_idx + 1, right_child)
            node["keys"], node["children"] = keys, children
            if len(keys) <= self.order:
                changes[page_no] = node
                return None, None, False
            middle = len(keys) // 2
            promoted = keys[middle]
            right_page = self._allocate_page(meta)
            right = {"kind": "internal", "keys": keys[middle + 1:],
                     "children": children[middle + 1:]}
            node["keys"], node["children"] = keys[:middle], children[:middle + 1]
            changes[page_no] = node
            changes[right_page] = right
            return promoted, right_page, False

        separator, right_page, _ = insert_recursive(meta["root"])
        if separator is not None and right_page is not None:
            new_root_page = self._allocate_page(meta)
            changes[new_root_page] = {
                "kind": "internal", "keys": [separator],
                "children": [meta["root"], right_page],
            }
            meta["root"] = new_root_page
        if inserted_new_key:
            meta["size"] += 1
        changes[0] = meta
        image_map = {page_no: _encode_json(node) for page_no, node in changes.items()}
        self.recovery.commit(self.wal.next_txid, image_map, apply=True)
        self.buffer_pool.invalidate_all()
        self._meta = meta

    def range_scan(self, start: int | None = None, end: int | None = None) -> list[tuple[int, Any]]:
        self._ensure_open()
        if start is not None:
            self._validate_key(start)
        if end is not None:
            self._validate_key(end)
        if start is not None and end is not None and start > end:
            return []
        page_no = self._meta["root"]
        while True:
            node = self._read_node(page_no)
            if node["kind"] == "leaf":
                break
            child_idx = 0 if start is None else bisect.bisect_right(node["keys"], start)
            page_no = node["children"][child_idx]
        results: list[tuple[int, Any]] = []
        while page_no is not None:
            leaf = self._read_node(page_no)
            for key, value in zip(leaf["keys"], leaf["values"]):
                if start is not None and key < start:
                    continue
                if end is not None and key > end:
                    return results
                results.append((key, value))
            page_no = leaf.get("next")
        return results

    def validate(self) -> bool:
        self._ensure_open()
        leaf_order: list[int] = []
        seen: set[int] = set()

        def visit(page_no: int, is_root: bool = False):
            if page_no in seen:
                raise AssertionError(f"cycle or duplicate child reference at page {page_no}")
            seen.add(page_no)
            node = self._read_node(page_no)
            keys = node.get("keys")
            if not isinstance(keys, list) or keys != sorted(keys) or len(keys) != len(set(keys)):
                raise AssertionError(f"page {page_no} keys are not strictly increasing")
            if len(keys) > self.order:
                raise AssertionError(f"page {page_no} exceeds maximum key count")
            if node["kind"] == "leaf":
                if len(node.get("values", [])) != len(keys):
                    raise AssertionError(f"leaf page {page_no} key/value length mismatch")
                leaf_order.append(page_no)
                return (keys[0] if keys else None, keys[-1] if keys else None, len(keys), 0)
            children = node.get("children")
            if not isinstance(children, list) or len(children) != len(keys) + 1:
                raise AssertionError(f"internal page {page_no} must have key_count + 1 children")
            if is_root and not keys:
                raise AssertionError("internal root must have at least one key")
            subtrees = [visit(child, False) for child in children]
            depths = {item[3] for item in subtrees}
            if len(depths) != 1:
                raise AssertionError("B+ tree leaves are not at a common depth")
            for idx, separator in enumerate(keys):
                left_max = subtrees[idx][1]
                right_min = subtrees[idx + 1][0]
                if left_max is not None and left_max >= separator:
                    raise AssertionError(f"left child violates separator {separator}")
                if right_min != separator:
                    raise AssertionError(f"separator {separator} is not minimum key in right subtree")
            nonempty_mins = [item[0] for item in subtrees if item[0] is not None]
            nonempty_maxs = [item[1] for item in subtrees if item[1] is not None]
            minimum = min(nonempty_mins) if nonempty_mins else None
            maximum = max(nonempty_maxs) if nonempty_maxs else None
            count = sum(item[2] for item in subtrees)
            return (minimum, maximum, count, next(iter(depths)) + 1)

        _, _, total, _ = visit(self._meta["root"], True)
        if total != self._meta["size"]:
            raise AssertionError(f"metadata size {self._meta['size']} != actual {total}")
        # The linked leaf chain must have the same order as the in-order tree walk.
        chain: list[int] = []
        page_no = leaf_order[0] if leaf_order else None
        while page_no is not None:
            if page_no in chain:
                raise AssertionError("cycle in leaf sibling chain")
            chain.append(page_no)
            page_no = self._read_node(page_no).get("next")
        if chain != leaf_order:
            raise AssertionError("leaf sibling chain differs from in-order tree traversal")
        return True

    def close(self) -> None:
        if self._closed:
            return
        self.buffer_pool.close()
        self.page_file.close()
        self._closed = True

    def __enter__(self) -> "DiskBPlusTree":
        self._ensure_open()
        return self

    def __exit__(self, exc_type, exc, tb) -> None:
        self.close()

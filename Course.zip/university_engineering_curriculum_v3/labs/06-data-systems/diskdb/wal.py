"""Checksummed write-ahead log and a deliberately small redo-only recovery manager.

The lab uses full-page after-images and writes data pages only after COMMIT is
fsynced. It is intentionally not ARIES: there are no loser-transaction UNDO,
checkpoints, concurrent transactions, or page-level locking.
"""
from __future__ import annotations

from dataclasses import dataclass
import os
from pathlib import Path
import struct
import zlib
from typing import Iterable, Mapping

WAL_MAGIC = b"WAL1"
_WAL_PREFIX = struct.Struct(">4sQQBII")  # magic, LSN, txid, kind code, page, payload length
_WAL_HEADER = struct.Struct(">4sQQBIII")  # prefix plus CRC32
MAX_WAL_PAYLOAD = 1 << 20
_KIND_TO_CODE = {"BEGIN": 1, "WRITE": 2, "COMMIT": 3, "ABORT": 4}
_CODE_TO_KIND = {value: key for key, value in _KIND_TO_CODE.items()}


class WALCorruptionError(ValueError):
    """Raised when a complete WAL record fails structural or checksum checks."""


@dataclass(frozen=True)
class WALRecord:
    lsn: int
    txid: int
    kind: str
    page_no: int = 0
    payload: bytes = b""


class WAL:
    """Append-only record file with monotonically increasing logical sequence numbers."""

    def __init__(self, path: str | os.PathLike[str]):
        self.path = Path(path)
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self.path.touch(exist_ok=True)
        self._records: list[WALRecord] = []
        self._last_lsn = 0
        self.durable_lsn = 0
        self._load_and_repair_torn_tail()

    @property
    def next_txid(self) -> int:
        return max((record.txid for record in self._records), default=0) + 1

    def _load_and_repair_torn_tail(self) -> None:
        raw = self.path.read_bytes()
        offset = 0
        valid_end = 0
        records: list[WALRecord] = []
        previous_lsn = 0
        while offset < len(raw):
            remaining = len(raw) - offset
            if remaining < _WAL_HEADER.size:
                # An incomplete terminal header is a torn final record. Earlier
                # complete records remain valid; discard only the incomplete tail.
                break
            header = raw[offset:offset + _WAL_HEADER.size]
            magic, lsn, txid, kind_code, page_no, payload_len, checksum = _WAL_HEADER.unpack(header)
            if magic != WAL_MAGIC:
                raise WALCorruptionError(f"invalid WAL magic at byte offset {offset}")
            if lsn <= previous_lsn or txid < 1:
                raise WALCorruptionError(f"invalid LSN/transaction id at byte offset {offset}")
            if kind_code not in _CODE_TO_KIND:
                raise WALCorruptionError(f"unknown WAL record kind at byte offset {offset}")
            if payload_len > MAX_WAL_PAYLOAD:
                raise WALCorruptionError(f"oversize WAL payload at byte offset {offset}")
            record_end = offset + _WAL_HEADER.size + payload_len
            if record_end > len(raw):
                # Header is complete, payload tail is not: torn final record.
                break
            payload = raw[offset + _WAL_HEADER.size:record_end]
            prefix = _WAL_PREFIX.pack(magic, lsn, txid, kind_code, page_no, payload_len)
            actual = zlib.crc32(prefix + payload) & 0xFFFFFFFF
            if actual != checksum:
                raise WALCorruptionError(f"checksum mismatch at byte offset {offset}")
            kind = _CODE_TO_KIND[kind_code]
            if kind != "WRITE" and payload:
                raise WALCorruptionError(f"unexpected payload on {kind} record at LSN {lsn}")
            if kind != "WRITE" and page_no != 0:
                raise WALCorruptionError(f"unexpected page number on {kind} record at LSN {lsn}")
            if kind == "WRITE" and payload_len == 0:
                # Empty page images are legal (they represent blank pages).
                pass
            records.append(WALRecord(lsn, txid, kind, page_no, payload))
            previous_lsn = lsn
            offset = record_end
            valid_end = offset
        if valid_end != len(raw):
            with self.path.open("r+b") as stream:
                stream.truncate(valid_end)
                stream.flush()
                os.fsync(stream.fileno())
        self._records = records
        self._last_lsn = previous_lsn
        # Any complete records surviving a reopen are the durable log prefix.
        self.durable_lsn = previous_lsn

    def append(self, txid: int, kind: str, page_no: int = 0, payload: bytes = b"") -> WALRecord:
        kind = str(kind).upper()
        if kind not in _KIND_TO_CODE:
            raise ValueError(f"unsupported WAL record kind: {kind}")
        if isinstance(txid, bool) or not isinstance(txid, int) or txid < 1:
            raise ValueError("txid must be a positive integer")
        if isinstance(page_no, bool) or not isinstance(page_no, int) or page_no < 0:
            raise ValueError("page_no must be a non-negative integer")
        if not isinstance(payload, bytes):
            raise TypeError("payload must be bytes")
        if len(payload) > MAX_WAL_PAYLOAD:
            raise ValueError(f"payload exceeds {MAX_WAL_PAYLOAD} bytes")
        if kind != "WRITE" and payload:
            raise ValueError(f"{kind} records cannot have a payload")
        if kind != "WRITE" and page_no != 0:
            raise ValueError(f"{kind} records cannot name a data page")
        lsn = self._last_lsn + 1
        code = _KIND_TO_CODE[kind]
        prefix = _WAL_PREFIX.pack(WAL_MAGIC, lsn, txid, code, page_no, len(payload))
        checksum = zlib.crc32(prefix + payload) & 0xFFFFFFFF
        encoded = _WAL_HEADER.pack(WAL_MAGIC, lsn, txid, code, page_no, len(payload), checksum) + payload
        with self.path.open("ab") as stream:
            stream.write(encoded)
            stream.flush()
        record = WALRecord(lsn, txid, kind, page_no, payload)
        self._records.append(record)
        self._last_lsn = lsn
        return record

    def flush_up_to(self, lsn: int) -> None:
        if isinstance(lsn, bool) or not isinstance(lsn, int) or lsn < 0:
            raise ValueError("lsn must be a non-negative integer")
        if lsn > self._last_lsn:
            raise ValueError(f"cannot flush future LSN {lsn}; last LSN is {self._last_lsn}")
        with self.path.open("ab") as stream:
            stream.flush()
            os.fsync(stream.fileno())
        self.durable_lsn = max(self.durable_lsn, lsn)

    def scan(self) -> list[WALRecord]:
        # Return a copy so callers cannot mutate the in-memory validated log.
        return list(self._records)

    def commit_lsn(self, txid: int) -> int:
        matches = [record.lsn for record in self._records if record.txid == txid and record.kind == "COMMIT"]
        if not matches:
            raise KeyError(f"transaction {txid} has no COMMIT record")
        return matches[-1]


class RecoveryManager:
    """Redo committed full-page images, skipping pages already at/after their LSN."""

    def __init__(self, wal: WAL, page_file):
        self.wal = wal
        self.page_file = page_file

    def commit(self, txid: int, page_images: Mapping[int, bytes], apply: bool = True) -> int:
        if not page_images:
            raise ValueError("a page-image transaction must update at least one page")
        if txid < 1:
            raise ValueError("txid must be positive")
        existing = [record for record in self.wal.scan() if record.txid == txid]
        if existing:
            raise ValueError(f"transaction id {txid} already appears in the WAL")
        self.wal.append(txid, "BEGIN")
        write_records = []
        for page_no in sorted(page_images):
            payload = page_images[page_no]
            record = self.wal.append(txid, "WRITE", page_no=page_no, payload=payload)
            write_records.append(record)
        commit = self.wal.append(txid, "COMMIT")
        # Write-ahead invariant: COMMIT and every preceding page image are stable
        # before the first corresponding data page is changed.
        self.wal.flush_up_to(commit.lsn)
        if apply:
            for record in write_records:
                self.page_file.write_page(record.page_no, record.payload, lsn=record.lsn)
            self.page_file.sync()
        return commit.lsn

    def recover(self) -> dict[str, int]:
        records = self.wal.scan()
        committed: set[int] = set()
        aborted: set[int] = set()
        for record in records:
            if record.kind == "COMMIT":
                committed.add(record.txid)
            elif record.kind == "ABORT":
                aborted.add(record.txid)
        winners = committed - aborted
        replayed = 0
        ignored = 0
        for record in records:
            if record.kind != "WRITE":
                continue
            if record.txid not in winners:
                ignored += 1
                continue
            if record.page_no < self.page_file.page_count:
                current = self.page_file.read_page(record.page_no)
                if current.lsn >= record.lsn:
                    continue
            self.page_file.write_page(record.page_no, record.payload, lsn=record.lsn)
            replayed += 1
        if replayed:
            self.page_file.sync()
        return {
            "committed_transactions": len(winners),
            "replayed_writes": replayed,
            "ignored_uncommitted": ignored,
        }

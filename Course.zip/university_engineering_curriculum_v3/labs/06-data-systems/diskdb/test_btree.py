from __future__ import annotations

import random

from btree import DiskBPlusTree


def test_disk_btree_splits_range_scans_and_reopens(tmp_path):
    path = tmp_path / "index.db"
    wal_path = tmp_path / "index.wal"
    tree = DiskBPlusTree(path, order=3, wal_path=wal_path, buffer_pool_capacity=3)
    for key in [17, 3, 9, 1, 22, 5, 11, 2, 4, 8, 16, 7, 12, 6, 10, 15, 14, 13, 18, 19, 20, 21]:
        tree.insert(key, {"value": key * 10})
    assert tree.validate()
    assert tree.range_scan(5, 12) == [(key, {"value": key * 10}) for key in range(5, 13)]
    tree.close()

    reopened = DiskBPlusTree(path, order=3, wal_path=wal_path, buffer_pool_capacity=2)
    assert len(reopened) == 22
    assert reopened.get(17) == {"value": 170}
    assert reopened.range_scan(1, 22) == [(key, {"value": key * 10}) for key in range(1, 23)]
    assert reopened.validate()
    reopened.close()


def test_disk_btree_duplicate_key_updates_value_and_reopens(tmp_path):
    path = tmp_path / "index.db"
    tree = DiskBPlusTree(path, order=4)
    tree.insert(7, "first")
    tree.insert(7, "updated")
    assert len(tree) == 1
    assert tree.get(7) == "updated"
    tree.close()
    reopened = DiskBPlusTree(path, order=4)
    assert len(reopened) == 1
    assert reopened.get(7) == "updated"
    reopened.close()


def test_seeded_disk_btree_histories_match_reference_dictionary(tmp_path):
    for seed in range(8):
        path = tmp_path / f"index-{seed}.db"
        wal_path = tmp_path / f"index-{seed}.wal"
        rng = random.Random(seed)
        tree = DiskBPlusTree(path, order=rng.randint(3, 6), wal_path=wal_path, buffer_pool_capacity=5)
        reference = {}
        for _ in range(45):
            key = rng.randint(-20, 20)
            value = {"seed": seed, "value": rng.randint(0, 10_000)}
            tree.insert(key, value)
            reference[key] = value
            assert len(tree) == len(reference)
            assert tree.validate()
            for probe in range(-20, 21, 5):
                assert tree.get(probe) == reference.get(probe)
        start, end = -8, 13
        assert tree.range_scan(start, end) == [(key, reference[key]) for key in sorted(reference) if start <= key <= end]
        tree.close()
        reopened = DiskBPlusTree(path, order=tree.order, wal_path=wal_path, buffer_pool_capacity=4)
        assert reopened.range_scan(-100, 100) == [(key, reference[key]) for key in sorted(reference)]
        assert reopened.validate()
        reopened.close()

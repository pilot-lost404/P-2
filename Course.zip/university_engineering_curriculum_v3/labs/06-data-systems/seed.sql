-- Idempotent educational seed data. Safe to rerun on this disposable schema.
INSERT INTO facility (name, timezone)
VALUES ('Teaching Facility A', 'Asia/Kolkata')
ON CONFLICT (name) DO NOTHING;

INSERT INTO tank (facility_id, tank_code, capacity_litres, target_percent)
SELECT facility_id, 'TANK-01', 10000, 75
FROM facility WHERE name = 'Teaching Facility A'
ON CONFLICT (facility_id, tank_code) DO NOTHING;

INSERT INTO sensor (tank_id, sensor_code)
SELECT t.tank_id, 'LEVEL-01' FROM tank AS t
JOIN facility AS f ON f.facility_id = t.facility_id
WHERE t.tank_code = 'TANK-01' AND f.name = 'Teaching Facility A'
ON CONFLICT (tank_id, sensor_code) DO NOTHING;

INSERT INTO app_user (email, password_verifier)
VALUES ('operator@example.test', 'REPLACE_WITH_A_REAL_PASSWORD_VERIFIER')
ON CONFLICT (email) DO NOTHING;

INSERT INTO user_facility (user_id, facility_id, role)
SELECT u.user_id, f.facility_id, 'OPERATOR'
FROM app_user u CROSS JOIN facility f
WHERE u.email = 'operator@example.test' AND f.name = 'Teaching Facility A'
ON CONFLICT (user_id, facility_id) DO NOTHING;

INSERT INTO measurement (event_id, sensor_id, sequence_no, event_time, level_percent, quality, schema_version)
SELECT '00000000-0000-4000-8000-000000000001'::uuid, sensor_id, 1,
       now() - interval '2 minutes', 61.250, 'VALID', 1
FROM sensor AS s
JOIN tank AS t ON t.tank_id = s.tank_id
JOIN facility AS f ON f.facility_id = t.facility_id
WHERE s.sensor_code = 'LEVEL-01' AND t.tank_code = 'TANK-01' AND f.name = 'Teaching Facility A'
ON CONFLICT (event_id) DO NOTHING;

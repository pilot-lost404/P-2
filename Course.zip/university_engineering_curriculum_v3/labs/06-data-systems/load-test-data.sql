-- Generate deterministic-scale synthetic data in a disposable database.
-- Re-running requires deleting measurements for the selected sensor first.
INSERT INTO measurement (
    event_id, sensor_id, sequence_no, event_time, level_percent, quality, schema_version
)
SELECT gen_random_uuid(), s.sensor_id, g.n + 1,
       now() - (g.n || ' seconds')::interval,
       (20 + (g.n % 7500) / 100.0)::numeric(6,3),
       CASE WHEN g.n % 97 = 0 THEN 'STALE' ELSE 'VALID' END,
       1
FROM sensor AS s
CROSS JOIN generate_series(1, 100000) AS g(n)
JOIN tank AS t ON t.tank_id = s.tank_id
JOIN facility AS f ON f.facility_id = t.facility_id
WHERE s.sensor_code = 'LEVEL-01' AND t.tank_code = 'TANK-01' AND f.name = 'Teaching Facility A';

ANALYZE measurement;

-- Educational PostgreSQL schema. Use a disposable local database only.
CREATE TABLE facility (
    facility_id bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    name text NOT NULL UNIQUE,
    timezone text NOT NULL,
    created_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE tank (
    tank_id bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    facility_id bigint NOT NULL REFERENCES facility(facility_id),
    tank_code text NOT NULL,
    capacity_litres numeric(12,2) NOT NULL CHECK (capacity_litres > 0),
    target_percent numeric(5,2) NOT NULL CHECK (target_percent BETWEEN 0 AND 100),
    UNIQUE (facility_id, tank_code)
);

CREATE TABLE sensor (
    sensor_id bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    tank_id bigint NOT NULL REFERENCES tank(tank_id),
    sensor_code text NOT NULL,
    enabled boolean NOT NULL DEFAULT true,
    UNIQUE (tank_id, sensor_code)
);

CREATE TABLE measurement (
    measurement_id bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    event_id uuid NOT NULL UNIQUE,
    sensor_id bigint NOT NULL REFERENCES sensor(sensor_id),
    sequence_no bigint NOT NULL CHECK (sequence_no >= 0),
    event_time timestamptz NOT NULL,
    received_at timestamptz NOT NULL DEFAULT now(),
    level_percent numeric(6,3),
    quality text NOT NULL CHECK (quality IN ('VALID','STALE','OUT_OF_RANGE','DISCONNECTED','UNKNOWN')),
    schema_version integer NOT NULL CHECK (schema_version > 0),
    UNIQUE (sensor_id, sequence_no),
    CHECK ((quality = 'VALID' AND level_percent IS NOT NULL AND level_percent BETWEEN 0 AND 100) OR quality <> 'VALID')
);

CREATE INDEX measurement_sensor_time_idx ON measurement(sensor_id, event_time DESC);

CREATE TABLE app_user (
    user_id bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    email text NOT NULL UNIQUE,
    password_verifier text NOT NULL,
    active boolean NOT NULL DEFAULT true
);

CREATE TABLE user_facility (
    user_id bigint NOT NULL REFERENCES app_user(user_id),
    facility_id bigint NOT NULL REFERENCES facility(facility_id),
    role text NOT NULL CHECK (role IN ('OPERATOR','SUPERVISOR','ADMIN')),
    PRIMARY KEY (user_id, facility_id)
);

CREATE TABLE command (
    command_id uuid PRIMARY KEY,
    tank_id bigint NOT NULL REFERENCES tank(tank_id),
    requested_by bigint NOT NULL REFERENCES app_user(user_id),
    requested_target_percent numeric(5,2) NOT NULL CHECK (requested_target_percent BETWEEN 0 AND 100),
    created_at timestamptz NOT NULL DEFAULT now(),
    expires_at timestamptz NOT NULL,
    status text NOT NULL CHECK (status IN ('PENDING','ACCEPTED','REJECTED','APPLIED','EXPIRED','FAILED')),
    result_detail text,
    CHECK (expires_at > created_at)
);

CREATE TABLE audit_event (
    audit_id bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    command_id uuid REFERENCES command(command_id),
    actor_user_id bigint REFERENCES app_user(user_id),
    event_type text NOT NULL,
    event_time timestamptz NOT NULL DEFAULT now(),
    detail jsonb NOT NULL DEFAULT '{}'::jsonb
);

CREATE TABLE outbox_event (
    outbox_id bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    event_id uuid NOT NULL UNIQUE,
    aggregate_type text NOT NULL,
    aggregate_id text NOT NULL,
    event_type text NOT NULL,
    payload jsonb NOT NULL,
    created_at timestamptz NOT NULL DEFAULT now(),
    published_at timestamptz
);
CREATE INDEX outbox_unpublished_idx ON outbox_event(created_at) WHERE published_at IS NULL;

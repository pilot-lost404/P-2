-- Two-session write-skew exercise. Run once in a disposable database.
DROP TABLE IF EXISTS demo_on_call;
CREATE TABLE demo_on_call (
    doctor_id text PRIMARY KEY,
    on_call boolean NOT NULL
);
INSERT INTO demo_on_call VALUES ('A', true), ('B', true);

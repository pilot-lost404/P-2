"""A small unique-key B+ tree for studying index invariants.

This is an in-memory teaching implementation, not a disk-backed DBMS index.
`order` is the maximum number of child pointers in an internal node; a node
therefore holds at most order-1 separator keys. Keys must be mutually ordered
using Python's comparison operators.
"""
from __future__ import annotations

from bisect import bisect_left, bisect_right
from dataclasses import dataclass, field
from typing import Generic, TypeVar

K = TypeVar("K")
V = TypeVar("V")


@dataclass
class _Node(Generic[K, V]):
    leaf: bool
    keys: list[K] = field(default_factory=list)
    values: list[V] = field(default_factory=list)
    children: list["_Node[K, V]"] = field(default_factory=list)
    next_leaf: "_Node[K, V] | None" = None


class BPlusTree(Generic[K, V]):
    """B+ tree with unique keys, point lookup and inclusive range scans."""

    def __init__(self, order: int = 4) -> None:
        if not isinstance(order, int) or isinstance(order, bool) or order < 3:
            raise ValueError("order must be an integer >= 3")
        self.order = order
        self.root: _Node[K, V] = _Node(leaf=True)
        self._size = 0
        self.height = 1

    def __len__(self) -> int:
        return self._size

    def get(self, key: K) -> V | None:
        leaf = self._find_leaf(key)
        index = bisect_left(leaf.keys, key)
        if index < len(leaf.keys) and leaf.keys[index] == key:
            return leaf.values[index]
        return None

    def insert(self, key: K, value: V) -> None:
        split = self._insert(self.root, key, value)
        if split is not None:
            separator, right = split
            old_root = self.root
            self.root = _Node(leaf=False, keys=[separator], children=[old_root, right])
            self.height += 1

    def range_scan(self, start: K, end: K) -> list[tuple[K, V]]:
        """Return key/value pairs for the inclusive interval [start, end]."""
        if end < start:
            return []
        leaf = self._find_leaf(start)
        index = bisect_left(leaf.keys, start)
        output: list[tuple[K, V]] = []
        while leaf is not None:
            while index < len(leaf.keys):
                key = leaf.keys[index]
                if key > end:
                    return output
                output.append((key, leaf.values[index]))
                index += 1
            leaf = leaf.next_leaf
            index = 0
        return output

    def validate(self) -> bool:
        """Check ordering, occupancy, child/separator and leaf-depth invariants."""
        leaf_depths: set[int] = set()
        all_leaf_keys: list[K] = []

        def walk(node: _Node[K, V], depth: int, is_root: bool) -> tuple[K | None, K | None, int]:
            if node.keys != sorted(node.keys):
                raise AssertionError("node keys are not sorted")
            if len(node.keys) > self.order - 1:
                raise AssertionError("node exceeds maximum key count")
            if node.leaf:
                if len(node.keys) != len(node.values):
                    raise AssertionError("leaf key/value counts differ")
                if node.children:
                    raise AssertionError("leaf must not have children")
                if not is_root and len(node.keys) < self.order // 2:
                    raise AssertionError("leaf under minimum occupancy")
                leaf_depths.add(depth)
                all_leaf_keys.extend(node.keys)
                if not node.keys:
                    return None, None, len(node.keys)
                return node.keys[0], node.keys[-1], len(node.keys)

            if node.values or len(node.children) != len(node.keys) + 1:
                raise AssertionError("internal node child/key structure invalid")
            minimum_children = (self.order + 1) // 2
            if is_root:
                if len(node.children) < 2:
                    raise AssertionError("internal root must have at least two children")
            elif len(node.children) < minimum_children:
                raise AssertionError("internal node under minimum occupancy")

            ranges = [walk(child, depth + 1, False) for child in node.children]
            for i, separator in enumerate(node.keys):
                right_min = ranges[i + 1][0]
                if right_min is None or separator != right_min:
                    raise AssertionError("separator must equal minimum key of right child")
                left_max = ranges[i][1]
                if left_max is not None and not left_max < separator:
                    raise AssertionError("child key ranges overlap or are unordered")
            return ranges[0][0], ranges[-1][1], sum(r[2] for r in ranges)

        walk(self.root, 0, True)
        if len(leaf_depths) > 1:
            raise AssertionError("leaves are not at the same depth")
        if all_leaf_keys != sorted(all_leaf_keys):
            raise AssertionError("leaf traversal is not globally ordered")
        if len(all_leaf_keys) != self._size or len(set(all_leaf_keys)) != self._size:
            raise AssertionError("tree size or unique-key invariant violated")
        # Verify the forward leaf chain matches DFS leaf order.
        leaves: list[_Node[K, V]] = []

        def collect(node: _Node[K, V]) -> None:
            if node.leaf:
                leaves.append(node)
            else:
                for child in node.children:
                    collect(child)

        collect(self.root)
        for i, leaf in enumerate(leaves):
            expected = leaves[i + 1] if i + 1 < len(leaves) else None
            if leaf.next_leaf is not expected:
                raise AssertionError("leaf sibling pointer is incorrect")
        return True

    def _find_leaf(self, key: K) -> _Node[K, V]:
        node = self.root
        while not node.leaf:
            node = node.children[bisect_right(node.keys, key)]
        return node

    def _insert(self, node: _Node[K, V], key: K, value: V) -> tuple[K, _Node[K, V]] | None:
        if node.leaf:
            index = bisect_left(node.keys, key)
            if index < len(node.keys) and node.keys[index] == key:
                node.values[index] = value
                return None
            node.keys.insert(index, key)
            node.values.insert(index, value)
            self._size += 1
            if len(node.keys) <= self.order - 1:
                return None
            split_at = (len(node.keys) + 1) // 2
            right = _Node(leaf=True, keys=node.keys[split_at:], values=node.values[split_at:])
            node.keys = node.keys[:split_at]
            node.values = node.values[:split_at]
            right.next_leaf = node.next_leaf
            node.next_leaf = right
            return right.keys[0], right

        child_index = bisect_right(node.keys, key)
        split = self._insert(node.children[child_index], key, value)
        if split is None:
            return None
        separator, right_child = split
        node.keys.insert(child_index, separator)
        node.children.insert(child_index + 1, right_child)
        if len(node.keys) <= self.order - 1:
            return None
        middle = len(node.keys) // 2
        promoted = node.keys[middle]
        right = _Node(
            leaf=False,
            keys=node.keys[middle + 1:],
            children=node.children[middle + 1:],
        )
        node.keys = node.keys[:middle]
        node.children = node.children[:middle + 1]
        return promoted, right

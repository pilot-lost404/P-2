import random
from bptree import BPlusTree


def test_empty_tree_lookup_and_range():
    tree = BPlusTree(order=3)
    assert tree.get(10) is None
    assert tree.range_scan(0, 20) == []
    assert tree.validate()


def test_insert_search_and_root_splits():
    tree = BPlusTree(order=3)
    for key in range(40):
        tree.insert(key, f"v{key}")
    assert all(tree.get(k) == f"v{k}" for k in range(40))
    assert tree.get(100) is None
    assert tree.height >= 2
    assert tree.validate()


def test_range_scan_follows_leaf_links_across_splits():
    tree = BPlusTree(order=4)
    for key in [12, 3, 8, 1, 9, 7, 15, 2, 14, 4, 6, 5, 11, 10, 13]:
        tree.insert(key, str(key))
    assert tree.range_scan(4, 11) == [(k, str(k)) for k in range(4, 12)]
    assert tree.validate()


def test_duplicate_key_updates_value_without_creating_duplicate_entry():
    tree = BPlusTree(order=3)
    tree.insert(7, "first")
    tree.insert(7, "updated")
    assert tree.get(7) == "updated"
    assert tree.range_scan(0, 10) == [(7, "updated")]
    assert tree.validate()


def test_deterministic_random_insertions_preserve_tree_invariants():
    keys = list(range(500))
    random.Random(42).shuffle(keys)
    tree = BPlusTree(order=5)
    for key in keys:
        tree.insert(key, key * 2)
        assert tree.validate()
    assert tree.range_scan(100, 199) == [(k, k * 2) for k in range(100, 200)]


def test_reversed_range_is_empty_and_insertion_order_does_not_change_ordering():
    tree = BPlusTree(order=4)
    for key in [50, 10, 90, 30, 70]:
        tree.insert(key, str(key))
    assert tree.range_scan(90, 10) == []
    assert tree.range_scan(-100, 100) == [(10, "10"), (30, "30"), (50, "50"), (70, "70"), (90, "90")]
    assert tree.validate()


def test_size_tracks_unique_keys_not_updates():
    tree = BPlusTree(order=3)
    for _ in range(5):
        tree.insert(2, "same")
    assert len(tree) == 1
    tree.insert(1, "one")
    assert len(tree) == 2
    assert tree.validate()


def test_order_must_allow_at_least_three_children():
    import pytest
    with pytest.raises(ValueError, match="order must be"):
        BPlusTree(order=2)

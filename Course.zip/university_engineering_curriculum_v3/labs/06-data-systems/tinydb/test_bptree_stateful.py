"""Seeded state-machine tests against a simple reference mapping."""
from __future__ import annotations

import random

from bptree import BPlusTree


def test_seeded_insert_update_lookup_and_range_sequences_match_reference_map():
    for seed in range(40):
        rng = random.Random(seed)
        tree = BPlusTree[int, int](order=rng.randint(3, 8))
        reference: dict[int, int] = {}

        for step in range(120):
            key = rng.randint(-35, 35)
            value = rng.randint(-100_000, 100_000)
            tree.insert(key, value)
            reference[key] = value

            assert len(tree) == len(reference)
            assert tree.validate()
            probe = rng.randint(-40, 40)
            assert tree.get(probe) == reference.get(probe)

            start, end = sorted((rng.randint(-40, 40), rng.randint(-40, 40)))
            expected = [(k, reference[k]) for k in sorted(reference) if start <= k <= end]
            assert tree.range_scan(start, end) == expected

            if step % 17 == 0:
                for existing_key, existing_value in reference.items():
                    assert tree.get(existing_key) == existing_value


def test_all_insertion_orders_produce_the_same_sorted_contents_for_small_key_set():
    keys = list(range(7))
    expected = [(key, key * 3) for key in keys]
    for seed in range(30):
        rng = random.Random(seed)
        shuffled = keys[:]
        rng.shuffle(shuffled)
        tree = BPlusTree[int, int](order=3 + seed % 4)
        for key in shuffled:
            tree.insert(key, key * 3)
        assert tree.range_scan(-100, 100) == expected
        assert tree.validate()

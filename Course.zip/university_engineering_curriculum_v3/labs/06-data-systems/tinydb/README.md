# Lab 6B — In-memory B+ tree index

## Setup and tests

Requires Python 3.11+ and pytest. From this directory run:

```bash
python -m pytest -q
```

## Learning goals

- Understand why B+ trees store record values/references in leaves and separator keys in internal nodes.
- Implement unique-key insertion, point lookup and inclusive range scan.
- Preserve sorted keys, child/key counts, separator semantics, occupancy, equal leaf depth and linked-leaf order through recursive splits.
- Use invariant validation after every insertion to catch structural corruption.

## Implementation contract

`order` is the maximum number of child pointers an internal node can hold; maximum keys per node is `order - 1`. Keys must be mutually ordered. Duplicate keys update the existing value. Range scans include both endpoints. The implementation has no deletion, persistence, page IDs, buffer pool, concurrency control, WAL, transaction isolation or crash recovery.

## Exercises

1. Trace each insertion for order 3 and order 4. Draw node contents after every split.
2. Prove the search path remains correct when a key equals an internal separator.
3. Add deletion with borrow/merge and root shrink, then extend invariants.
4. Add a serialization format with checksums and versioning; test corrupted pages.
5. Replace Python object nodes with a fixed-size page layout and implement a buffer pool with pin/dirty/eviction rules.
6. Measure height and key comparisons against a sorted array and a hash table. State the workload under which each is appropriate.

## Complexity and limitations

For a balanced tree of fanout m, point lookup and insertion take O(log_m n) node visits, while a range scan takes O(log_m n + k) for k returned entries. These asymptotic bounds do not model disk I/O, cache locality, page split write amplification or concurrency. This is a teaching index, not a DBMS storage engine.

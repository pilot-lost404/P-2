-- 1. Latest measurement for each sensor (PostgreSQL DISTINCT ON).
SELECT DISTINCT ON (sensor_id) sensor_id, event_time, level_percent, quality
FROM measurement
ORDER BY sensor_id, event_time DESC, measurement_id DESC;

-- 2. Window-function alternative; compare plan and readability.
SELECT sensor_id, event_time, level_percent, quality
FROM (
    SELECT m.*, row_number() OVER (
        PARTITION BY sensor_id ORDER BY event_time DESC, measurement_id DESC
    ) AS rn
    FROM measurement AS m
) AS ranked
WHERE rn = 1;

-- 3. Events received more than 30 seconds after their event timestamp.
SELECT event_id, event_time, received_at, received_at - event_time AS observed_delay
FROM measurement
WHERE received_at - event_time > interval '30 seconds'
ORDER BY observed_delay DESC;

-- 4. Sensors that have no measurements.
SELECT s.sensor_id, s.sensor_code
FROM sensor AS s
WHERE NOT EXISTS (SELECT 1 FROM measurement AS m WHERE m.sensor_id = s.sensor_id);

-- 5. Recent valid readings for one tank.
SELECT t.tank_code, m.event_time, m.level_percent
FROM tank AS t
JOIN sensor AS s ON s.tank_id = t.tank_id
JOIN measurement AS m ON m.sensor_id = s.sensor_id
WHERE t.tank_id = 1 AND m.quality = 'VALID'
  AND m.event_time >= now() - interval '1 day'
ORDER BY m.event_time DESC;

-- 6. Query plan. EXPLAIN ANALYZE executes the statement.
EXPLAIN (ANALYZE, BUFFERS, VERBOSE)
SELECT * FROM measurement
WHERE sensor_id = 1 AND event_time >= now() - interval '1 day'
ORDER BY event_time DESC;

-- 7. Use this query to compare partial-index usefulness for valid readings.
EXPLAIN (ANALYZE, BUFFERS)
SELECT event_time, level_percent
FROM measurement
WHERE sensor_id = 1 AND quality = 'VALID'
ORDER BY event_time DESC LIMIT 100;

-- 8. Aggregation: hourly telemetry summary; note timezone and bucket semantics.
SELECT date_trunc('hour', event_time) AS hour_utc,
       count(*) AS samples,
       avg(level_percent) FILTER (WHERE quality = 'VALID') AS avg_level_percent
FROM measurement
WHERE event_time >= now() - interval '7 days'
GROUP BY 1 ORDER BY 1;

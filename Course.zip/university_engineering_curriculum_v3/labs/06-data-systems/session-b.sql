-- Session B — execute one statement at a time in a second interactive psql session.
-- Do not run the whole file with psql -f; the exercise requires interleaving.
BEGIN ISOLATION LEVEL REPEATABLE READ;
SELECT count(*) AS doctors_on_call FROM demo_on_call WHERE on_call;
UPDATE demo_on_call SET on_call = false WHERE doctor_id = 'B';
COMMIT;
SELECT * FROM demo_on_call ORDER BY doctor_id;

# Lab 6 — Database design, internals, isolation and recovery (PostgreSQL 18)

## Setup
Use a disposable local PostgreSQL 18 instance. Never use production data.

```bash
docker run --name university-course-postgres \
  -e POSTGRES_PASSWORD=coursepass -e POSTGRES_DB=waterlab \
  -p 5432:5432 -d postgres:18

psql "postgresql://postgres:coursepass@localhost:5432/waterlab" -f schema.sql
psql "postgresql://postgres:coursepass@localhost:5432/waterlab" -f seed.sql
psql "postgresql://postgres:coursepass@localhost:5432/waterlab" -f queries.sql
```

The schema and seed are educational. The seed is designed to be rerunnable. `password_verifier` is an explicit placeholder, not a valid credential. Never deploy this schema as-is.

## Lab A — Relational design and constraints
1. Explain primary, candidate, alternate, foreign and composite keys for each relation.
2. Derive functional dependencies and justify normalization to 3NF/BCNF where applicable.
3. Attempt invalid capacity, target percentage, measurement quality, duplicate event ID, duplicate sensor sequence and nonexistent sensor references. Record SQLSTATE and constraint name.
4. Explain why an event UUID and a `(sensor_id, sequence_no)` uniqueness rule provide different integrity guarantees.

## Lab B — Storage, indexing and query optimization
1. Load at least 100,000 synthetic readings with `load-test-data.sql` into a disposable copy.
2. Run the queries before adding indexes. Save `EXPLAIN (ANALYZE, BUFFERS)` output and row counts.
3. Compare B-tree index scans, bitmap scans and sequential scans. Explain selectivity, correlation, heap fetches, cache effects and why a sequential scan can be optimal.
4. Compare `DISTINCT ON` and a `row_number()` window query for latest-per-sensor. Confirm equivalent results before comparing performance.
5. Add a partial index for `quality='VALID'` and evaluate write amplification, size and plan changes.
6. Change data distribution and repeat. Do not report one machine-specific timing as a universal benchmark.

## Lab C — Isolation, MVCC and write skew
Run `isolation-setup.sql` once. Open two sessions and execute `session-a.sql` and `session-b.sql` in overlapping order. Both sessions may observe two on-call doctors and update different rows; under REPEATABLE READ, the result can violate the intended cross-row invariant. Reset the table and repeat using `SERIALIZABLE`. Observe that PostgreSQL may abort one transaction with a serialization failure. The application must retry the entire transaction.

Also reproduce non-repeatable read behavior under READ COMMITTED, then compare with REPEATABLE READ. Record each session's exact sequence and SQLSTATE. State the PostgreSQL-specific MVCC behavior; do not generalize it to all DBMS implementations.

## Lab D — WAL, checkpoint, backup and restore
1. Read PostgreSQL 18 WAL and backup documentation.
2. Take a logical backup with `pg_dump -Fc`, restore it into a separate database with `pg_restore`, and verify row counts and constraints.
3. For an advanced extension, configure a disposable physical backup/PITR environment with archived WAL. Restore to a chosen recovery target and measure actual RPO/RTO.
4. Distinguish a logical backup from a physical base backup and from a replica. A replica is not an independent backup.
5. Do not simulate destructive crash conditions on your host or a non-disposable database.

## Lab E — Transactions, locking and concurrency control
Draw precedence graphs for supplied schedules; identify conflict-serializability and recoverability. Extend exercises to strict 2PL, deadlock detection and wait-for graphs. In PostgreSQL, inspect locks through `pg_locks` and observe blocking with two sessions. Compare an application-level lock with a database constraint; use the narrowest correct serialization boundary.

## Required submission
Schema and normalization rationale; SQL tests and SQLSTATE evidence; before/after query plans; query equivalence results; two-session schedule transcript; isolation anomaly explanation; backup/restore log; RPO/RTO measurements; limitations and exact environment.

## Important distinction
PostgreSQL is a real implementation used to observe MVCC, SQL and WAL behavior. It is not an implementation project for the internals of a DBMS. The database-engine implementation project is a separate capstone extension: page layout, buffer pool, B+ tree, iterator execution and transaction manager.

Cleanup:
```bash
docker rm -f university-course-postgres
```

## Lab F — Implement a B+ tree index (separate in-memory implementation exercise)
The [`tinydb/`](tinydb/) sublab implements an in-memory unique-key B+ tree with leaf links, point lookup, inclusive range scans and structural invariants. Run it independently:

```bash
python -m pip install -r ../../tools/requirements-labs.txt
pytest -q tinydb
```

This exercise is intentionally not a disk-backed DBMS: it omits page layout, a buffer pool, concurrency control, WAL and crash recovery. Use the PostgreSQL lab above for real database-engine behavior and the B+ tree as a focused data-structure implementation task.

## Edition 3 disk-backed engine implementation

The new [`diskdb/`](diskdb/README.md) lab is separate from PostgreSQL and the original in-memory `tinydb/` B+ tree. It adds a 4 KiB page file with CRC32 headers, LRU buffer pool and pinning, checksummed WAL records, fsync-before-data commit ordering, redo-only recovery of committed full-page images and a persistent integer-key B+ tree.

Run:

```bash
PYTHONPATH=labs/06-data-systems/diskdb pytest -q labs/06-data-systems/diskdb
PYTHONPATH=labs/06-data-systems/diskdb python labs/06-data-systems/diskdb/benchmark.py --inserts 500 --order 8
```

The lab tests persistence across reopen and compares index behavior with a reference dictionary. It does not implement a SQL engine, query execution, delete/merge, concurrency, MVCC, ARIES UNDO/checkpoints or production crash safety. PostgreSQL 18 remains the real-engine experiment and still must be run in a disposable PostgreSQL instance.

-- Session A — execute one statement at a time in an interactive psql session.
-- Do not run the whole file with psql -f; the exercise requires interleaving.
BEGIN ISOLATION LEVEL REPEATABLE READ;
SELECT count(*) AS doctors_on_call FROM demo_on_call WHERE on_call;
-- Pause here until Session B has also begun and run its SELECT.
UPDATE demo_on_call SET on_call = false WHERE doctor_id = 'A';
-- Commit only after Session B has performed its UPDATE.
COMMIT;
SELECT * FROM demo_on_call ORDER BY doctor_id;

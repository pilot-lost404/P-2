package clocklab

import "testing"

func TestLamportReceiveAdvancesPastMessage(t *testing.T) {
	var c LamportClock
	if got := c.Tick(); got != 1 {
		t.Fatalf("first tick = %d, want 1", got)
	}
	if got := c.Receive(7); got != 8 {
		t.Fatalf("receive = %d, want 8", got)
	}
	if got := c.Tick(); got != 9 {
		t.Fatalf("next tick = %d, want 9", got)
	}
}

func TestVectorClockCausalityAndConcurrency(t *testing.T) {
	a := VectorClock{0, 2, 1}
	b := VectorClock{0, 3, 1}
	c := VectorClock{1, 1, 2}
	if got := Compare(a, b); got != Before {
		t.Fatalf("Compare(a,b) = %v, want Before", got)
	}
	if got := Compare(b, a); got != After {
		t.Fatalf("Compare(b,a) = %v, want After", got)
	}
	if got := Compare(a, c); got != Concurrent {
		t.Fatalf("Compare(a,c) = %v, want Concurrent", got)
	}
	if got := Compare(a, VectorClock{0, 2, 1}); got != Equal {
		t.Fatalf("equal vectors = %v", got)
	}
}

func TestVectorClockSendAndReceive(t *testing.T) {
	a := NewVectorClock(2, 0)
	b := NewVectorClock(2, 1)
	message := a.Send(0)
	b.Receive(1, message)
	if Compare(message, b) != Before {
		t.Fatalf("received event should causally precede local receive")
	}
	if b[0] != 1 || b[1] != 1 {
		t.Fatalf("merged vector = %v, want [1 1]", b)
	}
}

func TestVectorClockRejectsDifferentDimensions(t *testing.T) {
	defer func() {
		if recover() == nil {
			t.Fatal("expected dimension mismatch panic")
		}
	}()
	_ = Compare(VectorClock{1}, VectorClock{1, 0})
}

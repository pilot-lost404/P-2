module university-course/clocklab

go 1.23

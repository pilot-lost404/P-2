# Lab 1B — Lamport and vector logical clocks

## Setup and execution

Requires Go 1.23 or newer. From this directory:

```bash
go test -race -count=1 ./...
go vet ./...
```

## Objectives

- Implement a Lamport scalar clock for local events and message receipt.
- Implement vector-clock tick, send and receive operations.
- Distinguish causal order from concurrency using component-wise comparison.
- Test dimension mismatch and state-copy behavior.

## Exercises

1. Work through `clock_test.go` before reading `clock.go`.
2. Add a third process and generate an execution trace containing a causal chain and concurrent events.
3. Add a serialization function for vector clocks and test round-trip behavior; define malformed-input handling.
4. Demonstrate that a Lamport timestamp ordering does not prove causality.
5. Add a merge operation for a replicated grow-only set. State the convergence assumptions.
6. Explain why a vector-clock implementation with a fixed process set does not directly solve membership changes in a large dynamic distributed system.

## Semantics and limitations

The package models logical event order only. It does not provide wall-clock time, synchronization, durable event history, network transport or thread safety when one clock value is concurrently mutated. A caller sharing a clock between goroutines must protect it with synchronization. Vector clocks grow with the number of processes and require a stable component identity mapping for the exercise.

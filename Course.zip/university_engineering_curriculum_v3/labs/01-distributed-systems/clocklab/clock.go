// Package clocklab implements Lamport and vector logical clocks for teaching.
// Clocks are intentionally small value types; callers must serialize access
// if a single clock is shared across goroutines.
package clocklab

import "fmt"

// LamportClock orders events consistently with happened-before, but cannot
// distinguish concurrent events. Zero is the initial clock value.
type LamportClock struct{ value uint64 }

// Tick records one local event and returns its timestamp.
func (c *LamportClock) Tick() uint64 {
	c.value++
	return c.value
}

// Receive records receipt of a message with timestamp remote.
func (c *LamportClock) Receive(remote uint64) uint64 {
	if remote > c.value {
		c.value = remote
	}
	c.value++
	return c.value
}

// Value returns the current timestamp without changing it.
func (c *LamportClock) Value() uint64 { return c.value }

// VectorClock stores one counter per process. The caller supplies the process
// index; a vector's length is the size of the modeled process set.
type VectorClock []uint64

// NewVectorClock returns a zero vector of the requested process count.
func NewVectorClock(processes, local int) VectorClock {
	if processes <= 0 || local < 0 || local >= processes {
		panic(fmt.Sprintf("invalid vector clock dimensions: processes=%d local=%d", processes, local))
	}
	return make(VectorClock, processes)
}

// Tick records a local event and returns a defensive copy of the timestamp.
func (v VectorClock) Tick(local int) VectorClock {
	v.checkIndex(local)
	v[local]++
	return v.Clone()
}

// Send returns the timestamp attached to a message. Sending itself is modeled
// as a local event and therefore increments the sender's component.
func (v VectorClock) Send(local int) VectorClock { return v.Tick(local) }

// Receive merges the remote timestamp component-wise, then increments the
// receiver's local component to record the receive event.
func (v VectorClock) Receive(local int, remote VectorClock) VectorClock {
	v.checkIndex(local)
	if len(v) != len(remote) {
		panic("vector clock dimension mismatch")
	}
	for i := range v {
		if remote[i] > v[i] {
			v[i] = remote[i]
		}
	}
	v[local]++
	return v.Clone()
}

// Clone creates an independent copy of the vector.
func (v VectorClock) Clone() VectorClock { return append(VectorClock(nil), v...) }

func (v VectorClock) checkIndex(local int) {
	if local < 0 || local >= len(v) {
		panic("local process index out of range")
	}
}

type Relation uint8

const (
	Equal Relation = iota
	Before
	After
	Concurrent
)

func (r Relation) String() string {
	switch r {
	case Equal:
		return "equal"
	case Before:
		return "before"
	case After:
		return "after"
	case Concurrent:
		return "concurrent"
	default:
		return "unknown"
	}
}

// Compare implements vector-clock partial ordering. It panics for vectors
// describing different process sets, because component-wise comparison would
// otherwise be meaningless.
func Compare(a, b VectorClock) Relation {
	if len(a) != len(b) {
		panic("vector clock dimension mismatch")
	}
	less, greater := false, false
	for i := range a {
		if a[i] < b[i] {
			less = true
		}
		if a[i] > b[i] {
			greater = true
		}
	}
	switch {
	case !less && !greater:
		return Equal
	case less && !greater:
		return Before
	case !less && greater:
		return After
	default:
		return Concurrent
	}
}

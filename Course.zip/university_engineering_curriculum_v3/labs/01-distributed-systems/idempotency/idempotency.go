package idempotency

import (
	"errors"
	"fmt"
	"sync"
)

var (
	ErrMissingID = errors.New("command ID is required")
	ErrConflictingReuse = errors.New("command ID reused with different payload")
)

type Command struct {
	ID    string
	Delta int64
}

type Result struct {
	NewValue int64
	Sequence uint64
}

type record struct {
	delta  int64
	result Result
}

// Service demonstrates process-local idempotency under concurrent requests.
// It is deliberately NOT durable and is NOT safe across multiple service replicas.
type Service struct {
	mu      sync.Mutex
	value   int64
	applied uint64
	records map[string]record
}

func NewService(initialValue int64) *Service {
	return &Service{value: initialValue, records: make(map[string]record)}
}

func (s *Service) Apply(cmd Command) (Result, error) {
	if cmd.ID == "" {
		return Result{}, ErrMissingID
	}
	s.mu.Lock()
	defer s.mu.Unlock()

	if prior, ok := s.records[cmd.ID]; ok {
		if prior.delta != cmd.Delta {
			return Result{}, ErrConflictingReuse
		}
		return prior.result, nil
	}

	s.value += cmd.Delta
	s.applied++
	result := Result{NewValue: s.value, Sequence: s.applied}
	s.records[cmd.ID] = record{delta: cmd.Delta, result: result}
	return result, nil
}

func (s *Service) State() (value int64, applied uint64) {
	s.mu.Lock()
	defer s.mu.Unlock()
	return s.value, s.applied
}

func (r Result) String() string {
	return fmt.Sprintf("value=%d sequence=%d", r.NewValue, r.Sequence)
}

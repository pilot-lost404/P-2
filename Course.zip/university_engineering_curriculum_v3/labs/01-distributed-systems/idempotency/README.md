# Lab 1A — Idempotency Under Concurrent Retries

Run:
```bash
go test ./...
go test -race ./...
```

Experiments:
1. Change each retry to use a new command ID. Explain why the effect repeats.
2. Remove the mutex and run the race detector.
3. Restart the process and observe that the in-memory deduplication record disappears.
4. Design a PostgreSQL transaction that stores command ID, payload fingerprint, business state and result atomically.

**Learning boundary:** this implementation provides one effect per ID only while one process remains alive. It is not durable and not distributed. A real service needs durable idempotency records, a transaction boundary, multi-replica coordination, retention, conflict detection and recovery semantics. Do not claim end-to-end exactly-once delivery.

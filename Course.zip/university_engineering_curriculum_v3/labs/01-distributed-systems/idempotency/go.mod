module example.com/course/idempotency

go 1.23

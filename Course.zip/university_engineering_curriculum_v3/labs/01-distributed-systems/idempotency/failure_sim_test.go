package idempotency

import "testing"

// TestLostResponseThenRetry models the failure window in which the server
// commits a command but the response is lost in transit. The client retries
// using the same ID; the server must return the recorded result, not reapply.
func TestLostResponseThenRetry(t *testing.T) {
	service := NewService(40)

	// First request reaches the service and is applied. Deliberately discard
	// the response to model a timeout after commit.
	if _, err := service.Apply(Command{ID: "lost-response-1", Delta: 2}); err != nil {
		t.Fatal(err)
	}

	// Client cannot know whether the first request committed and retries.
	retried, err := service.Apply(Command{ID: "lost-response-1", Delta: 2})
	if err != nil {
		t.Fatal(err)
	}
	if retried.NewValue != 42 || retried.Sequence != 1 {
		t.Fatalf("retry result = %+v, want value=42 sequence=1", retried)
	}
	value, applied := service.State()
	if value != 42 || applied != 1 {
		t.Fatalf("state after retry = value=%d applied=%d, want 42 and 1", value, applied)
	}
}

package idempotency

import (
	"errors"
	"sync"
	"testing"
)

func TestRepeatedCommandHasOneEffect(t *testing.T) {
	s := NewService(10)
	first, err := s.Apply(Command{ID: "cmd-1", Delta: 5})
	if err != nil { t.Fatal(err) }
	second, err := s.Apply(Command{ID: "cmd-1", Delta: 5})
	if err != nil { t.Fatal(err) }
	if first != second { t.Fatalf("retry should return original result: %v vs %v", first, second) }
	value, applied := s.State()
	if value != 15 || applied != 1 { t.Fatalf("expected value=15 applied=1; got %d %d", value, applied) }
}

func TestSameIDDifferentPayloadRejected(t *testing.T) {
	s := NewService(0)
	if _, err := s.Apply(Command{ID: "cmd-2", Delta: 3}); err != nil { t.Fatal(err) }
	_, err := s.Apply(Command{ID: "cmd-2", Delta: 99})
	if !errors.Is(err, ErrConflictingReuse) { t.Fatalf("expected ErrConflictingReuse, got %v", err) }
	value, applied := s.State()
	if value != 3 || applied != 1 { t.Fatalf("conflicting retry changed state: %d %d", value, applied) }
}

func TestMissingIDRejected(t *testing.T) {
	s := NewService(0)
	_, err := s.Apply(Command{Delta: 1})
	if !errors.Is(err, ErrMissingID) { t.Fatalf("expected ErrMissingID, got %v", err) }
}

func TestConcurrentDuplicateRequests(t *testing.T) {
	s := NewService(100)
	const workers = 100
	results := make(chan Result, workers)
	errs := make(chan error, workers)
	var wg sync.WaitGroup
	wg.Add(workers)
	for i := 0; i < workers; i++ {
		go func() {
			defer wg.Done()
			result, err := s.Apply(Command{ID: "same-command", Delta: 7})
			if err != nil { errs <- err; return }
			results <- result
		}()
	}
	wg.Wait()
	close(results)
	close(errs)
	for err := range errs { t.Error(err) }
	var first Result
	count := 0
	for result := range results {
		if count == 0 { first = result } else if result != first { t.Errorf("inconsistent result %v vs %v", result, first) }
		count++
	}
	if count != workers { t.Fatalf("expected %d results, got %d", workers, count) }
	value, applied := s.State()
	if value != 107 || applied != 1 { t.Fatalf("expected one effect: value=%d applied=%d", value, applied) }
}

# Lab 5 — Quorum election safety with TLA+ and an executable Python model

## What this lab proves (and what it does not)

The model is a deliberately bounded abstraction of leader election. Each voter may grant at most one vote in each term. A candidate is considered elected when it receives a quorum. With three nodes and quorum size two, any two majorities intersect; the one-vote-per-term rule prevents the intersection node from endorsing both candidates. The checked safety properties are:

- `TypeOK`: every vote names a configured term, voter and candidate.
- `OneVotePerTerm`: a voter endorses no more than one candidate in a term.
- `ElectionSafety`: no term has two different candidates with a quorum.

This model does **not** include Raft log freshness, AppendEntries, log matching, commit-index advancement, persistence, crash recovery, transport faults, joint consensus, read consistency or liveness. It is not a proof of Raft or of a production system. It isolates one necessary quorum-safety argument so the state-space and assumptions remain understandable.

## Run the Python bounded model

From the repository root:

```bash
PYTHONPATH=labs/04-vv/modelcheck_lab pytest -q \
  labs/04-vv/quorum_model/test_quorum_model.py \
  labs/04-vv/quorum_model/test_modelcheck_properties.py \
  labs/04-vv/quorum_model/test_tla_artifacts.py
```

The safe graph is explored exhaustively. The deliberately unsafe version allows a voter to endorse more than one candidate; breadth-first search returns a shortest counterexample ending in two leaders in one term. Property-style tests also generate 200 seeded finite graphs and compare reachability/counterexample distances against independent reference algorithms. These use the Python standard library so they run without extra packages. Hypothesis stateful testing is a recommended extension; it is not a runtime dependency in this baseline.

## Run the TLA+ models with TLC

Install Java 11 or newer. Download the official `tla2tools.jar` from the [TLA+ Tools releases](https://github.com/tlaplus/tlaplus/releases). The release page currently lists v1.8.0 and gives the SHA-1 for the JAR as:

```text
feffd16994db963ad945628cfd03d154c195a468
```

Verify the downloaded file before running it:

```bash
sha1sum tla2tools.jar
```

From this directory, run the correct model:

```bash
java -jar tla2tools.jar -config QuorumElection.cfg QuorumElection.tla
```

Then run the intentionally broken model. Its configuration orders `ElectionSafety` before `OneVotePerTerm`, so TLC should report the two-leaders-per-term counterexample before it reports the underlying multiple-vote defect:

```bash
java -jar tla2tools.jar -config QuorumElectionUnsafe.cfg QuorumElectionUnsafe.tla
```

The build environment used to prepare this course pack had Java 21 but no DNS/network access to retrieve the official JAR, so TLC itself was **not executed here**. The `.tla` and `.cfg` files are authored against the official syntax references, but parser and TLC result evidence are pending. The Python model is executable and tested; static artifact tests are not a substitute for a TLC run.

## Further work

1. Add Raft log terms, `lastLogIndex`/`lastLogTerm`, the RequestVote up-to-date rule and leader completeness.
2. Model `AppendEntries`, conflicting suffix truncation, current-term commitment and snapshots.
3. Add crash/restart and a persistence abstraction; model the durable-before-ack ordering.
4. Add message loss/duplication/reordering and explicit fairness assumptions; state liveness properties separately from safety invariants.
5. Increase the number of nodes and terms only after the small model has been understood; report state counts and state-space growth.
6. Compare TLC's counterexample to the Python graph model and to an executable Go Raft simulator test.

## References

- [TLA+ Tools and TLC — official repository and CLI instructions](https://github.com/tlaplus/tlaplus)
- [TLA+ Tools releases](https://github.com/tlaplus/tlaplus/releases)
- [MIT 6.5840 Spring 2026 Raft lab](https://pdos.csail.mit.edu/6.824/labs/lab-raft1.html)
- [University of Surrey COM3028 Systems Verification 2026/7](https://catalogue.surrey.ac.uk/2026-7/module/COM3028/SEMR2/2)

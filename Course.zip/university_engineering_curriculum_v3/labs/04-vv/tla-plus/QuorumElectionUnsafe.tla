---------------- MODULE QuorumElectionUnsafe ----------------
EXTENDS Naturals, FiniteSets

CONSTANTS Nodes, Terms, Quorum
ASSUME Quorum \in 1..Cardinality(Nodes)

VARIABLE votes
vars == <<votes>>

Init == votes = {}

(* Deliberate defect: no CanVote guard, so a voter may endorse two candidates. *)
GrantVote(term, voter, candidate) ==
    /\ term \in Terms
    /\ voter \in Nodes
    /\ candidate \in Nodes
    /\ votes' = votes \cup {<<term, voter, candidate>>}

Next ==
    \E term \in Terms :
        \E voter \in Nodes :
            \E candidate \in Nodes : GrantVote(term, voter, candidate)

Spec == Init /\ [][Next]_vars

VotersFor(term, candidate) ==
    {voter \in Nodes : <<term, voter, candidate>> \in votes}

LeadersAt(term) ==
    {candidate \in Nodes : Cardinality(VotersFor(term, candidate)) >= Quorum}

TypeOK ==
    votes \subseteq {<<term, voter, candidate>> :
        term \in Terms, voter \in Nodes, candidate \in Nodes}

OneVotePerTerm ==
    \A term \in Terms :
        \A voter \in Nodes :
            Cardinality({candidate \in Nodes :
                <<term, voter, candidate>> \in votes}) <= 1

ElectionSafety ==
    \A term \in Terms : Cardinality(LeadersAt(term)) <= 1

====

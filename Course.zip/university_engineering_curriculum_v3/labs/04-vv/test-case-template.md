# Test Case [ID]

- Requirement(s):
- Test level:
- Test type:
- Risk addressed:
- Preconditions:
- Configuration/build:
- Test data:
- Equipment/environment:
- Procedure:
  1.
  2.
  3.
- Expected result:
- Acceptance criterion:
- Actual result:
- Evidence:
- Anomalies:
- Verdict: PASS / FAIL / BLOCKED / NOT RUN
- Reviewer:

1. Populate the verification matrix for every capstone requirement.
2. Write 12 test cases covering boundaries, negative paths, faults and concurrency.
3. Capture requirement baseline, build, environment and test data.
4. Run tests and attach reproducible evidence.
5. Record anomalies rather than silently changing expected results.
6. Design two operational validation scenarios with representative users.


## Additional formal-methods lab

See [`quorum_model/README.md`](quorum_model/README.md) for the executable bounded quorum-election model and [`tla-plus/README.md`](tla-plus/README.md) for the TLA+ specification, deliberate unsafe mutant and TLC invocation. The Python model/tests have been executed. The TLA+ models are included but have **not** been run through TLC in this build because GitHub DNS was unavailable for downloading the official JAR.

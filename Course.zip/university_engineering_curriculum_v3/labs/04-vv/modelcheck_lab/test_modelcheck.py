from modelcheck import find_invariant_counterexample, reachable_states


def test_reachable_states_are_computed_without_revisiting_cycles():
    graph = {"idle": ["running"], "running": ["idle", "done"], "done": []}
    assert reachable_states("idle", graph) == {"idle", "running", "done"}


def test_invariant_checker_returns_shortest_counterexample_path():
    graph = {"safe": ["safe2", "failed"], "safe2": ["failed"], "failed": []}
    path = find_invariant_counterexample("safe", graph, lambda state: state != "failed")
    assert path == ["safe", "failed"]


def test_invariant_checker_returns_none_when_all_reachable_states_are_safe():
    graph = {"locked": ["open"], "open": ["locked"]}
    assert find_invariant_counterexample("locked", graph, lambda _: True) is None


def test_unlisted_destination_is_still_explored_as_terminal_state():
    assert reachable_states("start", {"start": ["terminal"]}) == {"start", "terminal"}

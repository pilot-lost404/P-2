# Lab 4 — Explicit-state model checking and invariant evidence

## Setup
Python 3.11+ and pytest. From this directory run `python -m pytest -q`.

The supplied `modelcheck.py` performs breadth-first exploration of a finite transition graph and returns a shortest counterexample path to an invariant violation. It is not a symbolic model checker and does not handle infinite-state systems, timed automata, probabilistic transitions or fairness without extensions.

## Tank-controller model
Model the states `IDLE`, `MEASURING`, `VALIDATING`, `FILLING`, `STOPPED`, `SENSOR_FAULT` and `TIMEOUT`. Define transitions for valid/stale/out-of-range sensor data, valve-open/close commands, command timeout and emergency stop.

Check at least these invariants:
- I1: the valve is never open while sensor data is stale or invalid;
- I2: the valve is not open when level is at or above the high-high threshold;
- I3: an emergency-stop state has no transition that opens the valve;
- I4: command acceptance does not imply physical actuation without a feedback observation.

Introduce one deliberate defect (for example, a transition that opens the valve from `SENSOR_FAULT`) and show the shortest counterexample. Then repair the transition relation and show that the finite explored graph satisfies the invariant. Keep the failing model and corrected model as separate artefacts.

## Further work
1. Add state variables for sensor age, measured level and target level. Discretize values and justify the abstraction.
2. Add a liveness property such as eventual transition to `STOPPED` under explicit fairness and availability assumptions. Explain why a simple invariant checker does not prove liveness.
3. Add transition coverage, state coverage and requirement-to-property traceability.
4. Compare bounded explicit-state exploration with test-case generation and property-based testing.

## Submission
State graph, transition table, invariants in precise language, failing counterexample trace, corrected result, test suite, state-space size, exploration assumptions and limitations. No finite model result proves the real system safe unless the abstraction and refinement relation are justified.

"""Breadth-first explicit-state invariant checking for finite teaching models."""
from __future__ import annotations

from collections import deque
from collections.abc import Callable, Hashable, Mapping, Sequence
from typing import TypeVar

State = TypeVar("State", bound=Hashable)


def reachable_states(initial: State, transitions: Mapping[State, Sequence[State]]) -> set[State]:
    """Return all states reachable from initial, including terminal states."""
    visited: set[State] = set()
    pending = deque([initial])
    while pending:
        state = pending.popleft()
        if state in visited:
            continue
        visited.add(state)
        pending.extend(transitions.get(state, ()))
    return visited


def find_invariant_counterexample(
    initial: State,
    transitions: Mapping[State, Sequence[State]],
    invariant: Callable[[State], bool],
) -> list[State] | None:
    """Return a shortest path to a violating reachable state, or None.

    Breadth-first search guarantees minimum transition count for a finite,
    unweighted transition graph. A returned path includes the initial state.
    """
    queue = deque([(initial, [initial])])
    visited: set[State] = set()
    while queue:
        state, path = queue.popleft()
        if state in visited:
            continue
        visited.add(state)
        if not invariant(state):
            return path
        for successor in transitions.get(state, ()):
            if successor not in visited:
                queue.append((successor, path + [successor]))
    return None

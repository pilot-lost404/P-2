from pathlib import Path

HERE = Path(__file__).resolve().parent.parent / "tla-plus"


def test_safe_tla_model_contains_vote_guard_and_required_safety_invariants():
    source = (HERE / "QuorumElection.tla").read_text()
    config = (HERE / "QuorumElection.cfg").read_text()
    assert "CanVote(term, voter)" in source
    assert "OneVotePerTerm ==" in source
    assert "ElectionSafety ==" in source
    assert "INVARIANTS" in config
    assert "ElectionSafety" in config


def test_unsafe_tla_mutant_removes_vote_guard_and_checks_same_invariant():
    source = (HERE / "QuorumElectionUnsafe.tla").read_text()
    config = (HERE / "QuorumElectionUnsafe.cfg").read_text()
    assert "Deliberate defect" in source
    assert "CanVote(" not in source
    assert "ElectionSafety" in config


def test_tla_configs_have_finite_three_node_quorum_models():
    for name in ("QuorumElection.cfg", "QuorumElectionUnsafe.cfg"):
        config = (HERE / name).read_text()
        assert "Nodes = {n1, n2, n3}" in config
        assert "Quorum = 2" in config
        assert "Terms = {1" in config

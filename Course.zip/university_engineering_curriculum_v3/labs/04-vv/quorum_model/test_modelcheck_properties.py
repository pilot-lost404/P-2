"""Deterministic property-style tests without an additional runtime dependency."""
from __future__ import annotations

import random

from modelcheck import find_invariant_counterexample, reachable_states


def reference_reachable(initial, transitions):
    seen = set()
    pending = [initial]
    while pending:
        state = pending.pop()
        if state in seen:
            continue
        seen.add(state)
        pending.extend(transitions.get(state, ()))
    return seen


def reference_distances(initial, transitions):
    distances = {initial: 0}
    pending = [initial]
    for state in pending:
        for successor in transitions.get(state, ()):
            if successor not in distances:
                distances[successor] = distances[state] + 1
                pending.append(successor)
    return distances


def test_reachability_matches_independent_reference_for_seeded_graphs():
    for seed in range(100):
        rng = random.Random(seed)
        count = rng.randint(1, 16)
        states = tuple(range(count))
        transitions = {
            state: tuple(other for other in states if rng.random() < 0.13)
            for state in states
        }
        assert reachable_states(0, transitions) == reference_reachable(0, transitions)


def test_counterexample_is_shortest_for_seeded_graphs():
    for seed in range(100, 200):
        rng = random.Random(seed)
        count = rng.randint(2, 18)
        states = tuple(range(count))
        transitions = {
            state: tuple(other for other in states if rng.random() < 0.11)
            for state in states
        }
        target = rng.choice(states)
        path = find_invariant_counterexample(0, transitions, lambda state: state != target)
        distances = reference_distances(0, transitions)
        if target not in distances:
            assert path is None
        elif target == 0:
            assert path == [0]
        else:
            assert path is not None
            assert path[0] == 0 and path[-1] == target
            assert len(path) - 1 == distances[target]


def test_true_invariant_never_returns_counterexample_for_seeded_graphs():
    for seed in range(200, 250):
        rng = random.Random(seed)
        count = rng.randint(1, 20)
        states = tuple(range(count))
        transitions = {
            state: tuple(other for other in states if rng.random() < 0.17)
            for state in states
        }
        assert find_invariant_counterexample(0, transitions, lambda _: True) is None


def test_false_initial_state_is_a_zero_step_counterexample():
    assert find_invariant_counterexample("broken", {}, lambda _: False) == ["broken"]

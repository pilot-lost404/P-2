# Quorum-election Python companion model

This module is an executable finite graph model of majority leader election. Its transition model and safety checks are described in the [TLA+ companion lab](../tla-plus/README.md).

Run from the repository root:

```bash
PYTHONPATH=labs/04-vv/modelcheck_lab pytest -q \
  labs/04-vv/quorum_model \
  labs/04-vv/modelcheck_lab
```

The safe model permits each voter one vote per term. The unsafe mutant permits multiple endorsements and must produce a shortest counterexample to election safety. The model is intentionally bounded: it omits log freshness, persistent state, crash recovery, leader completeness, reconfiguration and liveness.

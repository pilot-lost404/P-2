"""Finite quorum-election model used to test election safety and vote freshness.

This is an abstract teaching model, not a complete Raft implementation. It omits
log freshness, terms learned from messages, leader step-down, log replication,
crashes, persistence and liveness assumptions. The TLA+ files model the same
bounded vote-allocation safety property.
"""
from __future__ import annotations

from collections import deque
from dataclasses import dataclass
from typing import Callable

NODES = ("n1", "n2", "n3")
TERMS = (1,)
QUORUM = 2
Vote = tuple[int, str, str]  # (term, voter, candidate)


@dataclass(frozen=True, slots=True)
class ElectionState:
    votes: frozenset[Vote] = frozenset()


def initial_state() -> ElectionState:
    return ElectionState()


def leaders_by_term(state: ElectionState) -> dict[int, set[str]]:
    """Return candidates with at least QUORUM distinct votes in each term."""
    result: dict[int, set[str]] = {term: set() for term in TERMS}
    for term in TERMS:
        for candidate in NODES:
            voters = {
                voter
                for vote_term, voter, vote_candidate in state.votes
                if vote_term == term and vote_candidate == candidate
            }
            if len(voters) >= QUORUM:
                result[term].add(candidate)
    return result


def state_is_well_typed(state: ElectionState) -> bool:
    return all(
        term in TERMS and voter in NODES and candidate in NODES
        for term, voter, candidate in state.votes
    )


def one_vote_per_term(state: ElectionState) -> bool:
    for term in TERMS:
        for voter in NODES:
            candidates = {
                candidate
                for vote_term, vote_voter, candidate in state.votes
                if vote_term == term and vote_voter == voter
            }
            if len(candidates) > 1:
                return False
    return True


def election_safety(state: ElectionState) -> bool:
    return all(len(candidates) <= 1 for candidates in leaders_by_term(state).values())


def model_invariants() -> tuple[Callable[[ElectionState], bool], ...]:
    return state_is_well_typed, one_vote_per_term, election_safety


def _successors(state: ElectionState, *, unsafe: bool) -> tuple[ElectionState, ...]:
    successors: set[ElectionState] = set()
    for term in TERMS:
        for voter in NODES:
            already_voted = any(
                vote_term == term and vote_voter == voter
                for vote_term, vote_voter, _ in state.votes
            )
            if already_voted and not unsafe:
                continue
            for candidate in NODES:
                vote = (term, voter, candidate)
                if vote not in state.votes:
                    successors.add(ElectionState(state.votes | {vote}))
    return tuple(sorted(successors, key=lambda item: sorted(item.votes)))


def _build_graph(initial: ElectionState, *, unsafe: bool) -> dict[ElectionState, tuple[ElectionState, ...]]:
    graph: dict[ElectionState, tuple[ElectionState, ...]] = {}
    pending = deque([initial])
    while pending:
        state = pending.popleft()
        if state in graph:
            continue
        successors = _successors(state, unsafe=unsafe)
        graph[state] = successors
        pending.extend(successors)
    return graph


def election_transitions(initial: ElectionState) -> dict[ElectionState, tuple[ElectionState, ...]]:
    """Exhaustively generate the safe bounded state graph."""
    return _build_graph(initial, unsafe=False)


def unsafe_election_transitions(initial: ElectionState) -> dict[ElectionState, tuple[ElectionState, ...]]:
    """Mutation: a voter may vote for multiple candidates in the same term."""
    return _build_graph(initial, unsafe=True)

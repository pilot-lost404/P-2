from quorum_model import (
    election_transitions,
    initial_state,
    leaders_by_term,
    model_invariants,
    unsafe_election_transitions,
)
from modelcheck import find_invariant_counterexample, reachable_states


def test_safe_quorum_election_model_preserves_vote_and_leader_safety():
    initial = initial_state()
    graph = election_transitions(initial)
    states = reachable_states(initial, graph)
    assert len(states) > 1
    assert all(all(invariant(state) for invariant in model_invariants()) for state in states)


def test_majority_intersection_prevents_two_leaders_in_same_term():
    states = reachable_states(initial_state(), election_transitions(initial_state()))
    assert all(
        len(candidates) <= 1
        for state in states
        for candidates in leaders_by_term(state).values()
    )


def test_unsafe_multiple_vote_variant_has_a_counterexample():
    initial = initial_state()
    graph = unsafe_election_transitions(initial)
    invariant = model_invariants()[-1]
    path = find_invariant_counterexample(initial, graph, invariant)
    assert path is not None
    assert not invariant(path[-1])
    assert any(len(candidates) > 1 for candidates in leaders_by_term(path[-1]).values())


def test_every_transition_preserves_state_shape_and_monotonic_votes():
    for state in reachable_states(initial_state(), election_transitions(initial_state())):
        for next_state in election_transitions(state).get(state, ()):
            assert next_state.votes >= state.votes

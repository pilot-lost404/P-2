# Security engineering labs

1. Identify assets and trust boundaries in a data-flow diagram.
2. Populate the threat register with 12 concrete scenarios.
3. Create and implement an authorization matrix with resource ownership.
4. Test cross-facility access, expired credentials, command replay and privilege escalation.
5. Link high-priority threats to requirements, controls, tests and residual risk.
6. Build and test the loopback-only [secure-service project](secure_service/README.md).

The secure service includes an [ASVS/WSTG traceability matrix](secure_service/ASVS-WSTG-MATRIX.csv) and [guided exercises](secure_service/LAB-EXERCISES.md). It is a local teaching service, not a production platform. Only test intentionally vulnerable labs or systems with explicit authorization.

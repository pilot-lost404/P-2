# Secure Service — end-to-end application security lab

A deliberately small **loopback-only** JSON API that makes security controls observable and testable. It uses only the Python standard library. The lab covers password hashing, opaque server-side sessions, expiry/logout, CSRF, object-level authorization, tenant isolation, request validation, per-source rate limiting, security headers, optimistic versioning and a tamper-evident HMAC audit chain.

This is a training service, not a production identity platform. Users and sessions are in memory; the server is plain HTTP for local use; no TLS termination, MFA, password reset, federation, distributed session store, key rotation, durable database, WAF or high-availability design is included. Do not expose it to a LAN or public interface. Do not use real credentials or personal data.

## Prerequisites

- Python 3.11+ (tested with Python 3.13.5 in the course build)
- `pytest` for the tests

No third-party runtime package is required. From the repository root:

```bash
pytest -q labs/05-security/secure_service
```

## Start locally

Set three distinct strong demo passwords and a stable 32-byte audit HMAC key. Keep the key in a secret manager or protected local environment; do not commit it or regenerate it on every restart when reusing the same audit log.

```bash
export ALICE_PASSWORD='replace-with-a-unique-strong-demo-password'
export SUPERVISOR_PASSWORD='replace-with-another-unique-password'
export BOB_PASSWORD='replace-with-a-third-unique-password'
export AUDIT_HMAC_KEY_HEX="$(python -c 'import secrets; print(secrets.token_hex(32))')"
export AUDIT_PATH='./secure-service-audit.jsonl'
python labs/05-security/secure_service/run.py --host 127.0.0.1 --port 8765
```

The server rejects non-loopback host addresses, requires passwords to be at least 14 characters, and accepts an audit key as exactly 64 hexadecimal characters. This WSGI development server is not TLS-enabled. The local cookie intentionally omits the `Secure` flag because it runs over loopback HTTP; a deployment behind a trusted HTTPS termination layer must set `COOKIE_SECURE=1`, enforce HTTPS and protect the audit key. Do not mistake this exercise for production deployment guidance.

## Example interaction

Login (the password is supplied by an environment variable in your shell, not embedded in source):

```bash
curl -i -c cookies.txt -H 'Content-Type: application/json' \
  -d '{"username":"alice","password":"REPLACE_ME"}' \
  http://127.0.0.1:8765/api/login
```

The JSON response contains a CSRF token. Keep it private and send it in a custom header for write methods:

```bash
curl -i -b cookies.txt -H 'Content-Type: application/json' \
  -H 'X-CSRF-Token: REPLACE_WITH_SESSION_TOKEN' \
  -d '{"title":"Local test","body":"synthetic data only"}' \
  http://127.0.0.1:8765/api/records
```

List and read records:

```bash
curl -i -b cookies.txt http://127.0.0.1:8765/api/records
curl -i -b cookies.txt http://127.0.0.1:8765/api/records/RECORD_ID
```

## Verification scope

`test_app.py` currently exercises login failure/success, session fixation resistance, expiry, logout, CSRF, object-level authorization, cross-tenant IDOR, supervisor tenant boundary, record update version conflict, duplicate/unknown JSON keys, size limits, per-IP rate limiting, security headers, audit tampering and loopback startup guard.

`ASVS-WSTG-MATRIX.csv` maps the course controls to OWASP ASVS 5.0 and WSTG testing areas. It is a teaching traceability matrix, not a statement of formal ASVS compliance. All scanner tools remain an optional external task: this build environment did not have Ruff, Bandit, Semgrep or pip-audit installed. `LAB-EXERCISES.md` provides the safe hands-on sequence.

## Design cautions

- `scrypt` parameters are explicit and should be benchmarked/tuned for the deployment platform; a production system should use a maintained identity framework and established password-policy controls.
- The session store is process-local and lost on restart. Multi-worker deployment would need a shared store and atomic lifecycle controls.
- Source-IP throttling is illustrative; trusted proxy handling, distributed rate limiting and account-level controls need a separate design.
- The custom audit chain is HMAC-protected, the file is created with POSIX mode `0600` where supported, and each append is flushed/fsynced. The chain is rechecked before appending; `run.py` refuses to start when a pre-existing chain fails verification. The key and file are still on the same host in this local lab. It is tamper-evident, not immutable or non-repudiable. Rechecking the entire log is O(n) per append and is suitable only for this small exercise; production systems need efficient checkpoints, protected key custody and external log shipping/immutable storage.
- Authorization is tenant-bound and object-level for this record resource only. Every new resource type requires its own policy and negative tests.
- The CSRF token is returned in an authenticated JSON response, stored server-side and required in a custom header. The service intentionally has no permissive CORS policy.

## Primary references

- [OWASP ASVS 5.0.0](https://asvs.owasp.org/)
- [OWASP Web Security Testing Guide](https://owasp.org/www-project-web-security-testing-guide/latest/)
- [OWASP API Security Project](https://owasp.org/www-project-api-security/)
- [OWASP Juice Shop](https://owasp.org/projects/juice-shop) for a separate intentionally vulnerable training target running locally
- [NIST SP 800-160 Vol. 1 Rev. 1 — Engineering Trustworthy Secure Systems](https://csrc.nist.gov/pubs/sp/800/160/v1/r1/final)
- [Python `hashlib.scrypt`](https://docs.python.org/3/library/hashlib.html#hashlib.scrypt)
- [Python `hmac.compare_digest`](https://docs.python.org/3/library/hmac.html#hmac.compare_digest)
- [Python `secrets`](https://docs.python.org/3/library/secrets.html)

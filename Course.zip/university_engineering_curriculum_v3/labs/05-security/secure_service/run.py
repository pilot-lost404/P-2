#!/usr/bin/env python3
"""Start the security teaching service on a loopback interface only."""
from __future__ import annotations

import argparse
import os
import socket
import sys
from wsgiref.simple_server import WSGIServer, WSGIRequestHandler, make_server

from app import AuditLog, SecureService, create_user, validate_loopback_host


class IPv6WSGIServer(WSGIServer):
    address_family = socket.AF_INET6


def required_password(name: str) -> str:
    value = os.environ.get(name, "")
    if len(value) < 14 or len(value.encode("utf-8")) > 1024:
        raise ValueError(f"{name} must be 14-1024 characters; set it in the environment")
    return value


def main() -> int:
    parser = argparse.ArgumentParser(description="Run the loopback-only security course API")
    parser.add_argument("--host", default=os.environ.get("HOST", "127.0.0.1"))
    parser.add_argument("--port", type=int, default=int(os.environ.get("PORT", "8765")))
    args = parser.parse_args()

    try:
        host = validate_loopback_host(args.host)
        if not 1024 <= args.port <= 65535:
            raise ValueError("port must be between 1024 and 65535")
        key_hex = os.environ.get("AUDIT_HMAC_KEY_HEX", "")
        if len(key_hex) != 64:
            raise ValueError("AUDIT_HMAC_KEY_HEX must contain 64 hex characters (32 bytes)")
        audit_key = bytes.fromhex(key_hex)
        users = {
            "alice": create_user("alice", "tenant-a", "OPERATOR", required_password("ALICE_PASSWORD")),
            "supervisor": create_user("supervisor", "tenant-a", "SUPERVISOR", required_password("SUPERVISOR_PASSWORD")),
            "bob": create_user("bob", "tenant-b", "OPERATOR", required_password("BOB_PASSWORD")),
        }
        audit_path = os.environ.get("AUDIT_PATH", "./secure-service-audit.jsonl")
        audit = AuditLog(audit_path, key=audit_key)
        audit_valid, audit_problem = audit.verify()
        if not audit_valid:
            raise ValueError(f"audit log integrity verification failed at line {audit_problem}; refusing startup")
        # This educational server is plain HTTP on loopback. Set COOKIE_SECURE=1
        # only when placing it behind a trusted HTTPS termination layer.
        cookie_secure = os.environ.get("COOKIE_SECURE", "0") == "1"
        service = SecureService(users, audit=audit, cookie_secure=cookie_secure)
        server_class = IPv6WSGIServer if ":" in host else WSGIServer
    except (ValueError, OSError) as exc:
        parser.error(str(exc))

    class QuietHandler(WSGIRequestHandler):
        def log_message(self, format: str, *args: object) -> None:
            # Do not log request bodies, cookies, passwords or query values.
            sys.stderr.write("%s - %s\n" % (self.address_string(), format % args))

    with make_server(host, args.port, service, server_class=server_class, handler_class=QuietHandler) as server:
        print(f"Security course API listening on http://{host}:{args.port} (loopback only)")
        print(f"Audit chain: {audit_path}")
        try:
            server.serve_forever()
        except KeyboardInterrupt:
            print("Stopping security course API")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

# Security lab exercises — controlled local service only

Run only against the local course service at `127.0.0.1`. Do not substitute a public target or a third-party system. These exercises demonstrate verification of defensive controls, not instructions to attack an external service.

## Exercise 1 — Authentication and session lifecycle

1. Start the service and log in as `alice`.
2. Record the `Set-Cookie` flags; identify `HttpOnly`, `SameSite`, `Path`, optional `Secure`, and absence of `Domain`.
3. Present a made-up `sid` before login, authenticate, and show the server issues a new unrelated token.
4. Advance the test clock to expire a session, then verify the old token returns `401`.
5. Log out and verify the server-side session is no longer accepted.

Evidence: request/response transcript with all tokens and passwords redacted, expiry test and session-lifecycle explanation.

## Exercise 2 — CSRF control

1. Authenticate and obtain the CSRF token from `/api/session`.
2. Attempt a `POST /api/records` without `X-CSRF-Token` (expect `403`).
3. Repeat with an incorrect token (expect `403`).
4. Repeat with the session-bound token (expect `201`).
5. Explain why the token is not placed in the cookie or URL and how `SameSite=Strict` and the absence of permissive CORS complement the custom header.

## Exercise 3 — Object-level authorization and tenant isolation

1. Create a record as `alice` in `tenant-a`.
2. Read it as `alice` (expect `200`).
3. Read it as `bob` in `tenant-b` by changing only the object ID (expect `404`).
4. Read it as the `tenant-a` supervisor (expect `200`).
5. Create a `tenant-b` record as `bob` and try to read it as the `tenant-a` supervisor (expect `404`).
6. Explain why hiding the resource with `404` reduces direct existence disclosure but does not eliminate timing or side-channel leakage.

## Exercise 4 — Input and state validation

Try unknown fields (including `tenantId`), duplicate JSON keys, malformed JSON, a body larger than 1 MiB, overlong title/body and stale update versions. Record which layer rejects each request and whether the error response reveals internal details.

## Exercise 5 — Rate limiting

Use the test suite to show that failures from one source IP accumulate even when the username changes. Discuss the denial-of-service trade-off of source-IP limits (shared NAT, proxies, and IPv6 privacy addresses) and propose a production multi-dimensional policy with trusted proxy configuration.

## Exercise 6 — Audit integrity

1. Verify the HMAC chain with the configured key.
2. In a disposable copy of the JSONL file, modify one event field or change the key.
3. Show verification fails and that the service refuses to append to a corrupted chain.
4. Explain why a hash/HMAC chain detects tampering only while its key and checkpoints remain protected; it does not make a local file non-repudiable or immutable against a host administrator.

## Exercise 7 — Security response headers

Inspect `GET /api/session` with `curl -i`. Explain CSP, `X-Content-Type-Options`, `X-Frame-Options`, `Referrer-Policy`, cache controls, HSTS conditions, and why this JSON API emits no `Access-Control-Allow-Origin` header.

## Exercise 8 — Independent verification

Map each `SEC-*` objective in `ASVS-WSTG-MATRIX.csv` to an observed test, exact expected result and artifact. Add at least five negative tests not already present. Mark controls with no supporting result as **not verified**, even when the code appears to implement them.

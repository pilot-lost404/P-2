"""A small, loopback-only WSGI security lab service (Python standard library only).

Not a production identity provider: sessions and demo users are in memory,
there is no TLS server, account recovery, MFA, key rotation service or HA.
The demo is intentionally scoped to defensive HTTP/API security controls.
"""
from __future__ import annotations

import hashlib
import hmac
import ipaddress
import json
import os
import re
import secrets
import threading
from dataclasses import dataclass
from datetime import datetime, timezone
from http.cookies import SimpleCookie
from pathlib import Path
from typing import Any, Callable, Iterable

PASSWORD_SCRYPT_N = 1 << 14
PASSWORD_SCRYPT_R = 8
PASSWORD_SCRYPT_P = 1
PASSWORD_DKLEN = 32
PASSWORD_MAX_BYTES = 1024
MAX_BODY_BYTES = 1_048_576
USERNAME_RE = re.compile(r"^[a-zA-Z0-9_-]{1,32}$")
RECORD_ID_RE = re.compile(r"^[A-Za-z0-9_-]{1,40}$")
VALID_ROLES = {"OPERATOR", "SUPERVISOR"}


@dataclass(frozen=True, slots=True)
class User:
    user_id: str
    tenant_id: str
    role: str
    salt: bytes
    password_hash: bytes


@dataclass(slots=True)
class Session:
    user_id: str
    csrf_token: str
    expires_at: float


def _derive_password(password: str, salt: bytes) -> bytes:
    if not isinstance(password, str):
        raise TypeError("password must be text")
    encoded = password.encode("utf-8")
    if not encoded or len(encoded) > PASSWORD_MAX_BYTES:
        raise ValueError("password length is invalid")
    return hashlib.scrypt(
        encoded,
        salt=salt,
        n=PASSWORD_SCRYPT_N,
        r=PASSWORD_SCRYPT_R,
        p=PASSWORD_SCRYPT_P,
        maxmem=64 * 1024 * 1024,
        dklen=PASSWORD_DKLEN,
    )


def create_user(user_id: str, tenant_id: str, role: str, password: str, *, salt: bytes | None = None) -> User:
    """Create a demo user with a unique 16-byte-or-longer salt and scrypt hash."""
    if not USERNAME_RE.fullmatch(user_id):
        raise ValueError("user_id must be 1-32 simple identifier characters")
    if not isinstance(tenant_id, str) or not tenant_id or len(tenant_id) > 64:
        raise ValueError("tenant_id is invalid")
    if role not in VALID_ROLES:
        raise ValueError(f"role must be one of {sorted(VALID_ROLES)}")
    salt = secrets.token_bytes(16) if salt is None else salt
    if not isinstance(salt, bytes) or len(salt) < 16:
        raise ValueError("password salt must contain at least 16 bytes")
    return User(user_id, tenant_id, role, salt, _derive_password(password, salt))


def verify_password(user: User, candidate: str) -> bool:
    """Verify a candidate using a constant-time digest comparison."""
    try:
        actual = _derive_password(candidate, user.salt)
    except (TypeError, ValueError, UnicodeError):
        # Keep the caller's response generic; a malformed password is not an account oracle.
        return False
    return hmac.compare_digest(actual, user.password_hash)


def validate_loopback_host(host: str) -> str:
    """Accept only a literal loopback IP address; never bind this lab publicly."""
    try:
        address = ipaddress.ip_address(host)
    except ValueError as exc:
        raise ValueError("host must be a literal loopback IP address") from exc
    if not address.is_loopback:
        raise ValueError("host must be a loopback address")
    return str(address)


class AuditLog:
    """Append-only JSONL audit chain with HMAC integrity and fsync per entry."""

    def __init__(self, path: str | Path, *, key: bytes, clock: Callable[[], float] | None = None):
        if not isinstance(key, bytes) or len(key) < 32:
            raise ValueError("audit HMAC key must be at least 32 bytes")
        self.path = Path(path)
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self.path.touch(mode=0o600, exist_ok=True)
        try:
            os.chmod(self.path, 0o600)
        except OSError:
            # Some filesystems/platforms do not expose POSIX mode semantics.
            pass
        self.key = key
        self.clock = clock or __import__("time").time
        self._lock = threading.Lock()
        self._integrity_ok, self._integrity_problem = self.verify()
        if self._integrity_ok:
            entries = self._read_entries()
            self._sequence = len(entries)
            self._last_hash = entries[-1]["hash"] if entries else "0" * 64
        else:
            # Preserve the ability to inspect the bad chain, but never extend it.
            self._sequence = 0
            self._last_hash = "0" * 64

    def _read_entries(self) -> list[dict[str, Any]]:
        if not self.path.exists():
            return []
        entries: list[dict[str, Any]] = []
        with self.path.open("r", encoding="utf-8") as stream:
            for line in stream:
                if line.strip():
                    item = json.loads(line)
                    if not isinstance(item, dict):
                        raise ValueError("audit entry must be an object")
                    entries.append(item)
        return entries

    def _mac(self, unsigned_entry: dict[str, Any]) -> str:
        canonical = json.dumps(
            unsigned_entry,
            sort_keys=True,
            separators=(",", ":"),
            ensure_ascii=False,
            allow_nan=False,
        ).encode("utf-8")
        return hmac.new(self.key, canonical, hashlib.sha256).hexdigest()

    def append(self, *, actor: str, action: str, resource: str, outcome: str) -> dict[str, Any]:
        safe_fields = (actor, action, resource, outcome)
        if any(not isinstance(value, str) or len(value) > 128 for value in safe_fields):
            raise ValueError("audit fields must be bounded strings")
        with self._lock:
            if self._integrity_ok:
                still_valid, problem = self.verify()
                if not still_valid:
                    self._integrity_ok = False
                    self._integrity_problem = problem
            if not self._integrity_ok:
                raise ValueError(f"audit log integrity failure at line {self._integrity_problem}; append refused")
            unsigned = {
                "sequence": self._sequence + 1,
                "timestamp": datetime.fromtimestamp(self.clock(), timezone.utc).isoformat(),
                "actor": actor,
                "action": action,
                "resource": resource,
                "outcome": outcome,
                "previous_hash": self._last_hash,
            }
            entry = dict(unsigned)
            entry["hash"] = self._mac(unsigned)
            line = json.dumps(entry, sort_keys=True, separators=(",", ":"), ensure_ascii=False, allow_nan=False)
            with self.path.open("a", encoding="utf-8", newline="\n") as stream:
                stream.write(line + "\n")
                stream.flush()
                os.fsync(stream.fileno())
            self._sequence += 1
            self._last_hash = entry["hash"]
            return entry

    def verify(self) -> tuple[bool, int | None]:
        """Return (valid, failing_line); a missing/empty log is a valid empty chain."""
        if not self.path.exists():
            return True, None
        previous = "0" * 64
        expected_sequence = 1
        try:
            with self.path.open("r", encoding="utf-8") as stream:
                for line_number, line in enumerate(stream, start=1):
                    if not line.strip():
                        return False, line_number
                    entry = json.loads(line)
                    if not isinstance(entry, dict) or "hash" not in entry:
                        return False, line_number
                    supplied_hash = entry.pop("hash")
                    if entry.get("sequence") != expected_sequence or entry.get("previous_hash") != previous:
                        return False, line_number
                    calculated = self._mac(entry)
                    if not isinstance(supplied_hash, str) or not hmac.compare_digest(calculated, supplied_hash):
                        return False, line_number
                    previous = supplied_hash
                    expected_sequence += 1
        except (OSError, UnicodeError, json.JSONDecodeError, TypeError, ValueError):
            return False, expected_sequence
        return True, None


class _BadRequest(Exception):
    def __init__(self, status: int, code: str):
        self.status = status
        self.code = code


class SecureService:
    """WSGI JSON API demonstrating authentication and tenant/object controls."""

    def __init__(
        self,
        users: dict[str, User],
        *,
        audit: AuditLog,
        clock: Callable[[], float] | None = None,
        session_ttl: int = 600,
        login_limit: int = 5,
        login_window: int = 60,
        cookie_secure: bool = True,
    ):
        if session_ttl < 30 or session_ttl > 86_400:
            raise ValueError("session_ttl must be between 30 seconds and one day")
        if login_limit < 1 or login_window < 1:
            raise ValueError("login rate limits must be positive")
        if not users or any(key != user.user_id for key, user in users.items()):
            raise ValueError("users must be a non-empty user_id-to-User mapping")
        self.users = dict(users)
        self.audit = audit
        self.clock = clock or __import__("time").time
        self.session_ttl = session_ttl
        self.login_limit = login_limit
        self.login_window = login_window
        self.cookie_secure = cookie_secure
        self.sessions: dict[str, Session] = {}
        self.records: dict[str, dict[str, Any]] = {}
        self._failures: dict[tuple[str, str], list[float]] = {}
        self._lock = threading.RLock()
        # Unknown usernames still incur the password-derivation cost.
        self._dummy_user = create_user("dummy-user", "dummy-tenant", "OPERATOR", secrets.token_urlsafe(24))

    def _read_json(self, environ: dict[str, Any]) -> dict[str, Any]:
        raw_length = environ.get("CONTENT_LENGTH", "0") or "0"
        try:
            length = int(raw_length)
        except (TypeError, ValueError) as exc:
            raise _BadRequest(400, "invalid_content_length") from exc
        if length < 0:
            raise _BadRequest(400, "invalid_content_length")
        if length > MAX_BODY_BYTES:
            raise _BadRequest(413, "request_too_large")
        if length == 0:
            return {}
        content_type = environ.get("CONTENT_TYPE", "").split(";", 1)[0].strip().lower()
        if content_type != "application/json":
            raise _BadRequest(415, "application_json_required")
        stream = environ.get("wsgi.input")
        raw = stream.read(length) if stream is not None else b""
        if len(raw) != length:
            raise _BadRequest(400, "incomplete_request_body")

        def unique_object(pairs: list[tuple[str, Any]]) -> dict[str, Any]:
            output: dict[str, Any] = {}
            for key, value in pairs:
                if key in output:
                    raise ValueError("duplicate_json_key")
                output[key] = value
            return output

        try:
            data = json.loads(raw, object_pairs_hook=unique_object, parse_constant=lambda _: (_ for _ in ()).throw(ValueError("non_finite_number")))
        except (json.JSONDecodeError, UnicodeDecodeError, ValueError) as exc:
            raise _BadRequest(400, "invalid_json") from exc
        if not isinstance(data, dict):
            raise _BadRequest(400, "json_object_required")
        return data

    def _cookies(self, environ: dict[str, Any]) -> SimpleCookie:
        cookie = SimpleCookie()
        try:
            cookie.load(environ.get("HTTP_COOKIE", ""))
        except Exception:
            return SimpleCookie()
        return cookie

    def _session(self, environ: dict[str, Any]) -> tuple[str | None, Session | None, User | None]:
        cookie = self._cookies(environ)
        sid = cookie["sid"].value if "sid" in cookie else None
        if not sid:
            return None, None, None
        with self._lock:
            session = self.sessions.get(sid)
            if session is None:
                return sid, None, None
            if session.expires_at <= self.clock():
                self.sessions.pop(sid, None)
                return sid, None, None
            user = self.users.get(session.user_id)
            if user is None:
                self.sessions.pop(sid, None)
                return sid, None, None
            return sid, session, user

    def _csrf_valid(self, environ: dict[str, Any], session: Session) -> bool:
        supplied = environ.get("HTTP_X_CSRF_TOKEN", "")
        return isinstance(supplied, str) and bool(supplied) and hmac.compare_digest(supplied, session.csrf_token)

    def _cookie(self, sid: str, max_age: int) -> str:
        parts = [f"sid={sid}", "Path=/", "HttpOnly", "SameSite=Strict", f"Max-Age={max_age}"]
        if self.cookie_secure:
            parts.append("Secure")
        return "; ".join(parts)

    def _rate_limit_key(self, remote: str, username: str) -> tuple[str, str]:
        # A per-source limit must not be bypassable by cycling usernames.
        # Keep the second tuple slot for an easy future account-level bucket.
        return remote[:64], "*"

    def _rate_limited(self, key: tuple[str, str]) -> bool:
        now = self.clock()
        attempts = [when for when in self._failures.get(key, []) if now - when < self.login_window]
        self._failures[key] = attempts
        return len(attempts) >= self.login_limit

    def _login(self, environ: dict[str, Any], data: dict[str, Any]) -> tuple[int, dict[str, Any], dict[str, str]]:
        if set(data) != {"username", "password"}:
            raise _BadRequest(400, "invalid_login_payload")
        username = data.get("username")
        password = data.get("password")
        if not isinstance(username, str) or not USERNAME_RE.fullmatch(username) or not isinstance(password, str) or len(password.encode("utf-8", errors="ignore")) > PASSWORD_MAX_BYTES:
            raise _BadRequest(400, "invalid_login_payload")
        user = self.users.get(username)
        verifier = user if user is not None else self._dummy_user
        remote = str(environ.get("REMOTE_ADDR", "unknown"))
        key = self._rate_limit_key(remote, username)
        if self._rate_limited(key):
            self.audit.append(actor="anonymous", action="login", resource="auth", outcome="rate_limited")
            return 429, {"error": "rate_limited"}, {"Retry-After": str(self.login_window)}
        valid = verify_password(verifier, password) and user is not None
        if not valid:
            attempts = self._failures.setdefault(key, [])
            attempts.append(self.clock())
            self.audit.append(actor="anonymous", action="login", resource="auth", outcome="failure")
            return 401, {"error": "invalid_credentials"}, {}
        self._failures.pop(key, None)
        sid = secrets.token_urlsafe(32)
        csrf_token = secrets.token_urlsafe(32)
        session = Session(user_id=user.user_id, csrf_token=csrf_token, expires_at=self.clock() + self.session_ttl)
        with self._lock:
            self.sessions[sid] = session
        self.audit.append(actor=user.user_id, action="login", resource="auth", outcome="success")
        return 200, {"userId": user.user_id, "tenantId": user.tenant_id, "role": user.role, "csrfToken": csrf_token}, {"Set-Cookie": self._cookie(sid, self.session_ttl)}

    def _public_record(self, record: dict[str, Any]) -> dict[str, Any]:
        return {
            "id": record["id"],
            "tenantId": record["tenant_id"],
            "ownerId": record["owner_id"],
            "title": record["title"],
            "body": record["body"],
            "version": record["version"],
        }

    def _can_read_or_write(self, user: User, record: dict[str, Any]) -> bool:
        if record["tenant_id"] != user.tenant_id:
            return False
        return record["owner_id"] == user.user_id or user.role == "SUPERVISOR"

    @staticmethod
    def _validate_record_fields(data: dict[str, Any], *, partial: bool = False) -> dict[str, str]:
        allowed = {"title", "body", "expectedVersion"} if partial else {"title", "body"}
        if not data or set(data) - allowed:
            raise _BadRequest(400, "invalid_record_fields")
        result: dict[str, str] = {}
        for field, maximum in (("title", 120), ("body", 5_000)):
            if field not in data:
                continue
            value = data[field]
            if not isinstance(value, str) or not value.strip() or len(value) > maximum:
                raise _BadRequest(400, "invalid_record_fields")
            result[field] = value
        if not result:
            raise _BadRequest(400, "empty_record_update")
        return result

    def _handle(self, environ: dict[str, Any]) -> tuple[int, dict[str, Any], dict[str, str]]:
        method = str(environ.get("REQUEST_METHOD", "GET")).upper()
        path = str(environ.get("PATH_INFO", "/"))
        if method == "POST" and path == "/api/login":
            return self._login(environ, self._read_json(environ))

        sid, session, user = self._session(environ)
        if method == "GET" and path == "/api/session":
            if session is None or user is None:
                return 401, {"error": "authentication_required"}, {}
            return 200, {"userId": user.user_id, "tenantId": user.tenant_id, "role": user.role, "csrfToken": session.csrf_token}, {}
        if method == "POST" and path == "/api/logout":
            if session is None or user is None or sid is None:
                return 401, {"error": "authentication_required"}, {}
            if not self._csrf_valid(environ, session):
                return 403, {"error": "csrf_failed"}, {}
            with self._lock:
                self.sessions.pop(sid, None)
            self.audit.append(actor=user.user_id, action="logout", resource="auth", outcome="success")
            return 200, {"status": "logged_out"}, {"Set-Cookie": self._cookie("", 0)}

        if path == "/api/records" and method in {"GET", "POST"}:
            if session is None or user is None:
                return 401, {"error": "authentication_required"}, {}
            if method == "GET":
                with self._lock:
                    visible = [self._public_record(item) for item in self.records.values() if self._can_read_or_write(user, item)]
                visible.sort(key=lambda item: item["id"])
                return 200, {"records": visible}, {}
            if not self._csrf_valid(environ, session):
                return 403, {"error": "csrf_failed"}, {}
            data = self._read_json(environ)
            fields = self._validate_record_fields(data)
            record_id = secrets.token_urlsafe(12)
            record = {
                "id": record_id,
                "tenant_id": user.tenant_id,
                "owner_id": user.user_id,
                "title": fields["title"],
                "body": fields["body"],
                "version": 1,
            }
            with self._lock:
                self.records[record_id] = record
            self.audit.append(actor=user.user_id, action="record_create", resource=record_id, outcome="success")
            return 201, self._public_record(record), {}

        match = re.fullmatch(r"/api/records/([A-Za-z0-9_-]{1,40})", path)
        if match and method in {"GET", "PATCH"}:
            if session is None or user is None:
                return 401, {"error": "authentication_required"}, {}
            record_id = match.group(1)
            with self._lock:
                record = self.records.get(record_id)
                authorized = record is not None and self._can_read_or_write(user, record)
                if not authorized:
                    record = None
            if record is None:
                self.audit.append(actor=user.user_id, action="record_read" if method == "GET" else "record_update", resource=record_id, outcome="denied")
                return 404, {"error": "not_found"}, {}
            if method == "GET":
                return 200, self._public_record(record), {}
            if not self._csrf_valid(environ, session):
                return 403, {"error": "csrf_failed"}, {}
            data = self._read_json(environ)
            if "expectedVersion" not in data or isinstance(data["expectedVersion"], bool) or not isinstance(data["expectedVersion"], int) or data["expectedVersion"] < 1:
                raise _BadRequest(400, "expected_version_required")
            fields = self._validate_record_fields(data, partial=True)
            with self._lock:
                current = self.records.get(record_id)
                if current is None or not self._can_read_or_write(user, current):
                    return 404, {"error": "not_found"}, {}
                if data["expectedVersion"] != current["version"]:
                    return 409, {"error": "version_conflict", "currentVersion": current["version"]}, {}
                current.update(fields)
                current["version"] += 1
                updated = dict(current)
            self.audit.append(actor=user.user_id, action="record_update", resource=record_id, outcome="success")
            return 200, self._public_record(updated), {}

        return 404, {"error": "not_found"}, {}

    def _response(self, start_response: Callable[..., Any], status: int, payload: dict[str, Any], extra_headers: dict[str, str] | None = None) -> list[bytes]:
        body = json.dumps(payload, ensure_ascii=False, separators=(",", ":"), allow_nan=False).encode("utf-8")
        headers = [
            ("Content-Type", "application/json; charset=utf-8"),
            ("Content-Length", str(len(body))),
            ("Cache-Control", "no-store"),
            ("Pragma", "no-cache"),
            ("X-Content-Type-Options", "nosniff"),
            ("X-Frame-Options", "DENY"),
            ("Referrer-Policy", "no-referrer"),
            ("Permissions-Policy", "camera=(), microphone=(), geolocation=()"),
            ("Content-Security-Policy", "default-src 'none'; base-uri 'none'; frame-ancestors 'none'; form-action 'none'"),
        ]
        if self.cookie_secure:
            headers.append(("Strict-Transport-Security", "max-age=31536000"))
        for key, value in (extra_headers or {}).items():
            headers.append((key, value))
        reason = {
            200: "OK", 201: "Created", 400: "Bad Request", 401: "Unauthorized", 403: "Forbidden",
            404: "Not Found", 409: "Conflict", 413: "Payload Too Large", 415: "Unsupported Media Type",
            429: "Too Many Requests", 500: "Internal Server Error",
        }.get(status, "Error")
        start_response(f"{status} {reason}", headers)
        return [body]

    def __call__(self, environ: dict[str, Any], start_response: Callable[..., Any]) -> Iterable[bytes]:
        try:
            status, payload, headers = self._handle(environ)
        except _BadRequest as exc:
            status, payload, headers = exc.status, {"error": exc.code}, {}
        except Exception:
            # Do not return exception detail, paths or stack traces to the caller.
            status, payload, headers = 500, {"error": "internal_error"}, {}
        return self._response(start_response, status, payload, headers)

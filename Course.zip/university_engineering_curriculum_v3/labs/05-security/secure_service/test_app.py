from __future__ import annotations

import io
import json
import re
from pathlib import Path

import pytest

from app import AuditLog, SecureService, create_user, validate_loopback_host


class FakeClock:
    def __init__(self, value: float = 1_800_000_000.0):
        self.value = value

    def __call__(self) -> float:
        return self.value

    def advance(self, seconds: float) -> None:
        self.value += seconds


def build_service(tmp_path: Path, *, clock=None, ttl=600, rate_limit=5, cookie_secure=True):
    clock = clock or FakeClock()
    users = {
        "alice": create_user("alice", "tenant-a", "OPERATOR", "CorrectHorse-123!"),
        "supervisor": create_user("supervisor", "tenant-a", "SUPERVISOR", "Supervisor-987!"),
        "bob": create_user("bob", "tenant-b", "OPERATOR", "OtherTenant-456!"),
    }
    audit = AuditLog(tmp_path / "audit.jsonl", key=b"test-audit-hmac-key-that-is-32-bytes-long")
    return SecureService(users, audit=audit, clock=clock, session_ttl=ttl, login_limit=rate_limit, cookie_secure=cookie_secure), clock


def request(app, method, path, *, body=None, cookie=None, headers=None, remote="127.0.0.1"):
    raw = b"" if body is None else (body if isinstance(body, bytes) else json.dumps(body).encode())
    environ = {
        "REQUEST_METHOD": method,
        "PATH_INFO": path,
        "QUERY_STRING": "",
        "CONTENT_LENGTH": str(len(raw)),
        "CONTENT_TYPE": "application/json",
        "REMOTE_ADDR": remote,
        "wsgi.input": io.BytesIO(raw),
        "wsgi.url_scheme": "https",
        "SERVER_NAME": "127.0.0.1",
        "SERVER_PORT": "443",
        "SERVER_PROTOCOL": "HTTP/1.1",
    }
    if cookie:
        environ["HTTP_COOKIE"] = cookie
    for name, value in (headers or {}).items():
        key = name.upper().replace("-", "_")
        if key not in {"CONTENT_TYPE", "CONTENT_LENGTH"}:
            key = "HTTP_" + key
        environ[key] = value
    result = {}

    def start_response(status, response_headers, exc_info=None):
        result["status"] = int(status.split()[0])
        result["headers"] = dict(response_headers)

    response = b"".join(app(environ, start_response))
    result["body"] = json.loads(response) if response else None
    result["raw"] = response
    return result


def login(app, username="alice", password="CorrectHorse-123!"):
    response = request(app, "POST", "/api/login", body={"username": username, "password": password})
    assert response["status"] == 200
    cookie = response["headers"]["Set-Cookie"].split(";", 1)[0]
    session = request(app, "GET", "/api/session", cookie=cookie)
    return cookie, session["body"]["csrfToken"]


def test_login_rotates_session_and_sets_secure_http_only_cookie(tmp_path):
    app, _ = build_service(tmp_path)
    response = request(app, "POST", "/api/login", body={"username": "alice", "password": "CorrectHorse-123!"}, cookie="sid=attacker-fixed-value")
    assert response["status"] == 200
    set_cookie = response["headers"]["Set-Cookie"]
    assert re.search(r"sid=[A-Za-z0-9_-]{30,}", set_cookie)
    assert "HttpOnly" in set_cookie and "Secure" in set_cookie
    assert "SameSite=Strict" in set_cookie and "Path=/" in set_cookie
    assert "Domain=" not in set_cookie
    new_cookie = set_cookie.split(";", 1)[0]
    assert new_cookie != "sid=attacker-fixed-value"
    assert request(app, "GET", "/api/session", cookie="sid=attacker-fixed-value")["status"] == 401


def test_login_failure_is_generic_and_does_not_create_session(tmp_path):
    app, _ = build_service(tmp_path)
    unknown = request(app, "POST", "/api/login", body={"username": "not-a-user", "password": "Guess-Password-123"})
    wrong = request(app, "POST", "/api/login", body={"username": "alice", "password": "Wrong-Password-123"})
    assert unknown["status"] == wrong["status"] == 401
    assert unknown["body"] == wrong["body"] == {"error": "invalid_credentials"}
    assert "Set-Cookie" not in unknown["headers"]
    assert "password" not in " ".join(unknown["headers"].keys()).lower()


def test_session_expires_and_is_removed(tmp_path):
    app, clock = build_service(tmp_path, ttl=30)
    cookie, _ = login(app)
    assert request(app, "GET", "/api/session", cookie=cookie)["status"] == 200
    clock.advance(31)
    assert request(app, "GET", "/api/session", cookie=cookie)["status"] == 401


def test_logout_invalidates_session_and_clears_cookie(tmp_path):
    app, _ = build_service(tmp_path)
    cookie, csrf = login(app)
    response = request(app, "POST", "/api/logout", cookie=cookie, headers={"X-CSRF-Token": csrf})
    assert response["status"] == 200
    assert "Max-Age=0" in response["headers"]["Set-Cookie"]
    assert request(app, "GET", "/api/session", cookie=cookie)["status"] == 401


def test_state_changing_request_requires_csrf_token(tmp_path):
    app, _ = build_service(tmp_path)
    cookie, csrf = login(app)
    missing = request(app, "POST", "/api/records", cookie=cookie, body={"title": "A", "body": "B"})
    wrong = request(app, "POST", "/api/records", cookie=cookie, body={"title": "A", "body": "B"}, headers={"X-CSRF-Token": "wrong-token"})
    accepted = request(app, "POST", "/api/records", cookie=cookie, body={"title": "A", "body": "B"}, headers={"X-CSRF-Token": csrf})
    assert missing["status"] == wrong["status"] == 403
    assert accepted["status"] == 201


def test_csrf_token_is_not_placed_in_cookie_or_url(tmp_path):
    app, _ = build_service(tmp_path)
    cookie, csrf = login(app)
    assert csrf not in cookie
    assert "csrfToken" not in request(app, "GET", "/api/records", cookie=cookie)["headers"].get("Location", "")


def test_object_level_authorization_blocks_cross_tenant_idor(tmp_path):
    app, _ = build_service(tmp_path)
    alice_cookie, alice_csrf = login(app)
    created = request(app, "POST", "/api/records", cookie=alice_cookie, headers={"X-CSRF-Token": alice_csrf}, body={"title": "Tenant A", "body": "private"})
    record_id = created["body"]["id"]
    bob_cookie, _ = login(app, "bob", "OtherTenant-456!")
    response = request(app, "GET", f"/api/records/{record_id}", cookie=bob_cookie)
    assert response["status"] == 404
    assert response["body"] == {"error": "not_found"}


def test_same_tenant_owner_and_supervisor_authorization(tmp_path):
    app, _ = build_service(tmp_path)
    alice_cookie, alice_csrf = login(app)
    created = request(app, "POST", "/api/records", cookie=alice_cookie, headers={"X-CSRF-Token": alice_csrf}, body={"title": "Owner data", "body": "only same tenant"})
    record_id = created["body"]["id"]
    supervisor_cookie, _ = login(app, "supervisor", "Supervisor-987!")
    assert request(app, "GET", f"/api/records/{record_id}", cookie=alice_cookie)["status"] == 200
    assert request(app, "GET", f"/api/records/{record_id}", cookie=supervisor_cookie)["status"] == 200


def test_list_endpoint_never_returns_other_tenant_records(tmp_path):
    app, _ = build_service(tmp_path)
    for username, password in (("alice", "CorrectHorse-123!"), ("bob", "OtherTenant-456!")):
        cookie, csrf = login(app, username, password)
        request(app, "POST", "/api/records", cookie=cookie, headers={"X-CSRF-Token": csrf}, body={"title": username, "body": "record"})
    alice_cookie, _ = login(app)
    records = request(app, "GET", "/api/records", cookie=alice_cookie)
    assert records["status"] == 200
    assert all(record["tenantId"] == "tenant-a" for record in records["body"]["records"])
    assert {record["title"] for record in records["body"]["records"]} == {"alice"}


def test_input_validation_rejects_unknown_fields_and_long_values(tmp_path):
    app, _ = build_service(tmp_path)
    cookie, csrf = login(app)
    unknown = request(app, "POST", "/api/records", cookie=cookie, headers={"X-CSRF-Token": csrf}, body={"title": "A", "body": "B", "tenantId": "tenant-b"})
    too_long = request(app, "POST", "/api/records", cookie=cookie, headers={"X-CSRF-Token": csrf}, body={"title": "x" * 121, "body": "B"})
    assert unknown["status"] == 400 and too_long["status"] == 400


def test_json_body_size_and_syntax_are_bounded(tmp_path):
    app, _ = build_service(tmp_path)
    oversized = request(app, "POST", "/api/login", body=b"{" + (b" " * (1_048_576 + 2)))
    malformed = request(app, "POST", "/api/login", body=b"not-json")
    assert oversized["status"] == 413
    assert malformed["status"] == 400


def test_login_rate_limit_triggers_after_configured_failures(tmp_path):
    app, _ = build_service(tmp_path, rate_limit=3)
    for _ in range(3):
        result = request(app, "POST", "/api/login", body={"username": "alice", "password": "Wrong-Password-123"}, remote="127.0.0.8")
        assert result["status"] == 401
    blocked = request(app, "POST", "/api/login", body={"username": "alice", "password": "CorrectHorse-123!"}, remote="127.0.0.8")
    assert blocked["status"] == 429


def test_security_headers_are_present_and_cors_is_absent(tmp_path):
    app, _ = build_service(tmp_path)
    cookie, _ = login(app)
    response = request(app, "GET", "/api/session", cookie=cookie)
    headers = response["headers"]
    assert headers["X-Content-Type-Options"] == "nosniff"
    assert headers["X-Frame-Options"] == "DENY"
    assert headers["Referrer-Policy"] == "no-referrer"
    assert headers["Cache-Control"] == "no-store"
    assert "default-src 'none'" in headers["Content-Security-Policy"]
    assert "Access-Control-Allow-Origin" not in headers


def test_audit_chain_detects_tampering_and_does_not_store_password(tmp_path):
    app, _ = build_service(tmp_path)
    response = request(app, "POST", "/api/login", body={"username": "alice", "password": "CorrectHorse-123!"})
    assert response["status"] == 200
    path = tmp_path / "audit.jsonl"
    log_text = path.read_text()
    assert "CorrectHorse-123!" not in log_text
    assert AuditLog(path, key=b"test-audit-hmac-key-that-is-32-bytes-long").verify() == (True, None)
    path.write_text(log_text.replace('"outcome":"success"', '"outcome":"failed"', 1))
    assert AuditLog(path, key=b"test-audit-hmac-key-that-is-32-bytes-long").verify()[0] is False


def test_audit_rejects_wrong_key(tmp_path):
    path = tmp_path / "audit.jsonl"
    audit = AuditLog(path, key=b"test-audit-hmac-key-that-is-32-bytes-long")
    audit.append(actor="alice", action="login", resource="auth", outcome="success")
    assert AuditLog(path, key=b"a-different-secret-audit-key-32-bytes").verify()[0] is False


def test_loopback_host_validation_rejects_external_interfaces():
    assert validate_loopback_host("127.0.0.1") == "127.0.0.1"
    assert validate_loopback_host("::1") == "::1"
    with pytest.raises(ValueError, match="loopback"):
        validate_loopback_host("0.0.0.0")
    with pytest.raises(ValueError, match="loopback"):
        validate_loopback_host("192.0.2.10")


def test_corrupted_audit_log_is_readable_for_diagnosis_but_refuses_further_appends(tmp_path):
    path = tmp_path / "tampered.jsonl"
    path.write_text('{"sequence":1,"invalid":true}\n')
    audit = AuditLog(path, key=b"test-audit-hmac-key-that-is-32-bytes-long")
    assert audit.verify()[0] is False
    with pytest.raises(ValueError, match="integrity"):
        audit.append(actor="alice", action="login", resource="auth", outcome="success")


def test_rate_limit_is_per_source_ip_not_per_username(tmp_path):
    app, _ = build_service(tmp_path, rate_limit=2)
    first = request(app, "POST", "/api/login", body={"username": "alice", "password": "Wrong-Password-123"}, remote="127.0.0.9")
    second = request(app, "POST", "/api/login", body={"username": "bob", "password": "Wrong-Password-123"}, remote="127.0.0.9")
    third = request(app, "POST", "/api/login", body={"username": "alice", "password": "CorrectHorse-123!"}, remote="127.0.0.9")
    assert first["status"] == second["status"] == 401
    assert third["status"] == 429


def test_record_update_uses_version_to_prevent_lost_updates(tmp_path):
    app, _ = build_service(tmp_path)
    cookie, csrf = login(app)
    created = request(app, "POST", "/api/records", cookie=cookie, headers={"X-CSRF-Token": csrf}, body={"title": "Original", "body": "body"})
    record_id = created["body"]["id"]
    updated = request(app, "PATCH", f"/api/records/{record_id}", cookie=cookie, headers={"X-CSRF-Token": csrf}, body={"title": "Updated", "expectedVersion": 1})
    stale = request(app, "PATCH", f"/api/records/{record_id}", cookie=cookie, headers={"X-CSRF-Token": csrf}, body={"body": "stale write", "expectedVersion": 1})
    assert updated["status"] == 200 and updated["body"]["version"] == 2
    assert stale["status"] == 409 and stale["body"]["currentVersion"] == 2


def test_supervisor_cannot_read_another_tenant_record(tmp_path):
    app, _ = build_service(tmp_path)
    bob_cookie, bob_csrf = login(app, "bob", "OtherTenant-456!")
    created = request(app, "POST", "/api/records", cookie=bob_cookie, headers={"X-CSRF-Token": bob_csrf}, body={"title": "Tenant B", "body": "secret"})
    supervisor_cookie, _ = login(app, "supervisor", "Supervisor-987!")
    response = request(app, "GET", f"/api/records/{created['body']['id']}", cookie=supervisor_cookie)
    assert response["status"] == 404


def test_duplicate_json_object_keys_are_rejected(tmp_path):
    app, _ = build_service(tmp_path)
    raw = b'{"username":"alice","username":"bob","password":"CorrectHorse-123!"}'
    response = request(app, "POST", "/api/login", body=raw)
    assert response["status"] == 400


def test_audit_log_rechecks_chain_before_appending_after_external_change(tmp_path):
    path = tmp_path / "audit.jsonl"
    audit = AuditLog(path, key=b"test-audit-hmac-key-that-is-32-bytes-long")
    audit.append(actor="alice", action="login", resource="auth", outcome="success")
    contents = path.read_text()
    path.write_text(contents.replace('"outcome":"success"', '"outcome":"failure"', 1))
    with pytest.raises(ValueError, match="integrity"):
        audit.append(actor="alice", action="logout", resource="auth", outcome="success")


def test_audit_file_is_created_with_restrictive_posix_permissions(tmp_path):
    import os
    import stat
    if os.name == "nt":
        pytest.skip("POSIX permission bits are not available on Windows")
    path = tmp_path / "private-audit.jsonl"
    AuditLog(path, key=b"test-audit-hmac-key-that-is-32-bytes-long")
    assert stat.S_IMODE(path.stat().st_mode) == 0o600

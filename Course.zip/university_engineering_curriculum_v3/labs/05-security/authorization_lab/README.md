# Lab 5 — Tenant-scoped authorization and negative testing

## Setup
Python 3.11+ and pytest. Run `python -m pytest -q` from this directory.

`policy.py` is a deliberately small authorization reference model. It provides deny-by-default action permissions with facility-scoped role assignment and an ownership check for command creation. It does not implement authentication, password storage, session management, cryptographic verification, audit durability or a production API.

## Tasks
1. Draw a data-flow diagram and mark public, authenticated, privileged and service-to-service trust boundaries.
2. Derive the authorization policy from requirements. Distinguish identity proof (authentication) from permission decisions (authorization).
3. Extend tests for cross-facility reads/writes, inactive users, missing roles, unknown actions, stale sessions, object-level IDOR, approval separation-of-duty and administrative actions.
4. Add property tests that changing an object ID cannot grant access to a resource in another facility.
5. Integrate the model into a small local API only after defining request validation, authentication and error handling. Ensure resource authorization occurs server-side after resource lookup.
6. Threat-model command replay, race conditions, stale role changes, confused deputy, mass assignment, secrets leakage and audit-log tampering.
7. Map each high-risk threat to one security requirement, design control, abuse-case test and residual-risk statement.

## Security test rule
Use only the local lab or systems for which you have explicit authorization. Never test a public system or another person's account. Do not store real credentials or personal data in the lab.

## Assessment rubric (100 points)
Threat model and trust boundaries 20; least-privilege policy 20; negative/property tests 25; requirements/control/test traceability 20; limitations, evidence and report 15.

from policy import Principal, Resource, authorize


def test_operator_can_read_resource_in_assigned_facility():
    p = Principal("u1", {"F1": "OPERATOR"}, active=True)
    r = Resource("tank-1", "F1", owner_user_id="u1")
    assert authorize(p, "read_tank", r)


def test_cross_facility_access_is_denied_even_for_admin_of_another_facility():
    p = Principal("admin1", {"F1": "ADMIN"}, active=True)
    r = Resource("tank-2", "F2", owner_user_id="u2")
    assert not authorize(p, "read_tank", r)


def test_inactive_principal_is_denied():
    p = Principal("u1", {"F1": "ADMIN"}, active=False)
    assert not authorize(p, "manage_users", Resource("u", "F1"))


def test_operator_cannot_manage_users():
    p = Principal("u1", {"F1": "OPERATOR"}, active=True)
    assert not authorize(p, "manage_users", Resource("u", "F1"))


def test_unknown_action_is_denied_by_default():
    p = Principal("u1", {"F1": "ADMIN"}, active=True)
    assert not authorize(p, "execute_arbitrary_code", Resource("x", "F1"))


def test_missing_facility_membership_is_denied():
    p = Principal("u1", {}, active=True)
    assert not authorize(p, "read_tank", Resource("x", "F1"))

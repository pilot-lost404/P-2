"""A deny-by-default, facility-scoped authorization model for course exercises.

This is an authorization decision function, not production authentication,
cryptography, session handling, or a complete application security system.
"""
from __future__ import annotations
from dataclasses import dataclass


@dataclass(frozen=True)
class Principal:
    user_id: str
    facility_roles: dict[str, str]
    active: bool = True


@dataclass(frozen=True)
class Resource:
    resource_id: str
    facility_id: str
    owner_user_id: str | None = None


ROLE_PERMISSIONS = {
    "OPERATOR": frozenset({"read_tank", "view_measurements", "create_command"}),
    "SUPERVISOR": frozenset({"read_tank", "view_measurements", "create_command", "approve_command"}),
    "ADMIN": frozenset({
        "read_tank", "view_measurements", "create_command", "approve_command",
        "configure_tank", "manage_users", "view_audit",
    }),
}


def authorize(principal: Principal, action: str, resource: Resource) -> bool:
    """Return whether principal may perform action on this facility resource.

    Authorization is facility-scoped even for ADMIN; there is no implicit
    global superuser. Unknown roles/actions, inactive users and missing
    memberships are denied.
    """
    if not principal.active or not principal.user_id or not resource.facility_id:
        return False
    role = principal.facility_roles.get(resource.facility_id)
    if role is None:
        return False
    permissions = ROLE_PERMISSIONS.get(role)
    if permissions is None or action not in permissions:
        return False
    if action == "create_command" and resource.owner_user_id not in (None, principal.user_id):
        # A delegated operator may act on a tank only if the task policy is
        # deliberately changed; the baseline denies cross-owner actuation.
        return False
    return True

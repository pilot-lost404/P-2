// Edition 3 water-tank system model.
// Stable M-* tags are mirrored in model-element-register.csv. These comments
// are trace tags for the accompanying CSV validator, not SysML annotations.
package WaterTankModel {
    // ---------- Structural architecture ----------
    port def LevelSignalPort {
        out levelPercent : Real;
        out sampleAgeSeconds : Real;
        out sensorHealthy : Boolean;
    }

    port def ValveCommandPort {
        out openCommand : Boolean;
        in positionFeedback : Boolean;
    }

    port def RemoteCommandPort {
        in requestedTargetPercent : Real;
        in commandAgeSeconds : Real;
        in commandId : String;
        in authenticated : Boolean;
        in authorized : Boolean;
    }

    part def Tank {
        attribute capacityLitres : Real;
        attribute levelPercent : Real;
    }

    // @element-id M-SENSOR
    part def LevelSensor {
        attribute samplePeriodSeconds : Real;
        attribute accuracyPercentFullScale : Real;
        port dataOut : LevelSignalPort;
    }

    // @element-id M-CONTROLLER
    part def Controller {
        attribute staleLimitSeconds : Real;
        attribute highClosePercent : Real;
        attribute reopenPercent : Real;
        attribute targetTolerancePercent : Real;
        attribute faultDetectionCycles : Integer;
        port levelIn : LevelSignalPort;
        port valveOut : ValveCommandPort;
    }

    // @element-id M-VALVE
    part def InletValve {
        attribute maximumFlowLitresPerSecond : Real;
        attribute maximumSafeClosureSeconds : Real;
        attribute normallyClosed : Boolean;
        port command : ValveCommandPort;
    }

    // @element-id M-HH-SWITCH
    part def HighHighSwitch {
        attribute tripPercent : Real;
        attribute independentOfPrimarySensor : Boolean;
        port isolationCommand : ValveCommandPort;
    }

    // @element-id M-COMMS
    part def RemoteCommandInterface {
        attribute autonomousControlOnDisconnect : Boolean;
        attribute maximumCommandAgeSeconds : Real;
        attribute retainProcessedCommandIds : Boolean;
        port remoteCommand : RemoteCommandPort;
    }

    // @element-id M-REMOTE-API
    part def RemoteCommandGateway {
        attribute authenticationRequired : Boolean;
        attribute authorizationRequired : Boolean;
        port command : RemoteCommandPort;
    }

    // @element-id M-AUDIT
    part def CommandAuditLog {
        attribute recordsAcceptedCommands : Boolean;
        attribute recordsRejectedCommands : Boolean;
        attribute storesActorCommandTimestampOutcome : Boolean;
    }

    // @element-id M-HMI
    part def OperatorDisplay {
        attribute displaysLevel : Boolean;
        attribute displaysSampleAge : Boolean;
        attribute displaysValveState : Boolean;
        attribute displaysActiveAlarms : Boolean;
    }

    // @element-id M-CONTROL-ACTION
    action def AcquireLevel {
        out levelPercent : Real;
        out sampleAgeSeconds : Real;
        out sensorHealthy : Boolean;
    }

    action def DecideValveState {
        in levelPercent : Real;
        in sampleAgeSeconds : Real;
        in sensorHealthy : Boolean;
        in targetPercent : Real;
        out openValve : Boolean;
    }

    action def ControlCycle {
        action acquire : AcquireLevel;
        action decide : DecideValveState;
        flow acquire.levelPercent to decide.levelPercent;
        flow acquire.sampleAgeSeconds to decide.sampleAgeSeconds;
        flow acquire.sensorHealthy to decide.sensorHealthy;
    }

    part def WaterTankController {
        part tank : Tank;
        part sensor : LevelSensor;
        part controller : Controller;
        part inletValve : InletValve;
        part highHighSwitch : HighHighSwitch;
        part commandInterface : RemoteCommandInterface;
        part commandGateway : RemoteCommandGateway;
        part auditLog : CommandAuditLog;
        part operatorDisplay : OperatorDisplay;
        perform action controlCycle : ControlCycle;
    }

    // ---------- Requirement definitions ----------
    requirement def <'REQ-SEN-001'> SensorSamplePeriod {
        doc /* The sensor sample period shall not exceed two seconds. */
        attribute actualSamplePeriodSeconds : Real;
        attribute maximumSamplePeriodSeconds : Real;
        require constraint { actualSamplePeriodSeconds <= maximumSamplePeriodSeconds }
    }

    requirement def <'REQ-SEN-002'> SensorAccuracy {
        doc /* Absolute sensor error shall not exceed 1.5 percent of full scale. */
        attribute absoluteErrorPercentFullScale : Real;
        attribute maximumErrorPercentFullScale : Real;
        require constraint { absoluteErrorPercentFullScale <= maximumErrorPercentFullScale }
    }

    requirement def <'REQ-SEN-003'> StaleSampleDetection {
        doc /* A sample older than the configured age limit shall be invalid. */
        attribute staleLimitSeconds : Real;
        attribute maximumPermittedStaleLimitSeconds : Real;
        require constraint { staleLimitSeconds <= maximumPermittedStaleLimitSeconds }
    }

    requirement def <'REQ-CTL-001'> HighLevelCloseThreshold {
        doc /* The controller shall command inlet closure at or above the high-level threshold. */
        attribute highClosePercent : Real;
        attribute latestPermittedHighClosePercent : Real;
        require constraint { highClosePercent <= latestPermittedHighClosePercent }
    }

    requirement def <'REQ-CTL-002'> ReopenHysteresis {
        doc /* Reopening shall be inhibited until level is below the hysteresis threshold. */
        attribute reopenPercent : Real;
        attribute maximumReopenPercent : Real;
        require constraint { reopenPercent <= maximumReopenPercent }
    }

    requirement def <'REQ-SAF-001'> ControllerHeartbeatFailSafe {
        doc /* Loss of controller heartbeat shall close the inlet within one second. */
        attribute closureTimeSeconds : Real;
        attribute maximumClosureTimeSeconds : Real;
        require constraint { closureTimeSeconds <= maximumClosureTimeSeconds }
    }

    requirement def <'REQ-SAF-002'> IndependentHighHighTrip {
        doc /* An independent high-high switch shall initiate isolation at the defined threshold. */
        attribute tripPercent : Real;
        attribute maximumTripPercent : Real;
        require constraint { tripPercent <= maximumTripPercent }
    }

    requirement def <'REQ-FLW-001'> MaximumInletFlow {
        doc /* Inlet flow shall remain within the specified hydraulic envelope. */
        attribute flowLitresPerSecond : Real;
        attribute maximumFlowLitresPerSecond : Real;
        require constraint { flowLitresPerSecond <= maximumFlowLitresPerSecond }
    }

    requirement def <'REQ-FLW-002'> FillTargetAccuracy {
        doc /* Final level shall be within one percentage point of the target. */
        attribute absoluteTargetErrorPercent : Real;
        attribute maximumTargetErrorPercent : Real;
        require constraint { absoluteTargetErrorPercent <= maximumTargetErrorPercent }
    }

    requirement def <'REQ-RES-001'> SensorFaultDetection {
        doc /* An open-circuit sensor fault shall be detected within two control cycles. */
        attribute detectionCycles : Integer;
        attribute maximumDetectionCycles : Integer;
        require constraint { detectionCycles <= maximumDetectionCycles }
    }

    requirement def <'REQ-RES-002'> ActuatorFailureAudit {
        doc /* Actuator failure evidence shall include timestamp, command identifier and feedback state. */
        attribute requiredAuditFields : Integer;
        attribute minimumAuditFields : Integer;
        require constraint { requiredAuditFields >= minimumAuditFields }
    }

    requirement def <'REQ-COM-001'> LocalAutonomy {
        doc /* Local level control shall continue during remote connectivity loss. */
        attribute localAutonomyMinutes : Real;
        attribute minimumAutonomyMinutes : Real;
        require constraint { localAutonomyMinutes >= minimumAutonomyMinutes }
    }

    requirement def <'REQ-COM-002'> RemoteCommandFreshness {
        doc /* Commands older than thirty seconds or already processed shall be rejected. */
        attribute maximumAcceptedCommandAgeSeconds : Real;
        attribute freshnessLimitSeconds : Real;
        require constraint { maximumAcceptedCommandAgeSeconds <= freshnessLimitSeconds }
    }

    requirement def <'REQ-SEC-001'> AuthenticatedAuthorizedCommand {
        doc /* A remote setpoint command shall be both authenticated and authorized. */
        attribute authenticationRequired : Boolean;
        attribute authorizationRequired : Boolean;
        require constraint { authenticationRequired == true and authorizationRequired == true }
    }

    requirement def <'REQ-SEC-002'> CommandAccountability {
        doc /* Both accepted and rejected remote commands shall be fully auditable. */
        attribute auditAcceptedCommands : Boolean;
        attribute auditRejectedCommands : Boolean;
        attribute auditActorCommandTimestampOutcome : Boolean;
        require constraint { auditAcceptedCommands == true and auditRejectedCommands == true and auditActorCommandTimestampOutcome == true }
    }

    requirement def <'REQ-PWR-001'> PowerLossFailClosed {
        doc /* Loss of primary power shall leave the inlet valve closed. */
        attribute valveNormallyClosed : Boolean;
        require constraint { valveNormallyClosed == true }
    }

    requirement def <'REQ-OPS-001'> OperatorStateVisibility {
        doc /* The operator interface shall expose level, sample age, valve state and alarms. */
        attribute displayedFieldCount : Integer;
        attribute minimumDisplayedFieldCount : Integer;
        require constraint { displayedFieldCount >= minimumDisplayedFieldCount }
    }

    requirement def <'REQ-MNT-001'> SafeMaintenanceMode {
        doc /* Maintenance mode shall inhibit automatic fill without disabling high-high isolation. */
        attribute automaticFillInhibited : Boolean;
        attribute highHighIsolationEnabled : Boolean;
        require constraint { automaticFillInhibited == true and highHighIsolationEnabled == true }
    }

    // ---------- Requirement uses and allocation ----------
    requirement WaterTankRequirements {
        subject system : WaterTankController;
        requirement <'REQ-SEN-001'> sensorSamplePeriod : SensorSamplePeriod {
            subject sensor : LevelSensor;
            attribute :>> maximumSamplePeriodSeconds = 2.0;
        }
        requirement <'REQ-SEN-002'> sensorAccuracy : SensorAccuracy {
            subject sensor : LevelSensor;
            attribute :>> maximumErrorPercentFullScale = 1.5;
        }
        requirement <'REQ-SEN-003'> staleSampleDetection : StaleSampleDetection {
            subject controller : Controller;
            attribute :>> maximumPermittedStaleLimitSeconds = 5.0;
        }
        requirement <'REQ-CTL-001'> highLevelClose : HighLevelCloseThreshold {
            subject controller : Controller;
            attribute :>> latestPermittedHighClosePercent = 90.0;
        }
        requirement <'REQ-CTL-002'> reopenHysteresis : ReopenHysteresis {
            subject controller : Controller;
            attribute :>> maximumReopenPercent = 88.0;
        }
        requirement <'REQ-SAF-001'> heartbeatFailSafe : ControllerHeartbeatFailSafe {
            subject valve : InletValve;
            attribute :>> maximumClosureTimeSeconds = 1.0;
        }
        requirement <'REQ-SAF-002'> highHighTrip : IndependentHighHighTrip {
            subject highHighSwitch : HighHighSwitch;
            attribute :>> maximumTripPercent = 95.0;
        }
        requirement <'REQ-FLW-001'> maximumInletFlow : MaximumInletFlow {
            subject valve : InletValve;
            attribute :>> maximumFlowLitresPerSecond = 0.8;
        }
        requirement <'REQ-FLW-002'> fillTargetAccuracy : FillTargetAccuracy {
            subject controller : Controller;
            attribute :>> maximumTargetErrorPercent = 1.0;
        }
        requirement <'REQ-RES-001'> sensorFaultDetection : SensorFaultDetection {
            subject controller : Controller;
            attribute :>> maximumDetectionCycles = 2;
        }
        requirement <'REQ-RES-002'> actuatorFailureAudit : ActuatorFailureAudit {
            subject auditLog : CommandAuditLog;
            attribute :>> minimumAuditFields = 4;
        }
        requirement <'REQ-COM-001'> localAutonomy : LocalAutonomy {
            subject commandInterface : RemoteCommandInterface;
            attribute :>> minimumAutonomyMinutes = 30.0;
        }
        requirement <'REQ-COM-002'> commandFreshness : RemoteCommandFreshness {
            subject commandInterface : RemoteCommandInterface;
            attribute :>> freshnessLimitSeconds = 30.0;
        }
        requirement <'REQ-SEC-001'> authenticatedCommand : AuthenticatedAuthorizedCommand {
            subject commandGateway : RemoteCommandGateway;
            attribute :>> authenticationRequired = true;
            attribute :>> authorizationRequired = true;
        }
        requirement <'REQ-SEC-002'> commandAccountability : CommandAccountability {
            subject auditLog : CommandAuditLog;
            attribute :>> auditAcceptedCommands = true;
            attribute :>> auditRejectedCommands = true;
            attribute :>> auditActorCommandTimestampOutcome = true;
        }
        requirement <'REQ-PWR-001'> powerLossSafeState : PowerLossFailClosed {
            subject valve : InletValve;
            attribute :>> valveNormallyClosed = true;
        }
        requirement <'REQ-OPS-001'> operatorVisibility : OperatorStateVisibility {
            subject display : OperatorDisplay;
            attribute :>> minimumDisplayedFieldCount = 4;
        }
        requirement <'REQ-MNT-001'> safeMaintenance : SafeMaintenanceMode {
            subject controller : Controller;
            attribute :>> automaticFillInhibited = true;
            attribute :>> highHighIsolationEnabled = true;
        }
    }

    // A verification definition makes the requirement group an explicit
    // verification objective. Execution remains a SysON/test-workbench gate.
    verification def WaterTankAcceptanceVerification {
        private import VerificationCases::*;
        subject testSystem : WaterTankController;
        objective waterTankObjective {
            verify WaterTankRequirements;
        }
        return verdict : VerdictKind;
    }

    // A design context binds the requirement subject to a concrete system usage.
    part waterTankController : WaterTankController;
    verification waterTankAcceptance : WaterTankAcceptanceVerification {
        subject testSystem :> waterTankController;
    }
    satisfy WaterTankRequirements::sensorSamplePeriod by waterTankController.sensor;
    satisfy WaterTankRequirements::sensorAccuracy by waterTankController.sensor;
    satisfy WaterTankRequirements::staleSampleDetection by waterTankController.controller;
    satisfy WaterTankRequirements::highLevelClose by waterTankController.controller;
    satisfy WaterTankRequirements::reopenHysteresis by waterTankController.controller;
    satisfy WaterTankRequirements::heartbeatFailSafe by waterTankController.inletValve;
    satisfy WaterTankRequirements::highHighTrip by waterTankController.highHighSwitch;
    satisfy WaterTankRequirements::maximumInletFlow by waterTankController.inletValve;
    satisfy WaterTankRequirements::fillTargetAccuracy by waterTankController.controller;
    satisfy WaterTankRequirements::sensorFaultDetection by waterTankController.controller;
    satisfy WaterTankRequirements::actuatorFailureAudit by waterTankController.auditLog;
    satisfy WaterTankRequirements::localAutonomy by waterTankController.commandInterface;
    satisfy WaterTankRequirements::commandFreshness by waterTankController.commandInterface;
    satisfy WaterTankRequirements::authenticatedCommand by waterTankController.commandGateway;
    satisfy WaterTankRequirements::commandAccountability by waterTankController.auditLog;
    satisfy WaterTankRequirements::powerLossSafeState by waterTankController.inletValve;
    satisfy WaterTankRequirements::operatorVisibility by waterTankController.operatorDisplay;
    satisfy WaterTankRequirements::safeMaintenance by waterTankController.controller;
}

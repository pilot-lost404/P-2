# Lab 2 — Model-Based Systems Engineering with SysML v2

**Scope:** Requirements engineering, system structure and behavior, traceability, model quality and design review.  
**Tool benchmark:** Eclipse SysON v2026.11.0 documentation (check release notes before using another version).  
**Status:** CSV traceability validator executed; SysML v2 import, graphical rendering and semantic validation have **not** been executed in this build environment.

## Learning outcomes

1. Translate stakeholder needs into measurable, testable system requirements.
2. Build a SysML v2 model with part definitions/usages, ports, actions, requirements and requirement-satisfaction links.
3. Create bidirectional trace links from need → requirement → model element → verification case → evidence.
4. Use automated model-quality queries to find duplicate IDs, dangling links, unverified requirements and orphan elements.
5. Produce a trade study and controlled change-impact analysis without presenting subjective scoring as objective fact.
6. Distinguish model well-formedness, requirement satisfaction, verification and operational validation.

## Files

| File | Purpose |
|---|---|
| `water-tank-v3.sysml` | Expanded SysML v2 textual model: structure, ports, control action, 18 requirement definitions/usages, satisfy links and a verification definition |
| `water-tank.sysml` | Original starter retained for comparison |
| `stakeholder-needs.csv` | Six source needs |
| `requirements-register.csv` | 18 measurable requirements, source need, allocation, verification method and acceptance criterion |
| `model-element-register.csv` | Stable `M-*` trace identifiers tied to model element names and source file |
| `verification-cases.csv` | 18 planned verification cases with test IDs and acceptance criteria |
| `traceability-matrix.csv` | 22 links across needs, requirements, model elements, behaviors, hazards/threats and tests |
| `traceability/validator.py` | Standard-library register/traceability validator with JSON output |
| `traceability/test_validator.py` | Six automated positive/negative tests |
| `trade-study.csv` | Three architecture alternatives and explicit scoring assumptions |
| `change-impact/CR-001-sample-period.md` | Example change impact of reducing sample period from 2 s to 1 s |

## Tool workflow

1. Install/use [Eclipse SysON](https://eclipse-syson.org/) and record its exact version. The current v2026.11.0 manual says the graphical editor supports core SysML v2 structure, behavior and requirements views; the documented built-in view types include block, interface, activity and state. Sequence diagrams are not represented as a currently supported view in that version's FAQ.
2. Create a project and import `water-tank-v3.sysml` as SysML v2 textual content. Resolve all import/parser diagnostics; do not edit away warnings without recording the change.
3. Render at minimum a block/structure view, interface view, activity/control-flow view and requirement view. Export SVG diagrams and the textual model.
4. Compare the tool's model elements against `model-element-register.csv`; record missing, renamed, unsupported or duplicated model elements.
5. Execute the CSV traceability validator and resolve every error and warning:

```bash
cd traceability
python validator.py ..
pytest -q test_validator.py
```

6. Create and export one report/query for requirements without tests, tests without requirements, unallocated requirements and orphan model elements. Re-import the SysML export into a clean SysON project and compare counts and relationships.
7. Perform the architecture trade study, then demonstrate the sample-period change request. Record who approves the baseline and what requires re-verification.

## Assessment tasks

- Add a requirement for brownout recovery with a measurable acceptance criterion and a verification case.
- Change sensor sample period from 2 s to 1 s; list the affected network, storage, power, alarm-latency, audit and verification artifacts.
- Make one model element orphaned, one test reference dangling and one requirement duplicate; prove the validator detects each defect.
- Adjust trade-study weights and show whether the preferred architecture changes.
- Produce a 4-view model review and a 10-minute design defense explaining assumptions and limitations.

## External verification boundary

The local validator is executed and tested. The textual SysML file is authored against current SysML v2 examples, but it has not been imported, parsed or rendered in SysON here. A CSV model register is not a substitute for an actual SysML metamodel instance; the actual tool import and semantic diagnostics remain mandatory learner evidence.

SysON's v2026.11.0 FAQ also says the product does not provide built-in model-management functions such as versioning, branching or access control. Keep baselines and change history in a controlled external version-control/configuration-management workflow.

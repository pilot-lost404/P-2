// SysML v2 textual starter model for the integrated water-tank controller.
// Import in a SysML v2-capable tool (e.g. Eclipse SysON). This file is a
// student-authored starter, not a claim of parser validation in this runtime.
package WaterTankSystem {
    part def Tank {
        attribute capacityLitres : Real;
        attribute measuredLevelPercent : Real;
        attribute targetLevelPercent : Real;
    }

    part def LevelSensor {
        attribute samplePeriodSeconds : Real;
        attribute accuracyPercent : Real;
    }

    part def Controller {
        attribute commandTimeoutSeconds : Real;
        attribute sensorStaleLimitSeconds : Real;
    }

    part def InletValve {
        attribute maximumFlowLitresPerSecond : Real;
    }

    part def WaterTankController {
        part tank : Tank;
        part sensor : LevelSensor;
        part controller : Controller;
        part inletValve : InletValve;
    }

    action def AcquireLevel {
        out levelPercent : Real;
        out sampleAgeSeconds : Real;
    }

    action def DecideValveState {
        in levelPercent : Real;
        in sampleAgeSeconds : Real;
        in targetPercent : Real;
        out openValve : Boolean;
    }

    action def ControlCycle {
        action acquire : AcquireLevel;
        action decide : DecideValveState;
        flow acquire.levelPercent to decide.levelPercent;
        flow acquire.sampleAgeSeconds to decide.sampleAgeSeconds;
    }
}

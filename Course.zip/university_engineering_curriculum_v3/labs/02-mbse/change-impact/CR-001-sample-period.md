# Change request CR-001 — reduce sensor sample period from 2 seconds to 1 second

**Status:** Example impact-analysis exercise; not an approved engineering change.  
**Requested change:** Update `REQ-SEN-001` from a maximum 2.0 s sample interval to a maximum 1.0 s interval.

## Directly affected artifacts

| Artifact | Impact | Required follow-up |
|---|---|---|
| `REQ-SEN-001` | Tightens sensor timing requirement | Update baseline, acceptance criterion and source need rationale |
| `M-SENSOR` / `LevelSensor` | Sampling and interface throughput increase | Check device capability, accuracy under faster sampling and sensor processing load |
| `M-CONTROLLER` / `ControlCycle` | Receives a more frequent measurement stream | Recalculate worst-case execution time, queue depth and stale-data detection timing |
| `M-COMMS` / remote link | Telemetry rate increases | Estimate bytes/s, bandwidth margin, retransmission behavior and disconnected buffering |
| `M-AUDIT` / data store | If every sample is retained, storage and retention costs increase | Recompute event volume, retention, aggregation and backup capacity |
| `REQ-SEN-003` | Stale-sample threshold may become too permissive relative to new sample rate | Review threshold and missed-sample behavior; do not change automatically |
| `REQ-OPS-001` | Display freshness metric may need a new target | Review display age and operator alarm requirements |
| `VC-001`, `VC-003`, related performance tests | Existing tests no longer demonstrate the revised design | Re-run sampling, stale-age, communication-load and long-duration soak tests |
| FMEA/STPA and safety case | New timing changes can create or reduce hazards | Revisit sensor loss, stale values, network overload and controller saturation scenarios |

## Analysis method

1. Traverse explicit trace links from the changed requirement to model element, behaviors, hazards and test IDs.
2. Add engineering judgment for indirect effects (network capacity, storage, power and alarm handling); pure graph reachability cannot infer these effects.
3. Record changed assumptions, calculations and evidence.
4. Obtain approval from requirements, controls, safety, cybersecurity and operations owners before baselining.
5. Define regression and re-validation scope. A change is not closed merely because the model imports or the traceability validator passes.

"""Cross-check MBSE requirements, model elements, verification and evidence.

This validates the CSV interchange/traceability layer. It does not parse or
semantically validate SysML v2 source; use a SysML v2 workbench for that gate.
"""
from __future__ import annotations

import argparse
import csv
import json
from pathlib import Path
from typing import Any

REQUIRED_COLUMNS = {
    "requirements-register.csv": {
        "requirement_id", "requirement_text", "source_need", "allocation",
        "verification_method", "acceptance_criterion", "status", "version",
    },
    "stakeholder-needs.csv": {"need_id", "stakeholder", "statement"},
    "model-element-register.csv": {
        "model_element_id", "sysml_name", "element_type", "requirement_ids",
        "source_path", "review_status",
    },
    "verification-cases.csv": {
        "test_id", "requirement_id", "verification_method",
        "acceptance_criterion", "evidence_uri", "status",
    },
    "traceability-matrix.csv": {
        "need_id", "requirement_id", "model_element", "interface_or_behavior",
        "hazard_or_threat", "test_id", "evidence_uri", "coverage_status",
    },
}
VALID_CASE_STATUS = {"planned", "implemented", "executed", "passed", "failed", "blocked"}
VALID_COVERAGE_STATUS = {"planned", "implemented", "verified", "waived"}


def _load_csv(root: Path, filename: str, errors: list[str]) -> list[dict[str, str]]:
    path = root / filename
    if not path.is_file():
        errors.append(f"missing required CSV: {filename}")
        return []
    try:
        with path.open("r", newline="", encoding="utf-8-sig") as stream:
            reader = csv.DictReader(stream)
            headers = set(reader.fieldnames or [])
            missing = REQUIRED_COLUMNS[filename] - headers
            if missing:
                errors.append(f"{filename} missing columns: {', '.join(sorted(missing))}")
                return []
            return [
                {key: (value or "").strip() for key, value in row.items() if key is not None}
                for row in reader
            ]
    except (OSError, csv.Error) as exc:
        errors.append(f"cannot read {filename}: {exc}")
        return []


def _index(rows: list[dict[str, str]], key: str, label: str, errors: list[str]) -> dict[str, dict[str, str]]:
    result: dict[str, dict[str, str]] = {}
    for line_number, row in enumerate(rows, start=2):
        value = row.get(key, "")
        if not value:
            errors.append(f"{label} row {line_number} has empty {key}")
            continue
        if value in result:
            errors.append(f"duplicate {key}: {value}")
            continue
        result[value] = row
    return result


def _resolve_artifact(root: Path, uri: str, errors: list[str], context: str) -> None:
    if not uri:
        errors.append(f"{context} has empty evidence/source path")
        return
    candidate = Path(uri)
    if candidate.is_absolute() or ".." in candidate.parts:
        errors.append(f"{context} path must be relative and cannot traverse directories: {uri}")
        return
    resolved = (root / candidate).resolve()
    root_resolved = root.resolve()
    if root_resolved not in resolved.parents and resolved != root_resolved:
        errors.append(f"{context} path escapes project root: {uri}")
        return
    if not resolved.is_file():
        if context.startswith(("verification case", "traceability row")):
            errors.append(f"evidence artifact does not exist for {context}: {uri}")
        else:
            errors.append(f"{context} source artifact does not exist: {uri}")


def validate_model(root: str | Path) -> dict[str, Any]:
    """Return deterministic validation errors, warnings and artifact counts."""
    root = Path(root)
    errors: list[str] = []
    warnings: list[str] = []
    if not root.is_dir():
        return {"errors": [f"project root does not exist: {root}"], "warnings": [], "counts": {}}

    files = {name: _load_csv(root, name, errors) for name in REQUIRED_COLUMNS}
    requirements = _index(files["requirements-register.csv"], "requirement_id", "requirements", errors)
    needs = _index(files["stakeholder-needs.csv"], "need_id", "stakeholder needs", errors)
    elements = _index(files["model-element-register.csv"], "model_element_id", "model elements", errors)
    cases = _index(files["verification-cases.csv"], "test_id", "verification cases", errors)
    matrix = files["traceability-matrix.csv"]

    for requirement_id, row in requirements.items():
        for field in ("requirement_text", "source_need", "allocation", "verification_method", "acceptance_criterion", "status", "version"):
            if not row.get(field):
                errors.append(f"requirement {requirement_id} has empty {field}")
        if row.get("source_need") and row["source_need"] not in needs:
            errors.append(f"requirement {requirement_id} references unknown stakeholder need {row['source_need']}")
        if row.get("allocation") and row["allocation"] not in elements:
            errors.append(f"requirement {requirement_id} references unknown allocated model element {row['allocation']}")

    element_requirements: dict[str, set[str]] = {}
    for element_id, row in elements.items():
        _resolve_artifact(root, row.get("source_path", ""), errors, f"model element {element_id}")
        if not row.get("sysml_name") or not row.get("element_type"):
            errors.append(f"model element {element_id} must have sysml_name and element_type")
        req_ids = {item.strip() for item in row.get("requirement_ids", "").split(";") if item.strip()}
        element_requirements[element_id] = req_ids
        for req_id in req_ids:
            if req_id not in requirements:
                errors.append(f"model element {element_id} references unknown requirement {req_id}")

    matrix_requirements: set[str] = set()
    matrix_needs: set[str] = set()
    matrix_elements: set[str] = set()
    matrix_tests: set[str] = set()
    for line_number, row in enumerate(matrix, start=2):
        req_id = row.get("requirement_id", "")
        need_id = row.get("need_id", "")
        element_id = row.get("model_element", "")
        test_id = row.get("test_id", "")
        if req_id not in requirements:
            errors.append(f"traceability row {line_number} references unknown requirement {req_id!r}")
        else:
            matrix_requirements.add(req_id)
            if element_id and req_id not in element_requirements.get(element_id, set()):
                errors.append(f"traceability link {req_id} -> {element_id} is absent from model-element-register requirement_ids")
        if need_id not in needs:
            errors.append(f"traceability row {line_number} references unknown stakeholder need {need_id!r}")
        else:
            matrix_needs.add(need_id)
        if element_id not in elements:
            errors.append(f"traceability row {line_number} references unknown model element {element_id!r}")
        else:
            matrix_elements.add(element_id)
        if test_id not in cases:
            errors.append(f"traceability row {line_number} references unknown test_id {test_id!r}")
        else:
            matrix_tests.add(test_id)
            if cases[test_id].get("requirement_id") != req_id:
                errors.append(f"traceability row {line_number}: test {test_id} does not verify {req_id}")
        if not row.get("interface_or_behavior") or not row.get("hazard_or_threat"):
            errors.append(f"traceability row {line_number} must state interface_or_behavior and hazard_or_threat")
        status = row.get("coverage_status", "")
        if status not in VALID_COVERAGE_STATUS:
            errors.append(f"traceability row {line_number} has invalid coverage_status {status!r}")
        _resolve_artifact(root, row.get("evidence_uri", ""), errors, f"traceability row {line_number}")

    for requirement_id in requirements:
        if requirement_id not in matrix_requirements:
            errors.append(f"requirement {requirement_id} has no traceability link")
    for need_id in needs:
        if need_id not in matrix_needs:
            warnings.append(f"stakeholder need {need_id} has no direct traceability link")
    for element_id, req_ids in element_requirements.items():
        if element_id not in matrix_elements:
            warnings.append(f"orphan model element {element_id} is not referenced by traceability matrix")
        for req_id in req_ids:
            if req_id not in matrix_requirements:
                errors.append(f"model element {element_id} requirement {req_id} has no matrix coverage")

    for test_id, row in cases.items():
        req_id = row.get("requirement_id", "")
        if req_id not in requirements:
            errors.append(f"verification case {test_id} references unknown requirement {req_id!r}")
        if not row.get("verification_method") or not row.get("acceptance_criterion"):
            errors.append(f"verification case {test_id} needs a method and measurable acceptance criterion")
        status = row.get("status", "")
        if status not in VALID_CASE_STATUS:
            errors.append(f"verification case {test_id} has invalid status {status!r}")
        _resolve_artifact(root, row.get("evidence_uri", ""), errors, f"verification case {test_id}")
        if test_id not in matrix_tests:
            errors.append(f"verification case {test_id} has no traceability-matrix link")

    return {
        "errors": sorted(set(errors)),
        "warnings": sorted(set(warnings)),
        "counts": {
            "requirements": len(requirements),
            "stakeholder_needs": len(needs),
            "model_elements": len(elements),
            "verification_cases": len(cases),
            "trace_links": len(matrix),
        },
    }


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("project_root", nargs="?", default=".", help="MBSE lab root directory")
    args = parser.parse_args()
    report = validate_model(args.project_root)
    print(json.dumps(report, indent=2))
    return 1 if report["errors"] else 0


if __name__ == "__main__":
    raise SystemExit(main())

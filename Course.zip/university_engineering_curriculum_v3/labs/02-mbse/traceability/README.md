# MBSE model and traceability validator

This validator checks the interchange registers and their cross-references. It does **not** parse SysML v2 grammar, perform semantic resolution, render diagrams, solve parametric constraints or validate whether the model is an adequate representation of a real tank installation.

## Run

From this directory:

```bash
python validator.py ..
pytest -q test_validator.py
```

The current sample should report zero errors, zero warnings, 18 requirements, 6 needs, 10 model elements, 18 verification cases and 22 traceability links. The 18 verification cases and all trace links are marked `planned`, not passed.

## What it checks

- Unique, non-empty need, requirement, model-element and verification-case IDs.
- Required CSV columns and non-empty measurable requirement fields.
- Valid source-need, model-element, requirement and test references.
- Each requirement linked to one or more model elements and at least one verification case.
- Each verification case linked from the traceability matrix and aligned to the same requirement.
- Evidence and model source paths are relative to the lab root, stay within that root and point to existing files.
- Coverage statuses use the declared vocabulary; model elements not linked from the matrix are surfaced as warnings.

The validator returns deterministic JSON with separate `errors`, `warnings` and artifact counts. It exits non-zero when errors exist. It is a traceability/data-quality check, not a SysML parser or formal model checker.

## TDD test coverage

`test_validator.py` includes a valid fixture plus negative cases for duplicate requirement IDs, dangling element/test references, unlinked requirements, missing evidence artefacts and orphan model elements. The missing module test was observed failing before `validator.py` was implemented; the full suite now passes.

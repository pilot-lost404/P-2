import csv
import importlib.util
import sys
from pathlib import Path

MODULE_PATH = Path(__file__).with_name("validator.py")
spec = importlib.util.spec_from_file_location("mbse_validator", MODULE_PATH)
validator = importlib.util.module_from_spec(spec)
sys.modules[spec.name] = validator
spec.loader.exec_module(validator)


def write_csv(path: Path, headers, rows):
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", newline="", encoding="utf-8") as stream:
        writer = csv.DictWriter(stream, fieldnames=headers)
        writer.writeheader()
        writer.writerows(rows)


def valid_fixture(root: Path):
    (root / "model" / "system.sysml").parent.mkdir(parents=True, exist_ok=True)
    (root / "model" / "system.sysml").write_text("package T { part def Tank; }\n", encoding="utf-8")
    evidence = root / "evidence" / "VC-001.md"
    evidence.parent.mkdir(parents=True, exist_ok=True)
    evidence.write_text("# Planned test evidence\n", encoding="utf-8")
    write_csv(root / "requirements-register.csv",
              ["requirement_id", "requirement_text", "source_need", "rationale", "owner", "allocation", "verification_method", "acceptance_criterion", "status", "version"],
              [{"requirement_id":"REQ-001", "requirement_text":"Level shall be measured", "source_need":"NEED-001", "rationale":"Protect operation", "owner":"Controls", "allocation":"M-SENSOR", "verification_method":"analysis", "acceptance_criterion":"Sample period <= 2 s", "status":"baselined", "version":"1.0"}])
    write_csv(root / "stakeholder-needs.csv",
              ["need_id", "stakeholder", "statement"],
              [{"need_id":"NEED-001", "stakeholder":"Operator", "statement":"Know the tank level"}])
    write_csv(root / "model-element-register.csv",
              ["model_element_id", "sysml_name", "element_type", "requirement_ids", "source_path", "review_status"],
              [{"model_element_id":"M-SENSOR", "sysml_name":"LevelSensor", "element_type":"part", "requirement_ids":"REQ-001", "source_path":"model/system.sysml", "review_status":"planned"}])
    write_csv(root / "verification-cases.csv",
              ["test_id", "requirement_id", "verification_method", "acceptance_criterion", "evidence_uri", "status"],
              [{"test_id":"VC-001", "requirement_id":"REQ-001", "verification_method":"analysis", "acceptance_criterion":"Sample period <= 2 s", "evidence_uri":"evidence/VC-001.md", "status":"planned"}])
    write_csv(root / "traceability-matrix.csv",
              ["need_id", "requirement_id", "model_element", "interface_or_behavior", "hazard_or_threat", "test_id", "evidence_uri", "coverage_status"],
              [{"need_id":"NEED-001", "requirement_id":"REQ-001", "model_element":"M-SENSOR", "interface_or_behavior":"AcquireLevel", "hazard_or_threat":"H-STALE", "test_id":"VC-001", "evidence_uri":"evidence/VC-001.md", "coverage_status":"planned"}])


def test_complete_fixture_has_no_errors(tmp_path):
    valid_fixture(tmp_path)
    report = validator.validate_model(tmp_path)
    assert report["errors"] == []
    assert report["counts"]["requirements"] == 1
    assert report["counts"]["trace_links"] == 1


def test_duplicate_requirement_ids_are_rejected(tmp_path):
    valid_fixture(tmp_path)
    path = tmp_path / "requirements-register.csv"
    with path.open(encoding="utf-8") as stream:
        rows = list(csv.DictReader(stream))
    write_csv(path, list(rows[0]), rows + [dict(rows[0])])
    report = validator.validate_model(tmp_path)
    assert any("duplicate requirement_id" in error for error in report["errors"])


def test_dangling_model_element_and_test_are_rejected(tmp_path):
    valid_fixture(tmp_path)
    path = tmp_path / "traceability-matrix.csv"
    with path.open(encoding="utf-8") as stream:
        rows = list(csv.DictReader(stream))
    rows[0]["model_element"] = "M-DOES-NOT-EXIST"
    rows[0]["test_id"] = "VC-MISSING"
    write_csv(path, list(rows[0]), rows)
    report = validator.validate_model(tmp_path)
    assert any("unknown model element" in error for error in report["errors"])
    assert any("unknown test_id" in error for error in report["errors"])


def test_unlinked_requirement_is_rejected(tmp_path):
    valid_fixture(tmp_path)
    path = tmp_path / "requirements-register.csv"
    with path.open(encoding="utf-8") as stream:
        rows = list(csv.DictReader(stream))
    rows.append({"requirement_id":"REQ-002", "requirement_text":"Valve shall close", "source_need":"NEED-001", "rationale":"Safety", "owner":"Controls", "allocation":"M-VALVE", "verification_method":"test", "acceptance_criterion":"Closed within 1 s", "status":"baselined", "version":"1.0"})
    write_csv(path, list(rows[0]), rows)
    report = validator.validate_model(tmp_path)
    assert any("has no traceability link" in error and "REQ-002" in error for error in report["errors"])


def test_missing_evidence_artifact_is_rejected(tmp_path):
    valid_fixture(tmp_path)
    (tmp_path / "evidence" / "VC-001.md").unlink()
    report = validator.validate_model(tmp_path)
    assert any("evidence artifact does not exist" in error for error in report["errors"])


def test_orphan_model_element_is_reported_as_warning(tmp_path):
    valid_fixture(tmp_path)
    path = tmp_path / "model-element-register.csv"
    with path.open(encoding="utf-8") as stream:
        rows = list(csv.DictReader(stream))
    rows.append({"model_element_id":"M-UNUSED", "sysml_name":"UnusedPart", "element_type":"part", "requirement_ids":"", "source_path":"model/system.sysml", "review_status":"planned"})
    write_csv(path, list(rows[0]), rows)
    report = validator.validate_model(tmp_path)
    assert any("orphan model element" in warning and "M-UNUSED" in warning for warning in report["warnings"])

# Model verification evidence plan — not an execution record

**Status:** Planned. No SysML v2 import, graphical rendering, solver, simulation or physical test was executed in the build environment.

This file is the common acceptance-test catalogue referenced by the CSV traceability records. The `VC-001` through `VC-018` IDs map one-to-one to the `requirements-register.csv` rows and `traceability-matrix.csv` rows. Each test must be executed against the appropriate requirement and the resulting raw output, tool version, fixture/data version, reviewer and disposition added before the status can be changed from `planned`.

| Test IDs | Method | Evidence to capture |
|---|---|---|
| VC-001–VC-003 | Sensor sampling, calibration and stale-data fault injection | Timestamped samples, calibration fixture, stale-value trace, measured maximum error |
| VC-004–VC-006 | Controller boundary, hysteresis and fail-safe tests | Input sequence, output-state trace, measured valve closure timing |
| VC-007–VC-009 | High-high trip, flow-rate and target accuracy analysis | Switch trace, calibrated flow measurements, final-level deviation data |
| VC-010–VC-011 | Sensor and actuator fault injection | Fault injection record, cycle count, command/feedback/audit trace |
| VC-012–VC-013 | Remote-loss and replay tests | Network-disconnect trace, stale/duplicate request IDs and rejection output |
| VC-014–VC-015 | Authentication, authorization and audit review | Negative request matrix, access-control decisions, audit completeness report |
| VC-016–VC-018 | Power-loss, HMI inspection and maintenance-mode tests | Power removal trace, acceptance-view capture, interlock state matrix |

A planned test row is not evidence that the requirement passed. Do not change `status` to `passed` until the acceptance criterion has been run and the raw evidence is stored.

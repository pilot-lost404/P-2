1. Define three losses and at least five hazards.
2. Complete eight FMEA rows and explain RPN limitations.
3. Draw a fault tree and identify minimal cut sets.
4. Draw a control structure and derive six unsafe control actions.
5. Derive safety requirements and verification methods from the analyses.
This is an educational worksheet, not a certified safety-analysis form.

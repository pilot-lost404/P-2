import math
import pytest
from reliability import (
    series_reliability, parallel_reliability, exponential_reliability,
    weibull_reliability, beta_binomial_posterior, fault_tree_probability,
)


def test_series_reliability_multiplies_independent_components():
    assert series_reliability([0.9, 0.8]) == pytest.approx(0.72)


def test_parallel_reliability_uses_complement_of_joint_failure():
    assert parallel_reliability([0.9, 0.8]) == pytest.approx(0.98)


def test_exponential_model_uses_consistent_rate_time_units():
    assert exponential_reliability(0.001, 100) == pytest.approx(math.exp(-0.1))


def test_weibull_reliability_generalizes_exponential_case():
    assert weibull_reliability(100, eta=100, beta=1) == pytest.approx(math.exp(-1))


def test_beta_binomial_update_returns_posterior_parameters():
    assert beta_binomial_posterior(alpha=1, beta=1, successes=8, failures=2) == (9, 3)


def test_fault_tree_exact_probability_with_shared_basic_event():
    # Top = (A AND B) OR (A AND C) = A AND (B OR C).
    got = fault_tree_probability({"A": 0.1, "B": 0.2, "C": 0.3}, [["A", "B"], ["A", "C"]])
    assert got == pytest.approx(0.1 * (1 - (1 - 0.2) * (1 - 0.3)))


@pytest.mark.parametrize("values", [[1.1], [-0.1], [], [float("nan")]])
def test_reliability_inputs_reject_invalid_probabilities(values):
    with pytest.raises(ValueError):
        series_reliability(values)


def test_fault_tree_rejects_unknown_basic_event():
    with pytest.raises(ValueError, match="Unknown basic event"):
        fault_tree_probability({"A": 0.1}, [["A", "B"]])


def test_beta_factor_model_exposes_common_cause_floor():
    from reliability import beta_factor_parallel_failure_probability

    independent_system_reliability = parallel_reliability([0.9, 0.9])
    dependent = beta_factor_parallel_failure_probability(
        component_failure_probability=0.1, beta_factor=0.2, channel_count=2
    )
    assert independent_system_reliability == pytest.approx(0.99)
    assert dependent == pytest.approx(0.2 * 0.1 + (0.8 * 0.1) ** 2)
    assert dependent > 1 - independent_system_reliability


def test_beta_factor_boundaries_reduce_to_independent_and_common_cause_limits():
    from reliability import beta_factor_parallel_failure_probability

    assert beta_factor_parallel_failure_probability(0.2, 0.0, 2) == pytest.approx(0.2**2)
    assert beta_factor_parallel_failure_probability(0.2, 1.0, 2) == pytest.approx(0.2)


def test_beta_posterior_interval_is_reproducible_and_contains_posterior_mean():
    from reliability import beta_posterior_interval

    first = beta_posterior_interval(9, 3, confidence=0.95, samples=12000, seed=71)
    second = beta_posterior_interval(9, 3, confidence=0.95, samples=12000, seed=71)
    assert first == second
    mean = 9 / 12
    assert 0.0 <= first[0] < mean < first[1] <= 1.0


def test_fault_tree_parameter_uncertainty_returns_reproducible_credible_band():
    from reliability import fault_tree_parameter_uncertainty

    posterior = {"A": (2.0, 98.0), "B": (4.0, 96.0)}
    first = fault_tree_parameter_uncertainty(
        posterior, [["A", "B"]], samples=1500, confidence=0.90, seed=12
    )
    second = fault_tree_parameter_uncertainty(
        posterior, [["A", "B"]], samples=1500, confidence=0.90, seed=12
    )
    assert first == second
    mean, lower, upper = first
    assert 0.0 <= lower <= mean <= upper <= 1.0
    assert upper > lower


def test_monte_carlo_fault_tree_returns_wilson_interval_and_is_reproducible():
    from reliability import monte_carlo_fault_tree_probability, fault_tree_probability

    probabilities = {"A": 0.1, "B": 0.2, "C": 0.3}
    cuts = [["A", "B"], ["A", "C"]]
    first = monte_carlo_fault_tree_probability(probabilities, cuts, trials=100000, seed=99)
    second = monte_carlo_fault_tree_probability(probabilities, cuts, trials=100000, seed=99)
    exact = fault_tree_probability(probabilities, cuts)
    assert first == second
    estimate, lower, upper = first
    assert lower <= exact <= upper
    assert abs(estimate - exact) < 0.002


def test_fault_tree_sensitivity_ranks_shared_event_by_birnbaum_importance():
    from reliability import fault_tree_sensitivity

    got = fault_tree_sensitivity({"A": 0.1, "B": 0.2, "C": 0.3}, [["A", "B"], ["A", "C"]])
    assert got[0][0] == "A"
    assert got[0][1] == pytest.approx(1 - (1 - 0.2) * (1 - 0.3))
    assert got[1][0] == "C"
    assert got[2][0] == "B"


def test_beta_factor_rejects_invalid_inputs():
    from reliability import beta_factor_parallel_failure_probability

    with pytest.raises(ValueError):
        beta_factor_parallel_failure_probability(0.1, 1.2, 2)
    with pytest.raises(ValueError):
        beta_factor_parallel_failure_probability(0.1, 0.2, 1)


def test_posterior_uncertainty_rejects_unknown_cut_set_event():
    from reliability import fault_tree_parameter_uncertainty

    with pytest.raises(ValueError, match="Unknown basic event"):
        fault_tree_parameter_uncertainty({"A": (1.0, 1.0)}, [["B"]], samples=10)

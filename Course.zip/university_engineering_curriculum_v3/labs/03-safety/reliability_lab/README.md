# Lab 3 — Quantitative reliability, common-cause failure and uncertainty

**Runtime:** Python 3.11+ and pytest; standard library only.  
**Local verification:** 19 tests pass.  
**Purpose:** Teaching calculations and sensitivity experiments. This is not a certified PRA, SIL verification, safety approval or replacement for a validated reliability tool.

## Run

```bash
python -m pytest -q
python analysis_example.py
```

The example uses a fixed random seed (`2026`) so its simulation output is reproducible. All numerical probabilities in the example are hypothetical. Do not present them as field failure rates or as evidence that a real control system is acceptably safe.

## Models and equations

### 1. Classical independent blocks

For a series system of independent components with reliabilities \(R_i\):

\[
R_{series}=\prod_i R_i
\]

For an active parallel system with independent component failures:

\[
R_{parallel}=1-\prod_i(1-R_i)
\]

`parallel_reliability()` takes component **reliabilities** as inputs. It does not take failure probabilities. In a two-channel redundant system with per-channel failure probability \(q\), the system failure probability under independence is \(q^2\).

### 2. Beta-factor common-cause approximation

A simple beta-factor model partitions a per-channel failure probability \(q\) into a shared common-cause fraction \(\beta q\) and an independent portion \((1-\beta)q\). For \(n\) identical redundant channels, this lab uses:

\[
Q_{sys}\approx \beta q+((1-\beta)q)^n
\]

For \(q=0.01\), \(\beta=0.20\), and two channels, independent failures give \(0.01^2=0.0001\), while the beta-factor approximation gives \(0.002064\). The difference shows why naive redundancy calculations can be dangerously optimistic when common causes are plausible.

This is a simplified static approximation with identical channels and a disjoint common-cause/independent-mode interpretation. It does not represent staggered proof tests, repair, exposure windows, diagnostic coverage, latent failure accumulation, shared utilities in detail or dependencies between multiple common-cause groups. State the model's scope and data source before using it.

### 3. Bayesian parameter uncertainty

A Beta prior is conjugate to a Bernoulli observation model. If \(p\sim Beta(\alpha,\beta)\), then observing \(s\) occurrences and \(f\) non-occurrences gives:

\[
 p\mid data\sim Beta(\alpha+s,\;\beta+f)
\]

`beta_binomial_posterior()` updates parameters. `beta_posterior_interval()` samples the posterior and returns an equal-tail credible interval. This is a probability statement about an unknown parameter conditioned on the prior and data model; it is not the same as a frequentist confidence interval. Censoring, changing exposure, non-identical populations, selection bias and dependent observations require different models.

`fault_tree_parameter_uncertainty()` samples independent Beta posteriors for each basic-event probability, evaluates the small fault tree exactly for each draw, and reports the sampled posterior mean and equal-tail credible interval for top-event probability. The independence of the *parameter posteriors* is an additional assumption and must not be confused with a validated causal-dependence model.

### 4. Aleatory simulation and Monte Carlo error

`monte_carlo_fault_tree_probability()` simulates top-event occurrences with fixed basic-event probabilities. It returns the sample estimate plus a 95% Wilson interval for the Monte Carlo binomial sampling error. This interval does not include uncertainty in the input probabilities; use the separate Beta-parameter propagation function for that question.

Use a fixed seed, compare the simulation estimate with `fault_tree_probability()` for small trees, and report the number of trials. A Monte Carlo result is an estimate with sampling error, not a proof of a design property.

### 5. Sensitivity

`fault_tree_sensitivity()` returns Birnbaum importance for each basic event:

\[
I_i=P(Top\mid X_i=1)-P(Top\mid X_i=0)
\]

For the monotone OR-of-ANDs structures used here, this is evaluated exactly by setting one event probability to 1 and 0. It measures absolute local influence on top-event probability. It is **not** a complete risk-priority score: consequence, exposure, uncertainty, intervention feasibility and cost still matter.

## Worked exercise

The example defines the top event as:

\[
Top=(SENSOR\land CONTROLLER)\lor(SENSOR\land POWER)
\]

Use the code to compare the exact result, the seeded aleatory estimate and the posterior parameter-uncertainty band. Explain why the last two intervals answer different questions. Then remove `SENSOR` from one cut set and predict how the Birnbaum ranking changes before re-running.

## Required report

Define the top event, mission/demand profile, basic events, units and operating assumptions. Include the cut sets, the independent and common-cause models, Beta prior/data interpretation, Monte Carlo seed/trial count, credible/confidence interval labels, sensitivity ranking and limitations. Identify common utilities, maintenance errors, design similarity and latent faults that could create dependencies. Separate calculated results from expert assumptions and from measured field evidence.

## Limits

`fault_tree_probability()` enumerates all \(2^n\) basic-event states and is intended for small teaching trees. The beta-factor formula is a simplified approximation. Monte Carlo covers only the specified model. None of these routines establishes the validity of the hazard analysis, the adequacy of the model, the completeness of cut sets, the acceptability of residual risk or compliance with a safety standard.

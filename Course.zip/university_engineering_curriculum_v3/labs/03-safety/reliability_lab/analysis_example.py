"""Reproducible worked example for uncertainty-aware safety analysis."""
from __future__ import annotations

import json

from reliability import (
    beta_factor_parallel_failure_probability,
    fault_tree_parameter_uncertainty,
    fault_tree_probability,
    fault_tree_sensitivity,
    monte_carlo_fault_tree_probability,
)


def main() -> None:
    # Each value is a hypothetical mission/demand failure probability, not a
    # field-derived rate. The common-cause beta is a teaching assumption.
    component_q = 0.01
    beta = 0.20
    independent_two_channel_failure = component_q**2
    beta_factor_two_channel_failure = beta_factor_parallel_failure_probability(
        component_failure_probability=component_q,
        beta_factor=beta,
        channel_count=2,
    )

    probabilities = {"SENSOR": 0.01, "CONTROLLER": 0.02, "POWER": 0.015}
    minimal_cut_sets = [["SENSOR", "CONTROLLER"], ["SENSOR", "POWER"]]
    exact_top_event = fault_tree_probability(probabilities, minimal_cut_sets)
    sensitivity = fault_tree_sensitivity(probabilities, minimal_cut_sets)

    # Priors/posteriors are hypothetical Beta distributions. They must be
    # estimated from relevant exposure data and a justified observation model.
    posterior_parameters = {
        "SENSOR": (3.0, 997.0),
        "CONTROLLER": (2.0, 998.0),
        "POWER": (4.0, 996.0),
    }
    parameter_mean, parameter_low, parameter_high = fault_tree_parameter_uncertainty(
        posterior_parameters,
        minimal_cut_sets,
        samples=5000,
        confidence=0.95,
        seed=2026,
    )
    mc_mean, mc_low, mc_high = monte_carlo_fault_tree_probability(
        probabilities,
        minimal_cut_sets,
        trials=100000,
        seed=2026,
    )

    result = {
        "model_scope": "Hypothetical small fault tree; not an operational risk estimate",
        "beta_factor_example": {
            "component_failure_probability": component_q,
            "beta_factor": beta,
            "channels": 2,
            "independent_system_failure_probability": independent_two_channel_failure,
            "beta_factor_system_failure_probability": beta_factor_two_channel_failure,
        },
        "fault_tree": {
            "basic_event_probabilities": probabilities,
            "minimal_cut_sets": minimal_cut_sets,
            "exact_top_event_probability": exact_top_event,
            "Birnbaum_importance_descending": sensitivity,
        },
        "parameter_uncertainty": {
            "assumption": "Independent Beta posteriors for each basic-event probability",
            "posterior_parameters": posterior_parameters,
            "posterior_mean_top_event_probability": parameter_mean,
            "equal_tail_95_percent_credible_interval": [parameter_low, parameter_high],
            "samples": 5000,
            "seed": 2026,
        },
        "aleatory_monte_carlo": {
            "fixed_basic_event_probabilities": probabilities,
            "estimated_top_event_probability": mc_mean,
            "wilson_95_percent_interval": [mc_low, mc_high],
            "trials": 100000,
            "seed": 2026,
        },
    }
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()

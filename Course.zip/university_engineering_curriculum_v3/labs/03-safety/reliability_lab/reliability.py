"""Small, validated reliability and fault-tree calculations for teaching.

Assumptions are explicit: component failures are independent unless the
fault-tree structure itself reuses a basic event. Common-cause dependence
requires a separate model and must not be hidden inside these functions.
"""
from __future__ import annotations

import math
from collections.abc import Iterable, Mapping, Sequence


def _probabilities(values: Iterable[float]) -> list[float]:
    result = [float(value) for value in values]
    if not result:
        raise ValueError("at least one probability is required")
    if any(not math.isfinite(p) or p < 0.0 or p > 1.0 for p in result):
        raise ValueError("probabilities must be finite values in [0, 1]")
    return result


def series_reliability(reliabilities: Iterable[float]) -> float:
    """Reliability of a series system with independent component failures."""
    return math.prod(_probabilities(reliabilities))


def parallel_reliability(reliabilities: Iterable[float]) -> float:
    """Reliability of an active parallel system with independent components."""
    values = _probabilities(reliabilities)
    return 1.0 - math.prod(1.0 - p for p in values)


def exponential_reliability(failure_rate: float, mission_time: float) -> float:
    """R(t)=exp(-lambda*t), for constant hazard rate lambda >= 0."""
    if not math.isfinite(failure_rate) or failure_rate < 0:
        raise ValueError("failure_rate must be finite and non-negative")
    if not math.isfinite(mission_time) or mission_time < 0:
        raise ValueError("mission_time must be finite and non-negative")
    return math.exp(-failure_rate * mission_time)


def weibull_reliability(mission_time: float, eta: float, beta: float) -> float:
    """Two-parameter Weibull survival function; eta>0 and beta>0."""
    if not math.isfinite(mission_time) or mission_time < 0:
        raise ValueError("mission_time must be finite and non-negative")
    if not math.isfinite(eta) or eta <= 0:
        raise ValueError("eta must be finite and positive")
    if not math.isfinite(beta) or beta <= 0:
        raise ValueError("beta must be finite and positive")
    return math.exp(-((mission_time / eta) ** beta))


def beta_binomial_posterior(
    alpha: float, beta: float, successes: int, failures: int
) -> tuple[float, float]:
    """Update Beta(alpha,beta) after Bernoulli observations.

    A success means the event of interest occurred. The return is the
    posterior (alpha, beta) pair, not a point estimate or a safety claim.
    """
    if not math.isfinite(alpha) or alpha <= 0 or not math.isfinite(beta) or beta <= 0:
        raise ValueError("prior alpha and beta must be finite and positive")
    if not isinstance(successes, int) or not isinstance(failures, int):
        raise ValueError("successes and failures must be integers")
    if successes < 0 or failures < 0:
        raise ValueError("observation counts must be non-negative")
    return alpha + successes, beta + failures


def fault_tree_probability(
    basic_event_probabilities: Mapping[str, float],
    minimal_cut_sets: Sequence[Sequence[str]],
) -> float:
    """Exact OR-of-ANDs top-event probability under independent basics.

    Enumerates all 2^n states, so this is intentionally suitable only for a
    small teaching example. Reused basic events are handled exactly; events
    are assumed independent. Empty cut sets are rejected because they make
    the top event certain and usually indicate a modeling mistake.
    """
    if not basic_event_probabilities:
        raise ValueError("at least one basic event is required")
    names = list(basic_event_probabilities)
    probs = _probabilities(basic_event_probabilities.values())
    if len(set(names)) != len(names):
        raise ValueError("basic event names must be unique")
    cuts = [tuple(cut) for cut in minimal_cut_sets]
    if not cuts or any(not cut for cut in cuts):
        raise ValueError("at least one non-empty cut set is required")
    unknown = sorted({event for cut in cuts for event in cut if event not in basic_event_probabilities})
    if unknown:
        raise ValueError(f"Unknown basic event(s): {', '.join(unknown)}")
    total = 0.0
    for mask in range(1 << len(names)):
        state_probability = 1.0
        failed = set()
        for i, name in enumerate(names):
            is_failed = bool(mask & (1 << i))
            p = probs[i]
            state_probability *= p if is_failed else (1.0 - p)
            if is_failed:
                failed.add(name)
        top_event = any(all(event in failed for event in cut) for cut in cuts)
        if top_event:
            total += state_probability
    return total


def beta_factor_parallel_failure_probability(
    component_failure_probability: float,
    beta_factor: float,
    channel_count: int = 2,
) -> float:
    """Simplified static beta-factor approximation for redundant channels.

    The component failure probability ``q`` is partitioned into a common-cause
    part ``beta*q`` and an independent per-channel part ``(1-beta)*q``. Under
    the stated disjoint-mode approximation, the system fails if the common
    cause occurs or every independent channel fails:

        Q_system ~= beta*q + ((1-beta)*q)**channel_count

    This is a teaching approximation for identical channels and a defined
    demand/mission profile. It is not a time-dependent CCF model, proof-test
    model, or a substitute for a validated dependent-failure analysis.
    """
    q = float(component_failure_probability)
    beta = float(beta_factor)
    if not math.isfinite(q) or not 0.0 <= q <= 1.0:
        raise ValueError("component_failure_probability must be finite and in [0, 1]")
    if not math.isfinite(beta) or not 0.0 <= beta <= 1.0:
        raise ValueError("beta_factor must be finite and in [0, 1]")
    if not isinstance(channel_count, int) or isinstance(channel_count, bool) or channel_count < 2:
        raise ValueError("channel_count must be an integer >= 2")
    common_cause = beta * q
    independent_per_channel = (1.0 - beta) * q
    return common_cause + independent_per_channel**channel_count


def _validate_beta_parameters(alpha: float, beta: float) -> tuple[float, float]:
    a, b = float(alpha), float(beta)
    if not math.isfinite(a) or a <= 0.0 or not math.isfinite(b) or b <= 0.0:
        raise ValueError("Beta distribution parameters must be finite and positive")
    return a, b


def _validate_simulation(samples: int, confidence: float) -> tuple[int, float]:
    if not isinstance(samples, int) or isinstance(samples, bool) or samples < 1:
        raise ValueError("samples/trials must be a positive integer")
    level = float(confidence)
    if not math.isfinite(level) or not 0.0 < level < 1.0:
        raise ValueError("confidence must be finite and strictly between 0 and 1")
    return samples, level


def _sample_quantile(sorted_values: Sequence[float], probability: float) -> float:
    """Linear-interpolated empirical quantile (Hyndman-Fan type 7)."""
    if not sorted_values:
        raise ValueError("at least one sample is required")
    if not 0.0 <= probability <= 1.0:
        raise ValueError("quantile probability must be in [0, 1]")
    position = probability * (len(sorted_values) - 1)
    lower = int(math.floor(position))
    upper = int(math.ceil(position))
    fraction = position - lower
    return sorted_values[lower] * (1.0 - fraction) + sorted_values[upper] * fraction


def beta_posterior_interval(
    alpha: float,
    beta: float,
    confidence: float = 0.95,
    samples: int = 20000,
    seed: int = 2026,
) -> tuple[float, float]:
    """Monte Carlo equal-tail credible interval for a Beta posterior.

    The result is a posterior credible interval for the unknown Bernoulli
    probability, not a frequentist confidence interval. The interval is
    reproducible when ``seed`` and all inputs are fixed.
    """
    a, b = _validate_beta_parameters(alpha, beta)
    samples, confidence = _validate_simulation(samples, confidence)
    import random

    rng = random.Random(seed)
    draws = sorted(rng.betavariate(a, b) for _ in range(samples))
    tail = (1.0 - confidence) / 2.0
    return _sample_quantile(draws, tail), _sample_quantile(draws, 1.0 - tail)


def fault_tree_parameter_uncertainty(
    beta_posteriors: Mapping[str, tuple[float, float]],
    minimal_cut_sets: Sequence[Sequence[str]],
    samples: int = 10000,
    confidence: float = 0.95,
    seed: int = 2026,
) -> tuple[float, float, float]:
    """Propagate independent Beta parameter posteriors through a small tree.

    Returns (posterior mean, lower credible bound, upper credible bound) for
    the top-event probability. Each Monte Carlo draw samples each basic-event
    probability from its Beta posterior, then evaluates the fault tree exactly
    by state enumeration. The Beta posteriors are assumed independent; any
    dependence between basic-event rates needs an explicit joint model.
    """
    if not beta_posteriors:
        raise ValueError("at least one basic-event posterior is required")
    samples, confidence = _validate_simulation(samples, confidence)
    if len(beta_posteriors) > 16:
        raise ValueError("parameter-uncertainty enumeration is limited to 16 basic events")
    parameters = {
        name: _validate_beta_parameters(alpha, beta)
        for name, (alpha, beta) in beta_posteriors.items()
    }
    # Reuse the exact tree validator before starting the sampling loop.
    means = {name: alpha / (alpha + beta) for name, (alpha, beta) in parameters.items()}
    fault_tree_probability(means, minimal_cut_sets)

    import random

    rng = random.Random(seed)
    top_event_draws = []
    for _ in range(samples):
        sampled_probabilities = {
            name: rng.betavariate(alpha, beta)
            for name, (alpha, beta) in parameters.items()
        }
        top_event_draws.append(fault_tree_probability(sampled_probabilities, minimal_cut_sets))
    ordered = sorted(top_event_draws)
    tail = (1.0 - confidence) / 2.0
    return (
        math.fsum(top_event_draws) / samples,
        _sample_quantile(ordered, tail),
        _sample_quantile(ordered, 1.0 - tail),
    )


def monte_carlo_fault_tree_probability(
    basic_event_probabilities: Mapping[str, float],
    minimal_cut_sets: Sequence[Sequence[str]],
    trials: int = 100000,
    seed: int = 2026,
) -> tuple[float, float, float]:
    """Simulate aleatory top-event occurrence and return a Wilson 95% interval.

    Input probabilities are treated as fixed. This is separate from
    ``fault_tree_parameter_uncertainty``, which propagates epistemic parameter
    uncertainty. The interval quantifies Monte Carlo sampling error only.
    """
    trials, _ = _validate_simulation(trials, 0.95)
    probabilities = _probabilities(basic_event_probabilities.values())
    names = list(basic_event_probabilities)
    if len(names) != len(probabilities):
        raise ValueError("basic event names must be unique")
    cuts = [tuple(cut) for cut in minimal_cut_sets]
    # Validate cut sets and unknown event names using the analytical routine.
    fault_tree_probability(basic_event_probabilities, cuts)

    import random

    rng = random.Random(seed)
    failures = 0
    for _ in range(trials):
        failed_events = {
            name for name, probability in zip(names, probabilities)
            if rng.random() < probability
        }
        if any(all(event in failed_events for event in cut) for cut in cuts):
            failures += 1

    estimate = failures / trials
    z = 1.959963984540054
    z_squared = z * z
    denominator = 1.0 + z_squared / trials
    centre = (estimate + z_squared / (2.0 * trials)) / denominator
    half_width = (
        z * math.sqrt(estimate * (1.0 - estimate) / trials + z_squared / (4.0 * trials * trials))
        / denominator
    )
    return estimate, max(0.0, centre - half_width), min(1.0, centre + half_width)


def fault_tree_sensitivity(
    basic_event_probabilities: Mapping[str, float],
    minimal_cut_sets: Sequence[Sequence[str]],
) -> list[tuple[str, float]]:
    """Return Birnbaum importance for each basic event, highest first.

    For this monotone coherent OR-of-ANDs fault tree, importance is
    P(top | event failed) - P(top | event working), evaluated exactly by
    setting that event's probability to 1 and 0. It is an absolute local
    sensitivity, not a risk ranking that includes exposure or intervention
    cost. Ties are sorted alphabetically for reproducibility.
    """
    probabilities = {name: float(value) for name, value in basic_event_probabilities.items()}
    fault_tree_probability(probabilities, minimal_cut_sets)
    importance = []
    for name in probabilities:
        failed = dict(probabilities)
        working = dict(probabilities)
        failed[name] = 1.0
        working[name] = 0.0
        value = fault_tree_probability(failed, minimal_cut_sets) - fault_tree_probability(working, minimal_cut_sets)
        importance.append((name, max(0.0, value)))
    return sorted(importance, key=lambda item: (-item[1], item[0]))

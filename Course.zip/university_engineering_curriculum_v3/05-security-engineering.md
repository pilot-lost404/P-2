# Course 5 — Security Engineering
**Level:** Upper-undergraduate / early graduate  
**Duration:** 14 teaching weeks  
**Expected workload:** 8–10 hours per week  
**Practical environment:** Local lab applications, containers, OWASP Juice Shop or another intentionally vulnerable training system  
**Prerequisites:** Programming, HTTP/API basics, databases, operating systems and networking.

## Course description

Security engineering is the discipline of engineering systems so that assets and missions remain protected under realistic threats and operational constraints. It is broader than adding authentication, installing a scanner or performing a penetration test. Security must shape requirements, architecture, implementation, procurement, operation, maintenance and retirement.

This course develops a systems view of security. It covers security objectives, assets, adversaries, trust boundaries, threat modeling, security requirements, identity, authentication, authorization, cryptographic services, application and API security, data protection, secure development, supply-chain risk, testing, monitoring and incident response. The recurring tank-control platform makes consequences concrete: a remote command endpoint is not just a web route; it is a pathway to a physical effect.

All offensive exercises must be performed only in intentionally vulnerable labs or systems for which the student has explicit authorization. The goal is to learn to identify and prevent weaknesses, not to access real systems without permission.

## Learning outcomes

Students should be able to:
1. Define security objectives and identify assets, trust boundaries and adversaries.
2. Build data-flow threat models and apply STRIDE or another justified method.
3. Convert threats and protection needs into verifiable security requirements.
4. Distinguish identification, authentication, authorization and accountability.
5. Design session, token and access-control mechanisms with explicit assumptions.
6. Explain confidentiality, integrity, authenticity, signatures, key exchange and password hashing.
7. Analyze common web/API vulnerabilities and identify root causes.
8. Apply secure data handling, secrets management and secure configuration.
9. Integrate security into requirements, architecture, code review, CI/CD and operations.
10. Design security tests and incident-response evidence without overclaiming assurance.

---

## Week 1 — Security objectives, assets and threat models

### 1.1 What is being protected?

Security engineering begins by identifying assets and the consequences of their compromise. An asset may be data, a service, a physical process, a credential, a safety function, an identity, an operational capability or an organization's ability to deliver a mission.

The CIA triad—confidentiality, integrity and availability—is a starting vocabulary:
- Confidentiality: prevent unauthorized disclosure.
- Integrity: prevent or detect unauthorized or accidental alteration.
- Availability: preserve timely access to authorized users.

Other properties commonly matter: authenticity, accountability, non-repudiation, privacy, safety and resilience. These properties can conflict. Strong authentication may increase operator friction; broad availability may increase attack surface; detailed logging may improve accountability but expose sensitive data.

### 1.2 Asset and adversary analysis

Identify who may threaten the system, their capability, access, motivation and constraints. Threats may be malicious, accidental or environmental. A curious unauthorized user, compromised supplier, malicious insider, ransomware operator and faulty integration partner are not interchangeable threat actors.

For the tank service, assets include: control authority, configuration thresholds, operator identities, command records, telemetry, audit logs, signing keys, database availability and the integrity of local safety constraints.

### Worked example

An attacker who steals an operator token may issue an authorized-looking command. A network attacker may replay a valid command. A database administrator may alter the audit trail. A compromised gateway may publish false telemetry. Each scenario affects different assets and requires different controls.

### Laboratory

Create an asset register with owner, business/safety consequence, confidentiality requirement, integrity requirement, availability target, dependencies and recovery priority. List at least five adversary types and explain what they can plausibly do.

---

## Week 2 — Trust boundaries and data-flow threat modeling

Threat modeling is a structured process for asking how a design could be attacked or misused, what the consequences would be, and which controls are justified. It should be performed early and repeated as the design changes.

A data-flow diagram should show external entities, processes, data stores, data flows and trust boundaries. The trust boundary marks a change in authority or security assumptions—for example, the boundary between the public Internet and a cloud API, or between a cloud service and a local controller network.

STRIDE categorizes threat classes:
- Spoofing identity;
- Tampering with data or code;
- Repudiation of actions;
- Information disclosure;
- Denial of service;
- Elevation of privilege.

STRIDE is a prompting technique, not a risk score. It helps ensure that reviewers consider different threat types. A threat model should record the specific scenario, affected asset, attack preconditions, impact, existing control, proposed mitigation, owner and verification evidence.

### Worked example

Data flow: Operator browser → public API → command service → gateway → local controller. Trust boundaries exist at browser/API, service/gateway and gateway/controller. Potential threats include stolen session (spoofing), command modification (tampering), missing audit record (repudiation), leaked telemetry (information disclosure), request flooding (DoS) and a low-privilege user changing system-wide thresholds (elevation of privilege).

### Laboratory

Draw the capstone data-flow diagram. Apply STRIDE to each process, store and flow. Record at least 12 concrete threat scenarios; avoid writing generic labels without a plausible attack path.

---

## Week 3 — Risk assessment and security requirements

Security risk combines the likelihood of a threat scenario and its impact, but both estimates are context-dependent. A risk register should preserve the scenario and rationale instead of hiding everything in a single score. Vulnerability severity, exploitability, asset criticality, exposure and business impact are related but distinct concepts. CVSS is a vulnerability severity framework; it is not by itself a complete business risk assessment.

A security requirement should be testable and traceable. Example:
`SEC-004: The command API shall authorize each command against the authenticated principal's role and the target facility's ownership relationship before accepting the command.`

This requirement is stronger than "the API shall be secure." It identifies the operation and the decision criteria. It still needs test cases for valid owner, non-owner, revoked user, stale identity state, missing facility, guessed object ID and privileged role misuse.

Security design principles include least privilege, complete mediation, defense in depth, fail-safe defaults, separation of duties, secure by default, minimize attack surface, economy of mechanism and assume breach. Treat them as design reasoning aids, not slogans.

### Laboratory

Write 15 security requirements for the command platform. Trace each requirement to one or more threats, design elements and verification tests. Include negative authorization cases.

---

## Week 4 — Identity, authentication and session management

Identification states who a principal claims to be. Authentication verifies that claim. Authorization determines what the authenticated principal may do. Accountability records actions and decisions sufficiently to support investigation and governance. These are distinct control stages.

Authentication factors are commonly grouped into knowledge (something known), possession (something held) and inherence (something inherent). Multi-factor authentication requires independent factor categories; two passwords are not two factors. Phishing-resistant authentication uses mechanisms designed to bind authentication to the legitimate service, such as WebAuthn/FIDO2 in suitable contexts.

Passwords should not be stored in plaintext or with a fast general-purpose hash. Use a password-hashing function designed to resist offline guessing, with a unique salt and work factor appropriate to the deployment. Argon2id is a common modern choice; scrypt, bcrypt or PBKDF2 may be selected where compatibility or policy requires them. Parameters must be benchmarked and revisited as hardware improves.

Sessions and tokens require expiration, revocation strategy, secure transport, audience/scope restrictions, protection from theft and safe storage. A signed JWT is not automatically encrypted, revocable or safe to trust indefinitely. Validate issuer, audience, expiry, signature algorithm and key lifecycle; do not accept attacker-controlled algorithm choices or unvalidated claims.

### Laboratory

Implement login and logout in a local training API. Store password verifiers with an appropriate password-hashing library. Add lockout/rate limiting that avoids trivial denial of service, session expiry and a revocation strategy. Write tests for expired, malformed and revoked credentials.

---

## Week 5 — Authorization and access-control models

Authorization determines whether a subject may perform an action on an object under a defined context. Role-Based Access Control (RBAC) assigns permissions to roles. Attribute-Based Access Control (ABAC) evaluates subject, object, action and environmental attributes. Relationship-based access control checks relationships such as ownership, membership or delegation.

Role checks alone often fail at the resource level. An operator role may be allowed to read telemetry, but only for facilities assigned to that operator. The server must verify object-level authorization on every request. Hiding a button in the UI is not authorization.

A policy should specify default deny, permitted operations, scope, delegation, privilege escalation controls, separation of duties and audit requirements. Administrative paths should be deliberately designed because administrators have the potential to bypass normal controls.

### Worked example

Let `canIssueCommand(user, facility, command)` require:
1. user is authenticated;
2. account is active;
3. user has `OPERATOR` or `SUPERVISOR` permission;
4. user is assigned to the facility;
5. command is within the user's operational scope;
6. no higher-priority local safety interlock prohibits the action.

Each condition should have a separate test. The UI may help users understand permissions, but the authoritative decision belongs at the server-side enforcement point and the local controller retains its own safety authority.

### Laboratory

Build an RBAC plus resource-ownership policy. Test direct object references, role changes, revoked accounts, cross-facility requests and privilege inheritance. Produce an authorization matrix.

---

## Week 6 — Cryptography for system engineers

Cryptography provides mechanisms; it does not define a complete security architecture.

- A cryptographic hash maps input to a fixed-size digest. It supports integrity checks and constructions such as digital signatures. It does not authenticate the sender by itself.
- A message authentication code (MAC) provides integrity and authenticity to parties sharing a secret key.
- Symmetric encryption uses a shared secret key and is efficient for bulk data.
- Asymmetric cryptography uses a key pair and supports key exchange and digital signatures.
- A digital signature lets a verifier check that a message was signed by the holder of a private key and was not altered, subject to key trust and algorithm assumptions.
- Authenticated encryption (for example, an AEAD mode) provides confidentiality and integrity together when used correctly.

Key management is often harder than choosing an algorithm. Define key generation, storage, access, rotation, revocation, backup, compromise response and destruction. Never embed long-lived secrets in source code or container images. Prefer managed secret stores or hardware-backed key protection where justified.

Transport Layer Security (TLS) protects communication when correctly configured and certificates are validated. It does not fix an application that trusts the wrong user or authorizes access to the wrong record.

### Laboratory

Use a local cryptography library to compare hash, HMAC and authenticated encryption. Show that a hash alone does not prove who created a message. Demonstrate certificate validation failure in a local test environment.

---

## Week 7 — Input handling and common application vulnerabilities

Many application vulnerabilities arise when untrusted input crosses an interpreter or authority boundary. SQL injection occurs when data is interpreted as SQL syntax. Use parameterized queries rather than string concatenation. Cross-site scripting (XSS) occurs when untrusted data is interpreted as executable browser content; use context-sensitive output encoding and safe templating. Cross-site request forgery (CSRF) exploits a browser's ambient credentials; use appropriate anti-CSRF defenses and SameSite cookie controls according to the application design.

Other important classes include path traversal, unsafe file handling, server-side request forgery (SSRF), insecure deserialization, command injection, memory-safety errors, race conditions and insecure defaults. Validate inputs at trust boundaries, but do not rely on validation alone. Encode outputs for their destination context and use APIs that preserve data/code separation.

### Worked example: injection

Unsafe:
```python
sql = "SELECT * FROM users WHERE email = '" + email + "'"
```

Safer:
```python
cursor.execute(
    "SELECT * FROM users WHERE email = %s",
    (email,)
)
```

The parameterized form sends the value separately from the SQL syntax. It still requires correct authorization and error handling; it does not make every database operation safe automatically.

### Laboratory

Use OWASP Juice Shop or another intentionally vulnerable lab. Identify one injection flaw and one access-control flaw. Write a regression test for each fix. Do not test public systems without written authorization.

---

## Week 8 — API security and distributed command authority

APIs expose operations and data to callers. Secure API design requires authentication, authorization, input validation, schema control, rate limiting, replay protection where needed, safe error handling, auditability and versioning. Treat every identifier supplied by the client as untrusted. A resource ID is not proof of ownership.

Commands that affect physical or financial state need stronger semantics than read-only queries. Use unique command identifiers, expiration or freshness constraints, target binding, audit records and local policy enforcement. A valid cryptographic token should not allow a remote command to bypass a local emergency stop or other safety interlock.

Rate limits should be defined by principal, resource, operation and system capacity. Overly broad limits can allow one client to block another. Backpressure, quotas, request-size limits and queue controls help protect availability.

### Laboratory

Create a command API threat test plan. Test unauthorized, out-of-scope, replayed, stale, oversized and malformed commands. Verify the controller rejects commands that violate local constraints even when they are correctly authenticated by the cloud service.

---

## Week 9 — Data protection, privacy and secrets

Classify data by sensitivity, integrity and retention requirements. Collect only the data needed for a defined purpose. Minimize copies, control access, encrypt sensitive information in transit and at rest where required, and define deletion and backup-expiration behavior. Encryption at rest protects against some storage disclosure scenarios; it does not stop an authorized application process from exposing the data.

Logs can become a high-value attack target. Do not log passwords, access tokens, private keys or unnecessary personal data. Protect audit records against unauthorized modification and deletion, separate operational logs from security audit trails when appropriate, synchronize clocks, and restrict access.

Secrets include passwords, API keys, database credentials, signing keys, certificates and recovery codes. A secret lifecycle includes creation, distribution, storage, access, rotation, revocation and destruction. Rotating a leaked secret without investigating its use may leave an attacker with an active session or copied data.

### Laboratory

Create a data-classification table and retention policy. Scan a test repository for deliberately planted secrets. Replace hard-coded values with environment/secret-store configuration and document rotation steps.

---

## Week 10 — Secure architecture and defense in depth

Security architecture defines trust boundaries, enforcement points, privilege separation, data flows and failure behavior. Defense in depth uses multiple controls so that one control's failure does not automatically expose the asset. Multiple controls are useful only when their failure modes are sufficiently independent.

A local control system may use network segmentation, mutual authentication, least-privilege service identities, command authorization, local allowlists, signed updates and physical controls. The local controller should validate the command's scope and retain local interlocks. A remote cloud service should not become an unrestricted bridge into a physical control network.

Secure defaults matter: disable unused services, remove default credentials, restrict management interfaces, validate certificates, pin supported protocol versions through configuration and avoid exposing debug endpoints. A secure architecture should describe what happens when authentication services, DNS, certificate validation or centralized logging become unavailable.

### Laboratory

Produce a deployment diagram with zones and conduits. For every trust boundary, identify controls, owner, allowed flows, denied flows and failure behavior. Review whether a compromised cloud account can directly disable local safety functions.

---

## Week 11 — Secure development lifecycle and supply-chain security

Security is integrated into each development activity:
- requirements: identify security/privacy needs and threat assumptions;
- design: perform threat modeling and architecture review;
- implementation: apply safe APIs, code review and secure configuration;
- build: protect toolchains, dependencies, secrets and artifact provenance;
- test: run static, dynamic, dependency and targeted security tests;
- release: sign artifacts, record versions and approve known risks;
- operations: monitor, patch, investigate and recover.

SAST analyzes source or compiled code without executing the deployed application. DAST tests a running system from an external perspective. Software composition analysis (SCA) identifies known risks in dependencies. Fuzzing explores unexpected inputs. Manual review identifies design and business-logic problems that tools may not understand. None of these proves the system secure.

Supply-chain threats include malicious packages, compromised build systems, exposed CI credentials, unsigned artifacts, dependency confusion, typosquatting and compromised maintainers. Use dependency pinning, provenance, signatures, least-privilege CI, reproducible builds where feasible and an inventory such as an SBOM.

### Laboratory

Set up a small CI pipeline with static analysis, dependency scanning, unit tests and secret detection. Review the output manually. Identify false positives, false negatives and controls that require human assessment.

---

## Week 12 — Security testing and assurance

Security testing begins with a threat model and security requirements. Tests should cover both allowed and forbidden behavior. A penetration test can demonstrate that an attack path exists; it cannot prove that no vulnerabilities exist. Negative results are bounded by scope, test knowledge, environment and time.

OWASP ASVS provides versioned requirements for application security verification. Reference the version alongside requirement IDs to avoid ambiguity when identifiers change. Use the ASVS as a security requirement and testing baseline, tailoring it to the application risk and architecture.

A good finding includes affected asset, preconditions, reproducible steps in the authorized test environment, impact, evidence, severity rationale, remediation and regression test. Avoid exaggerating a scanner alert into confirmed exploitation without evidence.

### Laboratory

Map at least 15 ASVS 5.0.0 requirements to the capstone. Select five controls and create negative test cases. Record pass/fail evidence and explain what the tests do not prove.

---

## Week 13 — Monitoring, incidents and cyber resilience

Preventive controls cannot guarantee that compromise never occurs. Detection and response are therefore essential. A security incident process identifies events, triages impact, contains the threat, preserves evidence, eradicates persistence, restores service and performs lessons learned.

Monitoring should focus on meaningful signals: anomalous login patterns, privilege changes, unusual command rates, policy denials, unexpected configuration changes, failed integrity checks, unusual data access and suspicious dependency behavior. Alert design should minimize noise and ensure someone owns the response.

Resilience includes the ability to maintain critical functions, isolate compromised elements, recover trusted state and restore service safely. A system should define how it behaves when identity, cloud control, database, network, DNS, time source or update service is unavailable. Availability under attack does not mean accepting every command.

### Laboratory

Write an incident playbook for a compromised operator account and another for a suspected gateway compromise. Include containment authority, evidence preservation, credential rotation, safe local operating mode and restoration criteria.

---

## Week 14 — Integrated security review and capstone

The final security assessment should connect each threat scenario to an asset, requirement, architectural control, implementation mechanism, test and operational owner. It should also document residual risk and unresolved assumptions.

### Final submission

Submit asset and data classification registers, DFD with trust boundaries, threat register, security requirements, identity and authorization model, cryptographic/key-management design, secure deployment diagram, CI security checks, test evidence and two incident playbooks.

### End-of-course problems

1. A user is authenticated. Does that imply they may issue a command to every facility?  
   **Solution:** No. Authentication establishes identity; authorization must evaluate role, resource ownership, scope and contextual restrictions.

2. Why is a signed JWT not necessarily confidential?  
   **Solution:** A typical signed JWT provides integrity/authenticity of claims, not encryption. Its payload can be readable by anyone who obtains the token unless an encryption format is used.

3. Why does a penetration test with no findings not prove the system is secure?  
   **Solution:** The result is bounded by test scope, methods, coverage, assumptions and time. It demonstrates that the chosen tests did not reveal a flaw, not that no flaw exists.

## Selected sources and further study

- NIST SP 800-160 Vol. 1 Rev. 1, *Engineering Trustworthy Secure Systems*: https://csrc.nist.gov/pubs/sp/800/160/v1/r1/final
- NIST SP 800-218, Secure Software Development Framework (SSDF): https://csrc.nist.gov/pubs/sp/800/218/final
- OWASP Application Security Verification Standard 5.0.0: https://owasp.org/www-project-application-security-verification-standard/
- OWASP Cheat Sheet Series: https://cheatsheetseries.owasp.org/
- OWASP Juice Shop: https://owasp.org/www-project-juice-shop/
- PortSwigger Web Security Academy: https://portswigger.net/web-security
- MITRE ATT&CK: https://attack.mitre.org/
- CWE: https://cwe.mitre.org/
- NIST Cybersecurity Framework 2.0: https://www.nist.gov/cyberframework
- Ross Anderson, *Security Engineering*, 3rd ed. author site: https://www.cl.cam.ac.uk/archive/rja14/book.html

Use standards and versioned checklists as controlled baselines. The NIST and OWASP documents are not substitutes for jurisdiction-specific privacy, safety, sector or contractual requirements.

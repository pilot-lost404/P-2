# University-Level Engineering Curriculum — Edition 3

**Six advanced-undergraduate / early-graduate self-study courses · 14 weeks each · Research snapshot 21 November 2026**

Edition 3 preserves the Edition 2 course pack and deepens its practical spine with six implementation/evidence workstreams. This is a self-study curriculum, not an accredited university award, professional certification or engineering approval.

## Start here

1. Read [`00-COURSE-GUIDE.md`](00-COURSE-GUIDE.md).
2. Study the six expanded readers in [`course-readers/`](course-readers/). Each keeps the original course notes and adds an Edition 3 implementation annex.
3. Follow the six 14-week source maps in [`weekly-reading-maps/`](weekly-reading-maps/).
4. Complete the [`84-weekly-problem bank`](assessments/WEEKLY-PROBLEM-BANK.md) and 30 longer worked problems in [`assessments/`](assessments/).
5. Complete the [integrated capstone](projects/INTEGRATED-CAPSTONE-V2.md) and retain the evidence required in [`LAB_MANUAL.md`](LAB_MANUAL.md).
6. Use [`09-SOURCE-LIBRARY.md`](09-SOURCE-LIBRARY.md) for primary course/standard references and research provenance.

## Courses and Edition 3 additions

| Course | Edition 3 implementation/evidence artifact | Key boundary |
|---|---|---|
| Distributed Systems | Deterministic Go Raft simulator with nine protocol/fault tests | Single-process simulator; not a real RPC or disk-durable service |
| Model-Based Systems Engineering | Expanded SysML v2 text, 18 measurable requirements, trace validator and 22 trace links | SysML import/render/semantic validation in SysON is still external |
| Safety and Risk Analysis | Common-cause, Bayesian uncertainty, Monte Carlo and Birnbaum reliability exercises | Simplified teaching models; not a validated PRA or safety approval |
| Verification and Validation | Safe/unsafe bounded quorum models, Python counterexamples and TLA+ specs/configs | Python tests pass; TLC has not been run here |
| Security Engineering | Loopback-only secure training API, tenant isolation and audit chain | Not production-ready and not a formal ASVS certification |
| Data Systems and Databases | Disk pages, buffer pool, WAL/redo recovery and persistent B+ tree | No SQL/ARIES/MVCC; PostgreSQL 18 external labs remain unexecuted here |

Assessment material includes 84 weekly problems with checkpoints, 30 longer worked problems and a six-course capstone rubric.

## Verification and audit

- [`audit/ACADEMIC-AUDIT-V3.md`](audit/ACADEMIC-AUDIT-V3.md) — local verification evidence and an author self-audit against the same rubric.
- [`audit/COURSE-SCORECARD-V3.csv`](audit/COURSE-SCORECARD-V3.csv) — criterion-level score for each course.
- [`audit/VERIFICATION-MATRIX-V3.md`](audit/VERIFICATION-MATRIX-V3.md) — exact commands, observed results and unexecuted external gates.
- [`audit/REMEDIATION-ROADMAP-V3.md`](audit/REMEDIATION-ROADMAP-V3.md) — remaining work required before a 100/100 claim can be considered.
- [`verification/progress.md`](verification/progress.md) — task execution ledger.

The Edition 3 self-audit is **91.00/100**, not 100. External SysML validation, TLC execution, PostgreSQL execution, independent subject-expert review and learner pilot remain open. The rubric is editorial and is not accreditation.

## Research workflow

EFT was used in order (Exa → Firecrawl → TinyFish), with Context7 for current technical APIs and official documentation. FMHY was used solely as a learning-resource discovery index; pirated course copies were excluded. Research and source-level decisions are recorded in `09-SOURCE-LIBRARY.md` and `docs/research/FMHY-RESOURCE-REVIEW.md`.

## Safety

All safety, security and database experiments must use synthetic data and disposable local environments. Never connect course code to live pumps, valves, industrial controllers or public infrastructure. Security testing outside the provided local lab requires explicit authorization.

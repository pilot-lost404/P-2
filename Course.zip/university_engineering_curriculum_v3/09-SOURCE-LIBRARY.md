# Source Library and Research Register
**Research snapshot:** 21 November 2026  
**Selection rule:** Prefer university course material, primary standards bodies, official documentation, original research and established textbooks. A resource is included because it supports a specific part of the curriculum, not merely because it is popular.

## 1. Distributed systems

| Resource | Type | How to use it |
|---|---|---|
| MIT 6.5840 Distributed Systems (Spring 2026) — https://pdos.csail.mit.edu/6.824/ | Full university subject | Use lectures, papers, labs and exams to deepen Weeks 1–14. The course explicitly covers fault tolerance, replication and consistency. |
| Harvard CS 2620 (2026) — https://read.seas.harvard.edu/cs2620/2026/ | University lectures/problem sets | Especially useful for consensus, FLP, failure detectors, Paxos, state-machine replication and Byzantine faults. |
| CMU 15-440/640 — https://www.cs.cmu.edu/~dga/15-440/F12/ | University course | Systems programming, communication, distributed algorithms and practical exercises. |
| Raft paper — https://raft.github.io/raft.pdf | Research paper | Read after the textbook introduction; focus on safety properties and log replication rules. |
| DDIA, 2nd ed. (2026) — https://martin.kleppmann.com/2026/03/24/designing-data-intensive-applications-2e.html | Textbook | Broad treatment of reliable, scalable and maintainable data-intensive systems. Check publisher/library access. |
| Go memory model — https://go.dev/ref/mem | Official language documentation | Use for concurrency correctness in Go labs. |
| Go context package — https://pkg.go.dev/context | Official API documentation | Use for deadlines, cancellation and request propagation. |

## 2. MBSE and systems engineering

| Resource | Type | How to use it |
|---|---|---|
| NASA Systems Engineering Handbook — https://www.nasa.gov/reference/systems-engineering-handbook/ | Government handbook | Lifecycle, stakeholder needs, requirements, architecture, product realization, verification and validation. |
| NASA-HDBK-1009A — https://standards.nasa.gov/standard/NASA/NASA-HDBK-1009 | Active NASA technical handbook | Practical model-building examples that connect SysML work to NASA SE processes and work products. Document date 12 March 2025; registry marked active during research. |
| OMG SysML — https://www.omg.org/sysml/ | Language standard portal | Formal specifications and the transition from SysML v1.x to SysML v2. |
| OMG SysML specification history — https://www.omg.org/spec/SysML/About-SysML/ | Standards record | Formal specification versions and dates. SysML v2.0 was adopted in 2025. |
| SEBoK — https://sebokwiki.org/ | Systems engineering body of knowledge | Use as a broad reference and cross-check definitions. |
| Eclipse SysON — https://eclipse.dev/syson/ and https://doc.mbse-syson.org/ | Open-source tool and documentation | Hands-on SysML v2 modeling. Check the supported language subset and maturity of the exact release used. |
| Capella — https://mbse-capella.org/ | Open-source MBSE workbench | Alternative model-based architecture method/tool; useful if a SysML v2 implementation is not practical. |

## 3. Safety and risk analysis

| Resource | Type | How to use it |
|---|---|---|
| MIT STAMP Institute handbooks — https://www.mit.stamp-institute.com/handbooks | Free handbooks | Primary teaching reference for STPA and CAST methods and worked examples. |
| Leveson, *Engineering a Safer World* — https://mitpress.mit.edu/9780262533690/engineering-a-safer-world/ | Textbook | Systems-theoretic foundations of safety and accident causation. Check library/publisher access. |
| NASA Systems Engineering Handbook — https://www.nasa.gov/reference/systems-engineering-handbook/ | Government handbook | Lifecycle integration and safety/reliability engineering context. |
| IEC Functional Safety — https://www.iec.ch/functional-safety | Standards portal | Official route to functional-safety standards such as IEC 61508. Full normative standards may require purchase or institutional access. |
| UK HSE risk guidance — https://www.hse.gov.uk/risk/ | Government guidance | General risk assessment and safety management concepts. |
| SEBoK safety engineering knowledge area — https://sebokwiki.org/ | Knowledge base | Overview and cross-references to systems safety engineering methods. |

## 4. Verification and validation

| Resource | Type | How to use it |
|---|---|---|
| NASA V&V distinctions — https://www.nasa.gov/reference/2-4-distinctions-between-product-verification-and-product-validation/ | Government guidance | Clear distinction between requirements compliance and intended-use validation. |
| NASA product verification — https://www.nasa.gov/reference/5-3-product-verification/ | Government guidance | Verification method selection, preparation, evidence and reporting. |
| NASA V&V plan outline — https://www.nasa.gov/reference/appendix-i-verification-and-validation-plan-outline/ | Planning template | Use to structure a project V&V plan. |
| ISTQB CTFL syllabus — https://www.istqb.org/certifications/certified-tester-foundation-level | Testing syllabus | Test design, levels, process and terminology. |
| Google Testing Blog — https://testing.googleblog.com/ | Engineering practice | Testing strategy, automation, testability and maintenance. |
| Hypothesis — https://hypothesis.readthedocs.io/ | Official tool documentation | Property-based testing for generated inputs and invariants. |
| RPI CSCI 4964/6964 Software Verification (Fall 2025) — https://www.cs.rpi.edu/academics/courses/fall25/csci4964/ | University course | Proof methods, specification, program correctness and concurrent-program verification; pair with a model checker/theorem prover lab. |
| TLA+ resources — https://lamport.azurewebsites.net/tla/tla.html | Formal specification resources | Model and reason about concurrent/distributed behavior. |

## 5. Security engineering

| Resource | Type | How to use it |
|---|---|---|
| NIST SP 800-160 Vol. 1 Rev. 1 — https://csrc.nist.gov/pubs/sp/800/160/v1/r1/final | Government systems security engineering publication | Core reference for engineering trustworthy secure systems through the lifecycle. Final publication date: November 2022. |
| NIST SP 800-218 SSDF — https://csrc.nist.gov/pubs/sp/800/218/final | Government guidance | Secure software development practices integrated into the SDLC. |
| NIST SP 800-61 Rev. 3 — https://csrc.nist.gov/pubs/sp/800/61/r3/final | Government incident-response publication | Current incident-response recommendations; use Rev. 3 rather than the superseded Rev. 2. |
| OWASP ASVS 5.0.0 — https://owasp.org/www-project-application-security-verification-standard/ | Versioned security verification standard | Requirements and tests for modern web applications and services. Stable release date shown by OWASP: 30 May 2025. |
| OWASP Cheat Sheet Series — https://cheatsheetseries.owasp.org/ | Practitioner guidance | Focused implementation guidance for authentication, sessions, validation, secrets and common controls. |
| OWASP Juice Shop — https://owasp.org/www-project-juice-shop/ | Intentionally vulnerable training app | Safe environment for authorized application-security practice. |
| PortSwigger Web Security Academy — https://portswigger.net/web-security | Free web security training | Guided labs for common web vulnerabilities. |
| MITRE ATT&CK — https://attack.mitre.org/ | Adversary behavior knowledge base | Structure threat scenarios around observed attacker tactics and techniques. |
| CWE — https://cwe.mitre.org/ | Weakness taxonomy | Classify root causes rather than only naming scanner findings. |
| NIST CSF 2.0 — https://www.nist.gov/cyberframework | Cybersecurity framework | Governance and risk-management context. |

## 6. Data systems and databases

| Resource | Type | How to use it |
|---|---|---|
| CMU 15-445/645 Fall 2026 — https://15445.courses.cs.cmu.edu/fall2026/ | University course | Database internals, relational algebra, storage, indexing, query processing, transaction processing, recovery and programming projects. Syllabus checked 19 Nov 2026. |
| CMU Database Group courses — https://db.cs.cmu.edu/courses/ | University course directory | Find related undergraduate and graduate database subjects. |
| PostgreSQL 18 documentation — https://www.postgresql.org/docs/18/ | Official DBMS documentation | SQL, indexes, transactions, concurrency, backup and administration. |
| PostgreSQL MVCC — https://www.postgresql.org/docs/18/mvcc.html | Official DBMS documentation | Multi-version concurrency control and transaction isolation behavior. |
| PostgreSQL transaction isolation — https://www.postgresql.org/docs/18/transaction-iso.html | Official DBMS documentation | Engine-specific anomaly and isolation semantics. |
| MIT 6.5830 Database Systems — https://dsg.csail.mit.edu/6.5830/ | University course | Database systems and data-management topics. |
| *Database System Concepts* — https://www.db-book.com/ | Textbook companion site | Relational theory, SQL, transaction processing and database design. |
| DDIA, 2nd ed. (2026) — https://martin.kleppmann.com/2026/03/24/designing-data-intensive-applications-2e.html | Textbook | Distributed data systems, storage, replication and processing. |

## 7. Open learning directories and FMHY findings

FMHY's educational directory was reviewed as a discovery index: https://fmhy.net/educational

Useful legitimate discovery routes listed there include:
- MIT OpenCourseWare: https://ocw.mit.edu/
- Class Central: https://www.classcentral.com/
- OpenLearn: https://www.open.edu/openlearn/
- Saylor Academy: https://www.saylor.org/
- OpenHPI: https://open.hpi.de/
- Yale open courses: https://oyc.yale.edu/
- edX: https://www.edx.org/
- Khan Academy: https://www.khanacademy.org/

FMHY is not treated as a quality authority or a licensing guarantee. It contains a mixture of educational resources, directories and links that may have different access and copyright conditions. The curriculum uses official university pages, primary standards publishers and legitimate learning platforms. It does **not** rely on torrent links, unauthorized textbook scans or pirated course copies.

## 8. Access and licensing notes

- "Free to read" does not necessarily mean public domain, open license or permission to redistribute.
- University lecture notes and assignments remain subject to their institution's terms. Follow the original course's academic-integrity rules; use them for study, not unauthorized submission.
- ISO, IEC, IEEE, OMG and other standards may have copyright/licensing terms. Use official publisher/library access. This course material summarizes concepts in original language and does not reproduce normative standards text.
- Commercial textbooks are recommended as optional deep references. Buy, borrow or use institutional access.
- Code examples in this pack are original teaching examples. Validate them in your own environment and do not treat educational snippets as production-ready.

## 9. Research method and limitations

The source set was researched using EFT in the user-defined order: Exa search and page retrieval, Firecrawl search/scrape, then TinyFish search/fetch. FMHY was inspected as a discovery index and each selected resource was checked against its originating university, standard publisher or official documentation. Context7 was used for the current Go, PostgreSQL 18 and Eclipse SysON technical documentation. Search highlights were treated as leads; course structure and version-sensitive details were checked against official pages wherever a fetch succeeded.

Research coverage is not exhaustive. A course page may expose only its public syllabus, and private LMS material, instructor feedback, grading tests and restricted standards were not accessed. Some external tasks (SysML import/render, PostgreSQL query-plan and restore experiments) still require execution by the learner in the named toolchain. Those are explicitly marked as not locally executed in the V2 verification matrix.

Research snapshot is 21 November 2026. Course pages and software documentation may change. Check the official page before installing tools or relying on a current standard edition.

## 9. Current university benchmark checks (2026)

These are comparative benchmarks, not source material to copy wholesale. Use the course's public pages, lecture notes and primary documentation according to the institution's terms.

| Benchmark | Verified current content | What it changes in this curriculum |
|---|---|---|
| MIT 6.5840 Distributed Systems, Spring 2026 — https://pdos.csail.mit.edu/6.824/ | Lecture/paper-driven graduate subject with programming labs for MapReduce, key-value service, Raft, Raft-backed KV and sharding, plus exams and optional project | DS course now needs staged implementations, fault injection, protocol reasoning and exams, not just an overview |
| CMU 15-445/645 Database Systems, Fall 2026 — https://15445.courses.cs.cmu.edu/fall2026/ | Upper-level database internals; storage, indexes, query processing, concurrency, recovery, parallel/distributed architecture; BusTub programming projects | Database course now includes storage/index/transaction internals and a database-engine project extension |
| Johns Hopkins 645.631 Introduction to MBSE, Fall 2026 — https://apps.ep.jhu.edu/syllabus/fall-2026/645.631.82 | 14-module sequence from MBSE and SysML package/structure/behavior/parametric/requirements/allocations to method, traceability, architecture and trade studies; hands-on modeling tools and exported model artifacts | MBSE lab requires a complete SysML model, traceability, change impact and exported views |
| RPI CSCI 4964/6964 Software Verification (Fall 2025) — https://www.cs.rpi.edu/academics/courses/fall25/csci4964/ | University course | Use its software-verification syllabus as a university benchmark for specification, proof and correctness topics alongside maintained formal-methods documentation. |


## 10. Primary standards and implementation references added

| Source | Version/date | Curriculum use |
|---|---|---|
| OMG SysML v2 portal — https://www.omg.org/sysml/SysML-2.htm | SysML v2 specification family, official OMG portal | MBSE language and model interoperability. Use the formal specification as authority for syntax/semantics. |
| Eclipse SysON user manual — https://doc.mbse-syson.org/syson/v2025.10.0/ | 2025.10.0 documentation | SysML v2 text import/export and rendered model views; confirm tool release and supported subset before lab use. |
| NASA Systems Engineering Handbook — https://www.nasa.gov/wp-content/uploads/2018/09/nasa_systems_engineering_handbook_0.pdf | NASA/SP-2016-6105 Rev 2 | Lifecycle, requirements, architecture, verification/validation and engineering reviews. |
| NASA System Safety Handbook Vol. 2 — https://ntrs.nasa.gov/archive/nasa/casi.ntrs.nasa.gov/20150015500.pdf | NASA publication | Safety objectives, integrated safety analysis and safety-case examples. |
| STPA Handbook — https://www.flighttestsafety.setp.org/images/STPA_Handbook.pdf | Leveson and Thomas, 2018 | Control structures, unsafe control actions and causal scenarios. Verify permitted educational use; do not redistribute without permission. |
| NIST SP 800-160 Vol. 1 Rev. 1 — https://csrc.nist.gov/pubs/sp/800/160/v1/r1/final | Final, November 2022 | Systems security engineering across the lifecycle. |
| NIST SP 800-218 SSDF — https://csrc.nist.gov/pubs/sp/800/218/final | Final publication page | Secure software development practices and lifecycle integration. |
| OWASP ASVS — https://owasp.org/www-project-application-security-verification-standard/ | Version 5.0.0 | Application-security verification requirements; map relevant controls to tests rather than treating ASVS as a threat model. |
| PostgreSQL documentation — https://www.postgresql.org/docs/18/ | PostgreSQL 18 | Version-specific SQL, MVCC, isolation, indexes, EXPLAIN, WAL and recovery behavior. |
| Go documentation — https://go.dev/doc/ | Current Go documentation | Concurrency primitives, memory model, race detector and testing APIs. Check minimum Go version before use. |

## 11. Research workflow and provenance

Research was conducted using EFT in the user-defined order: Exa discovery, Firecrawl search/scrape, then TinyFish search/fetch. FMHY's education page was inspected as a discovery index and filtered through the legitimacy/authority rules in `docs/research/FMHY-RESOURCE-REVIEW.md`. Context7 was queried for Go, PostgreSQL 18 and Eclipse SysON documentation; those implementation references informed the labs. Current course-year and tool-version statements are snapshots and should be refreshed before a later semester.

## 12. Edition 3 research and executable implementation references

**Research snapshot:** 21 November 2026. EFT was used in the user-defined order **Exa → Firecrawl → TinyFish**. Context7 was used to retrieve current API/tool documentation where a code example depends on a versioned library or CLI. FMHY was treated as a discovery index, not as evidence of academic quality or copyright permission.

| Source | Version/date observed | Specific use in Edition 3 | Source quality / caveat |
|---|---|---|---|
| [MIT 6.5840 Spring 2026 course](https://pdos.csail.mit.edu/6.824/) | Spring 2026 | Distributed systems course structure, paper readings, labs and assessments | Official MIT course primary source. The Raft lab implements a subset; this pack's simulator is not the full MIT assignment. |
| [MIT Lab 3: Raft](https://pdos.csail.mit.edu/6.824/labs/lab-raft1.html) | Spring 2026 | Leader election, log replication, persistence/restart, partitions and race-enabled tests | Official assignment. Membership changes are explicitly outside that lab's scope. |
| [MIT Lab 4: Fault-tolerant KV](https://pdos.csail.mit.edu/6.824/labs/lab-kvraft1.html) | Spring 2026 | Linearizable KV API, at-most-once client operations and snapshot layering | Official assignment. Edition 3 simulator stops short of this full service. |
| [MIT Lab 5: Sharded KV](https://pdos.csail.mit.edu/6.824/labs/lab-shard1.html) | Spring 2026 | Shard-controller design and migration | Official assignment. Reconfiguration in this assignment does not require changing Raft group membership. |
| [UW DSLabs teaching paper](https://ellismichael.com/papers/dslabs-eurosys19.pdf) | EuroSys 2019 | Why execution tests and model checking complement one another for distributed protocols | Original research paper; the Python bounded quorum exercise is only a tiny model and not the DSLabs framework. |
| [CMU 15-445 Fall 2026](https://15445.courses.cs.cmu.edu/fall2026/syllabus.html) | Fall 2026, updated 19 Nov 2026 | Upper-level DBMS internals, cumulative programming projects and exams | Official CMU course source. The local implementation is intentionally much smaller than BusTub. |
| [CMU Project 1: Buffer Pool](https://15445.courses.cs.cmu.edu/fall2026/project1/) | Fall 2026 | Disk pages, buffer frames, dirty state, pinning, replacement and thread safety | Official assignment; the new local buffer pool is single-process and not thread-safe. |
| [CMU Project 2: B+ Tree](https://15445.courses.cs.cmu.edu/fall2026/project2/) | Fall 2026 | Page-backed B+ tree, split/merge, iterators and latch coupling | Official assignment. Edition 3 implements insertion/split/read only; no delete/merge or latch coupling. |
| [CMU Project 3: Query Execution](https://15445.courses.cs.cmu.edu/fall2026/project3/) | Fall 2026 | Access methods, joins, aggregation, query plans and optimizer transformations | Official assignment. The local diskdb does not implement SQL or query execution. |
| [CMU Project 4: Concurrency Control](https://15445.courses.cs.cmu.edu/fall2026/project4/) | Fall 2026 | MVCC, timestamps, snapshot isolation and serializability | Official assignment. Its current project centers on optimistic MVCC; do not call it a full WAL/ARIES recovery project. |
| [JHU 645.631 MBSE syllabus](https://apps.ep.jhu.edu/syllabus/fall-2026/645.631.82) | Fall 2026 | 14-module MBSE sequence from language notation to requirements/architecture/trade studies | Official JHU syllabus, but public page is abridged and requires enrollment for complete course content. |
| [JHU 645.632 Applied Analytics MBSE](https://apps.ep.jhu.edu/syllabus/spring-2027/645.632.81) | Spring 2027 syllabus | Model queries, reports, variations, parametric analysis, model V&V and design reviews | Official JHU syllabus. The local SysML model has not been imported into a tool. |
| [OMG SysML v2 formal specification](https://www.omg.org/spec/SysML/2.0/Language/PDF) | Formal document dated March 2026 | Requirements, structure, behavior, constraints and verification syntax/semantics | Official normative standard. The example text in this pack requires parser validation before being treated as a valid model. |
| [SysML v2 Release repository](https://github.com/Systems-Modeling/SysML-v2-Release) | Formal adoption 30 June 2025; editorial update March 2026 | Training material and reference textual models, including requirements and verification cases | Official Systems Modeling release repo. Prefer its specification and examples over unofficial cheatsheets. |
| [Eclipse SysON documentation v2026.11.0](https://doc.mbse-syson.org/syson/v2026.11.0/) | v2026.11.0 | Current tool workflows, supported diagram families, model exchange and limitations | Maintained official tool docs. It states version management/branching/access control are not built in; use version-control/configuration-management tooling around the model. |
| [University of Maryland ENRE602](https://me.umd.edu/course-schedule/course/ENRE602) | Offered Fall 2026 | Quantitative reliability, FTA, RBD, FMEA, ETA and reliability data | Official university course page. The new beta-factor/Bayesian/MC code is a bounded teaching model, not a qualified PRA tool. |
| [University of Southampton FEEG6006](https://southampton.ac.uk/courses/modules/feeg6006.page) | Course page found in research | Reliability distributions, fault tree calculations and Monte Carlo methods | Official university module page. Confirm availability/current teaching year before following an enrollment plan. |
| [University of Surrey COM3028 Systems Verification](https://catalogue.surrey.ac.uk/2026-7/module/COM3028/SEMR2/2) | 2026/27 | Modal/temporal logic, LTL/CTL/CTL*, explicit/symbolic model checking, Hoare logic and labs | Official module catalogue; 15 credits and five labs listed. Strong V&V scope benchmark. |
| [TLA+ Tools release](https://github.com/tlaplus/tlaplus/releases/tag/v1.8.0) | v1.8.0 Clarke pre-release observed 15 Nov 2026 | TLC CLI for parsing/model checking the provided `.tla` and `.cfg` files | Official tool repository. Toolbox is no longer actively maintained; official repo recommends command line or VS Code extension. **TLC was not run in this build environment.** |
| [TLA+ Tools README / CLI usage](https://github.com/tlaplus/tlaplus) | Current repository docs | Java 11+ CLI invocation: `java -jar tla2tools.jar model.tla` | Official tool instructions. Local environment could not resolve GitHub to download the JAR; use a pinned/checksummed artifact. |
| [OWASP ASVS](https://owasp.org/projects/asvs) | v5.0.0 listed stable | Security requirements baseline and test mapping | Official OWASP project. An ASVS mapping is not a certification or proof all requirements are met. |
| [OWASP WSTG](https://owasp.org/www-project-web-security-testing-guide/latest/) | Latest rolling guide | Structured web-application testing methods | Official community-maintained guide; rolling content can change. Pin a release/commit for a formal course delivery. |
| [OWASP Juice Shop](https://owasp.org/projects/juice-shop) | Project release observed v20.2.0 | Controlled insecure application for authorized security training | Official OWASP training project. Must be kept local/isolated and used only for authorized exercises. |
| [NIST SP 800-160 Vol. 1 Rev. 1](https://csrc.nist.gov/pubs/sp/800/160/v1/r1/final) | November 2022 | Systems security engineering concepts, tasks and lifecycle integration | Primary NIST publication. |
| [NIST SP 800-218 SSDF](https://csrc.nist.gov/pubs/sp/800/218/final) | Version 1.1 | Secure software development lifecycle practices | Primary NIST publication. |
| [Python hashlib documentation](https://docs.python.org/3/library/hashlib.html) | Current CPython docs queried through Context7 | `scrypt` password KDF API and parameters | Official language/API documentation; deployment parameters require capacity review and tuning. |
| [Python hmac documentation](https://docs.python.org/3/library/hmac.html) | Current CPython docs queried through Context7 | Constant-time secret comparison using `compare_digest` | Official API docs; different input lengths/types can still leak metadata. |
| [Python secrets documentation](https://docs.python.org/3/library/secrets.html) | Current CPython docs queried through Context7 | Cryptographically strong session token generation | Official API docs; token lifecycle/storage still matters. |
| [Hypothesis stateful testing docs](https://hypothesis.readthedocs.io/en/latest/stateful.html) | Current docs queried through Context7 | Reference model for stateful/property testing | Official Hypothesis documentation. The current runtime did not have Hypothesis installed; Edition 3 uses deterministic standard-library generated histories and does not claim Hypothesis test results. |
| [PostgreSQL 18 MVCC](https://www.postgresql.org/docs/18/mvcc.html) | PostgreSQL 18 | Snapshot semantics and transaction isolation experiments | Official versioned docs. SQL lab scripts still require actual PostgreSQL 18 execution. |
| [PostgreSQL 18 WAL configuration](https://www.postgresql.org/docs/18/wal-configuration.html) | PostgreSQL 18 | Checkpoint and WAL durability reference | Official versioned docs. The local educational redo-only WAL is not PostgreSQL WAL nor ARIES. |
| [PostgreSQL 18 EXPLAIN](https://www.postgresql.org/docs/18/using-explain.html) | PostgreSQL 18 | Estimated/actual plans and safe query analysis | Official versioned docs. Use transaction rollback around modifying EXPLAIN ANALYZE experiments. |

### FMHY resource-discovery decisions

The [FMHY education index](https://fmhy.net/educational) was reviewed and used only to discover legal learning platforms/resources such as [MIT OpenCourseWare](https://ocw.mit.edu/), [edX](https://www.edx.org/), [CMU Open Learning Initiative](https://oli.cmu.edu/), [OpenLearn](https://www.open.edu/openlearn/), [Saylor Academy](https://learn.saylor.org/), [OpenHPI](https://open.hpi.de/), [Yale Open Courses](https://oyc.yale.edu/) and [Class Central](https://www.classcentral.com/). These aggregators are discovery routes, not validation of course depth. Entries pointing to torrents, Telegram mirrors or unauthorized course dumps were not used to source content. Full decision record: `docs/research/FMHY-RESOURCE-REVIEW.md`.

### Research-tool provenance

- **Exa:** broad semantic discovery for six course-specific research questions and original university/research materials; relevant pages were opened/fetched instead of accepting similarity-ranked snippets as ground truth.
- **Firecrawl:** six structured course/standard searches and focused page scrapes (MIT, CMU, JHU, NASA, OWASP, SysON, UMD, Surrey); returned sources were rated for usefulness.
- **TinyFish:** cross-check searches and focused page fetches for course outcomes, official assignment details and current tools.
- **Context7:** Go, PostgreSQL 18, SysON, TLA+ Tools, Python/CPython and Hypothesis documentation. Current APIs were used for lab designs; installed package availability was independently checked before claiming execution.

Current webpages can change; recheck tool releases and course editions before assigning the pack in a future semester.

# Laboratory Manual — Edition 3

The course-specific lab briefs and starter files live in `labs/`. Read the corresponding V2 course reader before each lab. All work must be performed in a disposable/local environment unless an institution has explicitly authorized another setup.

| Lab | Directory | Main artifact | Local verification status |
|---|---|---|---|
| 1A | `labs/01-distributed-systems/idempotency/` | Go idempotency/retry service with lost-response retry simulation | `go test -race -count=1 ./...` and `go vet ./...` passed in this build environment |
| 1B | `labs/01-distributed-systems/clocklab/` | Lamport and vector clocks | `go test -race -count=1 ./...` passed in this build environment |
| 2 | `labs/02-mbse/` | SysML v2 starter model, requirements, traceability | Files reviewed; import/render requires a learner's SysML v2 workbench and has not been run here |
| 3 | `labs/03-safety/reliability_lab/` | Reliability and fault-tree calculator | pytest suite passed; run `python -m pytest -q` in the directory |
| 4 | `labs/04-vv/modelcheck_lab/` | Explicit-state invariant checker | pytest suite passed; run `python -m pytest -q` in the directory |
| 5 | `labs/05-security/authorization_lab/` | Facility-scoped authorization reference model | pytest suite passed; run `python -m pytest -q` in the directory |
| 6A | `labs/06-data-systems/` | PostgreSQL 18 schema, query plans, isolation, backup/restore | SQL drafted and statically inspected; PostgreSQL/Docker absent in build environment, so database execution remains learner work |
| 6B | `labs/06-data-systems/tinydb/` | In-memory B+ tree: split/merge structure for inserts, point lookup, range scan and invariants | 8 pytest tests passed; in-memory teaching implementation only, not disk-backed or concurrent |

## Universal evidence template

For every lab, record:

1. **Objective:** The property or question being examined.
2. **Model:** The system boundary, abstractions and assumptions.
3. **Environment:** OS, runtime, dependency/tool versions and hardware where relevant.
4. **Procedure:** Exact reproducible commands or GUI steps.
5. **Expected result:** A criterion defined before running the test.
6. **Observed result:** Raw output, test logs, model warnings or query plans.
7. **Analysis:** Explain agreement or discrepancy, not only pass/fail.
8. **Limitations:** Unmodeled behavior, data limits, coverage gaps and external dependencies.
9. **Traceability:** Requirement, hazard or threat IDs and the artifact under test.
10. **Reproduction:** Clean checkout/setup instructions and cleanup steps.

## Tool safety

Do not connect these exercises to live industrial equipment. Run only the intentionally local vulnerable/security training environment with explicit authorization. Do not use production credentials, real personal data or destructive crash testing against non-disposable databases. Backups must be restored into an isolated target.


## Edition 3 implementation labs

| Lab | Directory | New deliverable | Verification status in this build |
|---|---|---|---|
| 1C | `labs/01-distributed/raftsim/` | Deterministic Raft teaching simulator and fault schedule | Go tests, race detector and vet passed; simulator-only, not network service |
| 2B | `labs/02-mbse/` | SysML v2 model, requirements baseline, traceability validator and planned verification cases | Traceability validator passed; SysML model NOT imported or semantically validated by SysON here |
| 3B | `labs/03-safety/reliability_lab/` | Common-cause approximation, Bayesian parameter uncertainty, Monte Carlo and sensitivity | 19 pytest tests passed; not a safety certification/PRA |
| 4B | `labs/04-vv/quorum_model/` and `labs/04-vv/tla-plus/` | Safe/unsafe bounded quorum model and counterexample | Python model tests pass; TLC NOT EXECUTED in this runtime |
| 5B | `labs/05-security/secure_service/` | Loopback-only secure training HTTP API and ASVS/WSTG matrix | 23 tests and live loopback smoke passed; not production security certification |
| 6C | `labs/06-data-systems/diskdb/` | Page file, LRU buffer pool, checksummed WAL, redo recovery and persistent B+ tree | See `audit/VERIFICATION-MATRIX-V3.md`; PostgreSQL 18 side-labs remain separate |

# Integrated Engineering Capstone — Water-Tank Control and Monitoring System

**Edition:** 2.0 · 21 November 2026  
**Level:** Advanced undergraduate / early graduate  
**Suggested duration:** 8–10 weeks alongside the six courses  
**Mode:** Individual implementation or teams of 2–3 with individually attributable analysis and code ownership  
**Safety boundary:** Simulation and benchtop demonstration only. No connection to real pumps, valves, mains voltage, public networks or live infrastructure.

## 1. Purpose

Design, model, implement and assure a small cyber-physical monitoring and control system. The capstone forces the student to connect requirements engineering, SysML/MBSE, distributed systems, database systems, safety analysis, security engineering and V&V. The objective is not to build a feature-rich dashboard. The objective is to demonstrate a coherent engineering argument from stakeholder need to architecture, implementation, hazard/threat controls, test evidence and residual risk.

## 2. Scenario

A facility operates a water tank with a level sensor, inlet valve, local controller, gateway and cloud monitoring service. The local controller must remain safe during cloud/network outages. Operators use a remote dashboard to observe telemetry and request target changes. Each telemetry event may be duplicated, delayed or delivered out of order. Commands may be retried after the response is lost. Accounts are scoped to facilities and roles. The data store must preserve measurement identity, command history and audit evidence.

The system has two distinct planes:

- **Local safety/control plane:** responsible for sensor plausibility, freshness, high-high shutdown, command expiry and safe local operation.
- **Cloud monitoring/management plane:** responsible for identity, authorization, durable command records, telemetry storage, history, audit and operator presentation.

A remote service must not be the only mechanism preventing a physical overflow. Loss of cloud connectivity must not disable the locally defined protective behavior.

## 3. System boundary and assumptions

### 3.1 Included
- Synthetic sensor telemetry and quality/freshness metadata.
- Local controller state machine or executable simulation.
- Valve command abstraction with explicit open/closed feedback state.
- Gateway protocol and retry/duplicate handling.
- Remote API and authorization decision.
- PostgreSQL logical data model and transaction semantics.
- Operator dashboard prototype or command-line client.
- Safety, security, verification and validation artefacts.

### 3.2 Excluded
- Real actuator wiring, physical process control, electrical design and certified safety instrumented systems.
- Production cloud hosting, public deployment or actual facility integration.
- Claims of compliance with IEC 61508, IEC 61511, ISO 26262, aviation or medical-device standards.
- A proof that the simulated system is safe in every real operating environment.

### 3.3 Illustrative operating assumptions
These values are defaults for learning, not approved safety limits:
- Tank capacity: 10,000 L.
- Normal target: 75%.
- High-high protective threshold: 90%.
- Sensor sample interval: 1 s.
- Data freshness limit: 3 s.
- Local protective response target: 250 ms after a valid high-high detection.
- Remote command expiry: 30 s from issue time.
- Gateway retry policy: bounded exponential backoff with jitter and a fixed overall deadline.
- Telemetry deduplication horizon: at least 7 days in the teaching deployment.

Every numeric value requires sensitivity analysis and stakeholder justification. The assumed 250 ms response includes only the modeled controller response unless the student separately models physical actuator closure time.

## 4. Stakeholders and needs

| Stakeholder | Need | Evidence of satisfaction |
|---|---|---|
| Facility operator | Understand current level, data freshness and controller mode | Scenario-based usability validation and display tests |
| Safety owner | Prevent overflow and unsafe actuation during invalid data or outages | Hazard controls, state model, fault-injection evidence |
| System administrator | Manage role assignments and access scope | Authorization model and negative tests |
| Maintenance technician | Identify failed sensors, stale data and communication outages | Diagnostic states and operational procedure |
| Data owner | Retain correct telemetry, command and audit history | Schema constraints, backup/restore and retention rules |
| Security owner | Prevent cross-facility access and command tampering/replay | Threat model, controls and abuse-case tests |

## 5. High-level requirements baseline

Treat each requirement as a controlled baseline item. Add rationale, owner, revision, source need, model element, verification method, acceptance criterion and status.

| ID | Requirement | Acceptance evidence |
|---|---|---|
| SYS-001 | The local controller shall continue its protective logic when cloud connectivity is unavailable. | Disconnect-network simulation; protective state still operates |
| SYS-002 | A measurement older than the configured freshness limit shall be marked invalid. | Boundary tests at limit−ε, limit and limit+ε |
| SYS-003 | Invalid/stale measurement data shall not authorize automatic valve opening. | State-transition model check and fault-injection test |
| SYS-004 | A valid high-high condition shall cause a local close-valve command within the approved response budget. | Timestamped simulation and timing analysis |
| SYS-005 | Every telemetry event shall have a stable event ID and per-source sequence number. | Duplicate/out-of-order message tests and database constraints |
| SYS-006 | A duplicate telemetry event ID shall not create a second logical measurement. | Retry/replay test and row-count evidence |
| SYS-007 | Every remote command shall include a unique command ID, expiry and target. | API schema/validation tests |
| SYS-008 | Repeating a command with the same ID and same content shall not create a second business effect. | Concurrent duplicate-request and lost-response tests |
| SYS-009 | Reusing a command ID with different content shall be rejected. | Negative idempotency-key conflict test |
| SYS-010 | The API shall authorize a command against the caller's active role and target facility. | Cross-facility and privilege-escalation tests |
| SYS-011 | An expired command shall not be forwarded for actuation. | Clock-boundary and replay tests |
| SYS-012 | Every remote command decision shall be auditable with actor, target, time and outcome. | Database integrity and audit query |
| SYS-013 | The dashboard shall visibly distinguish valid, stale, invalid and unavailable telemetry. | UI inspection and scenario-based validation |
| SYS-014 | The database shall enforce referential integrity across facility, tank, sensor and event records. | Invalid foreign-key and uniqueness tests |
| SYS-015 | A recoverable backup shall restore the approved data set into an isolated instance. | Recorded restore procedure, row-count checks and RTO/RPO |
| SYS-016 | Every approved requirement shall trace to at least one design/model element and verification case. | Automated/manual traceability audit |
| SYS-017 | High-priority hazards and threats shall have a recorded control, owner and residual-risk rationale. | Hazard/threat register review |
| SYS-018 | The system shall report the age of the latest telemetry observation separately from its value. | API contract and UI test |

The system requirements do not define physical safety certification. Derive lower-level requirements and identify unresolved stakeholder decisions.

## 6. Architecture deliverables

Produce at least two architecture alternatives before selecting one.

### 6.1 Required logical components
- Sensor adapter and data-quality validator.
- Local controller with explicit operating modes.
- Valve abstraction and feedback state.
- Gateway event buffer and retry worker.
- API authentication and authorization boundary.
- Command service with durable idempotency state.
- Telemetry ingestion service.
- PostgreSQL data store.
- Operator client/dashboard.
- Audit and monitoring subsystem.

### 6.2 Required sequence diagrams
1. Telemetry success and duplicate delivery.
2. Remote command accepted and executed locally.
3. Command commits but API response is lost; client retry returns stored result.
4. Cloud/network outage while local protection continues.
5. Stale sensor data followed by high-high independent shutdown.
6. Cross-facility user attempts a command and receives a deny decision.

### 6.3 Architecture decision records
For at least five decisions, record context, options, criteria, selected option, rejected alternatives, consequences and revisit trigger. Required decisions include local/cloud responsibility, message identity, command idempotency boundary, database isolation/constraints and authorization scope.

## 7. Six discipline work packages

### WP1 — MBSE and requirements
- System context and operational concept.
- Requirement hierarchy and unique IDs.
- SysML v2 structural, behavioral and parametric model (or justified alternative if tool support blocks import).
- Interfaces and allocation to components.
- Complete requirement-to-model-to-test traceability.
- Change impact assessment for one interface or timing parameter.

### WP2 — Distributed systems
- At-least-once message delivery with stable event identity and deduplication.
- Bounded retry, deadline propagation, retry budget and backpressure.
- Failure handling for lost response after commit.
- Explicit ordering and sequence-number policy.
- Network delay/partition/restart tests.
- Consistency statement that distinguishes what is guaranteed from what is not.

### WP3 — Database systems
- Normalized logical schema and key/constraint rationale.
- Indexes derived from a query workload.
- At least three query-plan measurements with actual rows and buffers.
- Two-session isolation experiment and transaction schedule analysis.
- Idempotency/outbox transaction design.
- Backup/restore rehearsal and RPO/RTO evidence.

### WP4 — Safety and reliability
- Losses, hazards, system constraints and initial hazard log.
- FMEA/FMECA with failure causes, detection, controls and actions.
- Quantitative RBD and FTA with units, model assumptions and common-cause discussion.
- STPA control structure, unsafe control actions and causal scenarios.
- Safety requirements allocated to design elements and tests.
- Safety case claims, evidence and defeaters/limitations.

### WP5 — Security engineering
- Assets, trust boundaries, data-flow diagram and threat model.
- STRIDE scenarios with likelihood/impact rationale.
- Authentication and facility/resource-scoped authorization policy.
- Command integrity, replay and expiry controls.
- Secret/key lifecycle and audit protection.
- Abuse-case test suite and residual-risk register.

### WP6 — Verification and validation
- V&V strategy and requirement verification matrix.
- Unit, integration, system and acceptance test cases.
- Boundary, negative, concurrency and fault-injection tests.
- At least one finite-state invariant model and counterexample.
- Performance/load experiment with p50/p95/p99 and saturation metrics.
- User validation scenarios and operational suitability findings.
- Anomaly report and release recommendation.

## 8. Milestones and weekly schedule

| Week | Milestone | Exit criteria |
|---:|---|---|
| 1 | Concept and boundary | Stakeholders, losses, system boundary and assumptions reviewed |
| 2 | Requirements baseline | 18 high-level requirements refined; IDs/acceptance criteria complete |
| 3 | Architecture alternatives | Two alternatives, decision matrix and ADRs reviewed |
| 4 | System model | Structure, behavior, interfaces and trace links drafted |
| 5 | Data/API design | Schema, message envelope, command protocol and threat boundary reviewed |
| 6 | Local controller prototype | State machine executes normal and protective paths; basic tests pass |
| 7 | Distributed integration | Gateway/API integration handles duplicate and lost-response cases |
| 8 | Safety/security analysis | FMEA, FTA, STPA and threat model linked to requirements and controls |
| 9 | V&V campaign | Negative, boundary, concurrency and fault-injection results captured |
| 10 | Final assurance review | Traceability, restore evidence, residual risks and oral defense complete |

## 9. Required repository structure

```text
capstone/
  README.md
  docs/
    system-context.md
    stakeholders-and-needs.md
    requirements.csv
    architecture-decisions/
    interface-control-document.md
    operational-concept.md
    assumptions-and-open-issues.md
  model/
    water-tank.sysml
    exports/
    traceability.csv
  safety/
    hazard-log.csv
    fmea.csv
    fault-tree.md
    stpa.md
    safety-case.md
  security/
    data-flow.md
    threat-register.csv
    security-requirements.csv
  database/
    schema.sql
    seed.sql
    queries.sql
    migration/
    backup-restore.md
  src/
    controller/
    gateway/
    api/
  tests/
    unit/
    integration/
    system/
    abuse-cases/
    model-checking/
  evidence/
    environment.txt
    test-results/
    query-plans/
    performance/
    restore/
  reports/
    verification-report.md
    validation-report.md
    final-engineering-review.md
```

The student may choose a different architecture or language, but must maintain the same artifact responsibilities and explain the deviation.

## 10. Acceptance tests

At minimum, automate and record the following:

1. Valid fresh telemetry is stored and shown as current.
2. Stale telemetry is visible as stale and cannot authorize valve opening.
3. Out-of-range telemetry is rejected or quarantined according to policy.
4. Duplicate telemetry event ID produces one logical record.
5. Out-of-order sequence numbers do not silently overwrite a newer accepted state.
6. API response lost after command commit; same-ID retry returns original result.
7. Same command ID with changed payload is rejected.
8. Concurrent duplicate command submissions create one business effect.
9. Expired command is rejected by cloud and local controller.
10. Cross-facility read and command attempts are denied.
11. Inactive user and revoked role are denied.
12. Cloud outage does not disable local high-high protective behavior.
13. Sensor stuck-low/stale fault produces safe modeled controller state.
14. Emergency stop cannot transition to valve-open state.
15. Database foreign-key and uniqueness constraints reject invalid data.
16. Query plan report includes actual rows, buffers and workload description.
17. Serialization anomaly is prevented or explicitly handled by selected isolation strategy.
18. Backup restore yields matching row counts and referential integrity.
19. Dashboard clearly distinguishes stale, invalid and unavailable telemetry.
20. All safety-critical requirements have approved acceptance criteria and test evidence.

Test IDs must trace to requirement IDs. A test that only checks an HTTP 200 response is not sufficient to verify a business or safety property.

## 11. Scoring rubric (100 points)

| Dimension | Points | Full-credit evidence |
|---|---:|---|
| Requirements, model and traceability | 15 | Testable requirements, coherent model, allocations and change impact |
| Architecture and distributed correctness | 15 | Explicit failure model, retry/idempotency, ordering and consistency argument |
| Database design and operations | 10 | Sound schema, useful indexes, isolation reasoning, restore evidence |
| Safety analysis and safety case | 15 | Quantitative and STPA analysis linked to verifiable constraints |
| Security engineering | 10 | Threat model, scoped authorization, command integrity and abuse tests |
| Verification and validation | 20 | Requirements coverage, fault injection, reproducibility, independent validation |
| Implementation quality | 10 | Clear structure, robust error handling, automated tests and operability |
| Technical communication and oral defense | 5 | Honest claims, limitations, code/model ownership and clear evidence |

### Critical-failure caps
The capstone cannot score above 59 if any of these remain unresolved:
- Cloud API is the only protection against an identified local overflow hazard.
- Cross-facility commands can be executed by an otherwise valid user.
- Duplicate retry can create repeated non-idempotent command effects.
- Safety-critical requirements have no acceptance criteria or evidence.
- Final report claims an external tool, test or restore operation was run when it was not.

## 12. Oral defense and code/model ownership

The student must be able to modify one requirement, one state-machine transition, one authorization rule, one SQL constraint and one test during review, then explain the impact on downstream artifacts. If generated or AI-assisted material is used, the student remains responsible for correctness, licensing, security and ability to defend every submitted artifact.

## 13. Final report structure

1. Executive engineering summary and scope.
2. Stakeholders, operational concept and system boundary.
3. Requirements baseline and verification criteria.
4. Architecture alternatives, selected design and ADRs.
5. System model and traceability.
6. Distributed protocol and failure assumptions.
7. Data model, query plans and transaction analysis.
8. Safety analysis, quantitative assumptions and safety case.
9. Threat model and security architecture.
10. V&V campaign, results and anomalies.
11. Operational readiness, backup/restore and monitoring.
12. Residual risk, limitations, open issues and recommendation.

## 14. What this capstone does not prove

A successful student project demonstrates learning and provides evidence about a defined simulation/prototype. It is not a production readiness certificate, a safety certification, a security accreditation, a regulatory compliance assessment or proof that unmodeled physical behavior is safe. Those judgments require appropriate domain experts, validated data, independent assurance and the applicable approval process.

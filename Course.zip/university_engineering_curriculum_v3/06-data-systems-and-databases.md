# Course 6 — Data Systems and Databases
**Level:** Upper-undergraduate / early graduate  
**Duration:** 14 teaching weeks  
**Expected workload:** 8–10 hours per week  
**Practical platform:** PostgreSQL 18 or another current relational database; optional implementation exercises in C++/Rust/Go  
**Prerequisites:** Programming, data structures, discrete mathematics and basic command-line use.

## Course description

A database system is not merely a place to store rows. It is a software system that models information, enforces integrity, processes queries, coordinates concurrent transactions, persists state, recovers from failure and exposes interfaces to applications. Data systems engineering extends this foundation to replication, partitioning, streaming, analytical workloads, data governance and distributed storage.

This course covers the relational model, conceptual/logical/physical design, relational algebra, SQL, normalization, storage engines, indexes, query processing, transaction semantics, concurrency control, recovery, migration, data quality and distributed database trade-offs. It uses PostgreSQL for concrete experiments and links database behavior to the remote tank platform.

The course deliberately distinguishes logical correctness from physical performance. A schema can be normalized but slow for a workload; an index can improve one query and degrade writes; a transaction can be atomic locally but not across independent services.

## Learning outcomes

Students should be able to:
1. Explain the relational model, keys, constraints and relational algebra.
2. Transform an ER model into relations and assess normalization.
3. Write SQL queries using joins, grouping, subqueries and window functions.
4. Explain storage pages, records, buffer pools, indexes and query plans.
5. Analyze ACID properties, transaction schedules and isolation anomalies.
6. Compare locking, timestamp ordering, optimistic concurrency and MVCC.
7. Explain write-ahead logging, checkpoints, backups and point-in-time recovery.
8. Design safe schema migrations and data-quality controls.
9. Evaluate replication, sharding, consistency and distributed database trade-offs.
10. Design and benchmark a database-backed application with reproducible evidence.

---

## Week 1 — Data models and database system architecture

A data model defines the structure of information and the constraints on it. Common models include relational, document, key-value, graph and column-family models. The choice depends on access patterns, integrity requirements, query needs, scale, operational skills and consistency requirements. A fashionable model is not automatically the right model.

A database management system (DBMS) typically includes a query processor, optimizer, execution engine, storage manager, buffer manager, transaction manager, concurrency-control subsystem, log/recovery subsystem and catalog. The application submits logical queries; the DBMS chooses a physical plan and coordinates access to stored data.

Separate three design levels:
- **Conceptual model:** business entities, relationships and rules.
- **Logical model:** relations, keys, attributes and constraints.
- **Physical model:** data types, indexes, partitions, storage parameters and deployment.

The distinction makes change easier to reason about. A physical index should not redefine the business meaning of an entity.

### Worked example

For the tank platform, conceptual entities include Facility, Tank, Sensor, Measurement, Command, User, Role and AuditEvent. The logical design identifies primary and foreign keys. The physical design chooses partitioning for time-series measurements, indexes for facility/time queries and retention rules.

### Laboratory

Draw a conceptual ER model with cardinalities and optionality. Do not choose data types or indexes until the business relationships and integrity rules are clear.

---

## Week 2 — Relational model, keys and integrity

A relation is a set of tuples over attributes. In the practical SQL model, tables can contain duplicate rows unless constraints prevent them, so designers should explicitly identify keys and integrity rules.

A candidate key is a minimal set of attributes that uniquely identifies a tuple. A primary key is the chosen candidate key. A foreign key enforces a referential relationship. A superkey uniquely identifies rows but may contain unnecessary attributes. Natural keys have domain meaning; surrogate keys are generated identifiers. The decision should consider stability, uniqueness, privacy and integration behavior.

Integrity constraints include domain constraints, NOT NULL, UNIQUE, CHECK, primary-key and foreign-key constraints. Enforcing integrity in the database protects against bugs in multiple application clients. Application validation improves user feedback, but it should not replace critical database constraints.

### Worked example

```sql
CREATE TABLE facility (
    facility_id bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    name text NOT NULL,
    timezone text NOT NULL
);

CREATE TABLE tank (
    tank_id bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    facility_id bigint NOT NULL REFERENCES facility(facility_id),
    tank_code text NOT NULL,
    capacity_litres numeric(12,2) NOT NULL CHECK (capacity_litres > 0),
    UNIQUE (facility_id, tank_code)
);
```

The composite unique constraint prevents duplicate tank codes within a facility while allowing the same code at another facility. The foreign key prevents a tank from referencing a nonexistent facility.

### Laboratory

Implement a schema with primary, foreign, unique and check constraints. Attempt invalid inserts and confirm that the database—not only the application—rejects them.

---

## Week 3 — Functional dependencies and normalization

A functional dependency \(X \rightarrow Y\) means that for any two rows, if their X values are equal, their Y values must also be equal. It describes a constraint of the domain, not merely a pattern observed in sample data.

Normalization reduces undesirable redundancy and update anomalies:
- 1NF requires attribute values to be atomic within the chosen relational model.
- 2NF requires non-prime attributes to depend on the whole candidate key, not part of a composite key.
- 3NF requires non-prime attributes not to depend transitively on a candidate key; formally, for every non-trivial FD \(X \rightarrow A\), either X is a superkey or A is prime.
- BCNF requires every determinant of a non-trivial functional dependency to be a superkey.

Normalization can reduce insertion, update and deletion anomalies. It does not mean that every table must contain one column or that all denormalization is wrong. Denormalization can be a justified performance decision when the duplicated facts have clear ownership and a reliable update strategy.

### Worked example

Consider `Enrollment(student_id, course_id, student_name, course_title, grade)` with key `(student_id, course_id)`. Dependencies include `student_id -> student_name`, `course_id -> course_title`, and `(student_id, course_id) -> grade`. The table has partial dependencies on parts of the composite key. Decompose into Student, Course and Enrollment. Each fact then has one authoritative location.

### Laboratory

Given a relation and a list of functional dependencies, identify candidate keys, find violations of 2NF/3NF/BCNF and produce a lossless decomposition. Explain whether dependency preservation is achieved.

---

## Week 4 — Relational algebra and SQL

Relational algebra provides operations that express queries over relations. Selection filters tuples; projection chooses attributes; union combines compatible relations; difference subtracts tuples; Cartesian product pairs tuples; joins combine related tuples. These ideas help explain how a DBMS can transform and optimize queries.

SQL is declarative: the user states the desired result, and the DBMS chooses a plan. SQL includes DDL (schema definition), DML (data manipulation), DQL (querying) and transaction control. A SQL query is not necessarily executed in the textual order in which clauses appear.

### Worked query

```sql
SELECT f.name,
       count(m.measurement_id) AS readings,
       avg(m.level_percent) AS avg_level
FROM facility AS f
JOIN tank AS t ON t.facility_id = f.facility_id
JOIN measurement AS m ON m.tank_id = t.tank_id
WHERE m.measured_at >= now() - interval '24 hours'
GROUP BY f.facility_id, f.name
HAVING count(m.measurement_id) >= 100
ORDER BY avg_level DESC;
```

The query joins facilities to tanks to measurements, filters the time range, groups by facility, filters groups with at least 100 readings, then orders the result. The `HAVING` condition applies after grouping. `WHERE` filters input rows before aggregation.

Understand NULL semantics. `NULL` means unknown or missing, not zero or an empty string. Comparisons with NULL produce unknown; use `IS NULL` and `IS NOT NULL`. Aggregates usually ignore NULL values except `COUNT(*)`, which counts rows.

### Laboratory

Write queries for: recent high-level alerts, daily average per tank, tanks with no telemetry, users who issued commands, and facilities whose number of active alarms exceeds a threshold. Explain how NULL values affect each query.

---

## Week 5 — Storage engines and physical data layout

A DBMS maps logical records to pages or blocks on storage. It may use heap files, sorted files, log-structured storage or other layouts. The buffer pool caches pages in memory. A page-oriented system reads and writes blocks rather than treating each row as an independent disk operation.

A table scan reads the relevant pages and checks rows. A sequential scan can be optimal when a large fraction of a table is needed. An index supports targeted lookup but adds storage and write overhead. Physical design depends on workload selectivity, data distribution, locality, row width, update patterns and cache behavior.

Write-ahead logging records changes needed for recovery. A common rule is that the log record describing a data-page change must become durable before the modified data page is written. This allows recovery to redo committed changes and undo or ignore incomplete changes according to the DBMS's protocol.

### Laboratory

Create a table with a million generated telemetry records. Measure table size, insert rate and sequential scan time. Observe how row width and data volume affect performance.

---

## Week 6 — Indexing and query optimization

An index is an auxiliary data structure that helps locate rows. B+ trees support ordered lookup and range queries. Hash indexes support equality lookup under the supported DBMS semantics. Bitmap and inverted indexes serve particular workloads. Indexes are not free: they consume storage, slow writes, require maintenance and may be ignored by the optimizer.

A query optimizer estimates the cost of candidate plans using statistics such as table cardinality, value distribution and selectivity. It may choose nested-loop, hash or merge joins, along with scans and index access. Bad estimates can lead to bad plans, especially with correlated columns, skew and stale statistics.

Use `EXPLAIN` to inspect the plan and `EXPLAIN ANALYZE` to compare estimates with actual execution. `EXPLAIN ANALYZE` executes the statement; be careful with data-modifying queries and production data.

### Worked example

An index on `(tank_id, measured_at)` can support a query that filters by tank and time range. An index on `measured_at` alone may be more useful for queries that scan all tanks for a time range. The best index depends on query patterns, cardinality and write frequency.

### Laboratory

Run the same query with and without a composite index. Capture execution plans, actual rows, estimated rows, execution time and buffer activity. Explain whether the index helps and why.

---

## Week 7 — ACID transactions and transaction boundaries

A transaction groups operations into a unit with ACID properties:
- Atomicity: all operations of the transaction take effect or none do.
- Consistency: constraints that are defined for the database are preserved by committed transactions.
- Isolation: concurrent transactions behave according to the isolation guarantee.
- Durability: committed changes survive the failure model promised by the system.

ACID does not automatically make business logic correct. A transaction can atomically commit an invalid state if the application failed to express the intended constraint. Consistency means the database's declared invariants are maintained; it does not mean every domain requirement was correctly declared.

A transaction should cover a coherent unit of work, avoid unnecessary duration and use appropriate constraints and locking. Long transactions can increase contention, delay vacuum/cleanup and complicate recovery.

### Worked example

```sql
BEGIN;

UPDATE tank
SET target_percent = 75
WHERE tank_id = 42;

INSERT INTO audit_event(event_type, object_id, actor_id)
VALUES ('TARGET_CHANGED', 42, 17);

COMMIT;
```

The target change and audit event commit together if both are part of the same database transaction. If the audit store is an external service, this local transaction does not make the cross-service operation atomic; use an outbox or another explicit coordination design.

### Laboratory

Implement a transaction that changes configuration and writes an audit record. Force an error between the statements. Demonstrate rollback and then test concurrent updates.

---

## Week 8 — Isolation anomalies and concurrency control

Concurrent transactions can interfere. Common anomalies include:
- dirty read: observing uncommitted data;
- non-repeatable read: reading the same row twice and observing different committed values;
- phantom: a repeated predicate query returns a different set;
- lost update: one update overwrites another without incorporating it;
- write skew: concurrent transactions make individually valid decisions that jointly violate a constraint.

Isolation levels specify which behaviors are prevented. Exact implementations vary by DBMS. PostgreSQL uses MVCC: a statement sees a snapshot, reducing read/write blocking. Its `READ COMMITTED`, `REPEATABLE READ` and `SERIALIZABLE` behavior should be studied from PostgreSQL's own documentation, including serialization failures that the application must handle.

Concurrency-control methods include two-phase locking (2PL), timestamp ordering, optimistic concurrency control and MVCC. 2PL acquires locks and has a growing phase followed by a shrinking phase; strict 2PL holds write locks until commit/abort. Optimistic concurrency control allows work to proceed and validates before commit. MVCC maintains versions so readers can observe snapshots.

### Worked example: write skew

Two operators each check that at least one of two pumps remains enabled. Transaction A sees pump 1 and pump 2 enabled, then disables pump 1. Transaction B sees the same original state, then disables pump 2. If both transactions commit under an isolation mode that permits the anomaly, the final state has no pump enabled. The rule must be enforced using an appropriate serializable transaction, explicit locking, a constraint on a shared row or another correct design.

### Laboratory

Open two database sessions. Reproduce a lost update or write skew under a permissive isolation level. Repeat under serializable isolation and handle serialization failure with a bounded retry strategy.

---

## Week 9 — Recovery, backups and durability

Recovery restores a database to a consistent state after crash or corruption. Write-ahead logging records changes so the system can recover durable transactions. Checkpoints limit recovery work by establishing a known point from which log replay can proceed.

A backup is not proven useful until restoration has been tested. Distinguish full, incremental and differential backups; physical and logical backups; and point-in-time recovery. Recovery objectives include Recovery Point Objective (RPO), the maximum tolerable data loss measured in time, and Recovery Time Objective (RTO), the target time to restore service.

A replica is not a backup: corruption or malicious deletion can replicate. A backup is not a high-availability solution: restoration may take too long for the service objective. Use backups, replicas, archival retention and tested recovery procedures for different needs.

### Worked example

If the service requires an RPO of five minutes, the backup/log-archiving strategy must ensure that the recoverable point is no more than five minutes before the incident under the defined failure assumptions. If restoration takes two hours but the service's RTO is 30 minutes, the design is insufficient even if the data is preserved.

### Laboratory

Create a backup, modify or delete test records, restore to a separate database and compare row counts and integrity checks. Record actual restore time and recoverable timestamp. Do not label a backup system "tested" based only on successful backup creation.

---

## Week 10 — Migrations and schema evolution

A schema evolves as requirements change. A migration must coordinate application versions, database versions, data transformation, rollback strategy, availability and compatibility. Large blocking migrations can cause outages. A safer pattern is often expand–migrate–contract:
1. Add the new structure while retaining compatibility.
2. Deploy code that can read/write the compatible form.
3. Backfill or transform data in bounded batches.
4. Switch reads to the new representation.
5. Remove the old structure only after all consumers have migrated.

Migrations should be versioned, repeatable where possible, reviewed, tested on representative data and observable during execution. A migration that works on a 100-row development table may fail on a production table with millions of rows and concurrent writes.

### Laboratory

Rename a field through an expand–migrate–contract process. Demonstrate compatibility between old and new application versions. Add a migration test and a rollback/forward-recovery decision.

---

## Week 11 — Data quality, governance, lineage and retention

Data quality can be assessed through accuracy, completeness, consistency, timeliness, validity, uniqueness and fitness for purpose. These dimensions are not interchangeable. A measurement may be syntactically valid but physically implausible. A missing value may be correct if a sensor was offline; replacing it with zero creates false information.

Enforce quality at multiple layers: input validation, database constraints, domain checks, deduplication, reconciliation, monitoring and human review. Preserve provenance: source, event time, ingestion time, transformations, schema version and correction history. Data lineage records where data came from and how it was transformed.

Governance defines ownership, access, classification, retention, deletion, legal constraints, data-sharing rules and audit responsibilities. Retention must be justified by operational, legal, safety and privacy needs. Do not retain sensitive data indefinitely simply because storage is cheap.

### Laboratory

Define quality rules for telemetry: valid range, timestamp freshness, sensor identity, duplicate event ID, missing sequence and plausible rate of change. Implement SQL checks and generate a data-quality report.

---

## Week 12 — Distributed databases: replication, sharding and consistency

Distributed databases partition and/or replicate data across nodes. Replication can improve availability and read locality, but introduces replica lag, conflict resolution, write coordination and recovery complexity. Sharding distributes data and load, but complicates joins, transactions, rebalancing and global constraints.

Synchronous replication waits for acknowledgements according to a defined durability policy; asynchronous replication may lose recent acknowledged writes during failover depending on the design. A read from a lagging replica may return stale data. The API should specify whether it offers read-your-writes, monotonic reads, causal guarantees or linearizability.

The CAP theorem concerns the impossibility of guaranteeing both linearizability and availability to every request during a network partition. It does not mean all databases must choose two properties permanently. Partition behavior depends on the operation and consistency guarantee. PACELC adds the observation that systems make latency/consistency trade-offs when there is no partition as well.

### Laboratory

Run a primary/replica setup or a simulator. Introduce replication lag and compare read results. Design a sharding key for telemetry and measure skew. Explain which queries become cross-shard operations.

---

## Week 13 — Analytical data systems and event-driven architectures

Online Transaction Processing (OLTP) systems support many small, concurrent state changes with strong integrity requirements. Online Analytical Processing (OLAP) systems support large scans and aggregations across historical data. Their storage and query patterns differ. Row-oriented storage is often useful for transactional access; columnar storage can be efficient for scans over a subset of columns.

A data warehouse integrates data for analysis. A data lake stores large volumes of data in varied formats, but without governance it can become a data swamp. A lakehouse combines aspects of data lake storage with table metadata and transaction features. Architectural labels do not replace explicit consistency, schema, ownership, retention and quality definitions.

Event-driven data systems use logs or messaging platforms to decouple producers and consumers. Events describe facts that happened; commands request actions. Event schemas need versioning. Consumers must handle duplicate delivery, delayed events, ordering scope, poison messages and replay. A data pipeline should preserve lineage and make reprocessing safe.

### Laboratory

Create an event pipeline that ingests sensor events, stores raw records and builds daily aggregates. Reprocess a date range and compare results. Document how schema changes and duplicate events are handled.

---

## Week 14 — Database design review and capstone

A database design review asks:
- What entities and facts are represented?
- Which constraints protect integrity?
- What are the critical query patterns?
- Which indexes support those patterns and what do they cost?
- What isolation level supports each transaction?
- How are deadlocks and serialization failures handled?
- What is the durability boundary?
- What are the backup, restore and retention guarantees?
- How do schema changes roll out?
- What happens during replication lag, partition and failover?

### Final submission

Submit an ER diagram, normalized logical schema, SQL DDL, migration history, representative queries, query plans, transaction/anomaly experiment, backup/restore evidence, data-quality report, distributed architecture note and performance analysis.

### End-of-course problems

1. What is the difference between a superkey and a candidate key?  
   **Solution:** A superkey uniquely identifies rows but may contain unnecessary attributes. A candidate key is a minimal superkey.

2. Why is a read replica not a backup?  
   **Solution:** Incorrect updates, malicious deletion and corruption may be replicated. A backup preserves a recoverable historical state under a separate retention and access model.

3. Why can a transaction pass at READ COMMITTED but fail under SERIALIZABLE?  
   **Solution:** A serializable engine may detect that concurrent transactions cannot be ordered as a valid serial execution. It aborts one transaction to preserve the guarantee. The application must handle the serialization failure.

4. Does adding an index always improve performance?  
   **Solution:** No. It adds storage and write/maintenance costs, may not be selective, may not match the query predicate/order, and may be slower than a sequential scan for large result fractions.

## Selected sources and further study

- CMU 15-445/645 Intro to Database Systems (Fall 2026): https://15445.courses.cs.cmu.edu/fall2026/
- CMU Database Group course catalogue: https://db.cs.cmu.edu/courses/
- PostgreSQL 18 documentation: https://www.postgresql.org/docs/18/
- PostgreSQL MVCC and concurrency control: https://www.postgresql.org/docs/18/mvcc.html
- PostgreSQL transaction isolation: https://www.postgresql.org/docs/18/transaction-iso.html
- MIT 6.5830 Database Systems: https://dsg.csail.mit.edu/6.5830/
- *Database System Concepts*, Silberschatz, Korth and Sudarshan: https://www.db-book.com/
- *Designing Data-Intensive Applications*, 2nd ed. (2026): https://martin.kleppmann.com/2026/03/24/designing-data-intensive-applications-2e.html
- SQLite documentation for a lightweight second DBMS comparison: https://www.sqlite.org/docs.html

CMU's course provides particularly strong coverage of database internals and programming projects. PostgreSQL documentation should be used for precise engine-specific behavior; do not generalize PostgreSQL's implementation details to every DBMS.

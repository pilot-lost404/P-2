# Course 2 — Model-Based Systems Engineering (MBSE)
**Level:** Upper-undergraduate / early graduate  
**Duration:** 14 teaching weeks  
**Expected workload:** 8–10 hours per week  
**Modeling baseline:** SysML v2 concepts, with explicit comparisons to SysML v1 where useful  
**Prerequisites:** Basic software/system architecture, requirements concepts, elementary algebra, and the ability to read block diagrams.

## Course description

Model-Based Systems Engineering (MBSE) is the disciplined use of structured, connected models to support systems engineering activities across a system's lifecycle. A model is more than a drawing. It is a representation of elements, relationships, properties, constraints, behavior, requirements and evidence, organized so engineers can ask questions and assess consequences.

Document-centric engineering commonly spreads requirements, architecture, interfaces, hazards, analysis and test evidence across separate files. These artifacts may contradict one another after repeated changes. MBSE seeks to make relationships explicit and queryable. It does not remove engineering judgment, guarantee correctness, or make a poor process effective merely because a modeling tool is installed.

This course teaches the thinking behind modeling, then the modeling work products used to describe a system. It uses a remote water-tank controller as a continuous example and includes a model-based capstone. The course is tool-neutral at the conceptual level. A SysML v2-capable environment such as Eclipse SysON may be used for practical work; the exact supported language subset depends on tool maturity and release.

## Learning outcomes

Students completing the course should be able to:
1. Define a system boundary, stakeholders, operational context and lifecycle concerns.
2. Translate stakeholder needs into validated, measurable and traceable requirements.
3. Decompose a system into functions, logical elements, physical elements and interfaces.
4. Represent structure, behavior, constraints and requirements using an appropriate modeling language.
5. Explain the difference between a model, a view, a diagram, a simulation and a digital twin.
6. Maintain traceability from needs through requirements, architecture, analyses and V&V.
7. Assess model quality, completeness, consistency and configuration.
8. Use models to support trade studies, interface reviews and change-impact analysis.
9. Build and review a coherent system model rather than a disconnected diagram collection.

---

## Week 1 — Systems thinking and the system boundary

### 1.1 System, environment and purpose

A system is a set of interacting elements organized to achieve a purpose in an environment. The definition is intentionally broad: elements can include hardware, software, people, facilities, data, procedures and external services. A boundary determines what is treated as part of the system and what is modeled as an external actor or dependency.

Boundary selection is a modeling decision, not a discovery of an objectively obvious line. If a cloud platform is external to a local controller project, its interface and assumptions still matter. Excluding an element from the design model does not remove the risk created by depending on it.

A good system definition identifies purpose, scope, environment, stakeholders, interfaces, operating modes, constraints and assumptions. The system context diagram shows external actors and exchanges. It should not be confused with a detailed component architecture.

### 1.2 Emergent properties

Some important properties belong to interactions rather than individual components. Safety, resilience, usability, performance and security are often emergent. A sensor may be accurate, a controller may be correct and a valve may work mechanically, yet the integrated system can still overfill a tank because the sensor is mounted incorrectly or the command path is delayed.

Systems thinking therefore asks how behavior emerges from relationships, feedback, delays, incentives and operating context. Local optimization may harm global performance. For example, maximizing telemetry frequency can overload a constrained network and delay the control-related messages that matter more.

### Worked example

Purpose: maintain water availability while preventing unsafe filling and allowing local operation during a network outage.

System boundary for the capstone includes the local controller, sensor interface, pump/valve interface, local panel, remote service, command API, event store and operator interface. The water supply, electrical supply, physical tank and Internet are external entities, but they remain explicit context dependencies.

### Laboratory

Create a context diagram. Label every exchanged item as command, measurement, status, power, human input or environmental influence. Identify at least five assumptions that would need stakeholder validation.

---

## Week 2 — Lifecycle, stakeholders and operational concepts

Systems engineering is lifecycle-oriented. A solution is conceived, developed, integrated, verified, validated, operated, maintained, upgraded and eventually retired. Decisions made early constrain later phases. A system that is easy to build but impossible to maintain is not a successful lifecycle solution.

Stakeholders are people or organizations that affect, are affected by, or have an interest in the system. Stakeholder analysis should identify their concerns, authority, success measures and operational context. A stakeholder need is not yet a technical requirement. It is usually expressed in outcome-oriented language, such as "operators must know when the tank is approaching its safe operating limit."

A Concept of Operations (ConOps) describes how the system is expected to be used in context. It should describe users, missions/tasks, operating modes, normal workflows, degraded modes, exceptions, training, maintenance and external dependencies. A good ConOps exposes requirements that would be missed by designing only for a normal day.

### Worked example: operating modes

```text
NORMAL_LOCAL
  - sensor measurements available
  - controller runs autonomous local rules
  - remote telemetry enabled when link is available

DEGRADED_NETWORK
  - local control continues
  - cloud commands are rejected or queued under policy
  - telemetry buffers locally

SENSOR_FAULT
  - controller enters defined safe state
  - alarm is raised locally
  - remote state is marked uncertain

MAINTENANCE
  - authorized technician controls permitted functions
  - safety interlocks remain active
```

The mode names are not themselves requirements. Each mode needs entry conditions, allowed actions, exit conditions and failure handling.

### Laboratory

Write one ConOps scenario for a normal fill cycle and another for a sensor fault plus network outage. Have a second reader role-play an operator and identify missing information.

---

## Week 3 — Requirements engineering for model-based work

### 3.1 Need, requirement and design

A stakeholder need explains a desired outcome. A requirement states a necessary, verifiable condition that the system or element must satisfy. A design decision describes how the solution will satisfy it. Confusing these creates premature design lock-in.

A good requirement is necessary, singular, unambiguous, feasible, consistent, traceable and verifiable. Use a subject, a required action or property, and a measurable condition. Avoid vague words such as fast, easy, robust, sufficient or user-friendly unless they are defined by measurable criteria.

Weak: "The system shall quickly detect overflow."  
Stronger: "When the level input indicates a value at or above the configured high-high threshold, the local controller shall command the inlet valve to its defined closed state within 250 ms."

The stronger statement still requires review: sensor sampling period, measurement uncertainty, valve response time and failure behavior must be considered. A number without a justified rationale is false precision.

### 3.2 Requirement attributes

Store more than the sentence. Useful attributes include identifier, text, rationale, source, owner, verification method, acceptance criterion, priority, status, version, assumptions, allocation and trace links. Bidirectional traceability allows engineers to ask both "what justifies this requirement?" and "what does this requirement affect?"

### Worked example

| ID | Requirement | Verification | Rationale |
|---|---|---|---|
| SYS-001 | The local controller shall continue autonomous level control during loss of the remote network connection. | Test | Cloud dependency must not remove local control. |
| SYS-002 | The controller shall close the inlet valve within 250 ms after a valid high-high input is sampled. | Test | Limit additional inflow after threshold detection. |
| SYS-003 | The remote API shall reject commands from unauthenticated callers. | Test + analysis | Prevent unauthenticated remote actuation. |

### Laboratory

Create 15 requirements. Mark each as stakeholder, system, subsystem, interface, performance, constraint or quality requirement. Reject or rewrite every requirement with no objective verification method.

---

## Week 4 — Modeling foundations: semantics, views and abstraction

A model is a purposeful abstraction of a system. It omits detail that is irrelevant to a question and preserves detail needed to answer it. An architecture view presents a system from a particular viewpoint for particular stakeholders. A diagram is a rendering of selected model information; a set of disconnected diagrams is not necessarily a coherent model.

Model semantics matter. A line between two boxes could mean data flow, physical connection, dependency, ownership or merely visual grouping. If its meaning is not defined by the language or modeling convention, readers may infer different relationships.

A model should support questions such as:
- Which requirement is allocated to the controller?
- Which interface carries a remote command?
- Which behavior occurs when sensor data becomes stale?
- Which tests verify the high-high response?
- What is affected if the valve interface changes?

### Modeling quality properties

- **Correctness:** elements and relations represent the intended system.
- **Completeness:** required aspects are represented at the necessary level.
- **Consistency:** no contradictory values or relationships.
- **Traceability:** links exist between related engineering artifacts.
- **Usability:** stakeholders can understand and query the model.
- **Configuration integrity:** the model has a controlled version and change history.

### Laboratory

Take a context diagram and create a second view for the local control subsystem. Keep the model elements consistent across both views. Record what is intentionally omitted from each view.

---

## Week 5 — Structural architecture and decomposition

Architecture defines major elements, their responsibilities, relationships, interfaces and constraints. Decomposition moves from a whole-system view into subsystems and components. There is no single universally correct decomposition. Functional decomposition groups what the system does; physical decomposition groups the elements that realize it. These views are related but not interchangeable.

A functional model may contain:
- acquire level measurement;
- validate measurement;
- determine control state;
- command actuator;
- publish telemetry;
- authenticate remote operator;
- record command and audit event.

A physical architecture may allocate these functions to a sensor module, local controller, actuator driver, gateway, cloud command service, identity service and database. A function can be allocated across multiple physical elements, and a physical element can support multiple functions.

Interfaces should identify exchanged items, direction, units, protocols, timing, ownership, failure behavior and constraints. "REST API" is not a complete interface definition. It omits operation semantics, schemas, authentication, error handling and version compatibility.

### Worked example

```mermaid
flowchart LR
  Sensor[Level Sensor] -->|measurement + validity| PLC[Local Controller]
  PLC -->|actuator command| Actuator[Pump / Valve]
  PLC -->|telemetry| Gateway[Gateway]
  Gateway -->|HTTPS events| Cloud[Remote Service]
  Operator[Operator] -->|authenticated command| Cloud
  Cloud -->|approved command| Gateway
  Cloud --> DB[(Event / Config DB)]
```

The local controller is the authority for local interlocks. The cloud service is not permitted to bypass those constraints.

### Laboratory

Build a functional decomposition and physical block architecture. Every element must have a named responsibility and every interface must identify at least one exchanged item.

---

## Week 6 — Behavior modeling: activities, states and sequences

Structure says what elements exist. Behavior says what happens, under what conditions, and in what order. Activity models represent workflows and transformations. State machines represent state-dependent behavior. Sequence diagrams show interactions over time between participants.

A state machine is useful when the response depends on current state, event and guard conditions. A state transition can be written:

\[
(q, e, g) \rightarrow (q', a)
\]

where \(q\) is the current state, \(e\) the triggering event, \(g\) the guard condition, \(q'\) the next state and \(a\) the action.

For the controller, `FILLING` should not transition to `IDLE` merely because a remote service sends a stop request. The controller must validate local conditions and the command's authority. Safety-related transitions should be designed so that a communication error cannot accidentally disable local protections.

### Worked example: simplified control states

```mermaid
stateDiagram-v2
  [*] --> IDLE
  IDLE --> FILLING: level below low threshold AND sensor valid
  FILLING --> IDLE: target reached
  FILLING --> SAFE_STOP: high-high OR sensor invalid
  IDLE --> SAFE_STOP: sensor invalid
  SAFE_STOP --> MAINTENANCE: authorized inspection
  MAINTENANCE --> IDLE: checks complete and reset authorized
```

The diagram is a teaching abstraction. Real control behavior must define hysteresis, debounce, sensor diagnostics, actuator feedback, reset conditions and fault response.

### Laboratory

Create a state machine with at least six states and ten transitions. For each transition, specify trigger, guard, action and trace to a requirement. Test unreachable states and ambiguous guards.

---

## Week 7 — SysML v2 concepts and requirements integration

SysML is a general-purpose systems modeling language for specifying, analyzing, designing and verifying systems that may combine hardware, software, information, people, procedures and facilities. SysML v2 was formally adopted by OMG in 2025; SysML v1 remains in use during the transition. A project should choose a language version based on its toolchain, exchange requirements and team capability.

SysML v2 emphasizes textual and graphical notations with a more explicit semantic foundation and standardized API/services. The important learning goal is not memorizing every keyword. It is understanding how model elements and relationships represent requirements, parts, actions, attributes, constraints, interfaces and verification-related work products.

A requirement element should be connected to its source, decomposition, allocation and verification. A diagram that displays requirement text without model relationships provides less value than a model that can answer traceability questions.

### Laboratory

Use a SysML v2-capable tool or a structured model repository. Create package organization, system definition, requirements, part definitions and relationships. Export a table showing each requirement and the model element responsible for satisfying it.

### Model fragment (conceptual, tool-neutral)

```text
Requirement SYS-001
  Text: Local control shall continue during remote network loss.
  Derived from: NEED-003
  Allocated to: LocalController
  Verified by: TEST-001, TEST-004

Part LocalController
  performs: ValidateMeasurement
  performs: DetermineControlState
  performs: CommandActuator
  connected to: LevelSensor
  connected to: ValveDriver
```

This is a readable model fragment, not a claim that the syntax is directly executable in a specific SysML tool.

---

## Week 8 — Interfaces, contracts and integration architecture

An interface is a boundary across which components exchange information, energy, material or control. The interface definition should include the contract: allowed operations, input/output schemas, units, timing, preconditions, postconditions, error states, security and versioning.

For software services, define API operations and event schemas. For physical interfaces, define electrical/mechanical characteristics and operating limits. For human-machine interfaces, define user roles, feedback, failure indications and prohibited actions. Interface mismatches are a major source of integration failure because each component may satisfy its own local specification while disagreeing with the neighboring component.

A contract should identify what the provider guarantees and what the consumer must ensure. Avoid ambiguous ownership of a field or state. For telemetry, define whether timestamps are event time or ingestion time, which component assigns sequence numbers, how invalid readings are represented and how duplicate events are handled.

### Laboratory

Create interface-control tables for sensor-to-controller, controller-to-valve, gateway-to-cloud and operator-to-command API. Include at least one failure case per interface. Review two interfaces as a team and record unresolved assumptions.

---

## Week 9 — Parametrics, constraints and performance reasoning

A parametric model expresses relationships among quantities. It can support sizing, sensitivity analysis, performance budgets and trade studies. A model is only as trustworthy as its assumptions, input data and validation against reality.

For a simple tank, volume may be approximated by \(V = A h\) for a vertical cylindrical tank with constant cross-sectional area \(A\) and level \(h\). If inflow is \(Q_{in}\) and outflow is \(Q_{out}\), then:

\[
\frac{dV}{dt} = Q_{in} - Q_{out}
\]

If area is constant, \(A\frac{dh}{dt}=Q_{in}-Q_{out}\). This simplified relation can estimate how quickly the level changes. It is not a substitute for a physical model when pipe losses, nonlinear geometry, compressibility or pump dynamics matter.

### Worked example

For \(A=2\,m^2\), net inflow \(Q_{in}-Q_{out}=0.01\,m^3/s\). Then \(dh/dt=0.01/2=0.005\,m/s\), or 5 mm/s. If the sample-to-actuation path takes 0.4 s, the level may rise approximately 2 mm during that delay, under the constant-flow approximation. The model tells us which parameter to measure; it does not by itself establish a safe margin.

### Laboratory

Construct a spreadsheet or model for tank level dynamics. Vary sensor delay, actuator delay, inflow and tank area. Plot sensitivity and explain which assumptions dominate the predicted level.

---

## Week 10 — Trade studies and architecture decisions

Architecture is a set of decisions under constraints, not a picture of boxes. A trade study compares alternatives against explicit criteria. First distinguish hard constraints from preferences. Then define criteria, weights (if using a weighted method), scoring scales, evidence and uncertainty.

A weighted sum can be useful:

\[
S_j = \sum_i w_i r_{ij}
\]

where \(w_i\) is the weight for criterion \(i\) and \(r_{ij}\) is the score for alternative \(j\). The resulting score is not an objective truth. The choice of criteria, weights and scores encodes judgment. Sensitivity analysis checks whether the preferred option changes when assumptions vary.

### Worked example

Compare local-only, cloud-centric and hybrid control. Criteria could include local safety autonomy, remote observability, network dependence, maintenance complexity, cost and cyber exposure. A cloud-centric design may score well for remote analytics but fail the hard constraint that local control must operate during network loss. A weighted sum must not override a non-negotiable constraint.

### Laboratory

Produce an architecture decision record with at least three alternatives, decision criteria, constraints, evidence, uncertainty, sensitivity test and selected option.

---

## Week 11 — Model verification, validation and quality assurance

A model itself needs assurance. Verification asks whether the model is syntactically and structurally well-formed and internally consistent. Validation asks whether it is an adequate representation of the real system for the intended use. A syntactically valid SysML model may still represent the wrong operating concept.

Model checks include duplicate identifiers, dangling relations, missing allocations, incomplete interface definitions, orphan requirements, conflicting property values and invalid state transitions. Reviews should inspect both the diagram and the underlying semantic model. Views can hide missing relationships if the reviewer treats the drawing as the whole model.

### Laboratory

Create automated checks or queries that report:
- requirements with no source;
- requirements with no allocated design element;
- requirements with no verification method;
- interface ports with no connected partner;
- state transitions with no defined guard/action;
- components with no assigned function.

Report false positives and limitations. A query that returns zero findings is not proof the model is correct.

---

## Week 12 — Model governance, configuration and change impact

A model is a lifecycle asset. It needs ownership, baselines, access control, naming rules, version history, review status and change management. Configuration management prevents an engineer from validating one model version and implementing a different one without detecting the difference.

Change-impact analysis follows model relations. If the valve response time changes, affected requirements may include shutdown latency, overflow margin, timing budget, safety analysis and verification tests. The model should help find these impacts, but a human engineer must assess whether the relation set is complete.

A model repository should distinguish approved baseline, working branch, proposed change, released version and archived version. Record why changes occurred and which evidence must be repeated after a change.

### Laboratory

Change the valve interface response from 250 ms to 400 ms. Produce an impact report listing affected requirements, calculations, hazards, design elements and test cases. Mark direct impacts separately from possible secondary impacts.

---

## Week 13 — MBSE across disciplines and digital engineering

MBSE provides a common structure for linking systems engineering to software, mechanical, electrical, safety, security, reliability, manufacturing and operations. Interoperability is not guaranteed simply because two tools support SysML. Data semantics, profiles, identifiers, units, versioning and transformations must be controlled.

A digital thread links lifecycle artifacts and their provenance. A digital twin is a model connected to a particular physical asset or operational data stream and used for defined purposes such as monitoring, prediction or control support. A static design model is not automatically a digital twin. A simulation is an execution or analysis of a model under defined assumptions; it does not automatically reproduce reality.

### Laboratory

Choose one model element and trace its identity from requirement to architecture, simulation, implementation and test evidence. Record where data is copied manually, where links are machine-maintained and where semantic transformations could lose information.

---

## Week 14 — Integrated model review and capstone

A model review should be organized around engineering questions, not diagram count. Review system purpose, boundary, stakeholder needs, requirements quality, functional decomposition, architecture, interfaces, behavior, constraints, safety/security connections, verification links, assumptions and model configuration.

### Final submission

Submit:
1. System context and stakeholder map.
2. ConOps with normal and degraded scenarios.
3. A uniquely identified requirement set with sources and verification methods.
4. Structural, functional and behavioral models.
5. Interface definitions.
6. Quantitative model or trade study with assumptions and sensitivity.
7. Traceability and model-quality reports.
8. Change-impact report.
9. Review log and model limitations.

### End-of-course problems

1. Why is a context diagram not a complete architecture?  
   **Solution:** It shows the system boundary and external interactions, but typically omits internal components, responsibilities, interfaces and behavior.

2. A requirement says "The controller shall react quickly." What makes it deficient?  
   **Solution:** "Quickly" is undefined, there is no operating condition or measurable response, and no acceptance criterion can be derived. Rewrite it with an event, condition, measurable time and defined system boundary.

3. A model is syntactically valid. Is it validated?  
   **Solution:** No. Syntax checks well-formedness. Validation requires evidence that the modeled system and behavior adequately represent the real system for the intended engineering purpose.

## Selected sources and further study

- NASA-HDBK-1009A, *NASA Systems Modeling Handbook for Systems Engineering* (active, 12 March 2025): https://standards.nasa.gov/standard/NASA/NASA-HDBK-1009
- OMG SysML official specifications: https://www.omg.org/sysml/
- OMG SysML v2 specification history and documents: https://www.omg.org/spec/SysML/About-SysML/
- NASA Systems Engineering Handbook: https://www.nasa.gov/reference/systems-engineering-handbook/
- SEBoK, Systems Engineering Body of Knowledge: https://sebokwiki.org/
- Eclipse SysON documentation and tutorials: https://doc.mbse-syson.org/
- Capella MBSE tool and training: https://mbse-capella.org/
- NASA Systems Engineering processes and requirements: https://nodis3.gsfc.nasa.gov/

The NASA MBSE handbook is a concrete worked reference for connecting models to stakeholder expectations, ConOps, technical requirements, verification and validation work products. SysML is a language; a sound method, governance process and engineering review are still required.

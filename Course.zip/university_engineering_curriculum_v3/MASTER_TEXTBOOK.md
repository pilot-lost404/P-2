# Master Textbook — University-Level Engineering Curriculum
**Six 14-week course readers | Research snapshot: 21 November 2026**

This combined reader contains the six standalone course textbooks. For practical worksheets, the capstone and sources, see the companion files in this pack.

# Course Guide — How to Study These Six University-Level Subjects

## 1. What this curriculum is and is not

This pack is written as a self-study course reader for advanced undergraduate learners. It is organized around 14 teaching weeks per course. Each weekly unit introduces a concept, explains why it matters, applies it to an engineering example and assigns practical work. The shared capstone forces the student to connect methods across disciplines.

It is not an accredited degree, an institutional syllabus, a substitute for faculty feedback or a certification program. It is not a reprint of a commercial textbook. The explanations and examples are original teaching material; primary sources and textbooks are listed for deeper study.

## 2. Prerequisite review

Before beginning, be comfortable with:
- programming fundamentals, data structures, debugging and Git;
- processes, threads, synchronization and basic operating systems;
- IP addressing, TCP, HTTP and client/server architecture;
- SQL queries, keys, joins and basic schema design;
- functions, sets, relations, probability and elementary algebra;
- drawing diagrams and explaining a design decision in writing.

Where a prerequisite is missing, use official tutorials and introductory courses in the Source Library. Do not skip a prerequisite because the topic sounds familiar.

## 3. A weekly study protocol

For each week:
1. Read the section once without trying to memorize it.
2. Write a one-page concept map from memory.
3. Re-derive every equation and worked calculation.
4. Recreate the diagram and label every boundary/relationship.
5. Complete the lab from a clean starting point.
6. Record the observed result, expected result and explanation of any difference.
7. Answer the exercises without looking at the solution.
8. Write down one limitation or assumption of the method.

A topic is mastered when you can explain the concept, identify when it is appropriate, apply it to a new case, and explain its limitations.

## 4. Engineering notebook

Keep one version-controlled notebook with:
- dated notes;
- diagrams and model versions;
- requirements and design decisions;
- lab setup and tool versions;
- commands, code, test cases and results;
- defects, anomalies and corrective actions;
- assumptions, unresolved issues and citations.

Never rewrite a failed experiment as a successful one. A reproducible failure is useful evidence.

## 5. Academic writing standard

For a design or analysis report, distinguish:
- **Fact:** directly supported by a source, measurement or test.
- **Assumption:** adopted to make the analysis possible; must be visible.
- **Estimate:** a calculated or judged quantity with uncertainty.
- **Decision:** a selected option and rationale.
- **Evidence:** an artifact that supports a claim.
- **Limitation:** what the analysis or test does not establish.

Avoid statements such as "secure", "safe", "reliable", "high performance" or "fully tested" without a defined claim and evidence.

## 6. Self-assessment rubric

Score each weekly assignment from 0 to 4:
- 0 — absent or fundamentally incorrect;
- 1 — recognizes terms but cannot apply them;
- 2 — performs the basic method with significant gaps;
- 3 — correct application with assumptions and evidence;
- 4 — correct, justified, critically evaluated and reproducible.

A score of 3 or 4 should be required before moving to the next major project milestone. If the same conceptual error appears twice, revisit the relevant foundation rather than accumulating more notes.

## 7. Recommended toolchain

Choose tools that make the concepts observable:
- Git for versioning and change history.
- Go for concurrency and distributed-service labs.
- PostgreSQL 18 for relational modeling, SQL and transaction experiments.
- Docker or Podman for isolated local services.
- Mermaid for diagrams in Markdown; a SysML v2 tool for formal MBSE practice.
- pytest / Go testing / SQL test harnesses for automated checks.
- OWASP Juice Shop for authorized security exercises.
- A local fault-injection harness for network delay, packet loss, crashes and restarts.

Tool choice is not the learning outcome. The student must understand the underlying model and the tool's limitations.

## 8. Course sequence and dependency logic

MBSE comes early because it teaches system boundaries, stakeholder needs, requirements and architecture. Database foundations are useful before distributed data systems. Distributed systems builds on networking, concurrency and persistence. Safety and security use the architecture and requirements to identify unacceptable outcomes and protections. V&V is planned from the beginning and culminates in an evidence-based assessment across the other courses.

## 9. Final portfolio

At the end, the student should have six course notebooks and one capstone repository containing:
- system definition and ConOps;
- a model and traceability report;
- a requirement baseline;
- hazard log, FMEA, fault tree and STPA analysis;
- threat model and security requirements;
- API and data model;
- running simulation or prototype;
- test plan, executed tests and evidence;
- backup/restore and failure-injection results;
- final engineering review and limitations statement.


---

# Course 1 — Distributed Systems
**Level:** Upper-undergraduate / early graduate  
**Duration:** 14 teaching weeks  
**Expected workload:** 8–10 hours per week  
**Primary language for laboratories:** Go (examples are language-independent unless stated)  
**Prerequisites:** Data structures, operating systems fundamentals, computer networks (TCP/IP, HTTP), concurrency, basic probability, Git and command-line use.

## Course description

A distributed system consists of multiple autonomous processes that communicate through a network and coordinate to provide a service. The defining difficulty is not simply that the system has many machines. It is that components execute independently, communicate with delay, observe events in different orders, and can fail independently. The network may lose, delay, duplicate or reorder messages. A process may pause, restart, or become unreachable while other components continue. Consequently, a correct local algorithm does not automatically produce a correct distributed service.

This course develops the models and engineering techniques used to reason about such systems. It connects communication, concurrency, time, replication, consistency, consensus, transactions, partitioning, reliability and operational design. The course emphasizes the distinction between a guarantee that can be proved under a stated model and a behavior that merely appeared to work in a small test.

The recurring case is a remote water-tank monitoring and control platform. A local controller must continue safe local operation when the network or cloud service is unavailable. A remote service receives telemetry, persists observations, and accepts authorized commands. The case is deliberately used to expose end-to-end failure modes rather than as a deployable industrial design.

## Learning outcomes

By the end of the course, a student should be able to:

1. Define process, communication, timing and failure assumptions for a distributed design.
2. Explain why timeouts cannot prove that a remote operation did not execute.
3. Use happens-before relations and logical clocks to reason about event ordering.
4. Compare primary-backup replication, quorum replication and state-machine replication.
5. Distinguish linearizability, sequential consistency, causal consistency and eventual consistency.
6. Explain the assumptions and limits of consensus protocols such as Raft and Paxos.
7. Design safe retries using idempotency keys, deduplication and durable operation records.
8. Analyze distributed transactions, sagas, sharding and rebalancing.
9. Instrument, test and operate a distributed service under partial failure.
10. Defend a design by stating its guarantees, assumptions, failure behavior and evidence.

## Assessment model

Suggested weighting for self-study or a university course: weekly problem sets 15%; programming laboratories 35%; midterm design analysis 15%; final project 25%; oral/debugging review 10%. A student should not receive full credit for a working demonstration that has no stated failure model or correctness argument.

---

## Week 1 — What makes a system distributed?

### 1.1 Definition and design problem

A distributed system is a collection of processes that communicate by exchanging messages and coordinate to perform a task. The processes may execute on different computers, virtual machines, containers or devices. They do not share ordinary process memory, and they cannot assume a globally visible clock.

A useful model separates three dimensions:

- **Process model:** crash-stop, crash-recovery, omission, timing, or Byzantine behavior.
- **Communication model:** reliable or unreliable channels; bounded or unbounded message delay; point-to-point or group communication.
- **Timing model:** synchronous, asynchronous, or partially synchronous assumptions.

These are not academic labels. They determine which guarantees are possible. For example, an asynchronous system provides no known upper bound on message delay. A slow process and a failed process may therefore look identical to a remote observer.

### 1.2 Why distribution is useful

Distribution may improve scale, availability, geographic reach, fault isolation, resource utilization or organizational autonomy. Each benefit introduces costs: network latency, partial failure, coordination, operational complexity, data consistency problems and harder debugging. Moving a function from one process to another is not a neutral refactor; it changes the failure and timing model.

A useful system boundary identifies which components are inside the system, which dependencies are external, and what assumptions are made about each dependency. For the tank platform, the cloud service must not be the only component capable of stopping the pump: loss of Internet connectivity must not remove the local control loop.

### 1.3 Quantifying latency and load

Average latency is insufficient when a service has a long-tailed distribution. If 99 requests complete in 20 ms and one takes 2 seconds, the mean is 39.8 ms, but the 99th percentile is 20 ms and the 100th percentile is 2 seconds. Use percentiles, throughput and error rates together.

Little's Law states:

\[
L = \lambda W
\]

where \(L\) is the average number of items in a stable system, \(\lambda\) is the average arrival rate, and \(W\) is average time in the system. If a service receives 200 requests/s and average response time is 0.05 s, the average in-flight request count is about 10. This is a steady-state relationship, not a guarantee during overload or unstable queues.

### Worked example

A telemetry service receives 500 messages/s. Average processing time is 40 ms. Under stable load, Little's Law predicts \(L = 500 \times 0.04 = 20\) messages in the processing system. If the system is provisioned for only 10 concurrent workers, the queue grows unless each worker's effective processing capacity or the number of workers increases. Increasing concurrency may improve throughput until CPU, database or network contention becomes dominant.

### Laboratory

Create two processes that exchange a heartbeat message. Add an artificial delay and terminate one process. Observe that a timeout is an observation about elapsed time, not proof of process death. Record the assumptions used by your detector.

### Check your understanding

1. Why is a remote process's slowness indistinguishable from failure in a fully asynchronous model?
2. Name two benefits and three costs of distribution.
3. Under what assumptions is Little's Law useful?

**Worked answer:** A remote observer sees only messages and elapsed local time. If no message arrives, the process may have crashed, the message may be delayed, or the path may be partitioned. Distribution is beneficial for scale and fault isolation, but introduces network delay, partial failure and coordination. Little's Law applies to a stable system over an appropriate observation interval.

---

## Week 2 — Communication, RPC and failure semantics

### 2.1 Messages are not function calls

A local function call normally transfers control within one process. A remote procedure call (RPC) crosses a communication boundary. The caller must serialize arguments, send bytes, wait for a response, deserialize a result and handle connection and protocol errors. Either side may crash at any point.

A timeout means: **the caller stopped waiting**. It does not mean the server did not receive or execute the request. Consider a command to start a pump. The server can perform the command and crash before replying. The client retries, and the command may execute twice unless the application has an explicit deduplication rule.

### 2.2 Request/response states

Model a request as a state machine:

```text
CREATED -> SENT -> RECEIVED -> EXECUTING -> COMMITTED -> REPLIED
                      |            |             |
                      +------------+-------------+--> caller may time out
```

The caller can observe only a subset of these states. A timeout may occur after `COMMITTED` but before `REPLIED`. Thus, client-side timeout and server-side outcome are separate pieces of state.

### 2.3 Delivery and execution semantics

- **At-most-once attempt:** the client does not retry after uncertainty. An operation may be lost.
- **At-least-once attempt:** the client retries until it obtains a response or reaches a policy limit. The server may see duplicates.
- **Effectively-once business effect:** retries are allowed, but the application records a stable operation identifier and ensures the business effect is applied once within a defined scope.

"Exactly once delivery" is generally an unsafe promise across arbitrary failures. An engineer should specify what is exactly-once: message delivery, state transition, database commit, or external physical effect. These are different properties.

### 2.4 Timeouts, retries and backoff

Use a request deadline that propagates across service calls. A timeout hierarchy should be coherent: a downstream operation should not routinely outlive the caller's deadline. Retry only errors that are plausibly transient, and only when the operation is safe to retry. Exponential backoff with jitter reduces synchronized retry storms:

\[
d_n = \min(d_{\max}, d_0 2^n) \cdot U(0.5, 1.5)
\]

where \(d_0\) is the initial delay and \(U\) is a random multiplier. Enforce an overall deadline and retry budget. Retrying a permanently invalid request is not resilience; it is load amplification.

### Worked example: idempotent command

A client sends `command_id = 8f...` to set the pump state to ON. The server stores the command ID and result in the same durable transaction as the state change. A duplicate request with the same ID returns the original result. A different command ID is a distinct operation. The deduplication retention period must be at least as long as the maximum retry/replay horizon.

### Laboratory

Implement a Go HTTP endpoint that accepts `command_id` and a target state. Persist command IDs and results in PostgreSQL or, for the first exercise, in a mutex-protected in-memory map. Add an artificial crash after the state change but before the response. Demonstrate the duplicate-request case. Then explain why the in-memory map is not safe across restarts or multiple replicas.

### Practice

A client times out after sending an update. Give three possible server states and the correct client behavior for each. Explain why generating a new idempotency key on every retry defeats deduplication.

---

## Week 3 — Time, event ordering and logical clocks

### 3.1 Physical clocks are imperfect

A computer clock is an estimate of physical time. Clocks can drift, jump due to correction, or differ between machines. Network time synchronization reduces error but does not create a perfect global clock. Therefore, timestamps alone cannot reliably determine the causal order of distributed events.

### 3.2 Happens-before relation

Lamport's happens-before relation, written \(a \rightarrow b\), is defined by:

1. If events \(a\) and \(b\) occur in the same process and \(a\) occurs first, then \(a \rightarrow b\).
2. If \(a\) is sending a message and \(b\) is receiving that message, then \(a \rightarrow b\).
3. The relation is transitive.

If neither \(a \rightarrow b\) nor \(b \rightarrow a\), the events are concurrent in the causal model. Concurrent does not mean they happened at precisely the same physical instant. It means the model contains no causal path between them.

### 3.3 Lamport clocks

Each process maintains an integer clock. Before each local event, increment it. When sending a message, attach the clock. On receiving a message with timestamp \(t\), set the local clock to \(\max(local,t)+1\). If \(a \rightarrow b\), then \(L(a) < L(b)\). The converse does not necessarily hold: a smaller Lamport timestamp does not prove causality.

### 3.4 Vector clocks

Vector clocks retain a component per process. A process increments its own component for local events and merges received vectors by component-wise maximum before incrementing its own component. For vectors \(x\) and \(y\), \(x < y\) when every component of \(x\) is no greater than the corresponding component of \(y\), and at least one is smaller. If neither vector is less than the other, the events are concurrent.

Vector clocks provide richer causal information but require metadata proportional to the number of tracked processes or groups. Production designs may use bounded or hierarchical alternatives.

### Worked example

Two controllers create events with vector clocks. Process A creates \(x=(1,0)\). Process B creates \(y=(0,1)\). Neither vector dominates the other, so the events are concurrent. A later event at A after receiving B's event may be \(z=(2,1)\), for which \(x<z\) and \(y<z\); both are causally before \(z\).

### Laboratory

Build a three-process event simulator. Compare physical timestamps, Lamport clocks and vector clocks. Construct one execution where physical timestamps order concurrent events, and show why that ordering should not be interpreted as causality.

---

## Week 4 — Replication and state-machine replication

### 4.1 Why replicate?

Replication stores or computes multiple copies of state. It can improve availability, throughput, geographic proximity and recovery from faults. It also creates the problem of coordinating copies. The system must decide which writes are accepted, how updates propagate, how conflicts are resolved and what reads are allowed to observe.

### 4.2 Primary-backup replication

A primary receives writes and propagates ordered updates to backups. This is conceptually simple, but requires a protocol for primary failure and promotion. If two nodes both believe they are primary, split brain can produce conflicting histories. A fencing mechanism or quorum-backed lease can prevent an old primary from continuing to mutate shared resources after its authority expires.

### 4.3 State-machine replication

A deterministic state machine has an initial state \(s_0\), a sequence of commands \(c_1,\dots,c_n\), and a deterministic transition function \(\delta\). Replicas that start from the same state and apply the same commands in the same order reach the same state:

\[
s_{i+1} = \delta(s_i,c_i)
\]

The consensus protocol orders commands; the application state machine applies them. Nondeterminism must be controlled. For example, a replicated command should not independently read a local wall clock at each replica and branch on the result.

### 4.4 Quorums

For a replica set of \(N\) nodes, read and write quorums may be chosen so that they intersect. A common sufficient condition is \(R+W>N\), where \(R\) and \(W\) are read and write quorum sizes. Intersection alone is not the whole correctness proof: version selection, concurrent writes, failure handling and replica recovery also matter.

For \(N=5\), choosing \(R=3\) and \(W=3\) guarantees intersection because \(3+3>5\). It does not automatically guarantee linearizability; that depends on protocol details such as write ordering and read repair.

### Laboratory

Implement a primary plus two replicas for a counter. First use fire-and-forget replication, then wait for one backup, then wait for a majority. Kill nodes at different points. Record which acknowledged writes survive each failure. State the consistency guarantee actually achieved.

---

## Week 5 — Consistency models

### 5.1 Why one word is not enough

"Consistent" may refer to data integrity, replica agreement, or a formal visibility guarantee. A system can preserve database constraints while offering eventual consistency across replicas. Always name the property being promised.

### 5.2 Linearizability

An operation appears to take effect atomically at a point between its invocation and response, and respects real-time order between non-overlapping operations. If a write completes before a later read begins, the later read must observe that write or a later one. Linearizability is valuable for locks, unique ownership and externally visible control state, but it can require coordination and may reduce availability during partitions.

### 5.3 Sequential consistency

There is one total order of operations that respects each process's program order, but it need not respect real-time order across processes. It is weaker than linearizability.

### 5.4 Causal consistency

If one operation causally depends on another, every observer that sees the dependent operation must also see the cause first. Concurrent operations may be observed in different orders. This is useful for systems where causal relationships matter more than a single global order.

### 5.5 Eventual consistency

If no new updates occur and communication/reconciliation continues, replicas eventually converge. Eventual consistency alone does not specify read-your-writes, monotonic reads, conflict resolution or convergence time. A system must define these details.

### Worked comparison

An operator changes a tank threshold from 80% to 90%. A later read by the same operator should usually have read-your-writes behavior. A telemetry dashboard may tolerate a short delay before all regions show the new value. A safety interlock should not depend on an eventually consistent cloud replica. Choose consistency per operation and risk, not per product label.

### Exercise

For account transfer, collaborative document editing, telemetry dashboards and a local emergency stop, choose a consistency model and explain the trade-off. There is not one universally correct answer; the justification is the assessed part.

---

## Week 6 — Failure detection, impossibility and availability

### 6.1 Failure detectors are suspicions

A timeout-based detector can suspect a process, but suspicion is not certainty. A short timeout detects failures quickly but produces false suspicions during congestion. A long timeout reduces false suspicions but delays recovery. Adaptive detectors can estimate expected delay, but cannot eliminate uncertainty in an asynchronous system.

### 6.2 FLP result and practical systems

The Fischer-Lynch-Paterson result shows that in a fully asynchronous message-passing system, no deterministic consensus protocol can guarantee termination in every execution if even one process may crash. The result does not say consensus is impossible in practice. Real systems use additional assumptions such as eventual synchrony, randomized choices or failure detectors. The key is to state which assumption supports progress.

### 6.3 CAP theorem

In the presence of a network partition, a distributed data store cannot guarantee both linearizable consistency and availability for every request to every non-failing node. CAP is not a menu where a system permanently chooses two out of three in all conditions. Partition tolerance is a fact of networked operation; the design decision is how the system behaves when a partition occurs.

### 6.4 Availability budgets

Availability over an interval is \(A = \frac{uptime}{total\ time}\). The unavailability budget is \((1-A)\times T\). At 99.9% availability over a 30-day month, the downtime budget is approximately 43.2 minutes. This arithmetic does not describe the severity of an outage: a 30-second outage at the wrong moment may be unacceptable.

### Laboratory

Simulate a three-node service with controllable message delays and partitions. Change election timeouts and measure false leader suspicions. Distinguish detection latency from correctness.

---

## Week 7 — Consensus: Raft and the core invariants

### 7.1 Consensus problem

Consensus allows a group of nodes to agree on a value or ordered log under a specified failure model. A protocol should satisfy safety (no two correct participants decide conflicting values) and liveness (a decision eventually occurs under stated progress assumptions).

### 7.2 Raft conceptual model

Raft organizes time into terms. A leader is elected for a term; it accepts client commands and replicates log entries. Followers acknowledge entries. A leader commits an entry when the protocol's quorum and current-term rules are satisfied. A new leader must preserve committed history.

The main safety ideas are:
- at most one leader is elected in a term;
- leaders do not overwrite committed entries;
- a candidate's log must be sufficiently up-to-date to win an election;
- followers accept log entries according to term and index rules.

A correct Raft implementation is more than a leader-election demonstration. It must handle crashes, partitions, stale terms, log conflicts, snapshots, persistence ordering and client retries.

### 7.3 Majority arithmetic

For \(N\) voting members, a majority quorum is \(\lfloor N/2 \rfloor + 1\). With five members, three acknowledgements form a majority and tolerate up to two unavailable members for quorum decisions. This does not mean the service continues through every combination of failures: network placement and leader reachability matter.

### Worked example

A five-node cluster has nodes A–E. A leader A commits an entry after A, B and C persist it. A becomes partitioned from B–E. B, C, D and E can elect a new leader only if the new leader's log is eligible under the protocol. A must not independently continue committing entries without a quorum. The quorum intersection plus log-up-to-date rules protect committed history.

### Laboratory

Complete a Raft implementation lab from MIT 6.5840 or an equivalent teaching implementation. Start with deterministic tests and then inject loss, duplication, reordering, partitions and crashes. Do not claim correctness from passing only a happy-path test.

---

## Week 8 — Logs, snapshots, recovery and durable state

A replicated log is an ordered history of state-machine commands. The log must be persisted in a crash-safe order. If a node acknowledges an entry before the required durable write completes, a power loss can erase an acknowledged operation. The protocol's durability claim must match the storage semantics used.

Logs grow indefinitely unless the system takes snapshots or compacts old entries. A snapshot represents the state after a committed log index. A recovering replica loads the snapshot and then applies later entries. Snapshot creation must be coordinated with the log index and configuration so the system does not skip or replay state incorrectly.

Crash recovery separates volatile state, durable state and externally visible acknowledgements. A write-ahead logging discipline generally records the information needed for recovery before overwriting the corresponding data pages. The exact WAL protocol depends on the storage engine; the general rule is that acknowledged durability must have a well-defined persistence boundary.

**Worked example:** If a replica has committed through index 1000, it may snapshot state at 1000 and discard earlier entries only when the snapshot is durable and the replication protocol can safely install it on lagging followers. A follower at index 700 needs either the retained log range or a snapshot plus entries after 1000; it cannot infer the missing state.

**Lab:** Persist a key-value log to disk, restart after a forced process kill, replay committed operations and compare the reconstructed state to a clean execution. Include a crash between writing a record and updating an index. Document the recovery invariant.

---

## Week 9 — Distributed transactions and sagas

A transaction across independent services is difficult because each service owns its own state and may fail independently. Two-phase commit (2PC) separates prepare from commit. A coordinator asks participants to prepare; prepared participants promise they can commit or roll back. The coordinator then announces the decision. Classic 2PC can block if the coordinator fails at a critical time and participants cannot discover the durable decision.

A saga decomposes a long-running business transaction into local transactions with compensating actions. If step three fails after steps one and two committed, the system invokes compensations. A compensation is not necessarily a literal inverse: a refund is not the same as erasing the fact that a payment happened. Sagas trade atomicity for explicit workflow and recovery logic.

Use a transactional outbox when a service must update its database and publish an event. The service writes both the business change and an outbox record in one local transaction; a separate publisher sends the event and marks it delivered. Consumers should be idempotent because delivery may repeat.

**Worked example:** The command service records a requested valve setting and an outbox event. If the process crashes after the database commit but before publication, the outbox publisher recovers the event. If it publishes but crashes before marking it sent, it may publish again; the telemetry consumer deduplicates using event ID.

**Lab:** Build a two-service workflow: command acceptance and audit logging. Demonstrate the failure window without an outbox, then implement an outbox and duplicate-safe consumer.

---

## Week 10 — Sharding, partitioning and rebalancing

Partitioning divides a dataset into subsets. Horizontal sharding distributes rows, commonly by key range or hash. Range partitioning preserves key locality and supports range scans, but may create hotspots for monotonic keys. Hash partitioning distributes keys more evenly, but makes range queries expensive and complicates placement changes.

A partition key should distribute load while aligning with access patterns. A poor key can overload one shard. A shard is not simply a physical database: it also has ownership, routing, replication, failover and rebalancing rules.

Rebalancing transfers data when the number or capacity of nodes changes. Naive rehashing may move most keys. Consistent hashing reduces movement in many designs, but does not eliminate operational coordination, hotspot risk or replica placement concerns.

**Worked example:** A telemetry store receives 10,000 events/s. Sharding by `sensor_id` gives even load only if sensor activity is reasonably uniform. Sharding by event date creates a hot current partition. A composite partitioning scheme may use time buckets plus a hash of sensor ID.

**Lab:** Implement a consistent-hash ring or a deterministic hash partitioner. Measure key movement when adding a node. Then generate skewed sensor traffic and report the hottest partition.

---

## Week 11 — Distributed storage and data-processing architectures

Distributed file systems, object stores, key-value stores and stream processors solve different problems. A file system exposes files and directories; an object store exposes object keys and metadata; a key-value store optimizes keyed reads/writes; a log-based stream platform retains ordered events for consumers; batch frameworks process bounded datasets.

MapReduce introduced a programming model with map and reduce stages, partitioning and shuffle. Stream processors handle unbounded event sequences, where event time and processing time differ. Late-arriving events, duplicate events, watermarks, windowing and replay are first-class concerns.

A design must specify delivery guarantees, ordering scope, retention, backpressure, schema evolution and consumer recovery. "Exactly-once processing" must identify the boundary and mechanism. It often depends on transactional checkpoints or coordinated commits, not on the absence of duplicate messages.

**Lab:** Build an event consumer that aggregates telemetry by five-minute event-time windows. Inject delayed and duplicated events. Compare processing-time windows with event-time windows and describe how late data is handled.

---

## Week 12 — Concurrency control and coordination services

Distributed locks are not ordinary mutexes. A process may pause beyond a lease deadline, lose connectivity and later resume while another process has acquired the lock. A lease alone may not stop the stale process from modifying an external resource. Fencing tokens solve this by issuing monotonically increasing epochs; the resource rejects operations with an older token.

Coordination services provide membership, leader election, configuration and small pieces of shared metadata. They should not be used as high-throughput general-purpose databases. Chubby and ZooKeeper illustrate the separation between a coordination plane and application data plane.

**Worked example:** Process A obtains fencing token 41 and pauses. Its lease expires. Process B obtains token 42 and writes configuration. A resumes and submits a write with token 41. The storage service rejects it because 41 is lower than the last accepted token 42.

**Lab:** Implement a lease simulation with stale clients and a storage API that enforces fencing tokens. Demonstrate the failure of an unfenced lock.

---

## Week 13 — Reliability engineering and operations

Distributed-system correctness includes production behavior. Measure latency percentiles, throughput, saturation, error rates, queue depth, replication lag, leader changes and recovery time. Logs provide event detail; metrics reveal aggregate trends; traces connect work across service boundaries. Use correlation and trace IDs, but avoid logging secrets or personal data.

A service-level indicator (SLI) is a measured property such as successful request fraction or latency. A service-level objective (SLO) is a target over a defined window. An error budget is the allowed amount of SLI failure implied by the SLO. SLOs should reflect user impact, not just the easiest metric to collect.

Failure injection should test realistic fault classes: process crash, network delay, packet loss, disk full, slow database, expired credentials, clock jump and dependency overload. Chaos experiments are controlled hypotheses with safety limits, not random destruction of production systems.

**Lab:** Instrument a service with request counts, latency histogram and dependency errors. Create an SLO for a read API and calculate its error budget. Inject a slow database and show how the symptoms propagate.

---

## Week 14 — Design review and integrated capstone

A distributed-system design review should answer:
- What are the nodes, processes, links and external dependencies?
- What failures are assumed and which are out of scope?
- What consistency guarantee does each operation require?
- How are retries made safe?
- What state is durable, and at what point is success acknowledged?
- How are leaders elected and stale leaders fenced?
- What happens during a partition, overload and recovery?
- Which metrics and tests demonstrate the claimed behavior?

### Final assessment

Submit a running service or deterministic simulator, architecture diagram, failure model, API contract, consistency table, idempotency design, test report, performance report and a design decision record. At least five fault-injection scenarios must be reproducible.

### End-of-course problem set

1. A request takes effect but its response is lost. What does the client know?  
   **Solution:** Only that it did not receive a response before its deadline. The operation may not have arrived, may be executing, may have committed, or may have committed and lost its response. Use a stable operation ID and a query/retry protocol that returns the recorded result.

2. A cluster has seven voters. How many votes form a majority, and how many voters may be unavailable while retaining a majority?  
   **Solution:** A majority is four. Three may be unavailable, assuming the remaining four can communicate and the protocol's placement/failure assumptions hold.

3. Explain why a Lamport timestamp order is not proof of causality.  
   **Solution:** Lamport clocks preserve the implication from causality to increasing timestamp, but independent concurrent events can receive different scalar timestamps. The scalar order imposes an arbitrary total order on events that have no causal relation.

4. A service claims linearizable reads while allowing reads from any stale replica during a partition. What is wrong?  
   **Solution:** A stale replica may return a value older than a completed write, violating real-time order. The design must coordinate reads, use a valid lease/quorum/read-index mechanism, or weaken the guarantee.

## Selected sources and further study

- MIT 6.5840 Distributed Systems (Spring 2026): https://pdos.csail.mit.edu/6.5840/ — lectures, papers, programming labs and exams.
- Harvard CS 2620 Distributed Systems (2026): https://read.seas.harvard.edu/cs2620/2026/ — consensus, Paxos, PBFT, problem sets and papers.
- CMU 15-440/640 Distributed Systems: https://www.cs.cmu.edu/~dga/15-440/F12/ — systems programming and networked services.
- Martin Kleppmann & Chris Riccomini, *Designing Data-Intensive Applications*, 2nd ed. (2026): https://martin.kleppmann.com/2026/03/24/designing-data-intensive-applications-2e.html
- Raft paper and extended version: https://raft.github.io/raft.pdf
- Go memory model: https://go.dev/ref/mem
- Go concurrency and context documentation: https://pkg.go.dev/context
- PostgreSQL concurrency control: https://www.postgresql.org/docs/current/mvcc.html

Use research papers to understand the algorithm and its limits. Use the official lab/course repositories to reproduce implementations. Do not cite a course's existence as evidence that your own implementation is correct.


---

# Course 2 — Model-Based Systems Engineering (MBSE)
**Level:** Upper-undergraduate / early graduate  
**Duration:** 14 teaching weeks  
**Expected workload:** 8–10 hours per week  
**Modeling baseline:** SysML v2 concepts, with explicit comparisons to SysML v1 where useful  
**Prerequisites:** Basic software/system architecture, requirements concepts, elementary algebra, and the ability to read block diagrams.

## Course description

Model-Based Systems Engineering (MBSE) is the disciplined use of structured, connected models to support systems engineering activities across a system's lifecycle. A model is more than a drawing. It is a representation of elements, relationships, properties, constraints, behavior, requirements and evidence, organized so engineers can ask questions and assess consequences.

Document-centric engineering commonly spreads requirements, architecture, interfaces, hazards, analysis and test evidence across separate files. These artifacts may contradict one another after repeated changes. MBSE seeks to make relationships explicit and queryable. It does not remove engineering judgment, guarantee correctness, or make a poor process effective merely because a modeling tool is installed.

This course teaches the thinking behind modeling, then the modeling work products used to describe a system. It uses a remote water-tank controller as a continuous example and includes a model-based capstone. The course is tool-neutral at the conceptual level. A SysML v2-capable environment such as Eclipse SysON may be used for practical work; the exact supported language subset depends on tool maturity and release.

## Learning outcomes

Students completing the course should be able to:
1. Define a system boundary, stakeholders, operational context and lifecycle concerns.
2. Translate stakeholder needs into validated, measurable and traceable requirements.
3. Decompose a system into functions, logical elements, physical elements and interfaces.
4. Represent structure, behavior, constraints and requirements using an appropriate modeling language.
5. Explain the difference between a model, a view, a diagram, a simulation and a digital twin.
6. Maintain traceability from needs through requirements, architecture, analyses and V&V.
7. Assess model quality, completeness, consistency and configuration.
8. Use models to support trade studies, interface reviews and change-impact analysis.
9. Build and review a coherent system model rather than a disconnected diagram collection.

---

## Week 1 — Systems thinking and the system boundary

### 1.1 System, environment and purpose

A system is a set of interacting elements organized to achieve a purpose in an environment. The definition is intentionally broad: elements can include hardware, software, people, facilities, data, procedures and external services. A boundary determines what is treated as part of the system and what is modeled as an external actor or dependency.

Boundary selection is a modeling decision, not a discovery of an objectively obvious line. If a cloud platform is external to a local controller project, its interface and assumptions still matter. Excluding an element from the design model does not remove the risk created by depending on it.

A good system definition identifies purpose, scope, environment, stakeholders, interfaces, operating modes, constraints and assumptions. The system context diagram shows external actors and exchanges. It should not be confused with a detailed component architecture.

### 1.2 Emergent properties

Some important properties belong to interactions rather than individual components. Safety, resilience, usability, performance and security are often emergent. A sensor may be accurate, a controller may be correct and a valve may work mechanically, yet the integrated system can still overfill a tank because the sensor is mounted incorrectly or the command path is delayed.

Systems thinking therefore asks how behavior emerges from relationships, feedback, delays, incentives and operating context. Local optimization may harm global performance. For example, maximizing telemetry frequency can overload a constrained network and delay the control-related messages that matter more.

### Worked example

Purpose: maintain water availability while preventing unsafe filling and allowing local operation during a network outage.

System boundary for the capstone includes the local controller, sensor interface, pump/valve interface, local panel, remote service, command API, event store and operator interface. The water supply, electrical supply, physical tank and Internet are external entities, but they remain explicit context dependencies.

### Laboratory

Create a context diagram. Label every exchanged item as command, measurement, status, power, human input or environmental influence. Identify at least five assumptions that would need stakeholder validation.

---

## Week 2 — Lifecycle, stakeholders and operational concepts

Systems engineering is lifecycle-oriented. A solution is conceived, developed, integrated, verified, validated, operated, maintained, upgraded and eventually retired. Decisions made early constrain later phases. A system that is easy to build but impossible to maintain is not a successful lifecycle solution.

Stakeholders are people or organizations that affect, are affected by, or have an interest in the system. Stakeholder analysis should identify their concerns, authority, success measures and operational context. A stakeholder need is not yet a technical requirement. It is usually expressed in outcome-oriented language, such as "operators must know when the tank is approaching its safe operating limit."

A Concept of Operations (ConOps) describes how the system is expected to be used in context. It should describe users, missions/tasks, operating modes, normal workflows, degraded modes, exceptions, training, maintenance and external dependencies. A good ConOps exposes requirements that would be missed by designing only for a normal day.

### Worked example: operating modes

```text
NORMAL_LOCAL
  - sensor measurements available
  - controller runs autonomous local rules
  - remote telemetry enabled when link is available

DEGRADED_NETWORK
  - local control continues
  - cloud commands are rejected or queued under policy
  - telemetry buffers locally

SENSOR_FAULT
  - controller enters defined safe state
  - alarm is raised locally
  - remote state is marked uncertain

MAINTENANCE
  - authorized technician controls permitted functions
  - safety interlocks remain active
```

The mode names are not themselves requirements. Each mode needs entry conditions, allowed actions, exit conditions and failure handling.

### Laboratory

Write one ConOps scenario for a normal fill cycle and another for a sensor fault plus network outage. Have a second reader role-play an operator and identify missing information.

---

## Week 3 — Requirements engineering for model-based work

### 3.1 Need, requirement and design

A stakeholder need explains a desired outcome. A requirement states a necessary, verifiable condition that the system or element must satisfy. A design decision describes how the solution will satisfy it. Confusing these creates premature design lock-in.

A good requirement is necessary, singular, unambiguous, feasible, consistent, traceable and verifiable. Use a subject, a required action or property, and a measurable condition. Avoid vague words such as fast, easy, robust, sufficient or user-friendly unless they are defined by measurable criteria.

Weak: "The system shall quickly detect overflow."  
Stronger: "When the level input indicates a value at or above the configured high-high threshold, the local controller shall command the inlet valve to its defined closed state within 250 ms."

The stronger statement still requires review: sensor sampling period, measurement uncertainty, valve response time and failure behavior must be considered. A number without a justified rationale is false precision.

### 3.2 Requirement attributes

Store more than the sentence. Useful attributes include identifier, text, rationale, source, owner, verification method, acceptance criterion, priority, status, version, assumptions, allocation and trace links. Bidirectional traceability allows engineers to ask both "what justifies this requirement?" and "what does this requirement affect?"

### Worked example

| ID | Requirement | Verification | Rationale |
|---|---|---|---|
| SYS-001 | The local controller shall continue autonomous level control during loss of the remote network connection. | Test | Cloud dependency must not remove local control. |
| SYS-002 | The controller shall close the inlet valve within 250 ms after a valid high-high input is sampled. | Test | Limit additional inflow after threshold detection. |
| SYS-003 | The remote API shall reject commands from unauthenticated callers. | Test + analysis | Prevent unauthenticated remote actuation. |

### Laboratory

Create 15 requirements. Mark each as stakeholder, system, subsystem, interface, performance, constraint or quality requirement. Reject or rewrite every requirement with no objective verification method.

---

## Week 4 — Modeling foundations: semantics, views and abstraction

A model is a purposeful abstraction of a system. It omits detail that is irrelevant to a question and preserves detail needed to answer it. An architecture view presents a system from a particular viewpoint for particular stakeholders. A diagram is a rendering of selected model information; a set of disconnected diagrams is not necessarily a coherent model.

Model semantics matter. A line between two boxes could mean data flow, physical connection, dependency, ownership or merely visual grouping. If its meaning is not defined by the language or modeling convention, readers may infer different relationships.

A model should support questions such as:
- Which requirement is allocated to the controller?
- Which interface carries a remote command?
- Which behavior occurs when sensor data becomes stale?
- Which tests verify the high-high response?
- What is affected if the valve interface changes?

### Modeling quality properties

- **Correctness:** elements and relations represent the intended system.
- **Completeness:** required aspects are represented at the necessary level.
- **Consistency:** no contradictory values or relationships.
- **Traceability:** links exist between related engineering artifacts.
- **Usability:** stakeholders can understand and query the model.
- **Configuration integrity:** the model has a controlled version and change history.

### Laboratory

Take a context diagram and create a second view for the local control subsystem. Keep the model elements consistent across both views. Record what is intentionally omitted from each view.

---

## Week 5 — Structural architecture and decomposition

Architecture defines major elements, their responsibilities, relationships, interfaces and constraints. Decomposition moves from a whole-system view into subsystems and components. There is no single universally correct decomposition. Functional decomposition groups what the system does; physical decomposition groups the elements that realize it. These views are related but not interchangeable.

A functional model may contain:
- acquire level measurement;
- validate measurement;
- determine control state;
- command actuator;
- publish telemetry;
- authenticate remote operator;
- record command and audit event.

A physical architecture may allocate these functions to a sensor module, local controller, actuator driver, gateway, cloud command service, identity service and database. A function can be allocated across multiple physical elements, and a physical element can support multiple functions.

Interfaces should identify exchanged items, direction, units, protocols, timing, ownership, failure behavior and constraints. "REST API" is not a complete interface definition. It omits operation semantics, schemas, authentication, error handling and version compatibility.

### Worked example

```mermaid
flowchart LR
  Sensor[Level Sensor] -->|measurement + validity| PLC[Local Controller]
  PLC -->|actuator command| Actuator[Pump / Valve]
  PLC -->|telemetry| Gateway[Gateway]
  Gateway -->|HTTPS events| Cloud[Remote Service]
  Operator[Operator] -->|authenticated command| Cloud
  Cloud -->|approved command| Gateway
  Cloud --> DB[(Event / Config DB)]
```

The local controller is the authority for local interlocks. The cloud service is not permitted to bypass those constraints.

### Laboratory

Build a functional decomposition and physical block architecture. Every element must have a named responsibility and every interface must identify at least one exchanged item.

---

## Week 6 — Behavior modeling: activities, states and sequences

Structure says what elements exist. Behavior says what happens, under what conditions, and in what order. Activity models represent workflows and transformations. State machines represent state-dependent behavior. Sequence diagrams show interactions over time between participants.

A state machine is useful when the response depends on current state, event and guard conditions. A state transition can be written:

\[
(q, e, g) \rightarrow (q', a)
\]

where \(q\) is the current state, \(e\) the triggering event, \(g\) the guard condition, \(q'\) the next state and \(a\) the action.

For the controller, `FILLING` should not transition to `IDLE` merely because a remote service sends a stop request. The controller must validate local conditions and the command's authority. Safety-related transitions should be designed so that a communication error cannot accidentally disable local protections.

### Worked example: simplified control states

```mermaid
stateDiagram-v2
  [*] --> IDLE
  IDLE --> FILLING: level below low threshold AND sensor valid
  FILLING --> IDLE: target reached
  FILLING --> SAFE_STOP: high-high OR sensor invalid
  IDLE --> SAFE_STOP: sensor invalid
  SAFE_STOP --> MAINTENANCE: authorized inspection
  MAINTENANCE --> IDLE: checks complete and reset authorized
```

The diagram is a teaching abstraction. Real control behavior must define hysteresis, debounce, sensor diagnostics, actuator feedback, reset conditions and fault response.

### Laboratory

Create a state machine with at least six states and ten transitions. For each transition, specify trigger, guard, action and trace to a requirement. Test unreachable states and ambiguous guards.

---

## Week 7 — SysML v2 concepts and requirements integration

SysML is a general-purpose systems modeling language for specifying, analyzing, designing and verifying systems that may combine hardware, software, information, people, procedures and facilities. SysML v2 was formally adopted by OMG in 2025; SysML v1 remains in use during the transition. A project should choose a language version based on its toolchain, exchange requirements and team capability.

SysML v2 emphasizes textual and graphical notations with a more explicit semantic foundation and standardized API/services. The important learning goal is not memorizing every keyword. It is understanding how model elements and relationships represent requirements, parts, actions, attributes, constraints, interfaces and verification-related work products.

A requirement element should be connected to its source, decomposition, allocation and verification. A diagram that displays requirement text without model relationships provides less value than a model that can answer traceability questions.

### Laboratory

Use a SysML v2-capable tool or a structured model repository. Create package organization, system definition, requirements, part definitions and relationships. Export a table showing each requirement and the model element responsible for satisfying it.

### Model fragment (conceptual, tool-neutral)

```text
Requirement SYS-001
  Text: Local control shall continue during remote network loss.
  Derived from: NEED-003
  Allocated to: LocalController
  Verified by: TEST-001, TEST-004

Part LocalController
  performs: ValidateMeasurement
  performs: DetermineControlState
  performs: CommandActuator
  connected to: LevelSensor
  connected to: ValveDriver
```

This is a readable model fragment, not a claim that the syntax is directly executable in a specific SysML tool.

---

## Week 8 — Interfaces, contracts and integration architecture

An interface is a boundary across which components exchange information, energy, material or control. The interface definition should include the contract: allowed operations, input/output schemas, units, timing, preconditions, postconditions, error states, security and versioning.

For software services, define API operations and event schemas. For physical interfaces, define electrical/mechanical characteristics and operating limits. For human-machine interfaces, define user roles, feedback, failure indications and prohibited actions. Interface mismatches are a major source of integration failure because each component may satisfy its own local specification while disagreeing with the neighboring component.

A contract should identify what the provider guarantees and what the consumer must ensure. Avoid ambiguous ownership of a field or state. For telemetry, define whether timestamps are event time or ingestion time, which component assigns sequence numbers, how invalid readings are represented and how duplicate events are handled.

### Laboratory

Create interface-control tables for sensor-to-controller, controller-to-valve, gateway-to-cloud and operator-to-command API. Include at least one failure case per interface. Review two interfaces as a team and record unresolved assumptions.

---

## Week 9 — Parametrics, constraints and performance reasoning

A parametric model expresses relationships among quantities. It can support sizing, sensitivity analysis, performance budgets and trade studies. A model is only as trustworthy as its assumptions, input data and validation against reality.

For a simple tank, volume may be approximated by \(V = A h\) for a vertical cylindrical tank with constant cross-sectional area \(A\) and level \(h\). If inflow is \(Q_{in}\) and outflow is \(Q_{out}\), then:

\[
\frac{dV}{dt} = Q_{in} - Q_{out}
\]

If area is constant, \(A\frac{dh}{dt}=Q_{in}-Q_{out}\). This simplified relation can estimate how quickly the level changes. It is not a substitute for a physical model when pipe losses, nonlinear geometry, compressibility or pump dynamics matter.

### Worked example

For \(A=2\,m^2\), net inflow \(Q_{in}-Q_{out}=0.01\,m^3/s\). Then \(dh/dt=0.01/2=0.005\,m/s\), or 5 mm/s. If the sample-to-actuation path takes 0.4 s, the level may rise approximately 2 mm during that delay, under the constant-flow approximation. The model tells us which parameter to measure; it does not by itself establish a safe margin.

### Laboratory

Construct a spreadsheet or model for tank level dynamics. Vary sensor delay, actuator delay, inflow and tank area. Plot sensitivity and explain which assumptions dominate the predicted level.

---

## Week 10 — Trade studies and architecture decisions

Architecture is a set of decisions under constraints, not a picture of boxes. A trade study compares alternatives against explicit criteria. First distinguish hard constraints from preferences. Then define criteria, weights (if using a weighted method), scoring scales, evidence and uncertainty.

A weighted sum can be useful:

\[
S_j = \sum_i w_i r_{ij}
\]

where \(w_i\) is the weight for criterion \(i\) and \(r_{ij}\) is the score for alternative \(j\). The resulting score is not an objective truth. The choice of criteria, weights and scores encodes judgment. Sensitivity analysis checks whether the preferred option changes when assumptions vary.

### Worked example

Compare local-only, cloud-centric and hybrid control. Criteria could include local safety autonomy, remote observability, network dependence, maintenance complexity, cost and cyber exposure. A cloud-centric design may score well for remote analytics but fail the hard constraint that local control must operate during network loss. A weighted sum must not override a non-negotiable constraint.

### Laboratory

Produce an architecture decision record with at least three alternatives, decision criteria, constraints, evidence, uncertainty, sensitivity test and selected option.

---

## Week 11 — Model verification, validation and quality assurance

A model itself needs assurance. Verification asks whether the model is syntactically and structurally well-formed and internally consistent. Validation asks whether it is an adequate representation of the real system for the intended use. A syntactically valid SysML model may still represent the wrong operating concept.

Model checks include duplicate identifiers, dangling relations, missing allocations, incomplete interface definitions, orphan requirements, conflicting property values and invalid state transitions. Reviews should inspect both the diagram and the underlying semantic model. Views can hide missing relationships if the reviewer treats the drawing as the whole model.

### Laboratory

Create automated checks or queries that report:
- requirements with no source;
- requirements with no allocated design element;
- requirements with no verification method;
- interface ports with no connected partner;
- state transitions with no defined guard/action;
- components with no assigned function.

Report false positives and limitations. A query that returns zero findings is not proof the model is correct.

---

## Week 12 — Model governance, configuration and change impact

A model is a lifecycle asset. It needs ownership, baselines, access control, naming rules, version history, review status and change management. Configuration management prevents an engineer from validating one model version and implementing a different one without detecting the difference.

Change-impact analysis follows model relations. If the valve response time changes, affected requirements may include shutdown latency, overflow margin, timing budget, safety analysis and verification tests. The model should help find these impacts, but a human engineer must assess whether the relation set is complete.

A model repository should distinguish approved baseline, working branch, proposed change, released version and archived version. Record why changes occurred and which evidence must be repeated after a change.

### Laboratory

Change the valve interface response from 250 ms to 400 ms. Produce an impact report listing affected requirements, calculations, hazards, design elements and test cases. Mark direct impacts separately from possible secondary impacts.

---

## Week 13 — MBSE across disciplines and digital engineering

MBSE provides a common structure for linking systems engineering to software, mechanical, electrical, safety, security, reliability, manufacturing and operations. Interoperability is not guaranteed simply because two tools support SysML. Data semantics, profiles, identifiers, units, versioning and transformations must be controlled.

A digital thread links lifecycle artifacts and their provenance. A digital twin is a model connected to a particular physical asset or operational data stream and used for defined purposes such as monitoring, prediction or control support. A static design model is not automatically a digital twin. A simulation is an execution or analysis of a model under defined assumptions; it does not automatically reproduce reality.

### Laboratory

Choose one model element and trace its identity from requirement to architecture, simulation, implementation and test evidence. Record where data is copied manually, where links are machine-maintained and where semantic transformations could lose information.

---

## Week 14 — Integrated model review and capstone

A model review should be organized around engineering questions, not diagram count. Review system purpose, boundary, stakeholder needs, requirements quality, functional decomposition, architecture, interfaces, behavior, constraints, safety/security connections, verification links, assumptions and model configuration.

### Final submission

Submit:
1. System context and stakeholder map.
2. ConOps with normal and degraded scenarios.
3. A uniquely identified requirement set with sources and verification methods.
4. Structural, functional and behavioral models.
5. Interface definitions.
6. Quantitative model or trade study with assumptions and sensitivity.
7. Traceability and model-quality reports.
8. Change-impact report.
9. Review log and model limitations.

### End-of-course problems

1. Why is a context diagram not a complete architecture?  
   **Solution:** It shows the system boundary and external interactions, but typically omits internal components, responsibilities, interfaces and behavior.

2. A requirement says "The controller shall react quickly." What makes it deficient?  
   **Solution:** "Quickly" is undefined, there is no operating condition or measurable response, and no acceptance criterion can be derived. Rewrite it with an event, condition, measurable time and defined system boundary.

3. A model is syntactically valid. Is it validated?  
   **Solution:** No. Syntax checks well-formedness. Validation requires evidence that the modeled system and behavior adequately represent the real system for the intended engineering purpose.

## Selected sources and further study

- NASA-HDBK-1009A, *NASA Systems Modeling Handbook for Systems Engineering* (active, 12 March 2025): https://standards.nasa.gov/standard/NASA/NASA-HDBK-1009
- OMG SysML official specifications: https://www.omg.org/sysml/
- OMG SysML v2 specification history and documents: https://www.omg.org/spec/SysML/About-SysML/
- NASA Systems Engineering Handbook: https://www.nasa.gov/reference/systems-engineering-handbook/
- SEBoK, Systems Engineering Body of Knowledge: https://sebokwiki.org/
- Eclipse SysON documentation and tutorials: https://doc.mbse-syson.org/
- Capella MBSE tool and training: https://mbse-capella.org/
- NASA Systems Engineering processes and requirements: https://nodis3.gsfc.nasa.gov/

The NASA MBSE handbook is a concrete worked reference for connecting models to stakeholder expectations, ConOps, technical requirements, verification and validation work products. SysML is a language; a sound method, governance process and engineering review are still required.


---

# Course 3 — Safety and Risk Analysis
**Level:** Upper-undergraduate / early graduate  
**Duration:** 14 teaching weeks  
**Expected workload:** 8–10 hours per week  
**Prerequisites:** Basic systems engineering, probability, block diagrams, requirements and elementary control concepts.

## Course description

Safety engineering aims to prevent unacceptable losses arising from system behavior. It considers the system as a whole: hardware, software, operators, procedures, maintenance, organizations, environment and interactions among them. A component can operate exactly as specified while the overall system remains unsafe. For this reason, safety analysis cannot be reduced to finding defective parts or assigning a risk score to each component.

This course introduces hazard analysis, Failure Modes and Effects Analysis (FMEA/FMECA), Fault Tree Analysis (FTA), Event Tree Analysis (ETA), System-Theoretic Process Analysis (STPA), safety requirements, barriers, assurance cases and lifecycle safety management. It emphasizes the strengths and limitations of each technique. A remote water-tank controller provides a consistent example, but the material is educational and does not constitute a certified safety assessment.

## Learning outcomes

Students should be able to:
1. Distinguish loss, hazard, failure, fault, error, accident and risk.
2. Define system-level safety constraints and operating assumptions.
3. Conduct a structured FMEA and explain its limitations.
4. Construct qualitative and simple quantitative fault trees.
5. Use event trees to analyze possible consequence paths.
6. Apply the core STPA steps to software-intensive control systems.
7. Derive safety requirements and allocate them to design elements.
8. Evaluate independent protection layers, human factors and common-cause failures.
9. Construct a structured safety argument supported by evidence.
10. Maintain a hazard log and reassess risk when the design or operating context changes.

---

## Week 1 — Safety engineering foundations

### 1.1 Loss, hazard, accident and risk

A **loss** is an unacceptable outcome for a stakeholder, such as injury, environmental damage, major property damage, mission failure or loss of essential service. A **hazard** is a system state or set of conditions that, together with a particular environment, can lead to a loss. An **accident** is an undesired event or sequence resulting in a loss. A **failure** is the inability of an element to perform a required function; a hazard can exist without a component failure.

For the tank example:
- Loss L-1: a person is injured by electrical or mechanical equipment.
- Loss L-2: water causes unacceptable property damage.
- Hazard H-1: tank water level exceeds the safe physical limit.
- Hazard H-2: pump is energized while the relevant isolation condition is not satisfied.
- Hazard H-3: the controller fails to provide a required shutdown when the level input is unsafe or invalid.

Risk is often treated as a combination of likelihood and consequence, but the meaning of each quantity must be explicit. A numerical score is not a substitute for identifying the scenario, assumptions and uncertainty. Low estimated frequency can coexist with intolerable consequences or weak evidence.

### 1.2 Safety as a system property

A safety problem may arise from unsafe control action, incorrect feedback, timing, inadequate process model, misunderstood displays, maintenance error or conflicting goals. An operator may issue a valid command under a misleading display; the software may accept the request; the actuator may work; the combined result can still be hazardous.

### 1.3 Analysis boundary

Define the system, environment, users, lifecycle stage and losses before selecting an analysis technique. Include maintenance, test, startup, degraded operation and disposal when relevant. State assumptions about sensor accuracy, power quality, actuator response, operator availability and external dependencies.

### Laboratory

Write a one-page safety scope. Identify at least three losses, five hazards, key assumptions and the stakeholders authorized to accept residual risk. Do not assign scores yet.

---

## Week 2 — Hazard identification and preliminary hazard analysis

Hazard identification asks what system states or interactions could create unacceptable losses. It should be performed early and revisited as the architecture evolves. Techniques include structured brainstorming, checklists, functional hazard analysis, guide-word analysis, scenario analysis, interface analysis, operating experience and STPA.

A preliminary hazard analysis (PHA) records hazards before detailed design is complete. A useful record includes hazard ID, description, causes or scenarios, potential losses, operating modes, initial risk rationale, constraints, owner, evidence needed and status. Avoid writing a hazard as a component failure only. "Sensor failed" is not a system hazard statement; "controller uses an invalid level measurement and continues filling" is more informative.

### Worked example

| Hazard | Operating context | Potential loss | Initial constraint |
|---|---|---|---|
| H-1: tank above safe level | filling / unattended | property damage, injury | filling must be stopped before physical overflow |
| H-2: pump remains energized when dry-run prohibited | low supply / sensor fault | equipment damage | pump operation must be inhibited under defined low-water condition |
| H-3: unsafe remote command accepted | remote operation | injury / damage | local safety interlocks must dominate remote commands |

The constraint is at system level; later requirements allocate it to components and interfaces.

### Laboratory

Produce a PHA for normal fill, manual override, sensor fault, network loss, power restoration, maintenance and calibration. For every hazard, identify at least two plausible scenarios.

---

## Week 3 — Failure Mode and Effects Analysis (FMEA)

FMEA is a bottom-up, structured technique. It starts with an item or function, identifies how it could fail, and analyzes local, next-higher-level and system effects. A typical row includes item/function, failure mode, cause, local effect, end effect, detection, existing controls, severity, occurrence, recommended action and responsible owner.

A **failure mode** describes how a function or item fails: stuck open, stuck closed, incorrect output, intermittent operation, loss of output or out-of-tolerance behavior. A **cause** explains why. An **effect** explains what happens at local and system levels. Good FMEA does not stop at the component boundary.

### 3.1 RPN and its limits

Some organizations use a Risk Priority Number:

\[
RPN = S \times O \times D
\]

where S is a severity rating, O an occurrence rating, and D a detectability rating (often a higher D means harder to detect). This is a ranking aid, not a calibrated probability or universal risk metric. Different combinations can yield the same RPN while representing very different safety concerns. A catastrophic severity score must not be hidden by low occurrence or easy detection. Use severity categories and mandatory action rules in addition to any RPN.

### Worked example

A valve can fail stuck open. Assume a teaching scale S=9, O=3, D=6. RPN=162. Another failure has S=4, O=9, D=4, also RPN=144. These numbers do not prove the first event is "only slightly riskier"; the severity difference may dominate the decision. The team should examine the physical scenario, evidence and independent protections.

### Laboratory

Complete an FMEA with at least eight rows covering sensor, controller, communication path, pump, valve, power supply and operator interface. Include system effect, detection method and a recommended action. Explain which rows require escalation regardless of the RPN.

---

## Week 4 — FMECA, criticality and prioritization

FMECA extends FMEA by adding a criticality assessment. Quantitative criticality calculations require defensible failure-rate data, mission time, failure-mode fractions, operating profiles and assumptions. When data is unavailable, a qualitative criticality matrix may be more honest than fabricated numerical precision.

The analysis should identify single-point failures, common-cause failures, latent failures, diagnostic coverage, repair time and exposure duration. A single-point failure is particularly important when no independent protection prevents the hazard. A latent failure is present but not detected until a second event or demand exposes it.

A fault tree and FMECA are complementary. FMECA follows components or functions upward to effects; a fault tree starts with a defined top event and decomposes the combinations that can produce it. Neither replaces the other.

### Worked example

Suppose a high-level sensor can become stuck low. If a separate independent high-high switch exists, the hazard may still be prevented—provided it does not share the same power supply, wiring route, sensing principle, maintenance error or software path in a way that defeats independence. Independence must be argued, not assumed from separate labels.

### Laboratory

Identify single-point and common-cause failure candidates from the prior FMEA. Add a criticality rationale and specify what evidence would be required to treat a protective channel as independent.

---

## Week 5 — Fault Tree Analysis (FTA)

FTA is a top-down deductive analysis. Begin with a precisely defined top event, then use logical gates to express combinations of lower-level events. An OR gate means any input event can cause the parent event; an AND gate means all input events are required. Basic events may be component failures, human actions, environmental conditions or external events.

```mermaid
flowchart TD
  TOP["TOP: Tank overflows"]
  TOP --> OR1{{"OR"}}
  OR1 --> A["Inlet remains open"]
  OR1 --> B["Inflow exceeds safe capacity"]
  A --> OR2{{"OR"}}
  OR2 --> C["Valve stuck open"]
  OR2 --> D["Controller fails to close valve"]
  D --> AND1{{"AND"}}
  AND1 --> E["High-level detection unavailable"]
  AND1 --> F["No effective independent shutdown"]
```

The tree must reflect the actual system boundary, time window and operating conditions. Avoid mixing incompatible event definitions. If "sensor unavailable" already includes disconnected wiring and failed power, do not count those causes again below it without a carefully defined structure.

### 5.1 Minimal cut sets

A cut set is a combination of basic events sufficient to cause the top event. A minimal cut set is one where no proper subset is sufficient. Cut sets help identify critical combinations and single-point vulnerabilities.

### 5.2 Simple probability calculation

If A and B are independent basic events with probabilities 0.01 and 0.02, and the top event requires both (AND), then \(P(A \cap B)=0.01 \times 0.02=0.0002\). If the top event occurs when either A or B occurs (OR), then \(P(A \cup B)=P(A)+P(B)-P(A)P(B)=0.0298\). Independence must be justified; common-cause failure invalidates the simple product.

### Laboratory

Construct a fault tree for "water level exceeds the physical safe limit." Identify minimal cut sets. State whether each independence assumption is credible and identify common-cause paths.

---

## Week 6 — Event Tree Analysis (ETA) and barriers

ETA is an inductive technique. Start with an initiating event and branch through the success or failure of protective functions to identify possible outcomes. The branches describe scenario progression; they do not automatically assign probabilities.

Example initiating event: inlet valve fails open. Barriers may include high-level alarm, independent high-high switch, automatic isolation and operator response. The event tree should consider barrier failure, delayed response, power loss and whether a barrier is truly independent.

Barrier management asks:
- What is the safety function?
- What demand activates it?
- What performance is required?
- How is it tested and maintained?
- How can it be defeated by common cause or human action?
- What evidence proves it is available when demanded?

A backup system is not independent if it shares the same faulty sensor, power source, code path or maintenance procedure.

### Laboratory

Build an event tree beginning with a valve stuck-open event. Include at least three barriers and four distinct consequence paths. Explain which barrier has the greatest influence on the outcome and what evidence supports that claim.

---

## Week 7 — STPA: system-theoretic safety analysis

STPA is a hazard analysis method based on systems theory and control. It is particularly useful for software-intensive systems where unsafe behavior can arise from interactions among correctly functioning components. It does not require a component failure to be the initiating cause.

The core process is:
1. Define losses, hazards and system-level safety constraints.
2. Model the safety control structure, including controllers, controlled processes, actuators, sensors, feedback and external influences.
3. Identify unsafe control actions (UCAs).
4. Identify causal scenarios that could lead to each UCA and derive constraints or requirements.

Four general UCA categories are commonly examined:
- A required control action is not provided.
- An unsafe control action is provided.
- A control action is provided too early, too late or in the wrong order.
- A control action lasts too long or stops too soon.

For the tank system, "command close valve" can be unsafe if issued too late, omitted during a high-high condition, issued when the valve must remain open for a safe purge, or held for an incorrect duration. Context determines safety.

### Laboratory

Draw a control structure. Identify at least six UCAs and map each to a safety constraint. For each UCA, produce two causal scenarios involving feedback, process model, actuator, sensor, operator or coordination.

---

## Week 8 — Causal scenarios, control loops and software

A control loop depends on the controller's process model: what it believes about the controlled process, current state, capabilities and environment. Inaccurate or delayed feedback can make a reasonable control algorithm issue an unsafe command. Software can create hazards through incorrect timing, mode confusion, stale data, incorrect assumptions or unsafe interactions—even if it contains no traditional hardware fault.

A scenario should explain a causal path, not merely repeat the hazard. Example: the sensor reports a plausible but stale low level; the controller's validity logic does not detect staleness; the controller believes the tank is below target; the valve remains open; the independent high-high switch shares the sensor's power feed and is also unavailable. This scenario suggests requirements for freshness, plausibility, diagnostics, independent power and proof testing.

### Laboratory

Write five causal scenarios for one UCA. At least one must involve maintenance, one communication delay, one misleading feedback signal, one human-machine interface and one common-cause failure.

---

## Week 9 — Human factors and operational safety

Human action should be analyzed in context rather than treated as a generic "operator error." Consider workload, display design, alarms, procedures, training, fatigue, authority, incentives, maintenance access and handover. An alarm can be technically correct but operationally useless if it is ambiguous, repeated excessively or arrives after the response window.

Mode confusion occurs when the operator believes the system is in one mode while it is in another. A safe design makes mode and authority visible, prevents ambiguous state transitions and ensures critical controls have clear feedback. Procedures should be tested with representative users and realistic interruptions.

Safety analysis must include test, calibration, configuration, cleaning, bypass, degraded mode and repair. A control that is safe during normal operation may be unsafe during maintenance when interlocks are bypassed.

### Laboratory

Conduct a task analysis for an operator acknowledging a high-level alarm and entering maintenance mode. Identify slips, mistakes, mode confusion and organizational conditions. Propose design changes, not only training.

---

## Week 10 — Safety requirements and risk controls

Hazard analysis becomes useful when it produces design constraints and verifiable requirements. A safety requirement should identify the required behavior, triggering condition, timing, operating context and acceptance criteria. Requirements should be allocated to design elements and linked to verification evidence.

Use the hierarchy of controls carefully. Prefer eliminating a hazard through design where feasible; otherwise reduce risk through engineering controls, independent protective functions, administrative controls and warnings. Warnings and procedures are not equivalent to inherently safer design.

A safety requirement may be:
`SAFE-014: When the high-high channel detects a level above its trip threshold, the independent shutdown path shall de-energize the inlet valve within 300 ms, independent of the remote service.`

The exact threshold, trip logic, valve safe state and timing budget must be derived from physical and operational analysis. The requirement is an educational example, not an approved safety specification.

### Laboratory

For each high-severity hazard, derive one prevention constraint, one detection requirement, one mitigation requirement and one test or analysis. Trace them to system elements.

---

## Week 11 — Safety cases and assurance arguments

A safety case is a structured argument that a system is acceptably safe for a defined application and context, supported by evidence. It is not a document that asserts safety by listing completed analyses. A common structure is Goal Structuring Notation (GSN): claims, strategies, subclaims, contexts, assumptions, justifications and evidence.

Example top-level claim: "The tank control system is acceptably safe for unattended operation within the specified operating envelope." This claim must be decomposed into arguments about overflow prevention, electrical isolation, sensor fault handling, local autonomy, maintenance and operator response. Evidence may include analysis reports, test results, inspection records, operating data and independent review.

An argument can be invalid even when its evidence is real. For example, a successful software unit test does not prove the physical valve closes within the required time. Evidence must support the claim at the same abstraction level and operating context.

### Laboratory

Create a GSN-style assurance argument with one top claim, at least four subclaims, explicit context, assumptions, strategies and evidence references. Mark any claim for which evidence is missing.

---

## Week 12 — Functional safety standards and lifecycle integration

Safety standards define lifecycle processes and evidence expectations for particular domains. IEC 61508 is a foundational generic functional safety standard for electrical/electronic/programmable electronic safety-related systems. Sector standards such as ISO 26262 or IEC 61511 tailor principles to particular industries. Applicability depends on product, jurisdiction, contract and intended use.

A standard should not be treated as a recipe that makes a system safe by compliance alone. The engineering team must identify applicable editions, scope, lifecycle responsibilities, independence requirements, competence expectations and evidence. Standards may be copyrighted; use official publisher or library access rather than unauthorized copies.

Risk reduction may involve design changes, protective functions, procedures or operating limitations. Safety integrity levels (SILs) are not generic labels to add to a design. They involve specific allocation and lifecycle methods defined by applicable standards, with quantitative and qualitative requirements.

### Laboratory

Prepare a standards applicability memo for the educational tank controller. Identify which standard families might be relevant in an actual industrial context, what information is missing to determine applicability, and why no SIL claim is justified from the exercise.

---

## Week 13 — Change, operations and continuous safety management

Safety is not frozen at design release. Equipment ages, software is updated, suppliers change, operators learn workarounds, operating environments shift and maintenance practices evolve. A change must be assessed for new hazards and for changes to existing assumptions, failure rates, diagnostic coverage and safety functions.

Maintain a hazard log with status, owner, decision, rationale, evidence and review date. Record accepted residual risk and who has the authority to accept it. Track safety-significant anomalies, proof-test results, overrides, bypass duration, recurring alarms and incidents. Leading indicators can reveal weakening controls before a loss occurs.

### Laboratory

A valve manufacturer changes the actuator model and response time. Perform a change impact review: requirements, timing budgets, hazard analysis, common-cause assumptions, proof-test procedure, maintenance parts and verification evidence.

---

## Week 14 — Integrated safety assessment

The final safety review should connect:
- defined losses and hazards;
- constraints and safety requirements;
- FMEA/FMECA findings;
- fault-tree and event-tree results;
- STPA control actions and causal scenarios;
- protection architecture and independence argument;
- verification procedures and results;
- residual risk acceptance;
- safety-case claims and evidence;
- assumptions and unresolved issues.

### Final submission

Submit the system definition, hazard log, FMEA, fault tree, event tree, STPA control structure and UCA table, safety requirements, safety-case argument and a review report. The analysis must distinguish known facts, estimates, assumptions and unresolved uncertainty.

### End-of-course problems

1. Is "level sensor failed" a hazard?  
   **Solution:** Not by itself. It is a failure mode. A hazard describes the unsafe system state or condition, such as continued filling while the level is unknown or invalid.

2. Why can two separate shutdown channels still share a common-cause failure?  
   **Solution:** They may share power, sensor physics, wiring, environmental exposure, software, maintenance procedure, configuration data or human oversight.

3. Why is RPN not a probability?  
   **Solution:** S, O and D are typically ordinal ratings. Multiplying them creates a ranking number, not a calibrated probability of loss. Different score combinations can hide different severity profiles.

## Selected sources and further study

- MIT STAMP Institute, STPA and CAST handbooks: https://www.mit.stamp-institute.com/handbooks
- Nancy Leveson, *Engineering a Safer World* (MIT Press): https://mitpress.mit.edu/9780262533690/engineering-a-safer-world/
- NASA Systems Engineering Handbook: https://www.nasa.gov/reference/systems-engineering-handbook/
- NASA Systems Safety and Mission Assurance resources: https://sma.nasa.gov/
- IEC functional safety standards catalogue: https://www.iec.ch/functional-safety
- UK HSE, risk assessment and safety management guidance: https://www.hse.gov.uk/risk/
- SEBoK safety engineering knowledge area: https://sebokwiki.org/

The STPA handbook is especially useful for worked control-structure examples. The NASA handbook provides lifecycle context. Formal standards should be consulted in their controlled official editions for regulated work.


---

# Course 4 — Verification and Validation (V&V)
**Level:** Upper-undergraduate / early graduate  
**Duration:** 14 teaching weeks  
**Expected workload:** 8–10 hours per week  
**Prerequisites:** Software engineering, requirements engineering, basic programming and systems concepts.

## Course description

Verification and validation are evidence-producing engineering processes. Verification asks whether a product or work product satisfies its specified requirements. Validation asks whether the resulting product fulfills its intended purpose in its intended context. The activities may use similar methods—test, analysis, inspection or demonstration—but they answer different questions.

A system may pass every test derived from an incomplete specification and still fail the user's real need. Conversely, a system may appear useful in a demonstration while violating a critical performance, security or safety requirement. V&V therefore begins before implementation: requirements, architecture, testability, acceptance criteria and evidence plans must be designed together.

This course covers requirements quality, V&V planning, test design, levels of testing, integration, automation, model-based testing, formal analysis, performance, safety/security testing, traceability, anomaly management and acceptance. NASA's systems engineering guidance is used as a systems-level reference; software testing methods are taught as complementary techniques.

## Learning outcomes

Students should be able to:
1. Distinguish verification, validation, qualification, acceptance and regression testing.
2. Assess whether a requirement is objectively verifiable.
3. Select test, analysis, inspection or demonstration based on the claim being made.
4. Design tests using equivalence classes, boundaries, decision tables, state transitions and pairwise coverage.
5. Plan unit, integration, system, acceptance and operational tests.
6. Use traceability and coverage measures without confusing coverage with correctness.
7. Design reliable test environments, test data and test oracles.
8. Apply automation, continuous integration, mutation testing and defect analysis appropriately.
9. Verify safety and security requirements with suitable evidence.
10. Produce a reproducible V&V report and support a release decision.

---

## Week 1 — Foundations and the V-model

The V-model is a lifecycle representation that pairs decomposition and specification activities on the left with integration and verification activities on the right. It is a planning aid, not a claim that all projects must follow a waterfall sequence. Early validation and continuous verification can occur throughout iterative development.

At the top, stakeholder needs and operational concepts are validated. System requirements are derived and verified for quality. Architecture and subsystem requirements are decomposed. Implementation follows. On the right, components are verified against their allocated requirements, subsystems are integrated and verified, and the complete system is validated against stakeholder needs and intended operational use.

### Verification vs validation

- **Verification:** evidence that specified requirements are met. "Did we build the product correctly against its approved specification?"
- **Validation:** evidence that the product is suitable for its intended use. "Did we build the right product for its users and mission?"

NASA describes verification as proof of compliance with requirements and validation as proof that the product accomplishes its intended purpose in the intended environment. This distinction should be preserved even when the same test produces evidence for both.

### Worked example

Requirement: `The API shall respond to 95% of valid status requests within 300 ms under 100 requests per second for a 10-minute test.` Verification needs a controlled test environment, request distribution, measurement boundary and pass criterion. Validation asks whether this service level is adequate for operators making decisions. Passing the requirement does not prove the chosen 300 ms threshold is useful.

### Laboratory

Create a V-model for the tank platform. Map each left-side work product to one or more right-side verification activities. Identify at least two validation activities that should occur before the final system is built.

---

## Week 2 — Requirements quality and testability

A requirement is verifiable when objective evidence can determine whether it has been satisfied. The requirement must define the relevant condition, system boundary, stimulus, required response and acceptable range. An untestable adjective is not made testable by writing a test that interprets it arbitrarily.

Weak: "The system shall reliably store telemetry."  
Improved: "For accepted telemetry events, the service shall durably commit the event and return an acknowledgement only after the database transaction commits."  
The improved form is more testable, but its storage durability semantics, failure model and acknowledgement boundary still need definition.

A good verification method is selected during requirements development. Not every requirement should be tested by executing software. A physical dimension may be inspected; a mathematical limit may be verified by analysis; an operator workflow may be demonstrated; a timing requirement may require a controlled test.

### Requirement verification record

For each requirement, capture: ID, exact baseline version, verification level, method, procedure, environment, equipment, sample size, acceptance criteria, result, anomaly ID, evidence URI and approver. This allows a reviewer to reconstruct what was verified and against which product configuration.

### Laboratory

Review 20 requirements. Mark each as verifiable, ambiguous, unverifiable or conflicting. Rewrite at least ten and document the evidence method before writing test cases.

---

## Week 3 — Verification methods and evidence planning

Four common methods are:

- **Test:** operate an end product or representative article to collect measured data.
- **Analysis:** use mathematical reasoning, models, simulation or engineering calculations.
- **Inspection:** examine an item, document, code, physical characteristic or configuration.
- **Demonstration:** show that an item performs a function, typically without the detailed data collection of a formal test.

Method selection depends on requirement type, risk, lifecycle stage, available article, uncertainty and cost. A test is not automatically stronger than analysis. A badly controlled test may provide weaker evidence than a validated analytical model. A demonstration may show a function works once but not establish statistical reliability.

### Worked example

- "Valve body material shall be stainless steel grade X" — inspection of certificates/marking and, where necessary, material test.
- "Valve shall close within 300 ms" — measured test with defined timing boundaries.
- "Network throughput shall not exceed a specified safe utilization in a fixed scenario" — analysis plus load test.
- "Operator can acknowledge alarm using the local panel" — demonstration with representative users, supplemented by usability validation.

### Laboratory

For every capstone requirement, select a method and justify why the method produces sufficient evidence. Identify cases where a combination of methods is required.

---

## Week 4 — Test design: partitions, boundaries and decision tables

Equivalence partitioning divides an input domain into classes expected to behave similarly. Boundary-value analysis concentrates on edges where defects often occur. For a permitted tank threshold of 10%–90%, test below the minimum, at the minimum, just above, typical interior values, just below the maximum, at the maximum and above the maximum. Include invalid units, missing values, overflow and numeric precision where relevant.

Decision tables test combinations of conditions. For example, a command may be accepted only if the user is authenticated, authorized for the facility, the controller is online, the command is within the allowed range and the interlock does not prohibit it. The table exposes combinations that one-condition-at-a-time tests miss.

State-transition testing checks state/event pairs, including invalid transitions. It is especially useful for authentication sessions, maintenance mode, controller states, retry logic and recovery workflows.

### Worked example

Input class for `level_percent`:
- invalid: less than 0;
- lower boundary: 0;
- valid low: 0–10;
- normal: 10–80;
- high: 80–100;
- upper boundary: 100;
- invalid: greater than 100;
- malformed: null, string, NaN, infinity.

The partition boundaries must match domain rules; overlapping classes should be resolved explicitly.

### Laboratory

Build a decision table for remote command acceptance. Derive a minimal test set that covers every rule and every boundary. Include invalid user, valid user without resource ownership, stale controller and active safety interlock.

---

## Week 5 — Unit, component and integration testing

Unit tests verify a small unit in isolation. They are fast and local but may miss interface mismatches, environmental assumptions and distributed failure behavior. Component tests exercise a subsystem with controlled collaborators. Integration tests examine actual interactions across component boundaries.

Test doubles are useful but can lie. A mock can encode the same mistaken assumption as the implementation. Use real dependencies selectively for integration tests, contract tests for interfaces, and fakes for deterministic control of rare failure conditions. The test pyramid is a heuristic about feedback speed and scope, not a universal mandate for a fixed ratio.

Integration strategies include top-down, bottom-up, sandwich and incremental integration. Big-bang integration delays feedback and makes fault localization difficult. Incremental integration reveals interface defects earlier.

### Worked example

The command service writes a command to PostgreSQL and publishes a message. A unit test can verify command validation. An integration test must verify transaction plus outbox behavior. A consumer contract test must verify the event schema. An end-to-end test must prove that an authorized command reaches the controller and local interlocks still dominate.

### Laboratory

Implement tests for one command path at three levels: unit, database integration and API end-to-end. Force the process to crash after database commit but before message publication; demonstrate the outbox recovery.

---

## Week 6 — System, acceptance and operational validation

System testing evaluates the integrated system against system requirements. Acceptance testing determines whether the product is acceptable under the agreed acceptance criteria. Validation assesses suitability for stakeholder use in realistic operational conditions.

A validation scenario should include a user goal, realistic constraints, environment, expected outcome and observation method. A feature demo is not necessarily validation. Ask whether representative users can complete real tasks safely and effectively under normal and degraded conditions.

The ConOps is a useful validation anchor. It describes how the system is intended to be used, including operator roles, mission sequences, training, maintenance and exceptions. If test scenarios cover only the ideal workflow, they cannot validate the actual operating concept.

### Laboratory

Run a scenario-based validation exercise with a representative operator. Include network loss, stale telemetry, conflicting command and maintenance mode. Record task success, time, errors, workarounds and user interpretation of system state.

---

## Week 7 — Test environments, data and reproducibility

A test result is only meaningful when the test configuration is known. Record software revision, hardware, database schema, dependency versions, configuration, environment variables, test data, instrumentation, network profile and time source. If the same test produces materially different outcomes in the same stated conditions, investigate nondeterminism or hidden environmental dependence.

Test data should be representative but safe. Use synthetic or sanitized data; control secrets; avoid production personal information unless a formal approved process exists. Test environments should model the behaviors relevant to the claim, not imitate every production detail blindly.

For distributed systems, deterministic clocks, controllable schedulers, network fault injection and repeatable state initialization make testing more effective. Time-dependent tests should avoid relying on arbitrary sleeps when explicit synchronization or controlled clocks are available.

### Laboratory

Create a reproducible test environment using containers or documented scripts. Run the same tests twice from a clean state. Produce a manifest of versions, data and configuration.

---

## Week 8 — Non-functional verification: performance and reliability

Non-functional requirements are still requirements and need measurable criteria. Performance testing may include load, stress, spike, endurance and capacity testing. Measure latency distribution, throughput, saturation, queue depth, resource consumption, error rate and recovery time.

Reliability testing examines failure behavior over time and under defined conditions. Availability is not identical to reliability. A highly available architecture may recover quickly from component failure; a reliable component may rarely fail but take a long time to repair.

Statistical interpretation matters. If zero failures occur in \(n\) independent trials, the failure probability is not proven to be zero. A rough "rule of three" gives an approximate 95% upper bound of \(3/n\) on the failure probability when zero failures are observed, under suitable independent Bernoulli assumptions. With 1000 failure-free trials, the bound is about 0.003, not zero.

### Laboratory

Load-test the telemetry API at gradually increasing rates. Report p50, p95, p99 latency, throughput, error rate, resource saturation and queue behavior. Run an endurance test and identify memory/resource drift.

---

## Week 9 — Security and safety verification

Security testing should be driven by threat models and security requirements. Test authentication, authorization, object ownership, input validation, session lifecycle, cryptographic configuration, secrets handling, logging and dependency integrity. Include negative tests: a user who is not allowed to act must be denied, and one user's resource must not be accessible through another user's identifier.

Safety verification must test the required safety functions and fault responses. Test normal, degraded and fault states; check timing, independence assumptions and safe-state behavior. A test that disables all safety interlocks for convenience is not a valid demonstration of safe operation.

No finite test suite proves the absence of vulnerabilities or hazards. Testing provides bounded evidence under specified conditions. Analysis, inspection, formal reasoning, operational monitoring and independent review complement it.

### Laboratory

Create one safety verification and one security verification package. Include traceability to the relevant requirement, expected result, negative test, evidence artifact and residual limitation.

---

## Week 10 — Model-based testing and formal verification

Model-based testing derives tests from a behavioral model such as a state machine, activity model or protocol automaton. It can improve transition coverage and reveal missing behaviors. The model itself must be reviewed; incorrect models generate systematic but misleading tests.

Formal methods use mathematical representations to prove properties under explicit assumptions. Examples include invariants, temporal logic, model checking, theorem proving and refinement. A proof applies to the model and assumptions, not automatically to the deployed physical system. The abstraction gap must be considered.

An invariant is a property that must hold in every reachable state. For the control system, one candidate is: `if sensor_valid = false then actuator_enable = false`, provided that this is the intended policy and the actuator is controllable. A temporal property may express that a high-high condition eventually leads to a close command within a time bound. Temporal logic notation should be learned only after the event/state semantics are unambiguous.

### Laboratory

Generate tests from a simple controller state model. Add a model checker or property-based test for an invariant. Deliberately alter a guard so a test exposes an unsafe transition.

---

## Week 11 — Automation, CI and regression

Automated tests provide fast, repeatable feedback, but automation has costs: maintenance, flaky tests, false confidence, environment drift and slow pipelines. Automate stable, valuable checks; retain human review where judgment or context is essential.

A CI pipeline should separate formatting/static analysis, unit tests, component tests, integration tests, security checks and longer system suites. Each stage should produce clear evidence and preserve the failing artifact. Flaky tests should be treated as defects in the test system, not ignored by rerunning until green.

Regression testing evaluates whether changes broke previously working behavior. Select regression tests based on risk and impact, not simply by rerunning every test without analysis. Mutation testing changes code in small ways to assess whether the suite detects behavior changes. It measures test sensitivity for the chosen mutations, not overall test quality.

### Laboratory

Create a CI workflow that runs formatting, linting, unit tests, SQL migration checks and an integration test suite. Add one deliberately introduced defect and demonstrate that the pipeline fails.

---

## Week 12 — Traceability, coverage and defect management

Traceability connects needs, requirements, architecture, code/model elements, tests, results, hazards, threats and anomalies. A verification matrix records which method and evidence demonstrate each requirement. Coverage measures help identify untested areas, but coverage is not proof of correctness.

Common measures include requirement coverage, statement coverage, branch coverage, condition coverage, transition coverage, interface coverage and risk-based scenario coverage. Each answers a different question. 100% statement coverage does not mean every decision outcome, input class or hazard scenario was tested.

An anomaly report should include observed behavior, expected behavior, environment, reproducible steps, evidence, severity, impact, frequency and suspected scope. Triage distinguishes defect, test defect, requirement defect, configuration issue and accepted limitation.

### Laboratory

Create a bidirectional traceability matrix. Calculate requirement verification coverage and identify orphan requirements, orphan tests and tests with no clear objective. Create three anomaly reports with reproducible evidence.

---

## Week 13 — V&V planning, evidence and release decisions

A V&V plan defines objectives, scope, organization, responsibilities, methods, environments, sequence, entry/exit criteria, configuration control, evidence records, reporting and risk handling. It should be baselined before formal verification begins.

A verification report identifies the requirement baseline, product configuration, procedure revision, tools/equipment, operating conditions, results, anomalies and decisions. A pass/fail result without configuration information is difficult to reproduce and may not apply to the delivered build.

Release readiness is a risk-informed decision. Open defects should be assessed against severity, probability, user impact, mitigations, operational constraints and evidence. "All tests pass" is not a sufficient release argument if required tests were omitted, test data was unrepresentative or the test suite does not address major threats and hazards.

### Laboratory

Write a V&V plan and a sample verification report. Include a requirements baseline, test configuration, test cases, evidence, anomaly disposition and release recommendation.

---

## Week 14 — Integrated V&V assessment

The final review should show the chain:

```text
Stakeholder need
      -> validated requirement
      -> architecture allocation
      -> verification method and acceptance criterion
      -> approved procedure
      -> reproducible result
      -> anomaly disposition
      -> verification conclusion

ConOps + representative user
      -> validation scenario
      -> observed operational outcome
      -> stakeholder acceptance / corrective action
```

### Final submission

Submit a requirements quality report, V&V plan, verification matrix, validation plan, test design specification, automated test suite, test environment manifest, executed test report, anomaly log and release decision.

### End-of-course problems

1. A service meets all specified requirements but operators cannot use it under realistic conditions. Is it verified? Validated?  
   **Solution:** It may be verified against its stated requirements but has failed validation. The stakeholder needs or ConOps may be incomplete, or the requirements may not adequately represent actual operations.

2. Does 100% line coverage prove correctness?  
   **Solution:** No. It only indicates executed lines under the coverage tool's measurement. It does not prove correct assertions, adequate input classes, branch outcomes, timing, security or requirement coverage.

3. Why record the tested software version and requirement baseline?  
   **Solution:** Evidence applies to a specific configuration. Without both versions, the reviewer cannot determine which product and specification were assessed.

## Selected sources and further study

- NASA Systems Engineering Handbook: https://www.nasa.gov/reference/systems-engineering-handbook/
- NASA distinction between verification and validation: https://www.nasa.gov/reference/2-4-distinctions-between-product-verification-and-product-validation/
- NASA product verification methods: https://www.nasa.gov/reference/5-3-product-verification/
- NASA V&V plan outline: https://www.nasa.gov/reference/appendix-i-verification-and-validation-plan-outline/
- ISTQB Certified Tester Foundation Level syllabus: https://www.istqb.org/certifications/certified-tester-foundation-level
- Google Testing Blog: https://testing.googleblog.com/
- Hypothesis property-based testing: https://hypothesis.readthedocs.io/
- TLA+ resources: https://lamport.azurewebsites.net/tla/tla.html
- OWASP ASVS 5.0.0: https://owasp.org/www-project-application-security-verification-standard/

NASA's systems-level V&V guidance is particularly useful for method selection and evidence structure. Use software-testing references for detailed test design and automation; do not confuse tool reports with engineering conclusions.


---

# Course 5 — Security Engineering
**Level:** Upper-undergraduate / early graduate  
**Duration:** 14 teaching weeks  
**Expected workload:** 8–10 hours per week  
**Practical environment:** Local lab applications, containers, OWASP Juice Shop or another intentionally vulnerable training system  
**Prerequisites:** Programming, HTTP/API basics, databases, operating systems and networking.

## Course description

Security engineering is the discipline of engineering systems so that assets and missions remain protected under realistic threats and operational constraints. It is broader than adding authentication, installing a scanner or performing a penetration test. Security must shape requirements, architecture, implementation, procurement, operation, maintenance and retirement.

This course develops a systems view of security. It covers security objectives, assets, adversaries, trust boundaries, threat modeling, security requirements, identity, authentication, authorization, cryptographic services, application and API security, data protection, secure development, supply-chain risk, testing, monitoring and incident response. The recurring tank-control platform makes consequences concrete: a remote command endpoint is not just a web route; it is a pathway to a physical effect.

All offensive exercises must be performed only in intentionally vulnerable labs or systems for which the student has explicit authorization. The goal is to learn to identify and prevent weaknesses, not to access real systems without permission.

## Learning outcomes

Students should be able to:
1. Define security objectives and identify assets, trust boundaries and adversaries.
2. Build data-flow threat models and apply STRIDE or another justified method.
3. Convert threats and protection needs into verifiable security requirements.
4. Distinguish identification, authentication, authorization and accountability.
5. Design session, token and access-control mechanisms with explicit assumptions.
6. Explain confidentiality, integrity, authenticity, signatures, key exchange and password hashing.
7. Analyze common web/API vulnerabilities and identify root causes.
8. Apply secure data handling, secrets management and secure configuration.
9. Integrate security into requirements, architecture, code review, CI/CD and operations.
10. Design security tests and incident-response evidence without overclaiming assurance.

---

## Week 1 — Security objectives, assets and threat models

### 1.1 What is being protected?

Security engineering begins by identifying assets and the consequences of their compromise. An asset may be data, a service, a physical process, a credential, a safety function, an identity, an operational capability or an organization's ability to deliver a mission.

The CIA triad—confidentiality, integrity and availability—is a starting vocabulary:
- Confidentiality: prevent unauthorized disclosure.
- Integrity: prevent or detect unauthorized or accidental alteration.
- Availability: preserve timely access to authorized users.

Other properties commonly matter: authenticity, accountability, non-repudiation, privacy, safety and resilience. These properties can conflict. Strong authentication may increase operator friction; broad availability may increase attack surface; detailed logging may improve accountability but expose sensitive data.

### 1.2 Asset and adversary analysis

Identify who may threaten the system, their capability, access, motivation and constraints. Threats may be malicious, accidental or environmental. A curious unauthorized user, compromised supplier, malicious insider, ransomware operator and faulty integration partner are not interchangeable threat actors.

For the tank service, assets include: control authority, configuration thresholds, operator identities, command records, telemetry, audit logs, signing keys, database availability and the integrity of local safety constraints.

### Worked example

An attacker who steals an operator token may issue an authorized-looking command. A network attacker may replay a valid command. A database administrator may alter the audit trail. A compromised gateway may publish false telemetry. Each scenario affects different assets and requires different controls.

### Laboratory

Create an asset register with owner, business/safety consequence, confidentiality requirement, integrity requirement, availability target, dependencies and recovery priority. List at least five adversary types and explain what they can plausibly do.

---

## Week 2 — Trust boundaries and data-flow threat modeling

Threat modeling is a structured process for asking how a design could be attacked or misused, what the consequences would be, and which controls are justified. It should be performed early and repeated as the design changes.

A data-flow diagram should show external entities, processes, data stores, data flows and trust boundaries. The trust boundary marks a change in authority or security assumptions—for example, the boundary between the public Internet and a cloud API, or between a cloud service and a local controller network.

STRIDE categorizes threat classes:
- Spoofing identity;
- Tampering with data or code;
- Repudiation of actions;
- Information disclosure;
- Denial of service;
- Elevation of privilege.

STRIDE is a prompting technique, not a risk score. It helps ensure that reviewers consider different threat types. A threat model should record the specific scenario, affected asset, attack preconditions, impact, existing control, proposed mitigation, owner and verification evidence.

### Worked example

Data flow: Operator browser → public API → command service → gateway → local controller. Trust boundaries exist at browser/API, service/gateway and gateway/controller. Potential threats include stolen session (spoofing), command modification (tampering), missing audit record (repudiation), leaked telemetry (information disclosure), request flooding (DoS) and a low-privilege user changing system-wide thresholds (elevation of privilege).

### Laboratory

Draw the capstone data-flow diagram. Apply STRIDE to each process, store and flow. Record at least 12 concrete threat scenarios; avoid writing generic labels without a plausible attack path.

---

## Week 3 — Risk assessment and security requirements

Security risk combines the likelihood of a threat scenario and its impact, but both estimates are context-dependent. A risk register should preserve the scenario and rationale instead of hiding everything in a single score. Vulnerability severity, exploitability, asset criticality, exposure and business impact are related but distinct concepts. CVSS is a vulnerability severity framework; it is not by itself a complete business risk assessment.

A security requirement should be testable and traceable. Example:
`SEC-004: The command API shall authorize each command against the authenticated principal's role and the target facility's ownership relationship before accepting the command.`

This requirement is stronger than "the API shall be secure." It identifies the operation and the decision criteria. It still needs test cases for valid owner, non-owner, revoked user, stale identity state, missing facility, guessed object ID and privileged role misuse.

Security design principles include least privilege, complete mediation, defense in depth, fail-safe defaults, separation of duties, secure by default, minimize attack surface, economy of mechanism and assume breach. Treat them as design reasoning aids, not slogans.

### Laboratory

Write 15 security requirements for the command platform. Trace each requirement to one or more threats, design elements and verification tests. Include negative authorization cases.

---

## Week 4 — Identity, authentication and session management

Identification states who a principal claims to be. Authentication verifies that claim. Authorization determines what the authenticated principal may do. Accountability records actions and decisions sufficiently to support investigation and governance. These are distinct control stages.

Authentication factors are commonly grouped into knowledge (something known), possession (something held) and inherence (something inherent). Multi-factor authentication requires independent factor categories; two passwords are not two factors. Phishing-resistant authentication uses mechanisms designed to bind authentication to the legitimate service, such as WebAuthn/FIDO2 in suitable contexts.

Passwords should not be stored in plaintext or with a fast general-purpose hash. Use a password-hashing function designed to resist offline guessing, with a unique salt and work factor appropriate to the deployment. Argon2id is a common modern choice; scrypt, bcrypt or PBKDF2 may be selected where compatibility or policy requires them. Parameters must be benchmarked and revisited as hardware improves.

Sessions and tokens require expiration, revocation strategy, secure transport, audience/scope restrictions, protection from theft and safe storage. A signed JWT is not automatically encrypted, revocable or safe to trust indefinitely. Validate issuer, audience, expiry, signature algorithm and key lifecycle; do not accept attacker-controlled algorithm choices or unvalidated claims.

### Laboratory

Implement login and logout in a local training API. Store password verifiers with an appropriate password-hashing library. Add lockout/rate limiting that avoids trivial denial of service, session expiry and a revocation strategy. Write tests for expired, malformed and revoked credentials.

---

## Week 5 — Authorization and access-control models

Authorization determines whether a subject may perform an action on an object under a defined context. Role-Based Access Control (RBAC) assigns permissions to roles. Attribute-Based Access Control (ABAC) evaluates subject, object, action and environmental attributes. Relationship-based access control checks relationships such as ownership, membership or delegation.

Role checks alone often fail at the resource level. An operator role may be allowed to read telemetry, but only for facilities assigned to that operator. The server must verify object-level authorization on every request. Hiding a button in the UI is not authorization.

A policy should specify default deny, permitted operations, scope, delegation, privilege escalation controls, separation of duties and audit requirements. Administrative paths should be deliberately designed because administrators have the potential to bypass normal controls.

### Worked example

Let `canIssueCommand(user, facility, command)` require:
1. user is authenticated;
2. account is active;
3. user has `OPERATOR` or `SUPERVISOR` permission;
4. user is assigned to the facility;
5. command is within the user's operational scope;
6. no higher-priority local safety interlock prohibits the action.

Each condition should have a separate test. The UI may help users understand permissions, but the authoritative decision belongs at the server-side enforcement point and the local controller retains its own safety authority.

### Laboratory

Build an RBAC plus resource-ownership policy. Test direct object references, role changes, revoked accounts, cross-facility requests and privilege inheritance. Produce an authorization matrix.

---

## Week 6 — Cryptography for system engineers

Cryptography provides mechanisms; it does not define a complete security architecture.

- A cryptographic hash maps input to a fixed-size digest. It supports integrity checks and constructions such as digital signatures. It does not authenticate the sender by itself.
- A message authentication code (MAC) provides integrity and authenticity to parties sharing a secret key.
- Symmetric encryption uses a shared secret key and is efficient for bulk data.
- Asymmetric cryptography uses a key pair and supports key exchange and digital signatures.
- A digital signature lets a verifier check that a message was signed by the holder of a private key and was not altered, subject to key trust and algorithm assumptions.
- Authenticated encryption (for example, an AEAD mode) provides confidentiality and integrity together when used correctly.

Key management is often harder than choosing an algorithm. Define key generation, storage, access, rotation, revocation, backup, compromise response and destruction. Never embed long-lived secrets in source code or container images. Prefer managed secret stores or hardware-backed key protection where justified.

Transport Layer Security (TLS) protects communication when correctly configured and certificates are validated. It does not fix an application that trusts the wrong user or authorizes access to the wrong record.

### Laboratory

Use a local cryptography library to compare hash, HMAC and authenticated encryption. Show that a hash alone does not prove who created a message. Demonstrate certificate validation failure in a local test environment.

---

## Week 7 — Input handling and common application vulnerabilities

Many application vulnerabilities arise when untrusted input crosses an interpreter or authority boundary. SQL injection occurs when data is interpreted as SQL syntax. Use parameterized queries rather than string concatenation. Cross-site scripting (XSS) occurs when untrusted data is interpreted as executable browser content; use context-sensitive output encoding and safe templating. Cross-site request forgery (CSRF) exploits a browser's ambient credentials; use appropriate anti-CSRF defenses and SameSite cookie controls according to the application design.

Other important classes include path traversal, unsafe file handling, server-side request forgery (SSRF), insecure deserialization, command injection, memory-safety errors, race conditions and insecure defaults. Validate inputs at trust boundaries, but do not rely on validation alone. Encode outputs for their destination context and use APIs that preserve data/code separation.

### Worked example: injection

Unsafe:
```python
sql = "SELECT * FROM users WHERE email = '" + email + "'"
```

Safer:
```python
cursor.execute(
    "SELECT * FROM users WHERE email = %s",
    (email,)
)
```

The parameterized form sends the value separately from the SQL syntax. It still requires correct authorization and error handling; it does not make every database operation safe automatically.

### Laboratory

Use OWASP Juice Shop or another intentionally vulnerable lab. Identify one injection flaw and one access-control flaw. Write a regression test for each fix. Do not test public systems without written authorization.

---

## Week 8 — API security and distributed command authority

APIs expose operations and data to callers. Secure API design requires authentication, authorization, input validation, schema control, rate limiting, replay protection where needed, safe error handling, auditability and versioning. Treat every identifier supplied by the client as untrusted. A resource ID is not proof of ownership.

Commands that affect physical or financial state need stronger semantics than read-only queries. Use unique command identifiers, expiration or freshness constraints, target binding, audit records and local policy enforcement. A valid cryptographic token should not allow a remote command to bypass a local emergency stop or other safety interlock.

Rate limits should be defined by principal, resource, operation and system capacity. Overly broad limits can allow one client to block another. Backpressure, quotas, request-size limits and queue controls help protect availability.

### Laboratory

Create a command API threat test plan. Test unauthorized, out-of-scope, replayed, stale, oversized and malformed commands. Verify the controller rejects commands that violate local constraints even when they are correctly authenticated by the cloud service.

---

## Week 9 — Data protection, privacy and secrets

Classify data by sensitivity, integrity and retention requirements. Collect only the data needed for a defined purpose. Minimize copies, control access, encrypt sensitive information in transit and at rest where required, and define deletion and backup-expiration behavior. Encryption at rest protects against some storage disclosure scenarios; it does not stop an authorized application process from exposing the data.

Logs can become a high-value attack target. Do not log passwords, access tokens, private keys or unnecessary personal data. Protect audit records against unauthorized modification and deletion, separate operational logs from security audit trails when appropriate, synchronize clocks, and restrict access.

Secrets include passwords, API keys, database credentials, signing keys, certificates and recovery codes. A secret lifecycle includes creation, distribution, storage, access, rotation, revocation and destruction. Rotating a leaked secret without investigating its use may leave an attacker with an active session or copied data.

### Laboratory

Create a data-classification table and retention policy. Scan a test repository for deliberately planted secrets. Replace hard-coded values with environment/secret-store configuration and document rotation steps.

---

## Week 10 — Secure architecture and defense in depth

Security architecture defines trust boundaries, enforcement points, privilege separation, data flows and failure behavior. Defense in depth uses multiple controls so that one control's failure does not automatically expose the asset. Multiple controls are useful only when their failure modes are sufficiently independent.

A local control system may use network segmentation, mutual authentication, least-privilege service identities, command authorization, local allowlists, signed updates and physical controls. The local controller should validate the command's scope and retain local interlocks. A remote cloud service should not become an unrestricted bridge into a physical control network.

Secure defaults matter: disable unused services, remove default credentials, restrict management interfaces, validate certificates, pin supported protocol versions through configuration and avoid exposing debug endpoints. A secure architecture should describe what happens when authentication services, DNS, certificate validation or centralized logging become unavailable.

### Laboratory

Produce a deployment diagram with zones and conduits. For every trust boundary, identify controls, owner, allowed flows, denied flows and failure behavior. Review whether a compromised cloud account can directly disable local safety functions.

---

## Week 11 — Secure development lifecycle and supply-chain security

Security is integrated into each development activity:
- requirements: identify security/privacy needs and threat assumptions;
- design: perform threat modeling and architecture review;
- implementation: apply safe APIs, code review and secure configuration;
- build: protect toolchains, dependencies, secrets and artifact provenance;
- test: run static, dynamic, dependency and targeted security tests;
- release: sign artifacts, record versions and approve known risks;
- operations: monitor, patch, investigate and recover.

SAST analyzes source or compiled code without executing the deployed application. DAST tests a running system from an external perspective. Software composition analysis (SCA) identifies known risks in dependencies. Fuzzing explores unexpected inputs. Manual review identifies design and business-logic problems that tools may not understand. None of these proves the system secure.

Supply-chain threats include malicious packages, compromised build systems, exposed CI credentials, unsigned artifacts, dependency confusion, typosquatting and compromised maintainers. Use dependency pinning, provenance, signatures, least-privilege CI, reproducible builds where feasible and an inventory such as an SBOM.

### Laboratory

Set up a small CI pipeline with static analysis, dependency scanning, unit tests and secret detection. Review the output manually. Identify false positives, false negatives and controls that require human assessment.

---

## Week 12 — Security testing and assurance

Security testing begins with a threat model and security requirements. Tests should cover both allowed and forbidden behavior. A penetration test can demonstrate that an attack path exists; it cannot prove that no vulnerabilities exist. Negative results are bounded by scope, test knowledge, environment and time.

OWASP ASVS provides versioned requirements for application security verification. Reference the version alongside requirement IDs to avoid ambiguity when identifiers change. Use the ASVS as a security requirement and testing baseline, tailoring it to the application risk and architecture.

A good finding includes affected asset, preconditions, reproducible steps in the authorized test environment, impact, evidence, severity rationale, remediation and regression test. Avoid exaggerating a scanner alert into confirmed exploitation without evidence.

### Laboratory

Map at least 15 ASVS 5.0.0 requirements to the capstone. Select five controls and create negative test cases. Record pass/fail evidence and explain what the tests do not prove.

---

## Week 13 — Monitoring, incidents and cyber resilience

Preventive controls cannot guarantee that compromise never occurs. Detection and response are therefore essential. A security incident process identifies events, triages impact, contains the threat, preserves evidence, eradicates persistence, restores service and performs lessons learned.

Monitoring should focus on meaningful signals: anomalous login patterns, privilege changes, unusual command rates, policy denials, unexpected configuration changes, failed integrity checks, unusual data access and suspicious dependency behavior. Alert design should minimize noise and ensure someone owns the response.

Resilience includes the ability to maintain critical functions, isolate compromised elements, recover trusted state and restore service safely. A system should define how it behaves when identity, cloud control, database, network, DNS, time source or update service is unavailable. Availability under attack does not mean accepting every command.

### Laboratory

Write an incident playbook for a compromised operator account and another for a suspected gateway compromise. Include containment authority, evidence preservation, credential rotation, safe local operating mode and restoration criteria.

---

## Week 14 — Integrated security review and capstone

The final security assessment should connect each threat scenario to an asset, requirement, architectural control, implementation mechanism, test and operational owner. It should also document residual risk and unresolved assumptions.

### Final submission

Submit asset and data classification registers, DFD with trust boundaries, threat register, security requirements, identity and authorization model, cryptographic/key-management design, secure deployment diagram, CI security checks, test evidence and two incident playbooks.

### End-of-course problems

1. A user is authenticated. Does that imply they may issue a command to every facility?  
   **Solution:** No. Authentication establishes identity; authorization must evaluate role, resource ownership, scope and contextual restrictions.

2. Why is a signed JWT not necessarily confidential?  
   **Solution:** A typical signed JWT provides integrity/authenticity of claims, not encryption. Its payload can be readable by anyone who obtains the token unless an encryption format is used.

3. Why does a penetration test with no findings not prove the system is secure?  
   **Solution:** The result is bounded by test scope, methods, coverage, assumptions and time. It demonstrates that the chosen tests did not reveal a flaw, not that no flaw exists.

## Selected sources and further study

- NIST SP 800-160 Vol. 1 Rev. 1, *Engineering Trustworthy Secure Systems*: https://csrc.nist.gov/pubs/sp/800/160/v1/r1/final
- NIST SP 800-218, Secure Software Development Framework (SSDF): https://csrc.nist.gov/pubs/sp/800/218/final
- OWASP Application Security Verification Standard 5.0.0: https://owasp.org/www-project-application-security-verification-standard/
- OWASP Cheat Sheet Series: https://cheatsheetseries.owasp.org/
- OWASP Juice Shop: https://owasp.org/www-project-juice-shop/
- PortSwigger Web Security Academy: https://portswigger.net/web-security
- MITRE ATT&CK: https://attack.mitre.org/
- CWE: https://cwe.mitre.org/
- NIST Cybersecurity Framework 2.0: https://www.nist.gov/cyberframework
- Ross Anderson, *Security Engineering*, 3rd ed. author site: https://www.cl.cam.ac.uk/archive/rja14/book.html

Use standards and versioned checklists as controlled baselines. The NIST and OWASP documents are not substitutes for jurisdiction-specific privacy, safety, sector or contractual requirements.


---

# Course 6 — Data Systems and Databases
**Level:** Upper-undergraduate / early graduate  
**Duration:** 14 teaching weeks  
**Expected workload:** 8–10 hours per week  
**Practical platform:** PostgreSQL 18 or another current relational database; optional implementation exercises in C++/Rust/Go  
**Prerequisites:** Programming, data structures, discrete mathematics and basic command-line use.

## Course description

A database system is not merely a place to store rows. It is a software system that models information, enforces integrity, processes queries, coordinates concurrent transactions, persists state, recovers from failure and exposes interfaces to applications. Data systems engineering extends this foundation to replication, partitioning, streaming, analytical workloads, data governance and distributed storage.

This course covers the relational model, conceptual/logical/physical design, relational algebra, SQL, normalization, storage engines, indexes, query processing, transaction semantics, concurrency control, recovery, migration, data quality and distributed database trade-offs. It uses PostgreSQL for concrete experiments and links database behavior to the remote tank platform.

The course deliberately distinguishes logical correctness from physical performance. A schema can be normalized but slow for a workload; an index can improve one query and degrade writes; a transaction can be atomic locally but not across independent services.

## Learning outcomes

Students should be able to:
1. Explain the relational model, keys, constraints and relational algebra.
2. Transform an ER model into relations and assess normalization.
3. Write SQL queries using joins, grouping, subqueries and window functions.
4. Explain storage pages, records, buffer pools, indexes and query plans.
5. Analyze ACID properties, transaction schedules and isolation anomalies.
6. Compare locking, timestamp ordering, optimistic concurrency and MVCC.
7. Explain write-ahead logging, checkpoints, backups and point-in-time recovery.
8. Design safe schema migrations and data-quality controls.
9. Evaluate replication, sharding, consistency and distributed database trade-offs.
10. Design and benchmark a database-backed application with reproducible evidence.

---

## Week 1 — Data models and database system architecture

A data model defines the structure of information and the constraints on it. Common models include relational, document, key-value, graph and column-family models. The choice depends on access patterns, integrity requirements, query needs, scale, operational skills and consistency requirements. A fashionable model is not automatically the right model.

A database management system (DBMS) typically includes a query processor, optimizer, execution engine, storage manager, buffer manager, transaction manager, concurrency-control subsystem, log/recovery subsystem and catalog. The application submits logical queries; the DBMS chooses a physical plan and coordinates access to stored data.

Separate three design levels:
- **Conceptual model:** business entities, relationships and rules.
- **Logical model:** relations, keys, attributes and constraints.
- **Physical model:** data types, indexes, partitions, storage parameters and deployment.

The distinction makes change easier to reason about. A physical index should not redefine the business meaning of an entity.

### Worked example

For the tank platform, conceptual entities include Facility, Tank, Sensor, Measurement, Command, User, Role and AuditEvent. The logical design identifies primary and foreign keys. The physical design chooses partitioning for time-series measurements, indexes for facility/time queries and retention rules.

### Laboratory

Draw a conceptual ER model with cardinalities and optionality. Do not choose data types or indexes until the business relationships and integrity rules are clear.

---

## Week 2 — Relational model, keys and integrity

A relation is a set of tuples over attributes. In the practical SQL model, tables can contain duplicate rows unless constraints prevent them, so designers should explicitly identify keys and integrity rules.

A candidate key is a minimal set of attributes that uniquely identifies a tuple. A primary key is the chosen candidate key. A foreign key enforces a referential relationship. A superkey uniquely identifies rows but may contain unnecessary attributes. Natural keys have domain meaning; surrogate keys are generated identifiers. The decision should consider stability, uniqueness, privacy and integration behavior.

Integrity constraints include domain constraints, NOT NULL, UNIQUE, CHECK, primary-key and foreign-key constraints. Enforcing integrity in the database protects against bugs in multiple application clients. Application validation improves user feedback, but it should not replace critical database constraints.

### Worked example

```sql
CREATE TABLE facility (
    facility_id bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    name text NOT NULL,
    timezone text NOT NULL
);

CREATE TABLE tank (
    tank_id bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    facility_id bigint NOT NULL REFERENCES facility(facility_id),
    tank_code text NOT NULL,
    capacity_litres numeric(12,2) NOT NULL CHECK (capacity_litres > 0),
    UNIQUE (facility_id, tank_code)
);
```

The composite unique constraint prevents duplicate tank codes within a facility while allowing the same code at another facility. The foreign key prevents a tank from referencing a nonexistent facility.

### Laboratory

Implement a schema with primary, foreign, unique and check constraints. Attempt invalid inserts and confirm that the database—not only the application—rejects them.

---

## Week 3 — Functional dependencies and normalization

A functional dependency \(X \rightarrow Y\) means that for any two rows, if their X values are equal, their Y values must also be equal. It describes a constraint of the domain, not merely a pattern observed in sample data.

Normalization reduces undesirable redundancy and update anomalies:
- 1NF requires attribute values to be atomic within the chosen relational model.
- 2NF requires non-prime attributes to depend on the whole candidate key, not part of a composite key.
- 3NF requires non-prime attributes not to depend transitively on a candidate key; formally, for every non-trivial FD \(X \rightarrow A\), either X is a superkey or A is prime.
- BCNF requires every determinant of a non-trivial functional dependency to be a superkey.

Normalization can reduce insertion, update and deletion anomalies. It does not mean that every table must contain one column or that all denormalization is wrong. Denormalization can be a justified performance decision when the duplicated facts have clear ownership and a reliable update strategy.

### Worked example

Consider `Enrollment(student_id, course_id, student_name, course_title, grade)` with key `(student_id, course_id)`. Dependencies include `student_id -> student_name`, `course_id -> course_title`, and `(student_id, course_id) -> grade`. The table has partial dependencies on parts of the composite key. Decompose into Student, Course and Enrollment. Each fact then has one authoritative location.

### Laboratory

Given a relation and a list of functional dependencies, identify candidate keys, find violations of 2NF/3NF/BCNF and produce a lossless decomposition. Explain whether dependency preservation is achieved.

---

## Week 4 — Relational algebra and SQL

Relational algebra provides operations that express queries over relations. Selection filters tuples; projection chooses attributes; union combines compatible relations; difference subtracts tuples; Cartesian product pairs tuples; joins combine related tuples. These ideas help explain how a DBMS can transform and optimize queries.

SQL is declarative: the user states the desired result, and the DBMS chooses a plan. SQL includes DDL (schema definition), DML (data manipulation), DQL (querying) and transaction control. A SQL query is not necessarily executed in the textual order in which clauses appear.

### Worked query

```sql
SELECT f.name,
       count(m.measurement_id) AS readings,
       avg(m.level_percent) AS avg_level
FROM facility AS f
JOIN tank AS t ON t.facility_id = f.facility_id
JOIN measurement AS m ON m.tank_id = t.tank_id
WHERE m.measured_at >= now() - interval '24 hours'
GROUP BY f.facility_id, f.name
HAVING count(m.measurement_id) >= 100
ORDER BY avg_level DESC;
```

The query joins facilities to tanks to measurements, filters the time range, groups by facility, filters groups with at least 100 readings, then orders the result. The `HAVING` condition applies after grouping. `WHERE` filters input rows before aggregation.

Understand NULL semantics. `NULL` means unknown or missing, not zero or an empty string. Comparisons with NULL produce unknown; use `IS NULL` and `IS NOT NULL`. Aggregates usually ignore NULL values except `COUNT(*)`, which counts rows.

### Laboratory

Write queries for: recent high-level alerts, daily average per tank, tanks with no telemetry, users who issued commands, and facilities whose number of active alarms exceeds a threshold. Explain how NULL values affect each query.

---

## Week 5 — Storage engines and physical data layout

A DBMS maps logical records to pages or blocks on storage. It may use heap files, sorted files, log-structured storage or other layouts. The buffer pool caches pages in memory. A page-oriented system reads and writes blocks rather than treating each row as an independent disk operation.

A table scan reads the relevant pages and checks rows. A sequential scan can be optimal when a large fraction of a table is needed. An index supports targeted lookup but adds storage and write overhead. Physical design depends on workload selectivity, data distribution, locality, row width, update patterns and cache behavior.

Write-ahead logging records changes needed for recovery. A common rule is that the log record describing a data-page change must become durable before the modified data page is written. This allows recovery to redo committed changes and undo or ignore incomplete changes according to the DBMS's protocol.

### Laboratory

Create a table with a million generated telemetry records. Measure table size, insert rate and sequential scan time. Observe how row width and data volume affect performance.

---

## Week 6 — Indexing and query optimization

An index is an auxiliary data structure that helps locate rows. B+ trees support ordered lookup and range queries. Hash indexes support equality lookup under the supported DBMS semantics. Bitmap and inverted indexes serve particular workloads. Indexes are not free: they consume storage, slow writes, require maintenance and may be ignored by the optimizer.

A query optimizer estimates the cost of candidate plans using statistics such as table cardinality, value distribution and selectivity. It may choose nested-loop, hash or merge joins, along with scans and index access. Bad estimates can lead to bad plans, especially with correlated columns, skew and stale statistics.

Use `EXPLAIN` to inspect the plan and `EXPLAIN ANALYZE` to compare estimates with actual execution. `EXPLAIN ANALYZE` executes the statement; be careful with data-modifying queries and production data.

### Worked example

An index on `(tank_id, measured_at)` can support a query that filters by tank and time range. An index on `measured_at` alone may be more useful for queries that scan all tanks for a time range. The best index depends on query patterns, cardinality and write frequency.

### Laboratory

Run the same query with and without a composite index. Capture execution plans, actual rows, estimated rows, execution time and buffer activity. Explain whether the index helps and why.

---

## Week 7 — ACID transactions and transaction boundaries

A transaction groups operations into a unit with ACID properties:
- Atomicity: all operations of the transaction take effect or none do.
- Consistency: constraints that are defined for the database are preserved by committed transactions.
- Isolation: concurrent transactions behave according to the isolation guarantee.
- Durability: committed changes survive the failure model promised by the system.

ACID does not automatically make business logic correct. A transaction can atomically commit an invalid state if the application failed to express the intended constraint. Consistency means the database's declared invariants are maintained; it does not mean every domain requirement was correctly declared.

A transaction should cover a coherent unit of work, avoid unnecessary duration and use appropriate constraints and locking. Long transactions can increase contention, delay vacuum/cleanup and complicate recovery.

### Worked example

```sql
BEGIN;

UPDATE tank
SET target_percent = 75
WHERE tank_id = 42;

INSERT INTO audit_event(event_type, object_id, actor_id)
VALUES ('TARGET_CHANGED', 42, 17);

COMMIT;
```

The target change and audit event commit together if both are part of the same database transaction. If the audit store is an external service, this local transaction does not make the cross-service operation atomic; use an outbox or another explicit coordination design.

### Laboratory

Implement a transaction that changes configuration and writes an audit record. Force an error between the statements. Demonstrate rollback and then test concurrent updates.

---

## Week 8 — Isolation anomalies and concurrency control

Concurrent transactions can interfere. Common anomalies include:
- dirty read: observing uncommitted data;
- non-repeatable read: reading the same row twice and observing different committed values;
- phantom: a repeated predicate query returns a different set;
- lost update: one update overwrites another without incorporating it;
- write skew: concurrent transactions make individually valid decisions that jointly violate a constraint.

Isolation levels specify which behaviors are prevented. Exact implementations vary by DBMS. PostgreSQL uses MVCC: a statement sees a snapshot, reducing read/write blocking. Its `READ COMMITTED`, `REPEATABLE READ` and `SERIALIZABLE` behavior should be studied from PostgreSQL's own documentation, including serialization failures that the application must handle.

Concurrency-control methods include two-phase locking (2PL), timestamp ordering, optimistic concurrency control and MVCC. 2PL acquires locks and has a growing phase followed by a shrinking phase; strict 2PL holds write locks until commit/abort. Optimistic concurrency control allows work to proceed and validates before commit. MVCC maintains versions so readers can observe snapshots.

### Worked example: write skew

Two operators each check that at least one of two pumps remains enabled. Transaction A sees pump 1 and pump 2 enabled, then disables pump 1. Transaction B sees the same original state, then disables pump 2. If both transactions commit under an isolation mode that permits the anomaly, the final state has no pump enabled. The rule must be enforced using an appropriate serializable transaction, explicit locking, a constraint on a shared row or another correct design.

### Laboratory

Open two database sessions. Reproduce a lost update or write skew under a permissive isolation level. Repeat under serializable isolation and handle serialization failure with a bounded retry strategy.

---

## Week 9 — Recovery, backups and durability

Recovery restores a database to a consistent state after crash or corruption. Write-ahead logging records changes so the system can recover durable transactions. Checkpoints limit recovery work by establishing a known point from which log replay can proceed.

A backup is not proven useful until restoration has been tested. Distinguish full, incremental and differential backups; physical and logical backups; and point-in-time recovery. Recovery objectives include Recovery Point Objective (RPO), the maximum tolerable data loss measured in time, and Recovery Time Objective (RTO), the target time to restore service.

A replica is not a backup: corruption or malicious deletion can replicate. A backup is not a high-availability solution: restoration may take too long for the service objective. Use backups, replicas, archival retention and tested recovery procedures for different needs.

### Worked example

If the service requires an RPO of five minutes, the backup/log-archiving strategy must ensure that the recoverable point is no more than five minutes before the incident under the defined failure assumptions. If restoration takes two hours but the service's RTO is 30 minutes, the design is insufficient even if the data is preserved.

### Laboratory

Create a backup, modify or delete test records, restore to a separate database and compare row counts and integrity checks. Record actual restore time and recoverable timestamp. Do not label a backup system "tested" based only on successful backup creation.

---

## Week 10 — Migrations and schema evolution

A schema evolves as requirements change. A migration must coordinate application versions, database versions, data transformation, rollback strategy, availability and compatibility. Large blocking migrations can cause outages. A safer pattern is often expand–migrate–contract:
1. Add the new structure while retaining compatibility.
2. Deploy code that can read/write the compatible form.
3. Backfill or transform data in bounded batches.
4. Switch reads to the new representation.
5. Remove the old structure only after all consumers have migrated.

Migrations should be versioned, repeatable where possible, reviewed, tested on representative data and observable during execution. A migration that works on a 100-row development table may fail on a production table with millions of rows and concurrent writes.

### Laboratory

Rename a field through an expand–migrate–contract process. Demonstrate compatibility between old and new application versions. Add a migration test and a rollback/forward-recovery decision.

---

## Week 11 — Data quality, governance, lineage and retention

Data quality can be assessed through accuracy, completeness, consistency, timeliness, validity, uniqueness and fitness for purpose. These dimensions are not interchangeable. A measurement may be syntactically valid but physically implausible. A missing value may be correct if a sensor was offline; replacing it with zero creates false information.

Enforce quality at multiple layers: input validation, database constraints, domain checks, deduplication, reconciliation, monitoring and human review. Preserve provenance: source, event time, ingestion time, transformations, schema version and correction history. Data lineage records where data came from and how it was transformed.

Governance defines ownership, access, classification, retention, deletion, legal constraints, data-sharing rules and audit responsibilities. Retention must be justified by operational, legal, safety and privacy needs. Do not retain sensitive data indefinitely simply because storage is cheap.

### Laboratory

Define quality rules for telemetry: valid range, timestamp freshness, sensor identity, duplicate event ID, missing sequence and plausible rate of change. Implement SQL checks and generate a data-quality report.

---

## Week 12 — Distributed databases: replication, sharding and consistency

Distributed databases partition and/or replicate data across nodes. Replication can improve availability and read locality, but introduces replica lag, conflict resolution, write coordination and recovery complexity. Sharding distributes data and load, but complicates joins, transactions, rebalancing and global constraints.

Synchronous replication waits for acknowledgements according to a defined durability policy; asynchronous replication may lose recent acknowledged writes during failover depending on the design. A read from a lagging replica may return stale data. The API should specify whether it offers read-your-writes, monotonic reads, causal guarantees or linearizability.

The CAP theorem concerns the impossibility of guaranteeing both linearizability and availability to every request during a network partition. It does not mean all databases must choose two properties permanently. Partition behavior depends on the operation and consistency guarantee. PACELC adds the observation that systems make latency/consistency trade-offs when there is no partition as well.

### Laboratory

Run a primary/replica setup or a simulator. Introduce replication lag and compare read results. Design a sharding key for telemetry and measure skew. Explain which queries become cross-shard operations.

---

## Week 13 — Analytical data systems and event-driven architectures

Online Transaction Processing (OLTP) systems support many small, concurrent state changes with strong integrity requirements. Online Analytical Processing (OLAP) systems support large scans and aggregations across historical data. Their storage and query patterns differ. Row-oriented storage is often useful for transactional access; columnar storage can be efficient for scans over a subset of columns.

A data warehouse integrates data for analysis. A data lake stores large volumes of data in varied formats, but without governance it can become a data swamp. A lakehouse combines aspects of data lake storage with table metadata and transaction features. Architectural labels do not replace explicit consistency, schema, ownership, retention and quality definitions.

Event-driven data systems use logs or messaging platforms to decouple producers and consumers. Events describe facts that happened; commands request actions. Event schemas need versioning. Consumers must handle duplicate delivery, delayed events, ordering scope, poison messages and replay. A data pipeline should preserve lineage and make reprocessing safe.

### Laboratory

Create an event pipeline that ingests sensor events, stores raw records and builds daily aggregates. Reprocess a date range and compare results. Document how schema changes and duplicate events are handled.

---

## Week 14 — Database design review and capstone

A database design review asks:
- What entities and facts are represented?
- Which constraints protect integrity?
- What are the critical query patterns?
- Which indexes support those patterns and what do they cost?
- What isolation level supports each transaction?
- How are deadlocks and serialization failures handled?
- What is the durability boundary?
- What are the backup, restore and retention guarantees?
- How do schema changes roll out?
- What happens during replication lag, partition and failover?

### Final submission

Submit an ER diagram, normalized logical schema, SQL DDL, migration history, representative queries, query plans, transaction/anomaly experiment, backup/restore evidence, data-quality report, distributed architecture note and performance analysis.

### End-of-course problems

1. What is the difference between a superkey and a candidate key?  
   **Solution:** A superkey uniquely identifies rows but may contain unnecessary attributes. A candidate key is a minimal superkey.

2. Why is a read replica not a backup?  
   **Solution:** Incorrect updates, malicious deletion and corruption may be replicated. A backup preserves a recoverable historical state under a separate retention and access model.

3. Why can a transaction pass at READ COMMITTED but fail under SERIALIZABLE?  
   **Solution:** A serializable engine may detect that concurrent transactions cannot be ordered as a valid serial execution. It aborts one transaction to preserve the guarantee. The application must handle the serialization failure.

4. Does adding an index always improve performance?  
   **Solution:** No. It adds storage and write/maintenance costs, may not be selective, may not match the query predicate/order, and may be slower than a sequential scan for large result fractions.

## Selected sources and further study

- CMU 15-445/645 Intro to Database Systems (Fall 2026): https://15445.courses.cs.cmu.edu/fall2026/
- CMU Database Group course catalogue: https://db.cs.cmu.edu/courses/
- PostgreSQL 18 documentation: https://www.postgresql.org/docs/18/
- PostgreSQL MVCC and concurrency control: https://www.postgresql.org/docs/18/mvcc.html
- PostgreSQL transaction isolation: https://www.postgresql.org/docs/18/transaction-iso.html
- MIT 6.5830 Database Systems: https://dsg.csail.mit.edu/6.5830/
- *Database System Concepts*, Silberschatz, Korth and Sudarshan: https://www.db-book.com/
- *Designing Data-Intensive Applications*, 2nd ed. (2026): https://martin.kleppmann.com/2026/03/24/designing-data-intensive-applications-2e.html
- SQLite documentation for a lightweight second DBMS comparison: https://www.sqlite.org/docs.html

CMU's course provides particularly strong coverage of database internals and programming projects. PostgreSQL documentation should be used for precise engine-specific behavior; do not generalize PostgreSQL's implementation details to every DBMS.

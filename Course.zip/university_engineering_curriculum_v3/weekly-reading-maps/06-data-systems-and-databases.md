# Weekly Reading Map — Data Systems and Databases

| Week | Core reading / lecture route | Primary artifact to produce |
|---:|---|---|
| 1 | [CMU 15-445/645 Fall 2026 schedule](https://15445.courses.cs.cmu.edu/fall2026/schedule.html); *Database System Concepts* companion site | DBMS architecture, data model and workload classification |
| 2 | CMU 15-445 relational model/SQL lectures; [PostgreSQL 18 SQL docs](https://www.postgresql.org/docs/18/sql.html) | Schema, keys, constraints, SQL NULL/duplicate behavior |
| 3 | Database System Concepts relational design chapters; CMU course notes | Functional dependencies, candidate keys and BCNF decomposition proof |
| 4 | CMU relational algebra/query processing lectures; PostgreSQL query docs | Algebra trees, query rewrites and SQL semantic equivalence |
| 5 | CMU [Project 1: Buffer Pool](https://15445.courses.cs.cmu.edu/fall2026/project1/); local diskdb page-file and LRU buffer-pool lab | Page layout, buffer pool invariants and B+ tree split trace |
| 6 | CMU [Project 2: B+ Tree](https://15445.courses.cs.cmu.edu/fall2026/project2/); local disk-backed B+ tree | Index choice, B+ tree behavior and workload trade-off report |
| 7 | CMU query execution/optimization lectures; PostgreSQL `EXPLAIN` docs | Join algorithms, cost model and plan comparison |
| 8 | CMU transactions/concurrency lectures; PostgreSQL explicit locking docs | Conflict-serializability graph, lock schedule and deadlock analysis |
| 9 | [PostgreSQL 18 MVCC](https://www.postgresql.org/docs/18/mvcc.html); [transaction isolation](https://www.postgresql.org/docs/18/transaction-iso.html) | Isolation anomaly, write-skew reproduction and retry policy |
| 10 | CMU recovery lectures; local WAL/redo recovery lab and PostgreSQL WAL/backup docs | WAL timeline, recovery model, checkpoint and restore plan |
| 11 | DDIA replication/partitioning chapters; MIT 6.5840 distributed DB material | Replication mode, sharding strategy and loss/latency analysis |
| 12 | CMU analytical query/data architecture lectures; PostgreSQL aggregate/window docs | OLTP/OLAP schema, event processing and analytical query design |
| 13 | PostgreSQL migration/administration docs; NIST/OWASP database security sources | Expand-contract migration, role matrix, retention and operational plan |
| 14 | CMU 15-445/645 project structure and all prior artifacts | Database design review and optional tiny storage engine project |

**Primary course benchmark:** [CMU 15-445/645 Database Systems, Fall 2026](https://15445.courses.cs.cmu.edu/fall2026/). Its implementation-heavy projects set a higher bar than a SQL-only lab. The included Python B+ tree is one index component, not a BusTub-equivalent DBMS implementation.


**Edition 3 implementation sequence:** The new local database project is in `labs/06-data-systems/diskdb/`. For the full cumulative university benchmark, follow the official CMU project progression: [buffer pool](https://15445.courses.cs.cmu.edu/fall2026/project1/), [B+ tree](https://15445.courses.cs.cmu.edu/fall2026/project2/), [query execution](https://15445.courses.cs.cmu.edu/fall2026/project3/) and [MVCC/concurrency control](https://15445.courses.cs.cmu.edu/fall2026/project4/). The local implementation does not reproduce the full BusTub scope.

# Weekly Reading Map — Distributed Systems

| Week | Core reading / lecture route | Primary artifact to produce |
|---:|---|---|
| 1 | [MIT 6.5840 schedule](https://pdos.csail.mit.edu/6.824/schedule.html), introductory lectures; *Designing Data-Intensive Applications* (DDIA), ch. 1 if available through library | System model, fault assumptions, workload and Little's Law calculation |
| 2 | MIT 6.5840 early RPC/MapReduce material; [Go net/http docs](https://pkg.go.dev/net/http) and [context docs](https://pkg.go.dev/context) | RPC contract, timeout/retry matrix and idempotency-key design |
| 3 | [Lamport, Time, Clocks, and the Ordering of Events](https://lamport.org/pubs/time-clocks.pdf); MIT 6.5840 logical-time/consistency lecture route | Happens-before graph, Lamport timestamps and vector-clock execution trace |
| 4 | [FLP impossibility result](https://groups.csail.mit.edu/tds/papers/Lynch/jacm85.pdf); MIT schedule topics on failure and availability | Failure-detector assumptions, timeout policy and lease/fencing analysis |
| 5 | DDIA consistency/replication chapters; [MIT 6.5840 schedule](https://pdos.csail.mit.edu/6.824/schedule.html) | Histories showing linearizable, sequential and eventual consistency; counterexample traces |
| 6 | [Dynamo paper](https://www.allthingsdistributed.com/files/amazon-dynamo-sosp2007.pdf); MIT 6.5840 replication labs | Quorum intersection derivation, read-repair policy and stale-read analysis |
| 7 | [Raft extended paper](https://raft.github.io/raft.pdf); [MIT 6.5840 Lab 3](https://pdos.csail.mit.edu/6.824/labs/lab-raft1.html); local `labs/01-distributed/raftsim/` lab | Election, vote freshness, log-matching and leader-completeness invariants; run the deterministic simulator |
| 8 | DDIA transactions/distributed transactions chapters; MIT schedule material on transactions; local Raft simulator `PROTOCOL-TRACE.md` | Quorum commit under loss/partition; 2PC failure-state table and saga compensation design |
| 9 | Raft paper log/snapshot sections; [MIT 6.5840 Lab 4](https://pdos.csail.mit.edu/6.824/labs/lab-kvraft1.html); local simulator restart/conflict-repair exercise | Durable-log, snapshot and recovery timeline; explain the gap between simulated persistence and fsync-backed durability |
| 10 | DDIA partitioning chapter; [consistent hashing overview](https://www.cs.princeton.edu/courses/archive/spr11/cos461/docs/lec21-hashing.pdf) | Key distribution, hot-key and rebalancing experiment |
| 11 | [MapReduce paper](https://research.google/pubs/mapreduce-simplified-data-processing-on-large-clusters/); [Dataflow model paper](https://research.google/pubs/the-dataflow-model-a-practical-approach-to-balancing-correctness-latency-and-cost-in-massive-scale-unbounded-out-of-order-data-processing/) | Event-time/windowing design, duplicate handling and late-data policy |
| 12 | [PBFT paper](https://pmg.csail.mit.edu/papers/osdi99.pdf) and BFT lecture route from MIT/Harvard public systems courses | Byzantine fault assumptions, n≥3f+1 derivation and trust-boundary critique |
| 13 | [Google SRE book](https://sre.google/sre-book/table-of-contents/) chapters on SLOs, monitoring and overload | SLO/error-budget proposal, saturation dashboard and incident runbook |
| 14 | MIT 6.5840 project/lab sequence and all prior artifacts | Final system design, paper critique, fault campaign and oral defense |

**Primary course benchmark:** [MIT 6.5840 Distributed Systems, Spring 2026](https://pdos.csail.mit.edu/6.824/). The public course page includes staged programming labs (MapReduce, KV service, Raft, Raft-backed KV and sharding), lectures and assessment expectations. Use it as a progression benchmark, not as permission to copy private or graded assignment solutions.

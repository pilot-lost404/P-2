# Weekly Reading Map — Security Engineering

| Week | Core reading / lecture route | Primary artifact to produce |
|---:|---|---|
| 1 | [NIST SP 800-160 Vol. 1 Rev. 1](https://csrc.nist.gov/pubs/sp/800/160/v1/r1/final); [MITRE ATT&CK](https://attack.mitre.org/) | Asset inventory, system context and attacker capability assumptions |
| 2 | NIST SP 800-160 architecture/lifecycle material; [OWASP threat modeling resources](https://owasp.org/www-community/Threat_Modeling) | Data-flow diagram, trust boundaries and STRIDE threats |
| 3 | [OWASP ASVS 5.0](https://owasp.org/www-project-application-security-verification-standard/); [NIST SSDF](https://csrc.nist.gov/pubs/sp/800/218/final) | Security requirements and verification matrix |
| 4 | [OWASP Authentication Cheat Sheet](https://cheatsheetseries.owasp.org/cheatsheets/Authentication_Cheat_Sheet.html); Python [hashlib.scrypt](https://docs.python.org/3/library/hashlib.html#hashlib.scrypt) and [secrets](https://docs.python.org/3/library/secrets.html) docs | Password-verifier design and session-lifecycle tests in the local secure service |
| 5 | [OWASP Authorization Cheat Sheet](https://cheatsheetseries.owasp.org/cheatsheets/Authorization_Cheat_Sheet.html); ASVS access-control sections | Owner/supervisor/tenant policy and cross-tenant IDOR tests in the local secure service |
| 6 | [OWASP Cryptographic Storage Cheat Sheet](https://cheatsheetseries.owasp.org/cheatsheets/Cryptographic_Storage_Cheat_Sheet.html); NIST cryptographic guidance | Data-protection and key-management lifecycle |
| 7 | [OWASP Input Validation Cheat Sheet](https://cheatsheetseries.owasp.org/cheatsheets/Input_Validation_Cheat_Sheet.html); CWE | Input-validation, injection and canonicalization abuse cases |
| 8 | [OWASP API Security Top 10](https://owasp.org/www-project-api-security/); ASVS | API threat model plus CSRF, strict JSON, object-level authorization and per-IP rate-limit tests |
| 9 | [OWASP Logging Cheat Sheet](https://cheatsheetseries.owasp.org/cheatsheets/Logging_Cheat_Sheet.html); Python [hmac](https://docs.python.org/3/library/hmac.html) documentation | Data classification, credential redaction, HMAC audit-chain verification and residual limitations |
| 10 | NIST SP 800-160 and NIST SP 800-218 SSDF | Secure lifecycle, architecture and supply-chain threat controls |
| 11 | [OWASP Web Security Testing Guide](https://owasp.org/www-project-web-security-testing-guide/); [PortSwigger Web Security Academy](https://portswigger.net/web-security) | Guided local vulnerability labs and test evidence |
| 12 | [OWASP ASVS 5.0.0](https://asvs.owasp.org/); [OWASP WSTG](https://owasp.org/www-project-web-security-testing-guide/latest/) | ASVS/WSTG traceability plus local secure-service test evidence and negative cases |
| 13 | [NIST SP 800-61 Rev. 3 incident response guidance](https://csrc.nist.gov/pubs/sp/800/61/r3/final); MITRE ATT&CK | Incident playbook, containment and recovery exercise |
| 14 | ASVS, NIST SP 800-160, threat register and capstone evidence | Secure design review, residual-risk register and oral defense |

Use only local, intentionally vulnerable training applications or systems for which you have explicit authorization. Security checklists are not proof of absence of vulnerabilities.


## Executable security project and scope boundary

Use [`labs/05-security/secure_service/README.md`](../labs/05-security/secure_service/README.md) as the setup guide, [`LAB-EXERCISES.md`](../labs/05-security/secure_service/LAB-EXERCISES.md) as the lab manual, and [`ASVS-WSTG-MATRIX.csv`](../labs/05-security/secure_service/ASVS-WSTG-MATRIX.csv) as the requirement-to-test example. The local API is intended for loopback-only use. Its tests provide evidence for specific controls under the stated fixture; they do not constitute full OWASP ASVS compliance, professional penetration testing or production certification.

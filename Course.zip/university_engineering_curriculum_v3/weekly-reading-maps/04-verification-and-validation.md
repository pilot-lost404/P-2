# Weekly Reading Map — Verification and Validation

| Week | Core reading / lecture route | Primary artifact to produce |
|---:|---|---|
| 1 | [NASA product verification/validation distinction](https://www.nasa.gov/reference/2-4-distinctions-between-product-verification-and-product-validation/); NASA V&V plan outline | V&V strategy and evidence-chain diagram |
| 2 | NASA requirements and verification planning sections; [NASA V&V plan outline](https://www.nasa.gov/reference/appendix-i-verification-and-validation-plan-outline/) | Testable requirements, acceptance criteria and method selection |
| 3 | ISTQB CTFL test-design syllabus; boundary/equivalence material | Equivalence classes, boundary values and decision tables |
| 4 | FAA AC guidance on software verification where relevant; [NASA verification](https://www.nasa.gov/reference/5-3-product-verification/) | Structural coverage and MC/DC independence pairs |
| 5 | [RPI CSCI 4964/6964 Software Verification syllabus](https://www.cs.rpi.edu/academics/courses/fall25/csci4964/); Hoare logic notes | Hoare triples, loop invariants and proof obligations |
| 6 | ISTQB testing syllabus; [Hypothesis stateful testing reference](https://hypothesis.readthedocs.io/en/latest/stateful.html); Python `unittest`/pytest docs | Stateful operation sequences, reference-model oracle and unit/component/integration strategy |
| 7 | NASA product verification and system validation guidance | System test, acceptance criteria and operational validation scenario |
| 8 | Reliability/statistics methods; NIST statistical references | Load-test design, percentile reporting and confidence bounds |
| 9 | MIT 6.5840 failure/lab sequence; Go race detector documentation | Deterministic fault schedule, concurrency test and recovery invariant |
| 10 | [TLA+ Tools / TLC official repository and release notes](https://github.com/tlaplus/tlaplus); [MIT 6.5840 Raft lab](https://pdos.csail.mit.edu/6.824/labs/lab-raft1.html); [RPI CSCI 4964/6964 Software Verification syllabus](https://www.cs.rpi.edu/academics/courses/fall25/csci4964/) | Python quorum model, safe and unsafe TLA+ models, invariants and shortest counterexample |
| 11 | [OWASP ASVS 5.0](https://owasp.org/www-project-application-security-verification-standard/); NASA safety/security V&V | Traceable negative security and safety test suite |
| 12 | Go/Python/CI official documentation; test automation practices | Reproducible CI pipeline and evidence manifest |
| 13 | NASA IV&V and technical review process; [RPI CSCI 4964/6964 Software Verification, Fall 2025 syllabus](https://www.cs.rpi.edu/academics/courses/fall25/csci4964/) | Independent review plan, anomaly disposition and release criteria |
| 14 | NASA V&V planning/reporting guidance and capstone baseline | Final V&V report, residual risk, configuration baseline and release recommendation |

**Formal-methods boundary:** the local Python checker explores a finite explicit graph. It does not replace TLA+, a theorem prover, qualified model checker or an independent safety assessment.


## V&V toolchain and lab evidence update

- **Local executable model:** `labs/04-vv/quorum_model/quorum_model.py` plus tests. Runs with the repository's existing Python explicit-state checker.
- **Formal spec:** `labs/04-vv/tla-plus/QuorumElection.tla` and its finite TLC configuration.
- **Mutation:** `QuorumElectionUnsafe.tla` intentionally removes the per-voter/per-term guard. TLC should report `OneVotePerTerm` and `ElectionSafety` violations with the configuration file supplied.
- **Tool version:** official TLA+ tools v1.8.0 release page; verify JAR SHA-1 `feffd16994db963ad945628cfd03d154c195a468` before execution.
- **Status of this build:** Python graph tests pass. The TLC JAR was not downloaded because outbound DNS for GitHub is unavailable in this build runtime. Therefore the `.tla` modules are not parser-validated or TLC-executed here.
- **Property-style testing:** 200 deterministic generated graph cases test reachability, shortest counterexample distance, and invariant handling against independent reference algorithms. These use only Python's standard library. Hypothesis is an additional recommended extension, not installed or claimed as executed here.

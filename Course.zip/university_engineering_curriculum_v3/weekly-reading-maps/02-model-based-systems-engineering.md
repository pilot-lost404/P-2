# Weekly Reading Map — Model-Based Systems Engineering

| Week | Core reading / lecture route | Primary artifact to produce |
|---:|---|---|
| 1 | [NASA Systems Engineering Handbook](https://www.nasa.gov/reference/systems-engineering-handbook/), lifecycle and technical processes; [SEBoK](https://sebokwiki.org/) | System boundary, stakeholder/context map and lifecycle model |
| 2 | NASA handbook on stakeholder expectations, ConOps and technical requirements; [JHU 645.631 Fall 2026 syllabus](https://apps.ep.jhu.edu/syllabus/fall-2026/645.631.82) | Stakeholder needs, operational scenarios and measurable requirement set |
| 3 | [OMG SysML v2 portal](https://www.omg.org/sysml/SysML-2.htm); [official requirement-definition examples](https://github.com/Systems-Modeling/SysML-v2-Pilot-Implementation/blob/master/sysml/src/training/32.%20Requirements/Requirement%20Definitions.sysml); JHU 645.631 SysML basics modules | SysML v2 package, requirement definitions/usages and naming model |
| 4 | OMG SysML v2 specification material and [Eclipse SysON v2026.11.0 manual](https://doc.mbse-syson.org/syson/v2026.11.0/) | Structural model with part definitions/usages, ports and interfaces; import/render model views |
| 5 | JHU 645.631 behavior-diagram modules; OMG SysML v2 action/flow concepts | Activity/action model and operating modes |
| 6 | JHU 645.631 requirements/parametric/allocation modules; NASA requirements process; local `labs/02-mbse/requirements-register.csv` | 18 measurable requirements, source needs, owners, allocations and acceptance criteria |
| 7 | NASA handbook on interface management and architecture definition | Interface-control document, data/control flow and interface requirements |
| 8 | NASA handbook on technical assessment and trade studies; JHU 645.631 methodology modules | Architecture alternatives and scored trade study with sensitivity analysis |
| 9 | [Eclipse SysON v2026.11.0 documentation](https://doc.mbse-syson.org/syson/v2026.11.0/); local `water-tank-v3.sysml` | SysML v2 import, four rendered views, exported model and tool diagnostics; external execution required |
| 10 | NASA technical planning and requirements traceability sections; local `traceability/validator.py` | 22 explicit trace links, automated dangling-link/coverage checks and orphan report |
| 11 | NASA product realization/verification sections | Requirement-to-design-to-verification allocation |
| 12 | NASA technical data management and configuration management sections | Model baseline, versioning rules and change-impact report |
| 13 | JHU 645.632 advanced analytics modules; local `trade-study.csv` and `change-impact/CR-001-sample-period.md` | Weight sensitivity, model-query output, controlled change-impact report and re-verification scope |
| 14 | JHU course outcomes and NASA systems engineering review process | Final model review, exports, evidence dossier and oral defense |

**Primary course benchmark:** [Johns Hopkins 645.631 Introduction to MBSE, Fall 2026](https://apps.ep.jhu.edu/syllabus/fall-2026/645.631.82). It provides a 14-module progression across SysML diagrams, modeling tools, stakeholder needs, requirements, logical/physical architecture, traceability and trade studies. **Tool note:** `water-tank-v3.sysml` is a developed textual model, but its import/render and semantic validation are not claimed as locally executed. The CSV validator only checks the requirements/traceability interchange layer.

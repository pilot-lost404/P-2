# Weekly Reading Map — Safety and Risk Analysis

| Week | Core reading / lecture route | Primary artifact to produce |
|---:|---|---|
| 1 | [NASA Systems Engineering Handbook](https://www.nasa.gov/reference/systems-engineering-handbook/); [HSE risk assessment guidance](https://www.hse.gov.uk/risk/) | Losses, hazards, operating modes and system safety constraints |
| 2 | HSE risk assessment and hazard-identification guidance; NASA system safety material | HAZID/What-If register and preliminary hazard analysis |
| 3 | [NASA System Safety Handbook Vol. 2](https://ntrs.nasa.gov/archive/nasa/casi.ntrs.nasa.gov/20150015500.pdf); reliability-engineering textbook/library chapter | FMEA/FMECA with causes, effects, controls and actions |
| 4 | [University of Maryland ENRE602 reliability-analysis course](https://academiccatalog.umd.edu/graduate/courses/enre/enre.pdf); [Southampton FEEG6006 Systems Reliability](https://southampton.ac.uk/courses/modules/feeg6006.page) | Exponential/Weibull survival derivation, unit-consistent model and failure-data assumptions |
| 5 | NASA System Safety Handbook and UMD ENRE602 reliability topics; local `reliability_lab.py` | Series/parallel RBD, beta-factor common-cause approximation and dependence critique |
| 6 | NASA System Safety Handbook quantitative analysis sections | Fault tree, Boolean gates, minimal cut sets and exact/approximate probability |
| 7 | NASA System Safety Handbook; barrier and event-sequence analysis references | Event tree with conditional probabilities and barrier dependencies |
| 8 | Southampton FEEG6006 Monte Carlo module; local `analysis_example.py` and `reliability.py` | Beta posterior credible interval, parameter uncertainty propagation, seeded Monte Carlo/Wilson interval and Birnbaum sensitivity |
| 9 | [MIT STAMP/STPA handbooks](https://www.mit.stamp-institute.com/handbooks); [STPA Handbook](https://www.flighttestsafety.setp.org/images/STPA_Handbook.pdf) | Control structure, unsafe control actions and causal scenarios |
| 10 | STPA handbook sections on human control and organizational factors; NASA human-system integration | Human factors, alarms, workload and maintenance scenario analysis |
| 11 | NASA system safety lifecycle sections and applicable official standard catalogue | Derived safety requirements and verifiable controls |
| 12 | [NASA System Safety Handbook Vol. 2](https://ntrs.nasa.gov/archive/nasa/casi.ntrs.nasa.gov/20150015500.pdf); [SEBoK safety knowledge area](https://sebokwiki.org/) | Claim-argument-evidence safety case and defeater register |
| 13 | [IEC functional safety portal](https://www.iec.ch/functional-safety); NASA handbook | Standard applicability matrix and lifecycle assurance plan; obtain standards legally |
| 14 | All prior sources and capstone artifacts | Integrated safety review, uncertainty statement, residual-risk owner and management plan |

**Caution:** the independent fault-tree function still assumes independent basic events. The separate beta-factor formula is a simplified static common-cause approximation; parameter uncertainty assumes independent Beta posteriors; and Monte Carlo confidence intervals only quantify simulation error for fixed inputs. These are teaching tools, not a certified PRA. Do not infer safety acceptance from a risk-matrix score or unvalidated probabilities.

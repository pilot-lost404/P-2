# Weekly Reading and Lecture Maps

Each map pairs the 14-week reader with a primary university course, official standard, technical paper or maintained documentation. These references are the deeper lecture/text layer; the local reader provides the study sequence and original worked examples.

## How to use each week

- Budget 2–3 hours for the primary lecture/readings, 1–2 hours for derivations/notes, 2–4 hours for the lab/project, and 1–2 hours for assessment/review.
- Follow the exact week/topic row rather than trying to read every listed source at once.
- University syllabi may move or remove materials between semesters. Use the live official course page as the source of truth.
- A public syllabus link does not guarantee access to private LMS slides, instructor solutions or paid textbooks.
- Commercial textbooks are optional references; borrow or use legitimate institutional access. Do not use unauthorized copies.

## Maps

- `01-distributed-systems.md`
- `02-model-based-systems-engineering.md`
- `03-safety-and-risk-analysis.md`
- `04-verification-and-validation.md`
- `05-security-engineering.md`
- `06-data-systems-and-databases.md`

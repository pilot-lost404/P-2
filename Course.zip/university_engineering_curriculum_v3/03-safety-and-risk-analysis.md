# Course 3 — Safety and Risk Analysis
**Level:** Upper-undergraduate / early graduate  
**Duration:** 14 teaching weeks  
**Expected workload:** 8–10 hours per week  
**Prerequisites:** Basic systems engineering, probability, block diagrams, requirements and elementary control concepts.

## Course description

Safety engineering aims to prevent unacceptable losses arising from system behavior. It considers the system as a whole: hardware, software, operators, procedures, maintenance, organizations, environment and interactions among them. A component can operate exactly as specified while the overall system remains unsafe. For this reason, safety analysis cannot be reduced to finding defective parts or assigning a risk score to each component.

This course introduces hazard analysis, Failure Modes and Effects Analysis (FMEA/FMECA), Fault Tree Analysis (FTA), Event Tree Analysis (ETA), System-Theoretic Process Analysis (STPA), safety requirements, barriers, assurance cases and lifecycle safety management. It emphasizes the strengths and limitations of each technique. A remote water-tank controller provides a consistent example, but the material is educational and does not constitute a certified safety assessment.

## Learning outcomes

Students should be able to:
1. Distinguish loss, hazard, failure, fault, error, accident and risk.
2. Define system-level safety constraints and operating assumptions.
3. Conduct a structured FMEA and explain its limitations.
4. Construct qualitative and simple quantitative fault trees.
5. Use event trees to analyze possible consequence paths.
6. Apply the core STPA steps to software-intensive control systems.
7. Derive safety requirements and allocate them to design elements.
8. Evaluate independent protection layers, human factors and common-cause failures.
9. Construct a structured safety argument supported by evidence.
10. Maintain a hazard log and reassess risk when the design or operating context changes.

---

## Week 1 — Safety engineering foundations

### 1.1 Loss, hazard, accident and risk

A **loss** is an unacceptable outcome for a stakeholder, such as injury, environmental damage, major property damage, mission failure or loss of essential service. A **hazard** is a system state or set of conditions that, together with a particular environment, can lead to a loss. An **accident** is an undesired event or sequence resulting in a loss. A **failure** is the inability of an element to perform a required function; a hazard can exist without a component failure.

For the tank example:
- Loss L-1: a person is injured by electrical or mechanical equipment.
- Loss L-2: water causes unacceptable property damage.
- Hazard H-1: tank water level exceeds the safe physical limit.
- Hazard H-2: pump is energized while the relevant isolation condition is not satisfied.
- Hazard H-3: the controller fails to provide a required shutdown when the level input is unsafe or invalid.

Risk is often treated as a combination of likelihood and consequence, but the meaning of each quantity must be explicit. A numerical score is not a substitute for identifying the scenario, assumptions and uncertainty. Low estimated frequency can coexist with intolerable consequences or weak evidence.

### 1.2 Safety as a system property

A safety problem may arise from unsafe control action, incorrect feedback, timing, inadequate process model, misunderstood displays, maintenance error or conflicting goals. An operator may issue a valid command under a misleading display; the software may accept the request; the actuator may work; the combined result can still be hazardous.

### 1.3 Analysis boundary

Define the system, environment, users, lifecycle stage and losses before selecting an analysis technique. Include maintenance, test, startup, degraded operation and disposal when relevant. State assumptions about sensor accuracy, power quality, actuator response, operator availability and external dependencies.

### Laboratory

Write a one-page safety scope. Identify at least three losses, five hazards, key assumptions and the stakeholders authorized to accept residual risk. Do not assign scores yet.

---

## Week 2 — Hazard identification and preliminary hazard analysis

Hazard identification asks what system states or interactions could create unacceptable losses. It should be performed early and revisited as the architecture evolves. Techniques include structured brainstorming, checklists, functional hazard analysis, guide-word analysis, scenario analysis, interface analysis, operating experience and STPA.

A preliminary hazard analysis (PHA) records hazards before detailed design is complete. A useful record includes hazard ID, description, causes or scenarios, potential losses, operating modes, initial risk rationale, constraints, owner, evidence needed and status. Avoid writing a hazard as a component failure only. "Sensor failed" is not a system hazard statement; "controller uses an invalid level measurement and continues filling" is more informative.

### Worked example

| Hazard | Operating context | Potential loss | Initial constraint |
|---|---|---|---|
| H-1: tank above safe level | filling / unattended | property damage, injury | filling must be stopped before physical overflow |
| H-2: pump remains energized when dry-run prohibited | low supply / sensor fault | equipment damage | pump operation must be inhibited under defined low-water condition |
| H-3: unsafe remote command accepted | remote operation | injury / damage | local safety interlocks must dominate remote commands |

The constraint is at system level; later requirements allocate it to components and interfaces.

### Laboratory

Produce a PHA for normal fill, manual override, sensor fault, network loss, power restoration, maintenance and calibration. For every hazard, identify at least two plausible scenarios.

---

## Week 3 — Failure Mode and Effects Analysis (FMEA)

FMEA is a bottom-up, structured technique. It starts with an item or function, identifies how it could fail, and analyzes local, next-higher-level and system effects. A typical row includes item/function, failure mode, cause, local effect, end effect, detection, existing controls, severity, occurrence, recommended action and responsible owner.

A **failure mode** describes how a function or item fails: stuck open, stuck closed, incorrect output, intermittent operation, loss of output or out-of-tolerance behavior. A **cause** explains why. An **effect** explains what happens at local and system levels. Good FMEA does not stop at the component boundary.

### 3.1 RPN and its limits

Some organizations use a Risk Priority Number:

\[
RPN = S \times O \times D
\]

where S is a severity rating, O an occurrence rating, and D a detectability rating (often a higher D means harder to detect). This is a ranking aid, not a calibrated probability or universal risk metric. Different combinations can yield the same RPN while representing very different safety concerns. A catastrophic severity score must not be hidden by low occurrence or easy detection. Use severity categories and mandatory action rules in addition to any RPN.

### Worked example

A valve can fail stuck open. Assume a teaching scale S=9, O=3, D=6. RPN=162. Another failure has S=4, O=9, D=4, also RPN=144. These numbers do not prove the first event is "only slightly riskier"; the severity difference may dominate the decision. The team should examine the physical scenario, evidence and independent protections.

### Laboratory

Complete an FMEA with at least eight rows covering sensor, controller, communication path, pump, valve, power supply and operator interface. Include system effect, detection method and a recommended action. Explain which rows require escalation regardless of the RPN.

---

## Week 4 — FMECA, criticality and prioritization

FMECA extends FMEA by adding a criticality assessment. Quantitative criticality calculations require defensible failure-rate data, mission time, failure-mode fractions, operating profiles and assumptions. When data is unavailable, a qualitative criticality matrix may be more honest than fabricated numerical precision.

The analysis should identify single-point failures, common-cause failures, latent failures, diagnostic coverage, repair time and exposure duration. A single-point failure is particularly important when no independent protection prevents the hazard. A latent failure is present but not detected until a second event or demand exposes it.

A fault tree and FMECA are complementary. FMECA follows components or functions upward to effects; a fault tree starts with a defined top event and decomposes the combinations that can produce it. Neither replaces the other.

### Worked example

Suppose a high-level sensor can become stuck low. If a separate independent high-high switch exists, the hazard may still be prevented—provided it does not share the same power supply, wiring route, sensing principle, maintenance error or software path in a way that defeats independence. Independence must be argued, not assumed from separate labels.

### Laboratory

Identify single-point and common-cause failure candidates from the prior FMEA. Add a criticality rationale and specify what evidence would be required to treat a protective channel as independent.

---

## Week 5 — Fault Tree Analysis (FTA)

FTA is a top-down deductive analysis. Begin with a precisely defined top event, then use logical gates to express combinations of lower-level events. An OR gate means any input event can cause the parent event; an AND gate means all input events are required. Basic events may be component failures, human actions, environmental conditions or external events.

```mermaid
flowchart TD
  TOP["TOP: Tank overflows"]
  TOP --> OR1{{"OR"}}
  OR1 --> A["Inlet remains open"]
  OR1 --> B["Inflow exceeds safe capacity"]
  A --> OR2{{"OR"}}
  OR2 --> C["Valve stuck open"]
  OR2 --> D["Controller fails to close valve"]
  D --> AND1{{"AND"}}
  AND1 --> E["High-level detection unavailable"]
  AND1 --> F["No effective independent shutdown"]
```

The tree must reflect the actual system boundary, time window and operating conditions. Avoid mixing incompatible event definitions. If "sensor unavailable" already includes disconnected wiring and failed power, do not count those causes again below it without a carefully defined structure.

### 5.1 Minimal cut sets

A cut set is a combination of basic events sufficient to cause the top event. A minimal cut set is one where no proper subset is sufficient. Cut sets help identify critical combinations and single-point vulnerabilities.

### 5.2 Simple probability calculation

If A and B are independent basic events with probabilities 0.01 and 0.02, and the top event requires both (AND), then \(P(A \cap B)=0.01 \times 0.02=0.0002\). If the top event occurs when either A or B occurs (OR), then \(P(A \cup B)=P(A)+P(B)-P(A)P(B)=0.0298\). Independence must be justified; common-cause failure invalidates the simple product.

### Laboratory

Construct a fault tree for "water level exceeds the physical safe limit." Identify minimal cut sets. State whether each independence assumption is credible and identify common-cause paths.

---

## Week 6 — Event Tree Analysis (ETA) and barriers

ETA is an inductive technique. Start with an initiating event and branch through the success or failure of protective functions to identify possible outcomes. The branches describe scenario progression; they do not automatically assign probabilities.

Example initiating event: inlet valve fails open. Barriers may include high-level alarm, independent high-high switch, automatic isolation and operator response. The event tree should consider barrier failure, delayed response, power loss and whether a barrier is truly independent.

Barrier management asks:
- What is the safety function?
- What demand activates it?
- What performance is required?
- How is it tested and maintained?
- How can it be defeated by common cause or human action?
- What evidence proves it is available when demanded?

A backup system is not independent if it shares the same faulty sensor, power source, code path or maintenance procedure.

### Laboratory

Build an event tree beginning with a valve stuck-open event. Include at least three barriers and four distinct consequence paths. Explain which barrier has the greatest influence on the outcome and what evidence supports that claim.

---

## Week 7 — STPA: system-theoretic safety analysis

STPA is a hazard analysis method based on systems theory and control. It is particularly useful for software-intensive systems where unsafe behavior can arise from interactions among correctly functioning components. It does not require a component failure to be the initiating cause.

The core process is:
1. Define losses, hazards and system-level safety constraints.
2. Model the safety control structure, including controllers, controlled processes, actuators, sensors, feedback and external influences.
3. Identify unsafe control actions (UCAs).
4. Identify causal scenarios that could lead to each UCA and derive constraints or requirements.

Four general UCA categories are commonly examined:
- A required control action is not provided.
- An unsafe control action is provided.
- A control action is provided too early, too late or in the wrong order.
- A control action lasts too long or stops too soon.

For the tank system, "command close valve" can be unsafe if issued too late, omitted during a high-high condition, issued when the valve must remain open for a safe purge, or held for an incorrect duration. Context determines safety.

### Laboratory

Draw a control structure. Identify at least six UCAs and map each to a safety constraint. For each UCA, produce two causal scenarios involving feedback, process model, actuator, sensor, operator or coordination.

---

## Week 8 — Causal scenarios, control loops and software

A control loop depends on the controller's process model: what it believes about the controlled process, current state, capabilities and environment. Inaccurate or delayed feedback can make a reasonable control algorithm issue an unsafe command. Software can create hazards through incorrect timing, mode confusion, stale data, incorrect assumptions or unsafe interactions—even if it contains no traditional hardware fault.

A scenario should explain a causal path, not merely repeat the hazard. Example: the sensor reports a plausible but stale low level; the controller's validity logic does not detect staleness; the controller believes the tank is below target; the valve remains open; the independent high-high switch shares the sensor's power feed and is also unavailable. This scenario suggests requirements for freshness, plausibility, diagnostics, independent power and proof testing.

### Laboratory

Write five causal scenarios for one UCA. At least one must involve maintenance, one communication delay, one misleading feedback signal, one human-machine interface and one common-cause failure.

---

## Week 9 — Human factors and operational safety

Human action should be analyzed in context rather than treated as a generic "operator error." Consider workload, display design, alarms, procedures, training, fatigue, authority, incentives, maintenance access and handover. An alarm can be technically correct but operationally useless if it is ambiguous, repeated excessively or arrives after the response window.

Mode confusion occurs when the operator believes the system is in one mode while it is in another. A safe design makes mode and authority visible, prevents ambiguous state transitions and ensures critical controls have clear feedback. Procedures should be tested with representative users and realistic interruptions.

Safety analysis must include test, calibration, configuration, cleaning, bypass, degraded mode and repair. A control that is safe during normal operation may be unsafe during maintenance when interlocks are bypassed.

### Laboratory

Conduct a task analysis for an operator acknowledging a high-level alarm and entering maintenance mode. Identify slips, mistakes, mode confusion and organizational conditions. Propose design changes, not only training.

---

## Week 10 — Safety requirements and risk controls

Hazard analysis becomes useful when it produces design constraints and verifiable requirements. A safety requirement should identify the required behavior, triggering condition, timing, operating context and acceptance criteria. Requirements should be allocated to design elements and linked to verification evidence.

Use the hierarchy of controls carefully. Prefer eliminating a hazard through design where feasible; otherwise reduce risk through engineering controls, independent protective functions, administrative controls and warnings. Warnings and procedures are not equivalent to inherently safer design.

A safety requirement may be:
`SAFE-014: When the high-high channel detects a level above its trip threshold, the independent shutdown path shall de-energize the inlet valve within 300 ms, independent of the remote service.`

The exact threshold, trip logic, valve safe state and timing budget must be derived from physical and operational analysis. The requirement is an educational example, not an approved safety specification.

### Laboratory

For each high-severity hazard, derive one prevention constraint, one detection requirement, one mitigation requirement and one test or analysis. Trace them to system elements.

---

## Week 11 — Safety cases and assurance arguments

A safety case is a structured argument that a system is acceptably safe for a defined application and context, supported by evidence. It is not a document that asserts safety by listing completed analyses. A common structure is Goal Structuring Notation (GSN): claims, strategies, subclaims, contexts, assumptions, justifications and evidence.

Example top-level claim: "The tank control system is acceptably safe for unattended operation within the specified operating envelope." This claim must be decomposed into arguments about overflow prevention, electrical isolation, sensor fault handling, local autonomy, maintenance and operator response. Evidence may include analysis reports, test results, inspection records, operating data and independent review.

An argument can be invalid even when its evidence is real. For example, a successful software unit test does not prove the physical valve closes within the required time. Evidence must support the claim at the same abstraction level and operating context.

### Laboratory

Create a GSN-style assurance argument with one top claim, at least four subclaims, explicit context, assumptions, strategies and evidence references. Mark any claim for which evidence is missing.

---

## Week 12 — Functional safety standards and lifecycle integration

Safety standards define lifecycle processes and evidence expectations for particular domains. IEC 61508 is a foundational generic functional safety standard for electrical/electronic/programmable electronic safety-related systems. Sector standards such as ISO 26262 or IEC 61511 tailor principles to particular industries. Applicability depends on product, jurisdiction, contract and intended use.

A standard should not be treated as a recipe that makes a system safe by compliance alone. The engineering team must identify applicable editions, scope, lifecycle responsibilities, independence requirements, competence expectations and evidence. Standards may be copyrighted; use official publisher or library access rather than unauthorized copies.

Risk reduction may involve design changes, protective functions, procedures or operating limitations. Safety integrity levels (SILs) are not generic labels to add to a design. They involve specific allocation and lifecycle methods defined by applicable standards, with quantitative and qualitative requirements.

### Laboratory

Prepare a standards applicability memo for the educational tank controller. Identify which standard families might be relevant in an actual industrial context, what information is missing to determine applicability, and why no SIL claim is justified from the exercise.

---

## Week 13 — Change, operations and continuous safety management

Safety is not frozen at design release. Equipment ages, software is updated, suppliers change, operators learn workarounds, operating environments shift and maintenance practices evolve. A change must be assessed for new hazards and for changes to existing assumptions, failure rates, diagnostic coverage and safety functions.

Maintain a hazard log with status, owner, decision, rationale, evidence and review date. Record accepted residual risk and who has the authority to accept it. Track safety-significant anomalies, proof-test results, overrides, bypass duration, recurring alarms and incidents. Leading indicators can reveal weakening controls before a loss occurs.

### Laboratory

A valve manufacturer changes the actuator model and response time. Perform a change impact review: requirements, timing budgets, hazard analysis, common-cause assumptions, proof-test procedure, maintenance parts and verification evidence.

---

## Week 14 — Integrated safety assessment

The final safety review should connect:
- defined losses and hazards;
- constraints and safety requirements;
- FMEA/FMECA findings;
- fault-tree and event-tree results;
- STPA control actions and causal scenarios;
- protection architecture and independence argument;
- verification procedures and results;
- residual risk acceptance;
- safety-case claims and evidence;
- assumptions and unresolved issues.

### Final submission

Submit the system definition, hazard log, FMEA, fault tree, event tree, STPA control structure and UCA table, safety requirements, safety-case argument and a review report. The analysis must distinguish known facts, estimates, assumptions and unresolved uncertainty.

### End-of-course problems

1. Is "level sensor failed" a hazard?  
   **Solution:** Not by itself. It is a failure mode. A hazard describes the unsafe system state or condition, such as continued filling while the level is unknown or invalid.

2. Why can two separate shutdown channels still share a common-cause failure?  
   **Solution:** They may share power, sensor physics, wiring, environmental exposure, software, maintenance procedure, configuration data or human oversight.

3. Why is RPN not a probability?  
   **Solution:** S, O and D are typically ordinal ratings. Multiplying them creates a ranking number, not a calibrated probability of loss. Different score combinations can hide different severity profiles.

## Selected sources and further study

- MIT STAMP Institute, STPA and CAST handbooks: https://www.mit.stamp-institute.com/handbooks
- Nancy Leveson, *Engineering a Safer World* (MIT Press): https://mitpress.mit.edu/9780262533690/engineering-a-safer-world/
- NASA Systems Engineering Handbook: https://www.nasa.gov/reference/systems-engineering-handbook/
- NASA Systems Safety and Mission Assurance resources: https://sma.nasa.gov/
- IEC functional safety standards catalogue: https://www.iec.ch/functional-safety
- UK HSE, risk assessment and safety management guidance: https://www.hse.gov.uk/risk/
- SEBoK safety engineering knowledge area: https://sebokwiki.org/

The STPA handbook is especially useful for worked control-structure examples. The NASA handbook provides lifecycle context. Formal standards should be consulted in their controlled official editions for regulated work.

# Research Log — Six-Course Engineering Curriculum

**Date:** 21 November 2026  
**Order:** EFT = Exa → Firecrawl → TinyFish (user-defined order)  
**Context7:** Go, PostgreSQL 18 and Eclipse SysON official documentation queries

## 1. Discovery and benchmarking

### Exa
Searched university syllabi, full-course lectures, books, lab sheets, exams, standards and official documentation for all six courses. Retrieved source material for MIT 6.5840, MIT 6.5830, CMU 15-445/645, CMU 15-440, JHU MBSE, NASA handbooks, OMG SysML, NIST, and Southampton formal verification/reliability topics. FMHY's education index was fetched and used to find official open-course platforms.

### Firecrawl
Searched for current official course pages and relevant lab/program details. Key results included:
- MIT 6.5840 Spring 2026 page and five public labs: MapReduce, key-value service, Raft, Raft-backed KV and sharded KV.
- CMU 15-445/645 Fall 2026 course/syllabus/assignments with DBMS internals and BusTub cumulative programming projects.
- OMG SysML v2 official portal and NASA Systems Engineering Handbook.
- NASA System Safety Handbook Volume 2, STPA Handbook and NIST secure systems engineering sources.
The FMHY educational page was scraped and parsed to identify legitimate free learning platforms. Unauthorized/torrent download directories were excluded.

### TinyFish
Searched and fetched:
- Johns Hopkins 645.631 Fall 2026 MBSE syllabus: a 14-module progression covering SysML package, structure, behavior, parametric, requirements and allocation work; model setup, needs, requirements, architecture, traceability and trade studies.
- University of Southampton verification/reliability search results; any page URL that did not resolve through fetching was not used as a required reading. RPI CSCI 4964/6964 Software Verification was added as an accessible course-syllabus benchmark.
- OMG SysML v2 portal and NASA handbook pages.

## 2. Context7 technical documentation

- Go official docs: current concurrency and testing guidance, including race-detector commands. The `testing/synctest` general-availability API arrived in Go 1.25; the local lab baseline was kept compatible with Go 1.23 instead of depending on that newer testing API.
- PostgreSQL 18 docs: MVCC, transaction isolation, `EXPLAIN ANALYZE`, WAL and checkpoint behavior. The curriculum specifically distinguishes PostgreSQL's behavior from generic SQL-standard labels and from ARIES as a classic algorithm.
- Eclipse SysON v2025.10 docs: SysML v2 textual import/export and rendering graphical views from structurally valid imported models. The course therefore marks the model file as a starter and does not claim external import/validation.

## 3. Curriculum changes derived from the research

- Distributed systems includes a Go logical-clock lab, retry/idempotency experiments and problem sets on quorum intersection and Raft log safety. A full Raft replicated service remains a next-tier project.
- MBSE includes a SysML v2 textual starter, requirements register, traceability matrix and required model/tool export-import evidence.
- Safety includes tested quantitative reliability, Bayesian and fault-tree calculations, plus FMEA, STPA and safety-case work.
- V&V includes an executable finite-state invariant checker and formal reasoning in addition to test design.
- Security includes a deny-by-default facility-scoped authorization model and negative tests, while clearly stating it is not a full authentication/API system.
- Databases includes PostgreSQL 18 schema/seed/query scripts, query-plan comparison, data generation, write-skew experiment, and backup/restore assignment. It does not replace a DBMS implementation course.

## 4. Limitations and provenance

The research uses public course pages and technical manuals, not private learning-management system material, private instructor rubrics or restricted standards text. Some official pages provide only a public syllabus. Current course dates and tool versions are snapshots as of 21 November 2026. Recheck official source pages before a later teaching term. FMHY is a directory, not an academic authority or guarantee of the linked resource's redistribution rights.


## 5. Assessment and remaining evidence gates

Edition 2 adds 84 original week-by-week problems with solution checkpoints (one for each of six 14-week courses), 30 longer worked problems, and a six-discipline capstone with 20 acceptance tests. NIST incident-response reading was updated to SP 800-61 Rev. 3, and the V&V source map now points to RPI CSCI 4964/6964 Software Verification. The remaining gaps are listed with closure evidence in `../audit/REMEDIATION-ROADMAP-V2.md`.

## 6. Edition 3 update (21 November 2026)

Edition 3 used the same EFT order and added deeper current source extraction. For the full per-tool provenance see [`EXA-RESEARCH-LOG-V3.md`](EXA-RESEARCH-LOG-V3.md), [`FIRECRAWL-RESEARCH-LOG-V3.md`](FIRECRAWL-RESEARCH-LOG-V3.md), [`TINYFISH-RESEARCH-LOG-V3.md`](TINYFISH-RESEARCH-LOG-V3.md) and [`CONTEXT7-DOCUMENTATION-V3.md`](CONTEXT7-DOCUMENTATION-V3.md). Key updates: MIT 6.5840 current Raft/KV/sharding labs; CMU 15-445 Fall 2026 cumulative BusTub projects; JHU 645.631/632 MBSE; SysON v2026.11.0 current support boundaries; UMD reliability and Surrey verification syllabi; TLA+ Tools v1.8.0; OWASP ASVS 5.0.0/WSTG/Juice Shop. This research produced original lab implementations and explicit NOT EXECUTED external gates for SysON, TLC and PostgreSQL.

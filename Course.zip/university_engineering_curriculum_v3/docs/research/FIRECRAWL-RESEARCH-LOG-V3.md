# Firecrawl Research Log — Edition 3

**Date:** 21 November 2026  
**Role in EFT:** targeted search and focused scrape after Exa discovery; primary pages were scraped to verify actual contents and scope.

## Searches and focused page extraction

| Topic | Key pages fetched | Findings incorporated |
|---|---|---|
| Distributed systems | MIT [Raft Lab 3](https://pdos.csail.mit.edu/6.824/labs/lab-raft1.html), [KV Lab 4](https://pdos.csail.mit.edu/6.824/labs/lab-kvraft1.html) | Persistent term/vote/log state, tests, unreliable networks, quorum, linearizable KV and snapshot layers. Membership changes are outside the cited Raft lab. |
| Database internals | CMU [BusTub Project 1](https://15445.courses.cs.cmu.edu/fall2026/project1/), [Project 2](https://15445.courses.cs.cmu.edu/fall2026/project2/), [Project 3](https://15445.courses.cs.cmu.edu/fall2026/project3/), [Project 4](https://15445.courses.cs.cmu.edu/fall2026/project4/) | Sequential internals progression: thread-safe buffer pool, B+ tree, query executors/optimizer rules, then optimistic MVCC. Project 4 is not described as a full ARIES project. |
| MBSE | [JHU 645.631](https://apps.ep.jhu.edu/syllabus/fall-2026/645.631.82), [JHU 645.632](https://apps.ep.jhu.edu/syllabus/spring-2027/645.632.81), [SysON FAQ](https://doc.mbse-syson.org/syson/v2026.11.0/user-manual/faq/faq) | Course sequence covers language, needs, system requirements, logical/physical architectures, trade studies, model queries, variations, parametrics, reports and model V&V. SysON supports core structural/behavior/requirements views; built-in versioning/branching/access control are not provided. |
| Safety | [NASA System Safety Handbook Vol. 2](https://ntrs.nasa.gov/archive/nasa/casi.ntrs.nasa.gov/20150015500.pdf), UMD ENRE602 | Safety case and risk-informed decision context; quantitative reliability methods in university syllabus. |
| V&V | [Surrey 2026/27 COM3028](https://catalogue.surrey.ac.uk/2026-7/module/COM3028/SEMR2/2) | Temporal logics, explicit/symbolic model checking, BDDs, Hoare logic, labs and assessment structure. |
| Security | [OWASP ASVS](https://owasp.org/projects/asvs), [WSTG latest](https://owasp.org/www-project-web-security-testing-guide/latest/), [Juice Shop](https://owasp.org/projects/juice-shop) | ASVS version 5.0.0 listed stable; WSTG is rolling; Juice Shop is a deliberately vulnerable local training app. |

## Failed/non-used results

Some search hits were not reachable through the fetch path or had outdated/indirect material. They were not treated as required course sources. A 404/non-resolving fetch is not evidence that the underlying module or course does not exist. No unsupported access dates or unavailable tool passes were invented.

# Exa Research Log — Edition 3

**Date:** 21 November 2026  
**Purpose:** Find original university course structures, assignment specs, primary technical materials and references needed to close the six-course implementation gaps.

## Searches and selected source families

| Workstream | Discovery question | Selected primary sources | How used |
|---|---|---|---|
| Distributed systems | University-level consensus/replication, labs, fault injection and correctness criteria | [MIT 6.5840 Spring 2026](https://pdos.csail.mit.edu/6.824/), [Raft lab](https://pdos.csail.mit.edu/6.824/labs/lab-raft1.html), [fault-tolerant KV lab](https://pdos.csail.mit.edu/6.824/labs/lab-kvraft1.html) | Modeled the simulator tests and explicit limitations against the complete assignment sequence |
| Databases | Current DBMS implementation progression | [CMU 15-445 Fall 2026 syllabus](https://15445.courses.cs.cmu.edu/fall2026/syllabus.html), [Project 1](https://15445.courses.cs.cmu.edu/fall2026/project1/), [Project 2](https://15445.courses.cs.cmu.edu/fall2026/project2/), [Project 3](https://15445.courses.cs.cmu.edu/fall2026/project3/), [Project 4](https://15445.courses.cs.cmu.edu/fall2026/project4/) | Added buffer pool, page file, B+ tree, WAL and recovery exercises; maintained clear scope gaps vs BusTub |
| MBSE | SysML v2 formal language and advanced MBSE course progression | [OMG SysML v2 formal spec](https://www.omg.org/spec/SysML/2.0/Language/PDF), [JHU 645.631](https://apps.ep.jhu.edu/syllabus/fall-2026/645.631.82), [JHU 645.632](https://apps.ep.jhu.edu/syllabus/spring-2027/645.632.81), [SysON docs](https://doc.mbse-syson.org/syson/v2026.11.0/) | Structured needs, requirements, model elements, verification, traceability, tool import/export and reports |
| Safety | Quantitative reliability and system safety curriculum | [UMD ENRE602](https://me.umd.edu/course-schedule/course/ENRE602), [NASA Safety Handbook Vol. 2](https://ntrs.nasa.gov/archive/nasa/casi.ntrs.nasa.gov/20150015500.pdf), [STPA Handbook](https://www.flighttestsafety.setp.org/images/STPA_Handbook.pdf) | Added common-cause failure, parameter uncertainty, seeded Monte Carlo and sensitivity; retained explicit limitations |
| Verification | Temporal logic, model checking, Hoare logic and lab expectations | [Surrey COM3028 2026/27](https://catalogue.surrey.ac.uk/2026-7/module/COM3028/SEMR2/2), [TLA+ Tools](https://github.com/tlaplus/tlaplus) | Added safe/unsafe finite quorum models and `.tla`/`.cfg` pair |
| Security | Current standards and training lab | [OWASP ASVS](https://owasp.org/projects/asvs), [WSTG](https://owasp.org/www-project-web-security-testing-guide/latest/), [Juice Shop](https://owasp.org/projects/juice-shop), [NIST 800-160](https://csrc.nist.gov/pubs/sp/800/160/v1/r1/final) | Added ASVS/WSTG matrix and a local defensive application with negative tests |

## Source selection discipline

Search result snippets were treated as discovery clues, not as source-of-truth. High-value course pages and assignment sheets were opened/fetched, and their scope was translated into original lab interfaces and exercises. Protected course submissions/solutions were not copied. Use official assignment specifications as a curriculum benchmark and write original lab code.

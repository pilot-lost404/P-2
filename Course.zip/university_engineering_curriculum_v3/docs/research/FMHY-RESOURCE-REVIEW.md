# FMHY Education Directory Review

**Reviewed:** 21 November 2026  
**Page:** https://fmhy.net/educational  
**Purpose:** Resource discovery for the six-course curriculum. FMHY is an index, not the academic authority or a licensing guarantee for the linked materials.

## Useful, legitimate discovery routes selected

| Directory entry | Destination | Curriculum use | Selection decision |
|---|---|---|---|
| MIT OpenCourseWare | https://ocw.mit.edu/ | University lectures, problem sets and older course archives | Primary supplement where the course page confirms free access |
| edX | https://www.edx.org/ | Structured university courses | Use audit/free options only where currently offered; paid certificate is not required |
| CMU Open Learning Initiative | https://oli.cmu.edu/independent-learner-courses/ | Independent learning materials | Use where a course directly supports a prerequisite or foundation |
| OpenLearn | https://www.open.edu/openlearn/ | Open University modules | Prerequisite support, not a replacement for advanced engineering labs |
| OpenHPI | https://open.hpi.de/ | Structured computing courses | Supplement software, security and data foundations |
| Yale Open Courses | https://oyc.yale.edu/courses | Public lectures | General mathematical/scientific foundation, not specialist course assessment |
| Class Central | https://www.classcentral.com/ | Course discovery and comparison | Directory only; verify course existence, date, provider and current access at source |
| EbookFoundation Free Programming Books | https://github.com/EbookFoundation/free-programming-books | Legal free programming/documentation directory | Select individual resources and verify their licence and official source |
| VideoLectures | https://videolectures.net/ | Academic talks and lectures | Supplemental explanations; verify speaker and date |

## Excluded routes

The same FMHY page includes download directories, torrents and republished course material. Those are not used as course sources. The pack does not link or rely on unauthorized scans, leaked paid course files, or pirated textbooks. “Listed on FMHY” does not mean the underlying material is authorized for redistribution.

## Selection rule

1. Prefer the course's official university page, primary standards publisher or maintainer documentation.
2. Use FMHY only to discover a candidate resource.
3. Verify the course/asset at its originating institution or publisher.
4. Record version/year, access conditions, and a clear use in the syllabus.
5. Distinguish free-to-read from open-licensed/re-distributable.
6. Keep resource links supplementary: each weekly reader must teach core concepts itself and assign practical work.

## Result

The strongest use of FMHY for this curriculum is finding official open-course platforms. It is not a reason to substitute random video playlists or copied course archives for a coherent, assessed university-level course.

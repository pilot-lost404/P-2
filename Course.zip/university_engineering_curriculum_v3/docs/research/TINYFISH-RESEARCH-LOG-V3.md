# TinyFish Research Log — Edition 3

**Date:** 21 November 2026  
**Role in EFT:** cross-check search and targeted extraction for independent confirmation of course pages, standards and maintained tooling.

## Findings cross-checked

| Area | Query focus | Used evidence |
|---|---|---|
| MBSE | JHU intro and applied MBSE course progression, SysML v2 and NASA material | JHU's public 645.631 syllabus sets the 14-module baseline; 645.632 broadens requirements, functional architecture, parametrics, configuration baselines and model V&V |
| Safety | Reliability course syllabi, risk/PRA and STPA | UMD ENRE602 lists FTA, RBD, FMEA, ETA and reliability data; NASA/Leveson sources were retained for system-level methods |
| V&V | Formal verification course and temporal-logic labs | Surrey 2026/27 lists LTL/CTL/CTL*, explicit and symbolic model checking, Hoare logic/Dafny and five labs |
| Security | Standards, application testing and training platforms | OWASP ASVS/WSTG/Juice Shop official project pages verified; only local authorized training use recommended |
| TLA+ | Latest tool version and official CLI docs | Official TLA+ repository/release page indicates v1.8.0 Clarke pre-release and that the Toolbox is no longer actively maintained; CLI or VS Code integration recommended |

## Use in the curriculum

The cross-check changed practical deliverables and precise limitations, not merely the bibliography. In particular, the updated SysON release information distinguishes graphical view support from built-in configuration/version management; and the TLA+ tooling notes distinguish official current CLI instructions from older Toolbox tutorials.

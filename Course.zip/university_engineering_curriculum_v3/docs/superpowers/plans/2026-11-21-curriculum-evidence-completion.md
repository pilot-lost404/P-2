# Curriculum Evidence Completion — Implementation Plan

> **For agentic workers:** Execute inline in this harness; no subagent dispatch tool is available. Keep tests first and verify each task. All artifacts are in the isolated Edition 3 copy.

**Goal:** Raise the six-course curriculum to the highest evidence-supported quality level by closing the Edition 2 implementation and verification gaps.

**Architecture:** Preserve Edition 2 in a new folder; add six focused executable labs and a versioned evidence/audit layer. Each lab is independent and reports exactly what it verifies.

**Tech Stack:** Go 1.23+, Python 3.13 standard library, pytest 9, Java 21/TLA+ TLC when available, SysML v2 textual model and tool-import protocol, PostgreSQL 18 integration scripts.

**Spec:** `docs/superpowers/specs/2026-11-21-curriculum-evidence-completion-design.md`

## Global Constraints

- No production-readiness, accreditation, certification or safety-case claims.
- Preserve Edition 2; do not overwrite `/mnt/data/university_engineering_curriculum`.
- Test code before claiming; record unavailable external environments honestly.
- Use loopback-only security lab defaults.
- Do not include unauthorized course copies or private university solutions.
- Keep 14 weeks per reader and source mapping in the final package.

## Review Focus

- Raft election / log commit under message delay, loss, partition and crash/restart; test safety, not only happy-path liveness.
- MBSE traceability validator must reject unknown/duplicate IDs, missing test coverage and dangling references without silently normalizing bad data.
- Safety uncertainty model must state the beta-factor assumptions and avoid assuming independent failures in the common-cause path.
- TLA+ model must bound its finite model and avoid claiming unbounded proof; check configuration names and invariant semantics.
- Security lab must not bind beyond loopback, must use constant-time MAC comparison, reject cross-tenant/object access and test CSRF/session boundaries.
- Storage/WAL recovery must be idempotent under replay, reject torn/corrupt records and preserve page-file format invariants.

---

### Task 1: Preserve baseline and establish evidence workspace

**Files:**
- Create: `docs/superpowers/specs/2026-11-21-curriculum-evidence-completion-design.md`
- Create: `docs/superpowers/plans/2026-11-21-curriculum-evidence-completion.md`
- Create: `verification/progress.md`
- Modify: `README.md` only after all tasks are complete

**Verification:** inventory six readers, six reading maps, week counts and baseline audit. Preserve the V2 directory.

### Task 2: Distributed consensus and replicated-state lab

**Files:**
- Create: `labs/01-distributed/raftsim/` implementation, tests, README and protocol trace fixtures.
- Modify: `course-readers/01-distributed-systems.md`, `weekly-reading-maps/01-distributed-systems.md`.

**Tests:** election safety; one leader per term; log-match/committed-prefix safety; majority commit; stale-term rejection; dropped/reordered messages; leader crash and restart; partitions; deterministic seeds.

### Task 3: MBSE model completeness and traceability validator

**Files:**
- Create: `labs/02-mbse/model/` SysML v2 part/requirement/action/verification/analysis content.
- Create: `labs/02-mbse/traceability/` CSV registers and a standard-library validator with unit tests.
- Modify: MBSE reader, MBSE reading map and MBSE README.

**Tests:** duplicate identifiers, missing model references, unverified requirements, invalid links, round-trip parsing of the tabular interchange files. Tool-level SysML import/export is reported separately.

### Task 4: Quantitative safety uncertainty and common-cause analysis

**Files:**
- Modify: `labs/03-safety/reliability_lab/reliability.py` only after tests are written.
- Create: tests for beta-factor/common-cause model, Beta posterior sampling, deterministic Monte Carlo, confidence intervals and sensitivity rankings.
- Modify: Safety reader and lab README.

**Verification:** hand-check small cases analytically and test edge/invalid parameters. Fixed random seed must reproduce outputs.

### Task 5: Formal verification and property-based testing

**Files:**
- Create: `labs/04-vv/tla-plus/` specification, TLC config and run guide.
- Create: property/state-machine test suite for existing finite-state checker and data structures.
- Modify: V&V reader, reading map and README.

**Verification:** run TLC with bounded constants if tool installation succeeds. If not, preserve an explicit `NOT EXECUTED` status and test the companion state model locally.

### Task 6: End-to-end application security training service

**Files:**
- Create: `labs/05-security/secure_service/` WSGI app, config, tests and run script.
- Create: ASVS/WSTG requirement-to-test matrix and safe lab tasks.
- Modify: Security reader, reading map and README.

**Tests:** authentication failures, session expiry/rotation, CSRF, input validation, object-level authorization, tenant isolation, audit event integrity, response security headers and loopback-only startup. Run lint/security scanners when present.

### Task 7: Disk-backed database internals lab

**Files:**
- Create: `labs/06-data-systems/diskdb/` page file, buffer pool, WAL, recovery and disk-backed B+ tree.
- Create: tests for page CRC/shape, eviction/pinning, WAL commit/replay/torn records, B+ tree splits/range scan/reopen and crash injection.
- Modify: DB reader, reading map and README.

**Verification:** deterministic tests, randomized model comparison against a Python reference map, corruption/recovery tests and a small benchmark. PostgreSQL 18 execution remains a separate integration gate.

### Task 8: Integrate, re-audit and release

**Files:**
- Create: V3 source/evidence logs, research coverage matrix, verification matrix, issue register, course quality scorecard, audit and roadmap.
- Modify: `README.md`, `00-COURSE-GUIDE.md`, `LAB_MANUAL.md`, `09-SOURCE-LIBRARY.md`.
- Create: `MANIFEST.sha256` and `university_engineering_curriculum_v3.zip`.

**Verification:** all code tests; Go `-race` and `go vet`; Python compileall; heading/week counts; assessment counts; traceability checks; archive test; manifest checksum equality; internal links and source URLs checked. Author self-review only; no fabricated independent sign-off.

# Six-Course University Engineering Curriculum Upgrade — Implementation Plan

> **For agentic workers:** Execute inline using superpowers:executing-plans. Steps use checkbox syntax.

**Goal:** Upgrade all six 14-week course readers into source-grounded, technically rigorous self-study courses with reproducible labs, problem sets, solutions, and a second independent audit.

**Architecture:** Retain the original readers as source material, create expanded v2 readers under `course-readers/`, and complete the missing practical and assessment infrastructure in focused folders. Keep research provenance, tool versions, and verification results visible.

**Tech Stack:** Markdown, Go 1.23-compatible standard library, Python 3.13 + pytest, PostgreSQL 18 SQL, SysML v2 textual model, Mermaid, CSV.

**Spec:** `docs/superpowers/specs/2026-11-21-course-materials-upgrade-design.md`

## Global Constraints
- No copied/pirated textbooks, course videos, proprietary assignments, or copyrighted solutions.
- Every source URL must be official or clearly classified as a discovery pointer; current version claims need publisher/issuer verification.
- Preserve the original six subjects and water-tank capstone context.
- Do not claim unexecuted labs, model imports, SQL scripts, or formal methods tools were tested.
- Use 8–12 hours/week as the intended study load, backed by content and assessment.
- Report course scores using the pre-existing audit dimensions; never inflate a score to satisfy the requested target.

## Review Focus
- **Coverage:** every 14-week syllabus includes outcomes, required content, exercise/lab and assessment evidence.
- **Correctness:** formulas, assumptions, failure models, threat models and database behavior are accurately scoped.
- **Reproducibility:** fresh setup/reset commands and version floors are correct; tested vs. untested labs are labelled.
- **Traceability:** course outcomes map to weekly assessments, capstone requirements and evidence.
- **Copyright/licensing:** only original explanations and links; no wholesale textbook/assignment reproduction.

---

### Task 1: Research and curriculum map
**Files:** `09-SOURCE-LIBRARY.md`, `FMHY-RESOURCE-REVIEW.md`, `COURSE_ARCHITECTURE.md`, research notes.
- [x] Incorporate 2026 university syllabi and standards sources for all six courses.
- [x] Record FMHY as a discovery index; select only official, legitimate free resources.
- [x] Map each course's prerequisites, outcomes, 14-week topics, major deliverables and benchmarks.
- [x] Verify URLs, versions, and accessibility notes.

### Task 2: Expanded course readers
**Files:** create six files under `course-readers/` and update `README.md` / `00-COURSE-GUIDE.md`.
- [x] Expand all 14 weeks in every subject with substantive lecture notes and applied work.
- [x] Add equations/derivations, worked examples and critical assumptions where the discipline requires them.
- [x] Add research reading questions, weekly checkpoints, course learning outcomes and grading maps.

### Task 3: Runnable and inspectable laboratories
**Files:** `labs/01-distributed-systems/`, `labs/02-mbse/`, `labs/03-safety/`, `labs/04-vv/`, `labs/05-security/`, `labs/06-data-systems/`.
- [x] Add Go clock/consistency and deterministic failure-simulation exercises.
- [x] Add a SysML v2 model and traceability/validation artefacts; clearly state import tool is not run here.
- [x] Add tested Python reliability and fault-tree calculations.
- [x] Add tested state-machine/property-style V&V exercises and security authorization regression tests.
- [x] Strengthen PostgreSQL schema, indexing, transaction, query-plan, backup/restore exercises; state external DB runtime gap if unavailable.

### Task 4: University-grade assessment package
**Files:** `assessments/`, `projects/`.
- [x] Create weekly problem sets with worked solutions, midterm/final blueprints and marking rubrics.
- [x] Create cumulative projects with milestone acceptance tests / artefacts and code-ownership oral check prompts.
- [x] Provide integrated capstone traceability across requirements, architecture, safety, security, data, implementation and V&V.

### Task 5: Technical and academic audit
**Files:** `audit/ACADEMIC-AUDIT-V2.md`, `audit/COURSE-SCORECARD-V2.csv`, `audit/VERIFICATION-MATRIX.md`, manifest.
- [x] Verify all links and internal references; inspect word depth and week coverage.
- [x] Run all available Go and Python tests and static checks.
- [x] Run SQL only if PostgreSQL client/server exists; otherwise record as unexecuted and preserve exact user-run command.
- [x] Inspect SysML syntax against OMG/SysON documentation; do not claim a parser pass without an actual parser run.
- [x] Grade using evidence, document every remaining shortfall, and produce a final ZIP with integrity check.


## Execution note — 21 November 2026

The plan items are complete as curriculum/documentation deliverables. External SysML and PostgreSQL execution is explicitly recorded as unavailable, not passed. Independent faculty review, full Raft construction and a full disk-backed DBMS build remain future quality gates. The audit score is 86.83/100; do not inflate it to meet the target.

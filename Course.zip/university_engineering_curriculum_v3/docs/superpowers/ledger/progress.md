# SDD ledger — plan: docs/superpowers/plans/2026-11-21-course-materials-upgrade.md

- Pre-flight: tasks share the curriculum vocabulary, the water-tank case and the audit rubric; preserve one canonical set of IDs and terms across readers, labs, assessments and capstone.
- Ruling: No Git repository exists in the supplied curriculum directory, so no Git worktree/commit-based workflow is possible. Work directly in the provided directory; retain originals and use file-level checksums and an archive integrity test instead. Cost if wrong: no source-control rollback in this directory; original files are preserved and edits are additive wherever possible.
- Research route: Exa → Firecrawl → TinyFish; Context7 current docs; FMHY education index; web verification of 2026 benchmark syllabi and official standards.


- Ruling: Interpret “weekly problem sets” as one original exercise per course-week plus a separate longer exam-style bank — this yields complete 14-week practice coverage without copying proprietary university questions; cost if wrong: instructor may prefer formal weekly multi-question sheets.
- Task 1: complete — current official 2026 university benchmarks and standards recorded; FMHY discovery resources filtered for legitimacy.
- Task 2: complete — six course readers and six weekly reading maps each have exactly 14 weeks; reader word counts 8,203 / 6,583 / 6,314 / 6,049 / 6,296 / 6,546.
- Task 3: complete as runnable/inspectable lab deliverables — Go clock and idempotency labs; Python reliability, finite-state checker, authorization policy and B+ tree; SysML/PostgreSQL artefacts explicitly not externally executed.
- Task 4: complete — 84 weekly problems with worked checkpoints, 30 longer worked problems, 20 capstone acceptance tests and oral defense/rubric.
- Task 5: complete with external validation gates — two Go race/vet suites pass; Python 29/29 pass; compileall passes; local Markdown links 0 broken; 14/14 structure in all readers/maps; mean course score 86.83/100. PostgreSQL and SysML external tool runs unavailable.

- Final review: self-review of the complete artifact set (no subagent/reviewer tool available); automated validation re-run after edits. This is weaker than an independent examiner and remains a stated limitation.

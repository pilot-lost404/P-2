# Curriculum Evidence Completion — Edition 3 Design

**Date:** 2026-11-21  
**Baseline:** Edition 2, author self-audit 86.83/100  
**Audience:** Advanced undergraduate / early graduate self-study  
**Goal:** Close the practical and evidence gaps that materially limit the six-course package, while preserving its existing 14-week progression and all prior content.

## Intent

Edition 2 is a strong course-reader package, but the audit identifies missing executable depth in consensus, model-based traceability, uncertainty-aware safety analysis, formal verification, end-to-end security testing, and durable database internals. Edition 3 turns these remaining gaps into reproducible assignments with code/model artefacts, tests, expected evidence, marking rubrics and a source-to-claim register.

## Goals

- Retain all six courses, the 14-week sequence, source maps, weekly questions, worked solutions and integrated capstone.
- Add meaningful, runnable practical work for every identified gap.
- Test locally supported work in a clean environment; record exact commands, tool versions, outcomes and limitations.
- Add model and artifact traceability checks, quantitative safety uncertainty, and an executable formal specification.
- Provide an isolated security training target, scoped to localhost and deliberately safe use.
- Add disk-backed database primitives and a documented PostgreSQL 18 execution protocol.
- Re-audit against the unchanged six-dimension, 100-point editorial rubric.

## Non-goals

- Claim institutional accreditation, credit equivalence, professional certification, safety approval or production readiness.
- Reproduce or redistribute protected university course solutions, paid textbooks or unauthorized downloads.
- Treat a small educational implementation as an industrial Raft stack, SysML toolchain, PRA tool, theorem prover, commercial DBMS, penetration-test certification or production security service.
- Claim independent peer review unless a qualified reviewer actually completes and signs it.

## Approaches considered

1. **Patch Edition 2 in place.** Lowest maintenance overhead, but risks losing a known-good baseline and makes the audit trail harder to compare.
2. **Copy Edition 2 into Edition 3 and extend the copy.** Preserves the released baseline, provides a clean version boundary, and makes all modifications auditable. This is the selected approach.
3. **Rewrite the six courses from scratch.** Would introduce avoidable regression risk and duplicate already useful material; rejected.

## Architecture

- `course-readers/`: six main readers; Edition 3 addenda point to new labs and explain new depth.
- `labs/01-distributed/`: deterministic consensus/replication lab with failure injection and restart/persistence tests.
- `labs/02-mbse/`: SysML v2 model set plus a deterministic requirements → model element → verification case traceability validator; actual tool import remains separately evidenced.
- `labs/03-safety/`: common-cause, parameter-uncertainty and Monte Carlo reliability analysis with deterministic seeds and sensitivity output.
- `labs/04-vv/`: TLA+ specification/configuration plus stateful/property-based testing and verification-vs-testing guidance.
- `labs/05-security/`: isolated localhost training API with authentication, scoped authorization, session/CSRF controls, negative tests, and ASVS/WSTG mappings.
- `labs/06-data-systems/`: fixed-page storage, buffer cache, WAL recovery and disk-backed B+ tree with crash/reopen/invariant tests; existing PostgreSQL lab remains the real-engine integration layer.
- `docs/research/`: separate Exa, Firecrawl and TinyFish evidence logs, Context7 versioned documentation notes, source provenance and FMHY discovery decisions.
- `audit/` and `verification/`: requirement/evidence matrix, exact commands and outputs, issue register, revised scorecard and clear remaining external gates.

## Constraints and design calls

- Use Python 3.13 standard library for reliability, MBSE traceability and storage teaching components unless a maintained tool is specifically needed.
- Use Go for the distributed consensus lab, consistent with the existing Go starter labs and MIT 6.5840 benchmark.
- Use TLA+ / TLC for a finite-state protocol specification; label state-space bounds and properties checked.
- Use Hypothesis only as an optional, pinned test dependency; a deterministic standard-library fallback must remain available.
- Do not silently claim real PostgreSQL or SysON execution. Capture external outputs only if the actual supported tool is available and invoked.
- Never expose training service beyond loopback; the security target must reject non-loopback bind addresses by default.
- A self-audit may award author points for completed local evidence but cannot close the independent-review gate.

## Acceptance criteria

1. Six readers and all six reading maps retain 14 weeks and link each new practical component to its course outcomes.
2. Each new lab has a README with prerequisites, exact setup/run/test commands, expected output, failure cases, rubric, limitations and safety boundaries.
3. New code has tests written first; each new test is observed failing before implementation where TDD is applicable.
4. The Go and Python test suites pass freshly; race/static-analysis checks pass where available.
5. The TLA+ specification is run with TLC if the official tool can be obtained and installed; otherwise it is clearly marked not executed and no model-checking pass is claimed.
6. The release manifest hashes every distributable file; archive integrity and manifest checks pass.
7. The revised audit recomputes the score from explicit evidence and lists all remaining blockers. It cannot state 100 while an essential external tool run or independent review remains outstanding.

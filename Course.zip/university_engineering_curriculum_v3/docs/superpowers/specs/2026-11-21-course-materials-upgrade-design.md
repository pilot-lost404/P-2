# Six-Course University Engineering Curriculum — Upgrade Design

## Intent
Raise the existing six 14-week self-study course readers from introductory outlines to rigorous advanced-undergraduate / early-graduate learning materials. The curriculum is for a motivated individual learner; it is not an accredited degree, standards certification, or substitute for instructor feedback.

## Goals
- Preserve the six subjects, common water-tank cyber-physical case study, and prerequisite logic.
- Provide a coherent 14-week semester for each subject, with explicit outcomes, mathematical/technical foundations, derivations, worked cases, critical limitations, and further reading.
- Close the previously audited gaps: implementation labs, quantitative methods, formal reasoning, reproducibility, assessment breadth, and worked solutions.
- Benchmark content and workload against current 2026 university course pages and authoritative standards/documentation.
- Make all locally executable code examples reproducible, with exact versions, commands, expected observations, and tests.
- Use FMHY only to discover legitimate free learning platforms; verify every selected learning resource at its own official source.

## Non-goals
- Claim institutional accreditation, professional certification, or a guaranteed 100/100 independent accreditation result.
- Reproduce commercial textbooks, paid course video, proprietary university assignments/solutions, or standards text.
- Deploy safety/security examples to real industrial equipment or third-party systems.
- Require paid tools where an open alternative can meet the learning objective.

## Approaches considered
1. **Link-only syllabus:** fast, but fails the prior audit because the learner would have to assemble the course and labs independently.
2. **Rewrite all content from scratch:** causes avoidable loss of useful existing material and increases inconsistency.
3. **Selected approach — retain the original readers as source material, create six expanded v2 course readers, add reusable labs/assessments/solutions, and re-audit:** combines existing coverage with university benchmarks and verifiable practical evidence. This is the best balance of rigor, traceability, and preservation.

## Architecture
- `course-readers/`: six primary expanded course readers, one per discipline.
- `labs/`: runnable code exercises, model artifacts, worksheets, SQL, and test fixtures.
- `assessments/`: weekly problem banks, worked solutions, exam blueprints, project rubrics, and marking guides.
- `projects/`: integrated semester capstone specification, requirement baseline, model artefacts, interface contracts, and acceptance criteria.
- `09-SOURCE-LIBRARY.md`: verified source catalogue with source type, relevance, accessibility/licence notes, and last-checked date.
- `audit/`: new rubric, course scorecard, verification matrix, and residual-gap statement. Preserve the first audit for comparison.

## Educational design
Each course carries 14 weeks, a 3–4-hour core reading/lecture block, a 3–5-hour problem/lab block, and a 1–2-hour engineering notebook/review block. The intended total is 8–12 hours/week. Every week must include learning outcomes, substantive concept notes, an applied example or derivation, a lab/problem, and a self-check. Courses include at least two major technical assessments, an individual implementation/model project, an exam, and a portfolio review.

## Quality and evidence rules
- Distinguish universal theory from implementation-specific behavior (especially PostgreSQL and Go versions).
- Cite standards by issuer, identifier, revision, and official URL; mark paywalled/licensed material as reference-only.
- Do not state that code, SysML, SQL, or model-checking examples execute unless they have actually been tested in the named tool/version.
- Local Go and Python labs must have tests; SQL labs must include setup, reset, expected results, and a no-Docker fallback note.
- A course score of 100 requires all six rubric dimensions and all executable/artifact checks to pass. Any unexecuted external-tool workflow remains a documented limitation rather than being marked complete.

## Assumptions and calls
- Audience: advanced undergraduate learner with programming, algorithms, networking, databases, discrete mathematics, probability and calculus fundamentals.
- Semester: 14 teaching weeks per course; not a credit-hour equivalency claim.
- Main case: remote water-tank monitoring and control simulation.
- Go is the implementation language for distributed/concurrency exercises; Python for numerical analysis and model-based testing; PostgreSQL 18 for relational database exercises; SysML v2 with Eclipse SysON as the open MBSE tool path.
- Tool availability differs by learner machine; every lab must list required and optional tools and provide a no-container alternative where feasible.

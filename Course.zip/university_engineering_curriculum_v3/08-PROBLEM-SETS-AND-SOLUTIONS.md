# Problem Sets and Worked Solutions
These problems supplement the six course textbooks. Try each problem before reading its solution. The purpose is to assess reasoning, not memorization.

## A. Distributed Systems

### A1. RPC uncertainty
A client sends a request to transfer 100 units. It times out. Explain why it cannot safely infer that the transfer failed, and design a retry protocol.

**Worked solution:** The server may not have received the request, may still be processing it, may have committed it, or may have committed it and lost the response. The client should reuse a stable operation ID on retries. The server should persist the operation ID, request parameters and result in the same durable transaction as the business state change. A duplicate ID with identical parameters returns the recorded result; reuse of the same ID with different parameters is rejected. The operation record needs a defined retention horizon and must be available after failover.

### A2. Lamport clock calculation
Process P1 has clock 3 and sends a message to P2. P2's clock is 7 when it receives the message. What timestamp should P2 assign to the receive event? What does the result prove?

**Worked solution:** P2 assigns `max(7,3)+1 = 8`. Since send causally precedes receive, the sender's timestamp is lower. It does not prove that every event with a smaller timestamp caused the receive event; Lamport clocks preserve causality but do not fully identify concurrency.

### A3. Quorum
A replicated service has nine voters. Determine a majority quorum and the maximum number of unavailable voters that still leaves a majority.

**Worked solution:** Majority is `floor(9/2)+1 = 5`. Four voters may be unavailable while five remain. This only establishes arithmetic quorum availability; network topology, leader placement and protocol safety rules still matter.

### A4. Consistency choice
Choose an appropriate consistency guarantee for (a) an account balance transfer, (b) a telemetry graph, and (c) the local emergency-stop state.

**Worked solution:** A transfer generally requires serializable or otherwise carefully defined transactional invariants and externally coherent balance semantics. A telemetry graph may tolerate bounded staleness or eventual consistency if staleness is shown. An emergency-stop decision belongs in the local control path and must not depend on eventual cloud replication. The exact guarantee depends on how each value is used.

### A5. CAP interpretation
During a network partition, node A accepts writes while node B serves reads from stale data. Can the service claim linearizability?

**Worked solution:** Not if a read on B can occur after a completed write on A and return the old value. The service must coordinate, reject/limit some operations, or explicitly weaken the read guarantee.

---

## B. Model-Based Systems Engineering

### B1. Requirement quality
Rewrite: "The system shall be highly reliable and respond quickly."

**Worked solution:** This sentence combines two vague quality goals. Split them and define operational conditions and measurement. Example: "For the specified normal-load profile of 100 status requests/s, the API shall return 95% of valid status requests within 300 ms over a 10-minute measurement window." Reliability needs a defined failure event and observation interval, such as "The telemetry ingestion service shall successfully persist at least 99.9% of valid events under the specified 200 events/s load over a 24-hour test, excluding declared maintenance." The values need stakeholder and engineering justification.

### B2. Traceability
A stakeholder need leads to requirement SYS-08. SYS-08 is allocated to Gateway G1 and Database D1. Test T-17 verifies the event identifier is unique. What additional links should be recorded?

**Worked solution:** Record the originating stakeholder and need, rationale, requirement version, allocation rationale, interface/schema element carrying the identifier, database uniqueness constraint, verification procedure and evidence artifact. If SYS-08 is safety/security relevant, link the hazard/threat and corresponding control.

### B3. Context versus architecture
A diagram shows the tank, controller, operator and cloud API. Why is it insufficient as the full architecture?

**Worked solution:** It shows system context and external actors but not internal subsystem responsibilities, interfaces, internal control behavior, data ownership, deployment constraints or safety/security mechanisms. A complete architecture requires multiple consistent views.

### B4. Change-impact
The sensor's sampling interval changes from 100 ms to 500 ms. Name at least six artifacts to revisit.

**Worked solution:** Freshness requirement, control-loop timing budget, overflow response margin, controller state model, hazard scenarios, interface contract, telemetry volume assumptions, performance tests, fault-detection logic and operator alarm behavior.

---

## C. Safety and Risk Analysis

### C1. Failure mode versus hazard
Classify: "valve stuck open", "tank overflows", "controller uses stale data and continues filling".

**Worked solution:** "Valve stuck open" is a failure mode. "Tank overflows" is a hazard/unsafe state in the chosen system context and may lead to a loss. "Controller uses stale data and continues filling" is a causal scenario that can create or sustain the hazard.

### C2. RPN
Two FMEA rows have scores: row A severity 10, occurrence 2, detectability 8; row B severity 4, occurrence 8, detectability 4. Calculate RPN and explain why ranking only by RPN is dangerous.

**Worked solution:** A = 160; B = 128. RPN ranks A above B in this example, but the difference is not a calibrated risk ratio. If scales are ordinal, multiplication has no reliable probability interpretation. Severity must receive independent attention and mandatory escalation rules.

### C3. Fault-tree probability
Two independent events have probabilities 0.02 and 0.03. Find the probability of an OR gate and an AND gate.

**Worked solution:** OR: `0.02 + 0.03 - (0.02*0.03) = 0.0494`. AND: `0.02*0.03 = 0.0006`. Independence is a required assumption; shared power, environment or maintenance may invalidate it.

### C4. UCA classification
A controller does not issue a close-valve command within the required time after high-high detection. Which STPA unsafe-control-action category applies?

**Worked solution:** The control action is not provided when required, and may also be provided too late. STPA categories are contextual; record the specific unsafe context and timing requirement.

### C5. Independent protection
A primary level sensor and high-high switch have separate housings but share the same power supply. Are they independent?

**Worked solution:** Not necessarily. A common power failure can disable both. Independence must be evaluated across power, wiring, environment, sensing technology, software, maintenance, configuration and human action.

---

## D. Verification and Validation

### D1. Equivalence partitions
An API accepts `level_percent` from 0 through 100 inclusive. List useful input partitions and boundary values.

**Worked solution:** Invalid below 0; boundary 0; valid interior; boundary 100; invalid above 100; malformed types such as null, string, NaN/infinity; values with excessive decimal precision. Test just below/at/just above each boundary, e.g., -0.01, 0, 0.01, 99.99, 100, 100.01.

### D2. Verification or validation?
A dashboard meets the approved response-time requirement but operators misinterpret stale telemetry as current. Classify the finding.

**Worked solution:** It may have passed a performance verification requirement, but it failed an operational validation concern. The UI/requirements/ConOps need revision so the system makes freshness and uncertainty clear.

### D3. Zero-failure evidence
A test executes 2000 independent trials and observes zero failures. Using the rough rule of three, estimate the 95% upper bound on failure probability.

**Worked solution:** Approximately `3/2000 = 0.0015`, or 0.15%, under the rule's assumptions. This is not proof of zero failure probability, and real test trials may not be independent or representative.

### D4. Coverage
A project has 100% statement coverage and 60% branch coverage. Can it claim complete verification?

**Worked solution:** No. Coverage metrics describe execution, not correctness. Missing branches may include safety-relevant behavior. Also inspect requirements coverage, state transitions, interfaces, boundary classes, negative tests and risk scenarios.

### D5. Evidence package
List the minimum configuration information needed to reproduce a formal system verification result.

**Worked solution:** Product/build version, requirements baseline, procedure version, test environment, hardware and dependencies, configuration values, test data, tools/instrumentation and versions, operating conditions, result data, anomalies and reviewer/approval details.

---

## E. Security Engineering

### E1. STRIDE
A low-privilege operator changes a different facility's target by changing a URL parameter. Classify the issue and propose controls.

**Worked solution:** This is an authorization failure and commonly an elevation-of-privilege scenario in STRIDE. Enforce server-side object-level authorization on every operation, derive identity from verified authentication context, check facility ownership/scope, default deny and audit the decision. UI hiding is not a control.

### E2. JWT
An API validates a JWT signature but ignores `aud` and `exp`. What can go wrong?

**Worked solution:** A token issued for a different service may be accepted, and an expired token may remain usable. Validate issuer, audience, expiration, not-before if used, key/algorithm policy and required scopes. Also implement key rotation, revocation/session strategy and secure token storage.

### E3. Hashing and encryption
Explain why a password database should store a password verifier rather than encrypting passwords with a reversible key.

**Worked solution:** The application generally needs to verify a password, not recover it. A password-hashing/KDF function with a unique salt and tunable work factor makes offline guessing more expensive. Reversible encryption creates a high-value key whose compromise reveals all passwords.

### E4. Security testing claim
A DAST tool reports no critical issues. What conclusion is justified?

**Worked solution:** No critical issues were reported by that tool under the tested scope, configuration and runtime conditions. It does not prove the application has no vulnerabilities, and design flaws or authorization logic may be missed.

### E5. Command replay
An attacker replays a previously valid command. Give three control layers.

**Worked solution:** Transport authentication/integrity, stable command IDs with server-side duplicate tracking and expiry, plus local controller validation of freshness/sequence/target/operating mode. Audit the replay rejection. No single layer should be assumed to cover every path.

---

## F. Data Systems and Databases

### F1. Candidate keys
Relation R(A,B,C,D) has FDs: `A -> B`, `B -> C`, `CD -> A`. Find candidate keys.

**Worked solution:** Attribute D never appears on the right side, so every candidate key must include D. Compute `(AD)+`: A gives B, B gives C, so closure is ABCD; AD is a key. Compute `(CD)+`: CD gives A, then A gives B and B gives C; closure is ABCD, so CD is a key. Neither has a removable attribute under these FDs, so candidate keys are AD and CD.

### F2. SQL aggregation
Write a query returning each tank's latest measurement and quality.

**Worked solution:**
```sql
SELECT DISTINCT ON (sensor_id)
       sensor_id, event_time, level_percent, quality
FROM measurement
ORDER BY sensor_id, event_time DESC, measurement_id DESC;
```
This is PostgreSQL-specific syntax. A window-function alternative is:
```sql
SELECT sensor_id, event_time, level_percent, quality
FROM (
  SELECT m.*,
         row_number() OVER (
           PARTITION BY sensor_id
           ORDER BY event_time DESC, measurement_id DESC
         ) AS rn
  FROM measurement AS m
) AS ranked
WHERE rn = 1;
```

### F3. Normalization
Given `OrderLine(order_id, product_id, product_name, quantity, unit_price)` with key `(order_id, product_id)` and `product_id -> product_name`, explain the anomaly.

**Worked solution:** Product name depends only on part of the composite key. Repeating the product name in every order line creates update and insertion anomalies. Decompose Product(product_id, product_name) and OrderLine(order_id, product_id, quantity, unit_price). Whether unit price belongs in OrderLine depends on whether it records the sale-time price; historical transaction facts should not be replaced by the current product price.

### F4. Isolation
Two transactions both read `available_capacity=1`. Each reserves one unit and decrements the value. What can go wrong?

**Worked solution:** Under unsuitable isolation or update logic, both may commit based on the same old value, resulting in over-reservation or a lost update. Use an atomic conditional update, row lock, serializable isolation or another correctly enforced invariant. Test concurrent execution rather than assuming the application sequence is safe.

### F5. Index choice
A query filters by `sensor_id` and a recent time range and orders by `event_time DESC`. Propose an index and state the trade-off.

**Worked solution:** A B-tree on `(sensor_id, event_time DESC)` can support equality on sensor and ordered range access by time. It consumes disk, adds insert/update cost and must be evaluated with actual cardinality and `EXPLAIN ANALYZE`.

### F6. Backup
A primary database replicates synchronously to a standby. Is that enough for disaster recovery?

**Worked solution:** Not by itself. Replication may copy accidental deletion or malicious changes; a site-wide failure may affect both; the standby may share credentials or administration. Maintain independent backups, retention and offsite or isolated copies, then test restore and RPO/RTO.

# Cross-Course Glossary

**Acceptance criterion** — An objective condition used to decide whether a requirement or deliverable passes.

**Acceptance testing** — Evaluation used to determine whether a delivered product is acceptable for the agreed use or contract.

**ABAC** — Attribute-Based Access Control; authorization based on attributes of subject, object, action and context.

**ACID** — Atomicity, Consistency, Isolation and Durability; properties used to describe database transactions.

**Anomaly** — A deviation from expected behavior, a failed requirement, a test issue or another recorded discrepancy requiring disposition.

**Architecture** — The fundamental organization of a system: elements, responsibilities, relationships, interfaces, constraints and governing decisions.

**Asset** — Something valuable that needs protection, such as data, identity, service, process or mission capability.

**Assumption** — A condition accepted for analysis but not yet established as fact.

**Availability** — The degree to which a system or service is accessible and usable when required.

**BCNF** — Boyce–Codd Normal Form; every determinant of a non-trivial functional dependency is a superkey.

**Causal consistency** — A consistency model preserving causal order across replicas.

**Candidate key** — A minimal set of attributes that uniquely identifies a tuple.

**CAP theorem** — During a network partition, a distributed data service cannot guarantee both linearizable consistency and availability for every request to every non-failing node.

**ConOps** — Concept of Operations; description of system use in its operational context.

**Consensus** — Agreement among distributed participants on a value or ordered history under a specified failure model.

**Consistency model** — A formal contract describing which values or operation orders clients may observe.

**Control action** — A command from a controller to a controlled process or component.

**Control structure** — A model of controllers, controlled processes, actuators, sensors and feedback paths used in system-theoretic safety analysis.

**CWE** — Common Weakness Enumeration; taxonomy of software and hardware weakness types.

**Data lineage** — Record of data origin and transformations through a system.

**Deadlock** — A state where a set of transactions/processes wait indefinitely for resources held by one another.

**Durability** — Persistence of committed data under the DBMS's stated failure model.

**Eventual consistency** — A guarantee that replicas converge if updates stop and reconciliation continues, without necessarily guaranteeing stronger read properties.

**FMEA** — Failure Modes and Effects Analysis; bottom-up analysis of item/function failure modes and their effects.

**FMECA** — FMEA extended with a criticality analysis.

**Fault tree** — Top-down logic model decomposing a defined top event into combinations of lower-level events.

**Fault tolerance** — Ability to continue providing defined behavior despite specified faults.

**Functional dependency** — Constraint \(X \rightarrow Y\) stating that X values determine Y values in a relation.

**Hazard** — A system state or condition that, together with an environment, can lead to a loss.

**Idempotency** — Property that repeated execution of an operation has the same intended effect as one execution, under a defined scope.

**Isolation** — Transaction property controlling the interference visible between concurrent transactions.

**Linearizability** — Consistency condition where each operation appears to take effect atomically between invocation and response, preserving real-time order of non-overlapping operations.

**Little's Law** — \(L = \lambda W\), relating average population, arrival rate and time in a stable system.

**Loss** — Unacceptable outcome for a stakeholder, such as injury, damage, mission failure or loss of essential service.

**MBSE** — Model-Based Systems Engineering; disciplined use of connected system models across lifecycle engineering.

**Model** — Purposeful abstraction of a system, preserving detail needed for a particular engineering question.

**MVCC** — Multi-Version Concurrency Control; a concurrency-control approach that retains versions so transactions can observe snapshots.

**Need** — Stakeholder-desired outcome; not necessarily a fully specified technical requirement.

**Normalization** — Relational design process that reduces redundancy and update anomalies through dependencies and normal forms.

**Outbox pattern** — Pattern where a service commits a business change and an event record in one local database transaction, then publishes the event asynchronously.

**Primary key** — The chosen candidate key used to identify rows in a relation.

**RPN** — Risk Priority Number, often S×O×D in FMEA; a ranking aid, not automatically a calibrated risk probability.

**RPO** — Recovery Point Objective; maximum targeted data loss expressed as time.

**RTO** — Recovery Time Objective; target time to restore service after disruption.

**Safety case** — Structured argument, supported by evidence, that a system is acceptably safe for a defined context.

**Saga** — A sequence of local transactions with compensating actions for distributed workflows.

**Security requirement** — Testable condition needed to satisfy a system's protection needs.

**Sharding** — Partitioning data across multiple nodes.

**SIL** — Safety Integrity Level; a classification used within specific functional-safety standards and processes, not a generic label.

**SLO** — Service-Level Objective; target for a measured service-level indicator over a defined period.

**STPA** — System-Theoretic Process Analysis; hazard analysis method that examines unsafe control actions and causal scenarios.

**STRIDE** — Threat-modeling categories: Spoofing, Tampering, Repudiation, Information Disclosure, Denial of Service and Elevation of Privilege.

**Superkey** — Any set of attributes that uniquely identifies a tuple; may include redundant attributes.

**SysML** — Systems Modeling Language; standardized language for modeling complex systems.

**Technical requirement** — A statement describing an objectively verifiable condition the system or element must satisfy.

**Threat** — Potential cause of an unwanted security event affecting an asset.

**Traceability** — Explicit relationships between related engineering artifacts, such as needs, requirements, design elements, hazards, tests and evidence.

**UCA** — Unsafe Control Action; a control action that is unsafe in a particular context.

**Validation** — Evidence that a product meets stakeholder needs and intended use in its operational context.

**Verification** — Evidence that a product or work product conforms to specified requirements.

**WAL** — Write-Ahead Logging; recovery approach that records required log information before corresponding data-page changes become durable.

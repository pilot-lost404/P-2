# Course Guide — Six Advanced Engineering Courses (Edition 3)

**Level:** Advanced undergraduate / early graduate self-study  
**Length:** 14 teaching weeks per course  
**Expected effort:** 8–12 hours per week, including reading, derivations, labs and assessments  
**Research snapshot:** 21 November 2026

## 1. Start with the Edition 3 course readers

The six expanded course readers are in `course-readers/`. The original Edition 1 chapters are retained inside each V2 reader for continuity. Use the Edition 3 readers as the primary syllabus and the root-level first-edition files as the original baseline, not as the expanded replacement.

1. `course-readers/01-distributed-systems.md`
2. `course-readers/02-model-based-systems-engineering.md`
3. `course-readers/03-safety-and-risk-analysis.md`
4. `course-readers/04-verification-and-validation.md`
5. `course-readers/05-security-engineering.md`
6. `course-readers/06-data-systems-and-databases.md`

Each reader includes learning outcomes, 14 weekly modules, technical notes, worked applications, practical assignments, assessment design and a minimum evidence standard.

## 2. Prerequisites

Before beginning, be comfortable with:
- programming fundamentals, data structures, debugging, testing and Git;
- operating-system processes/threads, synchronization and basic networking;
- HTTP/TCP client-server architecture and basic Linux/Unix command-line work;
- relational tables, keys, joins, SQL and basic transaction concepts;
- functions, sets, logic, relations, probability and elementary calculus;
- diagrams, technical writing and version-controlled project work.

Recommended foundations where needed: MIT OpenCourseWare, edX, CMU Open Learning Initiative, OpenLearn, OpenHPI, Yale Open Courses and official Go/PostgreSQL documentation. FMHY is used only to discover legitimate learning destinations; see `docs/research/FMHY-RESOURCE-REVIEW.md`.

## 3. Recommended order

The courses interlock, but a practical learning path is:

1. MBSE and requirements establish system boundaries, stakeholder needs and architecture.
2. Data systems and databases establish durable state and query/transaction foundations.
3. Distributed systems adds partial failure, replication, retries, consistency and consensus.
4. Safety and risk analysis identifies hazardous system states and derives safety constraints.
5. Security engineering develops threat models, trusted boundaries and secure controls.
6. V&V plans evidence from the first requirement and executes a cross-course assurance campaign.

V&V is a continuous activity; it is not postponed until the sixth course.

## 4. Weekly study protocol

For each week:
1. Read the lecture notes and map the definitions, assumptions and equations.
2. Re-derive every quantitative result without looking at the worked example.
3. Recreate the diagram or model and identify its system boundary.
4. Complete the practical assignment in a clean environment.
5. Record expected results, observed results, raw evidence and tool versions.
6. Attempt the problem set before reading the worked solution.
7. State at least one limitation, failure mode or assumption that could invalidate the conclusion.

A topic is mastered when you can explain it, apply it to an unfamiliar case, derive its key result, and state what it does not prove.

## 5. Assessment structure

The standard reader assessment distribution is:

| Component | Weight |
|---|---:|
| Weekly problem sets and derivations | 20% |
| Practical labs and reproducibility | 25% |
| Midterm assessment | 15% |
| Individual cumulative project | 25% |
| Final examination and oral defense | 15% |

The 84-question week-by-week problem bank is `assessments/WEEKLY-PROBLEM-BANK.md`; the longer exam-style problems and solutions are in `assessments/PROBLEM-SETS-AND-SOLUTIONS-V2.md` (30 worked problems, five per course). The integrated project is `projects/INTEGRATED-CAPSTONE-V2.md`. Edition 3 adds six implementation annexes and additional tested code in each course lab. Worked solutions are study aids, not submissions to copy.

## 6. Toolchain and versions

- Go 1.23+ for the clock/concurrency labs. Some newer Go testing APIs may require a newer Go version; check the lab before using them.
- Python 3.11+ and pytest for quantitative reliability, finite-state model-checking and authorization exercises.
- PostgreSQL 18 for SQL, MVCC, indexing, WAL and recovery exercises.
- Docker or Podman for disposable local database containers.
- An OMG SysML v2-capable workbench such as Eclipse SysON for the MBSE model lab.
- Git and Markdown for version control and technical reports.

The Edition 3 execution environment did not provide `psql`, Docker, SysON or TLC JAR/network access to download and run the official checker. PostgreSQL execution, SysML import/render, and TLC are therefore not claimed as completed here. The verification matrix distinguishes locally executed tests from external exercises that require learner execution.

## 7. Evidence and academic standard

Each lab report must include objective, theory, assumptions, tool/environment versions, procedure, expected results, actual results, raw evidence, analysis, limitations and references. A screenshot alone does not prove model correctness, test coverage, a database transaction property or successful restoration.

Use these labels explicitly:
- **Fact:** supported by a source, measurement or test.
- **Assumption:** adopted to enable analysis.
- **Estimate:** calculated/judged quantity with uncertainty.
- **Decision:** selected design and rationale.
- **Evidence:** artifact supporting a claim.
- **Limitation:** what the model/test/analysis does not establish.

Never call a system safe, secure, reliable or fully tested without a defined claim, acceptance criterion and supporting evidence.

## 8. Integrated capstone

Use `projects/INTEGRATED-CAPSTONE-V2.md` as the master capstone brief. It defines a simulated water-tank control system, 18 requirements, architecture and interface deliverables, six discipline work packages, 20 acceptance tests, milestones and a scored rubric. `07-INTEGRATED-CAPSTONE.md` remains the original first-edition starter.

**Safety constraint:** simulation/bench-top only. Do not connect student software to real industrial equipment or public infrastructure.

## 9. What “100/100” means here

`audit/COURSE-QUALITY-CONTRACT.md` defines the scorecard and non-negotiable evidence gates. Edition 3 self-audit is recorded in `audit/ACADEMIC-AUDIT-V3.md`; current rubric result is 91.00/100. This is an editorial self-study benchmark, not university accreditation. External tool execution, independent peer review, instructor feedback and the applicable engineering approval authorities remain outside this package.

## 10. Weekly source maps

Use `weekly-reading-maps/README.md` and its six 14-week maps to connect every study week to official university lectures, standards, research papers and maintained documentation. They complement the course readers; they do not replace the original source material.

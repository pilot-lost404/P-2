# Course 1 — Distributed Systems
**Level:** Upper-undergraduate / early graduate  
**Duration:** 14 teaching weeks  
**Expected workload:** 8–10 hours per week  
**Primary language for laboratories:** Go (examples are language-independent unless stated)  
**Prerequisites:** Data structures, operating systems fundamentals, computer networks (TCP/IP, HTTP), concurrency, basic probability, Git and command-line use.

## Course description

A distributed system consists of multiple autonomous processes that communicate through a network and coordinate to provide a service. The defining difficulty is not simply that the system has many machines. It is that components execute independently, communicate with delay, observe events in different orders, and can fail independently. The network may lose, delay, duplicate or reorder messages. A process may pause, restart, or become unreachable while other components continue. Consequently, a correct local algorithm does not automatically produce a correct distributed service.

This course develops the models and engineering techniques used to reason about such systems. It connects communication, concurrency, time, replication, consistency, consensus, transactions, partitioning, reliability and operational design. The course emphasizes the distinction between a guarantee that can be proved under a stated model and a behavior that merely appeared to work in a small test.

The recurring case is a remote water-tank monitoring and control platform. A local controller must continue safe local operation when the network or cloud service is unavailable. A remote service receives telemetry, persists observations, and accepts authorized commands. The case is deliberately used to expose end-to-end failure modes rather than as a deployable industrial design.

## Learning outcomes

By the end of the course, a student should be able to:

1. Define process, communication, timing and failure assumptions for a distributed design.
2. Explain why timeouts cannot prove that a remote operation did not execute.
3. Use happens-before relations and logical clocks to reason about event ordering.
4. Compare primary-backup replication, quorum replication and state-machine replication.
5. Distinguish linearizability, sequential consistency, causal consistency and eventual consistency.
6. Explain the assumptions and limits of consensus protocols such as Raft and Paxos.
7. Design safe retries using idempotency keys, deduplication and durable operation records.
8. Analyze distributed transactions, sagas, sharding and rebalancing.
9. Instrument, test and operate a distributed service under partial failure.
10. Defend a design by stating its guarantees, assumptions, failure behavior and evidence.

## Assessment model

Suggested weighting for self-study or a university course: weekly problem sets 15%; programming laboratories 35%; midterm design analysis 15%; final project 25%; oral/debugging review 10%. A student should not receive full credit for a working demonstration that has no stated failure model or correctness argument.

---

## Week 1 — What makes a system distributed?

### 1.1 Definition and design problem

A distributed system is a collection of processes that communicate by exchanging messages and coordinate to perform a task. The processes may execute on different computers, virtual machines, containers or devices. They do not share ordinary process memory, and they cannot assume a globally visible clock.

A useful model separates three dimensions:

- **Process model:** crash-stop, crash-recovery, omission, timing, or Byzantine behavior.
- **Communication model:** reliable or unreliable channels; bounded or unbounded message delay; point-to-point or group communication.
- **Timing model:** synchronous, asynchronous, or partially synchronous assumptions.

These are not academic labels. They determine which guarantees are possible. For example, an asynchronous system provides no known upper bound on message delay. A slow process and a failed process may therefore look identical to a remote observer.

### 1.2 Why distribution is useful

Distribution may improve scale, availability, geographic reach, fault isolation, resource utilization or organizational autonomy. Each benefit introduces costs: network latency, partial failure, coordination, operational complexity, data consistency problems and harder debugging. Moving a function from one process to another is not a neutral refactor; it changes the failure and timing model.

A useful system boundary identifies which components are inside the system, which dependencies are external, and what assumptions are made about each dependency. For the tank platform, the cloud service must not be the only component capable of stopping the pump: loss of Internet connectivity must not remove the local control loop.

### 1.3 Quantifying latency and load

Average latency is insufficient when a service has a long-tailed distribution. If 99 requests complete in 20 ms and one takes 2 seconds, the mean is 39.8 ms, but the 99th percentile is 20 ms and the 100th percentile is 2 seconds. Use percentiles, throughput and error rates together.

Little's Law states:

\[
L = \lambda W
\]

where \(L\) is the average number of items in a stable system, \(\lambda\) is the average arrival rate, and \(W\) is average time in the system. If a service receives 200 requests/s and average response time is 0.05 s, the average in-flight request count is about 10. This is a steady-state relationship, not a guarantee during overload or unstable queues.

### Worked example

A telemetry service receives 500 messages/s. Average processing time is 40 ms. Under stable load, Little's Law predicts \(L = 500 \times 0.04 = 20\) messages in the processing system. If the system is provisioned for only 10 concurrent workers, the queue grows unless each worker's effective processing capacity or the number of workers increases. Increasing concurrency may improve throughput until CPU, database or network contention becomes dominant.

### Laboratory

Create two processes that exchange a heartbeat message. Add an artificial delay and terminate one process. Observe that a timeout is an observation about elapsed time, not proof of process death. Record the assumptions used by your detector.

### Check your understanding

1. Why is a remote process's slowness indistinguishable from failure in a fully asynchronous model?
2. Name two benefits and three costs of distribution.
3. Under what assumptions is Little's Law useful?

**Worked answer:** A remote observer sees only messages and elapsed local time. If no message arrives, the process may have crashed, the message may be delayed, or the path may be partitioned. Distribution is beneficial for scale and fault isolation, but introduces network delay, partial failure and coordination. Little's Law applies to a stable system over an appropriate observation interval.

---

## Week 2 — Communication, RPC and failure semantics

### 2.1 Messages are not function calls

A local function call normally transfers control within one process. A remote procedure call (RPC) crosses a communication boundary. The caller must serialize arguments, send bytes, wait for a response, deserialize a result and handle connection and protocol errors. Either side may crash at any point.

A timeout means: **the caller stopped waiting**. It does not mean the server did not receive or execute the request. Consider a command to start a pump. The server can perform the command and crash before replying. The client retries, and the command may execute twice unless the application has an explicit deduplication rule.

### 2.2 Request/response states

Model a request as a state machine:

```text
CREATED -> SENT -> RECEIVED -> EXECUTING -> COMMITTED -> REPLIED
                      |            |             |
                      +------------+-------------+--> caller may time out
```

The caller can observe only a subset of these states. A timeout may occur after `COMMITTED` but before `REPLIED`. Thus, client-side timeout and server-side outcome are separate pieces of state.

### 2.3 Delivery and execution semantics

- **At-most-once attempt:** the client does not retry after uncertainty. An operation may be lost.
- **At-least-once attempt:** the client retries until it obtains a response or reaches a policy limit. The server may see duplicates.
- **Effectively-once business effect:** retries are allowed, but the application records a stable operation identifier and ensures the business effect is applied once within a defined scope.

"Exactly once delivery" is generally an unsafe promise across arbitrary failures. An engineer should specify what is exactly-once: message delivery, state transition, database commit, or external physical effect. These are different properties.

### 2.4 Timeouts, retries and backoff

Use a request deadline that propagates across service calls. A timeout hierarchy should be coherent: a downstream operation should not routinely outlive the caller's deadline. Retry only errors that are plausibly transient, and only when the operation is safe to retry. Exponential backoff with jitter reduces synchronized retry storms:

\[
d_n = \min(d_{\max}, d_0 2^n) \cdot U(0.5, 1.5)
\]

where \(d_0\) is the initial delay and \(U\) is a random multiplier. Enforce an overall deadline and retry budget. Retrying a permanently invalid request is not resilience; it is load amplification.

### Worked example: idempotent command

A client sends `command_id = 8f...` to set the pump state to ON. The server stores the command ID and result in the same durable transaction as the state change. A duplicate request with the same ID returns the original result. A different command ID is a distinct operation. The deduplication retention period must be at least as long as the maximum retry/replay horizon.

### Laboratory

Implement a Go HTTP endpoint that accepts `command_id` and a target state. Persist command IDs and results in PostgreSQL or, for the first exercise, in a mutex-protected in-memory map. Add an artificial crash after the state change but before the response. Demonstrate the duplicate-request case. Then explain why the in-memory map is not safe across restarts or multiple replicas.

### Practice

A client times out after sending an update. Give three possible server states and the correct client behavior for each. Explain why generating a new idempotency key on every retry defeats deduplication.

---

## Week 3 — Time, event ordering and logical clocks

### 3.1 Physical clocks are imperfect

A computer clock is an estimate of physical time. Clocks can drift, jump due to correction, or differ between machines. Network time synchronization reduces error but does not create a perfect global clock. Therefore, timestamps alone cannot reliably determine the causal order of distributed events.

### 3.2 Happens-before relation

Lamport's happens-before relation, written \(a \rightarrow b\), is defined by:

1. If events \(a\) and \(b\) occur in the same process and \(a\) occurs first, then \(a \rightarrow b\).
2. If \(a\) is sending a message and \(b\) is receiving that message, then \(a \rightarrow b\).
3. The relation is transitive.

If neither \(a \rightarrow b\) nor \(b \rightarrow a\), the events are concurrent in the causal model. Concurrent does not mean they happened at precisely the same physical instant. It means the model contains no causal path between them.

### 3.3 Lamport clocks

Each process maintains an integer clock. Before each local event, increment it. When sending a message, attach the clock. On receiving a message with timestamp \(t\), set the local clock to \(\max(local,t)+1\). If \(a \rightarrow b\), then \(L(a) < L(b)\). The converse does not necessarily hold: a smaller Lamport timestamp does not prove causality.

### 3.4 Vector clocks

Vector clocks retain a component per process. A process increments its own component for local events and merges received vectors by component-wise maximum before incrementing its own component. For vectors \(x\) and \(y\), \(x < y\) when every component of \(x\) is no greater than the corresponding component of \(y\), and at least one is smaller. If neither vector is less than the other, the events are concurrent.

Vector clocks provide richer causal information but require metadata proportional to the number of tracked processes or groups. Production designs may use bounded or hierarchical alternatives.

### Worked example

Two controllers create events with vector clocks. Process A creates \(x=(1,0)\). Process B creates \(y=(0,1)\). Neither vector dominates the other, so the events are concurrent. A later event at A after receiving B's event may be \(z=(2,1)\), for which \(x<z\) and \(y<z\); both are causally before \(z\).

### Laboratory

Build a three-process event simulator. Compare physical timestamps, Lamport clocks and vector clocks. Construct one execution where physical timestamps order concurrent events, and show why that ordering should not be interpreted as causality.

---

## Week 4 — Replication and state-machine replication

### 4.1 Why replicate?

Replication stores or computes multiple copies of state. It can improve availability, throughput, geographic proximity and recovery from faults. It also creates the problem of coordinating copies. The system must decide which writes are accepted, how updates propagate, how conflicts are resolved and what reads are allowed to observe.

### 4.2 Primary-backup replication

A primary receives writes and propagates ordered updates to backups. This is conceptually simple, but requires a protocol for primary failure and promotion. If two nodes both believe they are primary, split brain can produce conflicting histories. A fencing mechanism or quorum-backed lease can prevent an old primary from continuing to mutate shared resources after its authority expires.

### 4.3 State-machine replication

A deterministic state machine has an initial state \(s_0\), a sequence of commands \(c_1,\dots,c_n\), and a deterministic transition function \(\delta\). Replicas that start from the same state and apply the same commands in the same order reach the same state:

\[
s_{i+1} = \delta(s_i,c_i)
\]

The consensus protocol orders commands; the application state machine applies them. Nondeterminism must be controlled. For example, a replicated command should not independently read a local wall clock at each replica and branch on the result.

### 4.4 Quorums

For a replica set of \(N\) nodes, read and write quorums may be chosen so that they intersect. A common sufficient condition is \(R+W>N\), where \(R\) and \(W\) are read and write quorum sizes. Intersection alone is not the whole correctness proof: version selection, concurrent writes, failure handling and replica recovery also matter.

For \(N=5\), choosing \(R=3\) and \(W=3\) guarantees intersection because \(3+3>5\). It does not automatically guarantee linearizability; that depends on protocol details such as write ordering and read repair.

### Laboratory

Implement a primary plus two replicas for a counter. First use fire-and-forget replication, then wait for one backup, then wait for a majority. Kill nodes at different points. Record which acknowledged writes survive each failure. State the consistency guarantee actually achieved.

---

## Week 5 — Consistency models

### 5.1 Why one word is not enough

"Consistent" may refer to data integrity, replica agreement, or a formal visibility guarantee. A system can preserve database constraints while offering eventual consistency across replicas. Always name the property being promised.

### 5.2 Linearizability

An operation appears to take effect atomically at a point between its invocation and response, and respects real-time order between non-overlapping operations. If a write completes before a later read begins, the later read must observe that write or a later one. Linearizability is valuable for locks, unique ownership and externally visible control state, but it can require coordination and may reduce availability during partitions.

### 5.3 Sequential consistency

There is one total order of operations that respects each process's program order, but it need not respect real-time order across processes. It is weaker than linearizability.

### 5.4 Causal consistency

If one operation causally depends on another, every observer that sees the dependent operation must also see the cause first. Concurrent operations may be observed in different orders. This is useful for systems where causal relationships matter more than a single global order.

### 5.5 Eventual consistency

If no new updates occur and communication/reconciliation continues, replicas eventually converge. Eventual consistency alone does not specify read-your-writes, monotonic reads, conflict resolution or convergence time. A system must define these details.

### Worked comparison

An operator changes a tank threshold from 80% to 90%. A later read by the same operator should usually have read-your-writes behavior. A telemetry dashboard may tolerate a short delay before all regions show the new value. A safety interlock should not depend on an eventually consistent cloud replica. Choose consistency per operation and risk, not per product label.

### Exercise

For account transfer, collaborative document editing, telemetry dashboards and a local emergency stop, choose a consistency model and explain the trade-off. There is not one universally correct answer; the justification is the assessed part.

---

## Week 6 — Failure detection, impossibility and availability

### 6.1 Failure detectors are suspicions

A timeout-based detector can suspect a process, but suspicion is not certainty. A short timeout detects failures quickly but produces false suspicions during congestion. A long timeout reduces false suspicions but delays recovery. Adaptive detectors can estimate expected delay, but cannot eliminate uncertainty in an asynchronous system.

### 6.2 FLP result and practical systems

The Fischer-Lynch-Paterson result shows that in a fully asynchronous message-passing system, no deterministic consensus protocol can guarantee termination in every execution if even one process may crash. The result does not say consensus is impossible in practice. Real systems use additional assumptions such as eventual synchrony, randomized choices or failure detectors. The key is to state which assumption supports progress.

### 6.3 CAP theorem

In the presence of a network partition, a distributed data store cannot guarantee both linearizable consistency and availability for every request to every non-failing node. CAP is not a menu where a system permanently chooses two out of three in all conditions. Partition tolerance is a fact of networked operation; the design decision is how the system behaves when a partition occurs.

### 6.4 Availability budgets

Availability over an interval is \(A = \frac{uptime}{total\ time}\). The unavailability budget is \((1-A)\times T\). At 99.9% availability over a 30-day month, the downtime budget is approximately 43.2 minutes. This arithmetic does not describe the severity of an outage: a 30-second outage at the wrong moment may be unacceptable.

### Laboratory

Simulate a three-node service with controllable message delays and partitions. Change election timeouts and measure false leader suspicions. Distinguish detection latency from correctness.

---

## Week 7 — Consensus: Raft and the core invariants

### 7.1 Consensus problem

Consensus allows a group of nodes to agree on a value or ordered log under a specified failure model. A protocol should satisfy safety (no two correct participants decide conflicting values) and liveness (a decision eventually occurs under stated progress assumptions).

### 7.2 Raft conceptual model

Raft organizes time into terms. A leader is elected for a term; it accepts client commands and replicates log entries. Followers acknowledge entries. A leader commits an entry when the protocol's quorum and current-term rules are satisfied. A new leader must preserve committed history.

The main safety ideas are:
- at most one leader is elected in a term;
- leaders do not overwrite committed entries;
- a candidate's log must be sufficiently up-to-date to win an election;
- followers accept log entries according to term and index rules.

A correct Raft implementation is more than a leader-election demonstration. It must handle crashes, partitions, stale terms, log conflicts, snapshots, persistence ordering and client retries.

### 7.3 Majority arithmetic

For \(N\) voting members, a majority quorum is \(\lfloor N/2 \rfloor + 1\). With five members, three acknowledgements form a majority and tolerate up to two unavailable members for quorum decisions. This does not mean the service continues through every combination of failures: network placement and leader reachability matter.

### Worked example

A five-node cluster has nodes A–E. A leader A commits an entry after A, B and C persist it. A becomes partitioned from B–E. B, C, D and E can elect a new leader only if the new leader's log is eligible under the protocol. A must not independently continue committing entries without a quorum. The quorum intersection plus log-up-to-date rules protect committed history.

### Laboratory

Complete a Raft implementation lab from MIT 6.5840 or an equivalent teaching implementation. Start with deterministic tests and then inject loss, duplication, reordering, partitions and crashes. Do not claim correctness from passing only a happy-path test.

---

## Week 8 — Logs, snapshots, recovery and durable state

A replicated log is an ordered history of state-machine commands. The log must be persisted in a crash-safe order. If a node acknowledges an entry before the required durable write completes, a power loss can erase an acknowledged operation. The protocol's durability claim must match the storage semantics used.

Logs grow indefinitely unless the system takes snapshots or compacts old entries. A snapshot represents the state after a committed log index. A recovering replica loads the snapshot and then applies later entries. Snapshot creation must be coordinated with the log index and configuration so the system does not skip or replay state incorrectly.

Crash recovery separates volatile state, durable state and externally visible acknowledgements. A write-ahead logging discipline generally records the information needed for recovery before overwriting the corresponding data pages. The exact WAL protocol depends on the storage engine; the general rule is that acknowledged durability must have a well-defined persistence boundary.

**Worked example:** If a replica has committed through index 1000, it may snapshot state at 1000 and discard earlier entries only when the snapshot is durable and the replication protocol can safely install it on lagging followers. A follower at index 700 needs either the retained log range or a snapshot plus entries after 1000; it cannot infer the missing state.

**Lab:** Persist a key-value log to disk, restart after a forced process kill, replay committed operations and compare the reconstructed state to a clean execution. Include a crash between writing a record and updating an index. Document the recovery invariant.

---

## Week 9 — Distributed transactions and sagas

A transaction across independent services is difficult because each service owns its own state and may fail independently. Two-phase commit (2PC) separates prepare from commit. A coordinator asks participants to prepare; prepared participants promise they can commit or roll back. The coordinator then announces the decision. Classic 2PC can block if the coordinator fails at a critical time and participants cannot discover the durable decision.

A saga decomposes a long-running business transaction into local transactions with compensating actions. If step three fails after steps one and two committed, the system invokes compensations. A compensation is not necessarily a literal inverse: a refund is not the same as erasing the fact that a payment happened. Sagas trade atomicity for explicit workflow and recovery logic.

Use a transactional outbox when a service must update its database and publish an event. The service writes both the business change and an outbox record in one local transaction; a separate publisher sends the event and marks it delivered. Consumers should be idempotent because delivery may repeat.

**Worked example:** The command service records a requested valve setting and an outbox event. If the process crashes after the database commit but before publication, the outbox publisher recovers the event. If it publishes but crashes before marking it sent, it may publish again; the telemetry consumer deduplicates using event ID.

**Lab:** Build a two-service workflow: command acceptance and audit logging. Demonstrate the failure window without an outbox, then implement an outbox and duplicate-safe consumer.

---

## Week 10 — Sharding, partitioning and rebalancing

Partitioning divides a dataset into subsets. Horizontal sharding distributes rows, commonly by key range or hash. Range partitioning preserves key locality and supports range scans, but may create hotspots for monotonic keys. Hash partitioning distributes keys more evenly, but makes range queries expensive and complicates placement changes.

A partition key should distribute load while aligning with access patterns. A poor key can overload one shard. A shard is not simply a physical database: it also has ownership, routing, replication, failover and rebalancing rules.

Rebalancing transfers data when the number or capacity of nodes changes. Naive rehashing may move most keys. Consistent hashing reduces movement in many designs, but does not eliminate operational coordination, hotspot risk or replica placement concerns.

**Worked example:** A telemetry store receives 10,000 events/s. Sharding by `sensor_id` gives even load only if sensor activity is reasonably uniform. Sharding by event date creates a hot current partition. A composite partitioning scheme may use time buckets plus a hash of sensor ID.

**Lab:** Implement a consistent-hash ring or a deterministic hash partitioner. Measure key movement when adding a node. Then generate skewed sensor traffic and report the hottest partition.

---

## Week 11 — Distributed storage and data-processing architectures

Distributed file systems, object stores, key-value stores and stream processors solve different problems. A file system exposes files and directories; an object store exposes object keys and metadata; a key-value store optimizes keyed reads/writes; a log-based stream platform retains ordered events for consumers; batch frameworks process bounded datasets.

MapReduce introduced a programming model with map and reduce stages, partitioning and shuffle. Stream processors handle unbounded event sequences, where event time and processing time differ. Late-arriving events, duplicate events, watermarks, windowing and replay are first-class concerns.

A design must specify delivery guarantees, ordering scope, retention, backpressure, schema evolution and consumer recovery. "Exactly-once processing" must identify the boundary and mechanism. It often depends on transactional checkpoints or coordinated commits, not on the absence of duplicate messages.

**Lab:** Build an event consumer that aggregates telemetry by five-minute event-time windows. Inject delayed and duplicated events. Compare processing-time windows with event-time windows and describe how late data is handled.

---

## Week 12 — Concurrency control and coordination services

Distributed locks are not ordinary mutexes. A process may pause beyond a lease deadline, lose connectivity and later resume while another process has acquired the lock. A lease alone may not stop the stale process from modifying an external resource. Fencing tokens solve this by issuing monotonically increasing epochs; the resource rejects operations with an older token.

Coordination services provide membership, leader election, configuration and small pieces of shared metadata. They should not be used as high-throughput general-purpose databases. Chubby and ZooKeeper illustrate the separation between a coordination plane and application data plane.

**Worked example:** Process A obtains fencing token 41 and pauses. Its lease expires. Process B obtains token 42 and writes configuration. A resumes and submits a write with token 41. The storage service rejects it because 41 is lower than the last accepted token 42.

**Lab:** Implement a lease simulation with stale clients and a storage API that enforces fencing tokens. Demonstrate the failure of an unfenced lock.

---

## Week 13 — Reliability engineering and operations

Distributed-system correctness includes production behavior. Measure latency percentiles, throughput, saturation, error rates, queue depth, replication lag, leader changes and recovery time. Logs provide event detail; metrics reveal aggregate trends; traces connect work across service boundaries. Use correlation and trace IDs, but avoid logging secrets or personal data.

A service-level indicator (SLI) is a measured property such as successful request fraction or latency. A service-level objective (SLO) is a target over a defined window. An error budget is the allowed amount of SLI failure implied by the SLO. SLOs should reflect user impact, not just the easiest metric to collect.

Failure injection should test realistic fault classes: process crash, network delay, packet loss, disk full, slow database, expired credentials, clock jump and dependency overload. Chaos experiments are controlled hypotheses with safety limits, not random destruction of production systems.

**Lab:** Instrument a service with request counts, latency histogram and dependency errors. Create an SLO for a read API and calculate its error budget. Inject a slow database and show how the symptoms propagate.

---

## Week 14 — Design review and integrated capstone

A distributed-system design review should answer:
- What are the nodes, processes, links and external dependencies?
- What failures are assumed and which are out of scope?
- What consistency guarantee does each operation require?
- How are retries made safe?
- What state is durable, and at what point is success acknowledged?
- How are leaders elected and stale leaders fenced?
- What happens during a partition, overload and recovery?
- Which metrics and tests demonstrate the claimed behavior?

### Final assessment

Submit a running service or deterministic simulator, architecture diagram, failure model, API contract, consistency table, idempotency design, test report, performance report and a design decision record. At least five fault-injection scenarios must be reproducible.

### End-of-course problem set

1. A request takes effect but its response is lost. What does the client know?  
   **Solution:** Only that it did not receive a response before its deadline. The operation may not have arrived, may be executing, may have committed, or may have committed and lost its response. Use a stable operation ID and a query/retry protocol that returns the recorded result.

2. A cluster has seven voters. How many votes form a majority, and how many voters may be unavailable while retaining a majority?  
   **Solution:** A majority is four. Three may be unavailable, assuming the remaining four can communicate and the protocol's placement/failure assumptions hold.

3. Explain why a Lamport timestamp order is not proof of causality.  
   **Solution:** Lamport clocks preserve the implication from causality to increasing timestamp, but independent concurrent events can receive different scalar timestamps. The scalar order imposes an arbitrary total order on events that have no causal relation.

4. A service claims linearizable reads while allowing reads from any stale replica during a partition. What is wrong?  
   **Solution:** A stale replica may return a value older than a completed write, violating real-time order. The design must coordinate reads, use a valid lease/quorum/read-index mechanism, or weaken the guarantee.

## Selected sources and further study

- MIT 6.5840 Distributed Systems (Spring 2026): https://pdos.csail.mit.edu/6.5840/ — lectures, papers, programming labs and exams.
- Harvard CS 2620 Distributed Systems (2026): https://read.seas.harvard.edu/cs2620/2026/ — consensus, Paxos, PBFT, problem sets and papers.
- CMU 15-440/640 Distributed Systems: https://www.cs.cmu.edu/~dga/15-440/F12/ — systems programming and networked services.
- Martin Kleppmann & Chris Riccomini, *Designing Data-Intensive Applications*, 2nd ed. (2026): https://martin.kleppmann.com/2026/03/24/designing-data-intensive-applications-2e.html
- Raft paper and extended version: https://raft.github.io/raft.pdf
- Go memory model: https://go.dev/ref/mem
- Go concurrency and context documentation: https://pkg.go.dev/context
- PostgreSQL concurrency control: https://www.postgresql.org/docs/current/mvcc.html

Use research papers to understand the algorithm and its limits. Use the official lab/course repositories to reproduce implementations. Do not cite a course's existence as evidence that your own implementation is correct.

# Curriculum Architecture and Build Specification

## Intent

Create six independently readable, upper-undergraduate / early graduate course readers that teach actual content. External resources deepen the study but do not replace the material.

## Scope

Each course spans 14 teaching weeks and includes:
- course description and learning outcomes;
- progressive chapter content;
- technical definitions and models;
- worked examples and diagrams;
- practical laboratories;
- exercises and selected worked solutions;
- curated primary-source references.

A shared capstone integrates all six disciplines through one cyber-physical case.

## Teaching design choices

1. **Course length:** 14 teaching weeks per subject, following common semester cadence. This is a study design, not a university credit equivalency claim.
2. **Audience:** advanced undergraduate / early graduate, with prerequisites stated per subject.
3. **Case study:** remote water-tank monitoring and control simulation to connect physical process, software, network, safety, security, model and database concerns.
4. **Modeling language:** teach SysML v2 concepts as the forward-looking baseline while acknowledging SysML v1 remains in practical use.
5. **Programming:** Go for concurrency/distributed examples; PostgreSQL for database work; tool-neutral reasoning elsewhere.
6. **Primary-source preference:** universities, standards bodies, official project documentation, original research and established books.
7. **Copyright:** summarize concepts in original wording; do not reproduce copyrighted textbooks, lecture transcripts or pirated files.

## Quality gates

- No source is treated as authoritative merely because it appears in a directory.
- Version-sensitive claims are checked against the publisher or issuer page.
- Standards access and licensing are identified; free-to-read does not imply redistributable.
- Code examples are labeled as teaching examples and should be verified in a local environment.
- Diagrams are explanatory; their assumptions and system boundaries must be stated.
- A test result is not described as proof beyond its defined scope.
- The capstone is simulated and not intended for real industrial deployment.

## Known limits of this edition

This is a substantial course-reader draft, not a verbatim substitute for several full commercial textbooks or faculty-led laboratories. The weekly chapters provide a direct learning path and selected worked material. Several labs require the learner to build the implementation and produce results; this pack does not claim that unexecuted labs have already been run. Advanced mathematical proofs, domain-specific certification standards and full production implementation details are intentionally assigned to the cited primary references and later specialist study.


## Edition 2 implementation status (21 November 2026)

Edition 2 adds six expanded 14-week readers, six weekly source maps, 30 worked problems (five per course), an integrated capstone with 20 acceptance tests, and a set of practical laboratories. Local automated evidence currently covers Go logical-clock/idempotency packages and Python reliability, finite-state model-checking, authorization-policy and in-memory B+ tree exercises.

The following remain external validation gates rather than completed claims: import/render and semantically validate the SysML v2 starter in SysON; execute PostgreSQL 18 DDL, transaction/isolation, query-plan and backup/restore experiments; build and test a complete Raft-backed distributed service; extend the B+ tree into a disk-backed DBMS engine; conduct a full ASVS-mapped security test campaign; and obtain independent subject-matter review of the six courses and worked solutions. The current author score is 86.83/100, not 100/100. See `audit/ACADEMIC-AUDIT-V2.md` and `audit/VERIFICATION-MATRIX.md`.


## Edition 3 implementation status (21 November 2026)

Edition 3 adds six expanded practical evidence workstreams: a deterministic Go Raft simulator; a SysML v2 model package and requirements/traceability validator; quantitative common-cause and uncertainty analysis; Python/TLA+ bounded quorum models; a loopback-only security training API; and disk-backed page, buffer-pool, WAL/recovery and B+ tree exercises. The 94-test Python aggregate, Go race suite and static checks are listed in `audit/VERIFICATION-MATRIX-V3.md`.

External gates remain open: SysML v2 import/render/semantic validation in SysON, official TLC execution, PostgreSQL 18 SQL/isolation/restore execution, full DBMS query/MVCC/recovery implementation extensions, external security scanner and ASVS review, independent subject-expert moderation and learner pilot. The Edition 3 author self-audit is 91.00/100. See `audit/ACADEMIC-AUDIT-V3.md`; do not treat this score as accreditation or proof of production/system safety.

# Problem Sets and Worked Solutions — Edition 2 baseline retained in Edition 3 — Six-Course Advanced Engineering Curriculum

**Edition:** 2.0 · 21 November 2026  
**Level:** Advanced undergraduate / introductory graduate  
**Use:** Attempt each problem closed-book first. Show assumptions, intermediate steps, units and a reasoned conclusion. A numerical answer without a model is incomplete.

For one exercise and worked checkpoint in every one of the 84 course-weeks, also use [`WEEKLY-PROBLEM-BANK.md`](WEEKLY-PROBLEM-BANK.md).

## Assessment policy

Each course has five problem sets. Each problem is worth 20 marks. Suggested marking: model/assumptions 4, method/derivation 8, result 4, interpretation/limitations 4. The worked solutions are reference solutions, not the only acceptable approaches. Credit valid alternative assumptions when explicitly stated. Do not copy solutions into a graded submission; use them to check reasoning after attempting the problem.

---

# Course 1 — Distributed Systems

## Problem 1. Vector-clock reasoning (20 marks)
Three events have vector timestamps, with process order P, Q, R:

- a = (2, 1, 0)
- b = (1, 2, 0)
- c = (2, 2, 0)

Classify each ordered pair as before, after, equal or concurrent. Explain why Lamport timestamps cannot in general make the same distinction.

### Worked solution
Vector x is before y iff every component of x is no greater than the corresponding component of y and at least one component is strictly smaller. `a` and `b` are incomparable: a has greater P count (2>1), but smaller Q count (1<2), so they are concurrent. Both are before c: a≤c component-wise and differs in Q; b≤c and differs in P. Reverse relations are `After`. No pair is equal. Lamport scalar clocks preserve the implication `a → b` implies `L(a)<L(b)`, but not the converse; unrelated events can have scalar timestamps ordered by process tie-breaks or counter values. Vector incomparability explicitly represents concurrency under the modeled process set.

## Problem 2. Retry safety across crash windows (20 marks)
A command service writes a payment, then stores the idempotency result. A client times out and retries. Identify two crash windows that can cause duplicate effects or lost acknowledgements. Propose a correct persistence boundary and state its limits.

### Worked solution
If the process crashes after the payment effect but before writing the deduplication record, the retry cannot tell the effect occurred and may execute it again. If it records the idempotency key before the effect and crashes before the effect, a retry may return a result for an operation never performed. Store the idempotency key, request hash, terminal result and business effect in the same atomic database transaction or in one durable state-machine transition. A duplicate key with the same request hash returns the recorded result; reuse with a different request hash is rejected. For external side effects, use an outbox/inbox or downstream idempotency protocol; one local transaction does not make an external payment network exactly-once. Define retention horizon, key scope, transaction isolation, recovery and reconciliation behavior.

## Problem 3. Quorum intersection (20 marks)
A replicated register has N=5 replicas. The system uses write quorum W and read quorum R. Show the intersection condition for every read quorum to intersect every successful write quorum. Evaluate (W,R)=(3,3) and (2,3). Explain why intersection alone does not define a correct linearizable register.

### Worked solution
Two subsets of sizes W and R in an N-element set are guaranteed to intersect when W+R>N. For 3+3=6>5, at least one replica is shared. For 2+3=5, they may be disjoint, so no guaranteed intersection. Even when they intersect, the protocol must ensure the shared replica exposes a sufficiently fresh version, track version/epoch metadata, define concurrent-write behavior and handle replica failures. Quorum arithmetic is a necessary structural fact, not a complete consistency proof.

## Problem 4. Raft leader election and log safety (20 marks)
Explain why a candidate cannot simply win by collecting a majority if its log is stale. State the role of the last-log-term/last-log-index restriction and the leader-completeness property.

### Worked solution
A majority vote is useful only if election safety prevents a candidate from replacing committed history. Raft voters grant a vote only when the candidate's log is at least as up-to-date as the voter's log, ordered first by last log term and then by index. Because committed entries exist on a majority, any later leader's winning majority must overlap that majority. The up-to-date restriction ensures the overlapping voter does not vote for a candidate missing the committed suffix. Leader completeness states that a committed entry appears in the logs of all subsequent leaders. A complete proof also depends on term rules, one vote per term, AppendEntries consistency checks and commit-index rules; describing “majority” alone is insufficient.

## Problem 5. Capacity and tail latency (20 marks)
A stable service completes 1,200 requests/s with mean response time 80 ms. Estimate average in-flight requests. During a burst, arrivals rise to 1,500/s while sustainable service capacity remains 1,200/s for 30 seconds. Explain why the steady-state calculation cannot describe the overload period and propose three controls.

### Worked solution
Little's Law gives L=λW=1,200×0.080=96 requests in flight in the stable regime. During overload the arrival rate exceeds the service rate by 300 requests/s; if the excess is admitted without bound, the queue grows by approximately 300×30=9,000 requests over 30 seconds (ignoring service-rate variation and early queue effects). The system is no longer in the same stable steady state, so applying the original L to the burst is invalid. Controls include bounded queues with explicit rejection, admission control/rate limiting, load shedding, autoscaling where useful, backpressure, and deadline propagation. Measure p95/p99, queue depth and saturation to avoid hiding overload behind averages.

---

# Course 2 — Model-Based Systems Engineering

## Problem 1. Rewrite vague requirements (20 marks)
Rewrite each sentence as a verifiable requirement and identify any missing stakeholder decision:

1. “The dashboard should be fast.”
2. “The system must be reliable.”
3. “The valve should close when the tank is full.”
4. “Only authorized users can control the tank.”

### Worked solution
Example rewrites (the numerical thresholds are assumptions that require stakeholder approval):

1. “For a 30-day representative workload at 200 concurrent users, the dashboard shall render the tank summary within 2.0 s at p95, measured from server receipt to browser-ready display.” Clarify workload, network profile and measurement boundary.
2. “During a 30-day operational interval, the cloud monitoring API shall achieve at least 99.9% monthly availability, excluding scheduled maintenance announced 48 hours in advance.” Clarify service boundary, monitoring source and allowed exclusions. Availability is not the same as reliability of every component.
3. “When a valid local level measurement is at or above the approved high-high threshold, the local controller shall command the inlet valve closed within 250 ms and shall enter the latched protective state until an authorized reset.” Clarify threshold, sensor independence, physical closure time and reset authority.
4. “For every remote actuator command, the API shall authenticate the caller and verify an active role assignment for the target facility and action before persisting or forwarding the command; cross-facility requests shall be denied and audited.” Clarify roles, delegated authority and break-glass behavior.

## Problem 2. Traceability and orphan analysis (20 marks)
A system has 12 approved requirements, 10 modeled requirement elements, 9 verification cases, and 8 requirements that have both a model link and a verification link. Calculate model coverage, verification coverage and end-to-end trace coverage. State what the ratios do not tell you.

### Worked solution
Model coverage = 10/12 = 83.3%. Verification coverage = 9/12 = 75%. End-to-end trace coverage = 8/12 = 66.7%. Two requirements lack model elements; three lack verification cases; four lack complete end-to-end trace (some of these may overlap). Counts alone do not establish correctness: a link can be wrong, a test may have no measurable acceptance criterion, a requirement can be duplicated or poorly scoped, and a model can contain semantically invalid elements. Inspect link direction, evidence quality, status, version and rationale.

## Problem 3. Parametric fill-time model (20 marks)
A tank has capacity 10,000 L, current level 40%, target level 75%, and a nominal constant inflow of 20 L/min. Estimate fill time. If flow measurement uncertainty is ±10%, calculate the minimum and maximum time under this simplified model.

### Worked solution
Required volume = 10,000×(0.75−0.40)=3,500 L. Nominal time = 3,500/20=175 min. Maximum flow 22 L/min gives minimum time 3,500/22=159.1 min. Minimum flow 18 L/min gives maximum time 3,500/18=194.4 min. This assumes constant flow, no leakage/evaporation, no control interruptions, and level sensor accuracy is adequate. Real valve flow can depend on pressure/head; the model should record whether flow is fixed or a function of state.

## Problem 4. Weighted trade study (20 marks)
Three architectures receive normalized scores from 1 (poor) to 5 (strong): A=(4,3,5), B=(3,5,3), C=(5,2,4) for reliability, cost and maintainability. Weights are 0.5, 0.3, 0.2. Compute scores and determine what sensitivity check should be done before selecting an architecture.

### Worked solution
A=4×0.5+3×0.3+5×0.2=3.9. B=3×0.5+5×0.3+3×0.2=3.6. C=5×0.5+2×0.3+4×0.2=3.9. A and C tie; the scores do not justify a unique winner. Vary the weights within stakeholder-approved ranges, test plausible score uncertainty, check threshold constraints (e.g., minimum reliability), and report Pareto-dominated alternatives. A weighted sum can hide a hard constraint or sensitivity to subjective values.

## Problem 5. Change-impact reasoning (20 marks)
The sensor sample period changes from 1 s to 5 s. List at least five artifacts to review and explain why “change one attribute in the model” is not a sufficient impact assessment.

### Worked solution
Review stale-data threshold, hazard analysis and loss scenarios, high-high response-time budget, control-state logic, communications bandwidth, latency/performance requirements, verification sampling and timeout tests, operator display freshness, safety case claims, sensor interface specification and operational procedures. A sample-period change alters timing assumptions and possibly risk exposure. The model must trace the affected element to requirements, analyses, implementation, tests, user procedures and evidence; semantic consistency and stakeholder acceptance need review. Tool-supported change impact is only as complete as the model links.

---

# Course 3 — Safety and Risk Analysis

## Problem 1. Series and parallel reliability (20 marks)
Two components have reliabilities R1=0.98 and R2=0.95 over the same mission. Calculate series-system reliability and active-parallel reliability under independence. Explain the assumption that most threatens the parallel estimate.

### Worked solution
Series: Rseries=0.98×0.95=0.931. Parallel: Rparallel=1−(1−0.98)(1−0.95)=1−(0.02×0.05)=0.999. The result assumes independent component failures and a valid switchover/parallel architecture. Common power, cooling, software, environment, maintenance errors or a shared sensor can defeat both channels simultaneously. Common-cause failures must be modeled rather than treated as negligible by assertion.

## Problem 2. Fault tree with overlapping cut sets (20 marks)
The top event is `A AND (B OR C)`. Basic-event probabilities are P(A)=0.01, P(B)=0.10, P(C)=0.20 and events are independent. Calculate the exact top-event probability. Why is simply adding P(AB)+P(AC) incorrect?

### Worked solution
P(B OR C)=1−(1−0.10)(1−0.20)=1−0.72=0.28. P(top)=P(A)×0.28=0.0028. Adding P(AB)+P(AC)=0.001+0.002=0.003 double-counts the intersection A∩B∩C, whose probability is 0.01×0.10×0.20=0.0002. Inclusion-exclusion gives 0.003−0.0002=0.0028. This is exact for independent basic events.

## Problem 3. Weibull survival and hazard trend (20 marks)
For a two-parameter Weibull model, η=1,000 hours and β=2. Calculate reliability at t=500 hours and interpret β. What additional data would be needed before treating the estimate as operational evidence?

### Worked solution
R(t)=exp[−(t/η)^β]=exp[−(0.5)^2]=exp(−0.25)≈0.7788. β=2 indicates an increasing hazard rate over time under the Weibull model, often used to represent wear-out behavior. This is not established by selecting β. Estimate parameters from representative, correctly censored life data; examine confidence intervals, test conditions, population heterogeneity and competing failure modes. Mission profile, maintenance and repair behavior also matter.

## Problem 4. Bayesian update (20 marks)
A failure probability has prior Beta(1,9). In a set of 100 independent, representative trials, two failures are observed. Find the posterior distribution and posterior mean. State two reasons this posterior may not be appropriate for a deployed system.

### Worked solution
For Bernoulli data, Beta(α,β) updates to Beta(α+failures, β+successes). The posterior is Beta(1+2, 9+98)=Beta(3,107). Mean = 3/(3+107)=0.02727, or about 2.73%. It may not represent deployment if test trials differ from the operational environment, if observations are correlated, if failures are censored/misclassified, or if the prior population is not exchangeable with the target population. Uncertainty intervals should accompany a point estimate.

## Problem 5. FMEA versus STPA (20 marks)
A level sensor transmits a plausible but stale low reading while the valve remains open. Describe what an FMEA might record, then derive an STPA-style unsafe control action and one causal scenario. Convert the analysis into a verifiable constraint.

### Worked solution
FMEA may record sensor failure mode “stale output,” local effect “controller uses outdated level,” system effect “continued filling,” detection “timestamp age/sequence check,” and mitigation “reject stale data/independent high-high cutout.” STPA focuses on the control action and context: the controller provides/continues `OPEN VALVE` when the true level is high or sensor feedback is stale. A scenario is a communication delay that preserves the old value while the controller incorrectly assumes freshness. A constraint could be: “The local controller shall not issue or maintain an OPEN command when the measurement age exceeds the approved freshness threshold; it shall enter the defined safe state and annunciate sensor-data invalidity within the response-time budget.” Verification needs timed fault-injection and evidence that the valve state response occurs.

---

# Course 4 — Verification and Validation

## Problem 1. Boundary-value test design (20 marks)
A controller accepts a target percentage in the closed interval [0,100]. Propose a compact boundary test set, explain expected behavior, and add tests for non-numeric and missing inputs.

### Worked solution
Use −1, 0, 1, 99, 100, 101 as a compact boundary set.
Expect rejection for −1 and 101, acceptance for 0, 1, 99 and 100, subject to other state constraints. Add `null`, empty string, malformed numeric text, NaN/infinity if the language accepts them, a large numeric value, and a missing field. The API should reject malformed values deterministically with a documented error and must not coerce an invalid value into a safe-looking default. Test server-side validation and client error presentation.

## Problem 2. MC/DC for a Boolean decision (20 marks)
A decision is `D = A AND (B OR C)`. Produce a set of tests that demonstrates modified condition/decision coverage (MC/DC): each condition independently affects the decision while other conditions are held so their effect is isolated.

### Worked solution
One suitable set is:

| Test | A | B | C | D |
|---|---:|---:|---:|---:|
| T1 | 1 | 1 | 0 | 1 |
| T2 | 0 | 1 | 0 | 0 |
| T3 | 1 | 0 | 0 | 0 |
| T4 | 1 | 0 | 1 | 1 |

A independently affects D between T1 and T2 (B OR C stays true). B independently affects D between T1 and T3 (A=1,C=0). C independently affects D between T3 and T4 (A=1,B=0). This demonstrates each condition can independently change the decision. Follow the precise MC/DC variant required by the target assurance standard.

## Problem 3. Hoare triple (20 marks)
For program `x := x + 1`, give a Hoare triple proving that an initial integer x≥0 yields x≥1 afterward. State an assumption about arithmetic semantics and describe how overflow changes the claim.

### Worked solution
Under mathematical integer arithmetic, `{x≥0} x:=x+1 {x≥1}` is valid. The assignment axiom substitutes the expression in the postcondition: require `x+1≥1` before assignment, which simplifies to `x≥0`. Under fixed-width machine arithmetic, overflow may wrap or trap. If x can equal the maximum representable value, a wraparound implementation may produce a negative result. Strengthen the precondition to `0≤x<MAX`, or define and verify a checked-arithmetic error path.

## Problem 4. Zero failures and statistical confidence (20 marks)
A reliability test runs n=300 independent Bernoulli trials and observes zero failures. Using the rule of three, approximate the one-sided 95% upper bound on failure probability. Interpret it correctly.

### Worked solution
The rule of three gives p≈3/n=3/300=0.01 (1%). Zero observed failures does not imply zero failure probability. The approximation assumes independent, identically distributed, representative trials. It does not address correlated failures, changing environments, censored observations or a different operational profile. Report the conditions and confidence method, not merely “300 tests passed.”

## Problem 5. Test versus model-checking evidence (20 marks)
A finite state model explores 18 reachable states and finds no violation of invariant I. Give four conditions that must be discussed before making a claim about the physical controller and one liveness property not proved by this invariant check.

### Worked solution
Discuss whether state abstraction preserves relevant physical distinctions; whether every transition and environmental input is represented; whether initial states and operating modes are complete; whether timing, numerical precision, sensor faults and concurrency are modeled; and whether the invariant itself captures the safety claim. The result proves only the encoded finite model under its assumptions. A liveness property might be: “If a valid stop command is issued and the actuator remains operational, the controller eventually enters STOPPED.” An invariant-only check does not prove eventual progress; fairness and temporal reasoning are required.

---

# Course 5 — Security Engineering

## Problem 1. STRIDE threat analysis (20 marks)
For a remote tank-control API, identify one threat in each STRIDE category, name a control, and propose a negative test.

### Worked solution
Spoofing: stolen session impersonates operator; require MFA/session protections and test revoked/expired token use. Tampering: attacker changes target percentage in transit; require authenticated transport and server-side integrity validation; test altered request. Repudiation: operator denies command; require tamper-evident audit records and test actor/command linkage. Information disclosure: cross-facility telemetry leak; enforce object-level authorization and test guessed resource IDs across tenants. Denial of service: floods command endpoint; apply quotas/rate limits/backpressure and test load in an authorized lab. Elevation of privilege: operator invokes admin route; use deny-by-default server policy and test escalation. STRIDE prompts threat discovery; it is not a complete risk rating.

## Problem 2. Facility-scoped authorization (20 marks)
An administrator has ADMIN role in facility F1 and requests a tank in F2. A naive API loads the tank by ID and checks only whether the user has ADMIN. Explain the defect and design a correct server-side decision.

### Worked solution
The defect is missing object-level/tenant authorization. ADMIN is scoped to F1, not global. Resolve the resource to its authoritative facility ID, derive the principal from the authenticated session, load the active role assignment for that facility, and check both the requested action and resource scope before returning or changing data. Deny by default and test cross-facility GET, UPDATE, DELETE and command operations. Do not trust a client-supplied `facility_id` or role claim without server-side policy validation.

## Problem 3. Password storage and token lifecycle (20 marks)
Explain why a fast general-purpose hash is unsuitable for password storage. List five controls for password verifier storage and five lifecycle controls for a bearer token.

### Worked solution
A fast hash makes offline guessing cheaper. Use a dedicated password-hashing function with per-password salt and configurable work/memory cost, such as Argon2id, scrypt or bcrypt selected against current guidance and deployment constraints. Store algorithm/parameters with the verifier, rehash after successful login when policy changes, rate-limit online attempts, use secure reset flows and protect the verifier database. Token controls include short expiry, secure transport, audience/issuer validation, signing-key rotation, revocation/session-version checks, secure storage, CSRF defense where cookie-based, and least-privilege scopes. No single control replaces lifecycle design.

## Problem 4. Key management design (20 marks)
A service signs commands for remote gateways. Describe key generation, storage, distribution, rotation, revocation, compromise response and audit. Distinguish encryption from command-origin authentication.

### Worked solution
Generate keys using a cryptographically secure source in an approved environment; avoid hardcoded or fleet-wide shared private keys. Store private signing keys in an appropriate managed key service/HSM or tightly controlled secret store with least privilege and audit. Gateways receive pinned public verification keys through authenticated provisioning. Define key IDs, validity, rotation overlap; reject revoked/out-of-policy keys and prevent downgrade. On compromise, revoke, distribute trust updates, rotate affected credentials, investigate signed commands and recover devices safely. Signatures authenticate possession of a private key and integrity of signed data; they do not encrypt payloads or prove the command is authorized for a target.

## Problem 5. Security verification traceability (20 marks)
For a high-risk cross-facility command threat, construct one complete chain from threat to requirement to design control to verification to residual risk.

### Worked solution
Threat: a user from F1 guesses a tank identifier in F2 and submits a control command. Requirement: every command shall be authorized against the target tank's facility and caller's active role before persistence/dispatch; invalid scope shall be denied and audited. Design: server resolves tank-to-facility mapping and queries the user's active role assignment; client cannot override scope. Verification: positive same-facility tests plus negative cross-facility tests for every method, guessed IDs, bulk endpoints, replay and race cases; assert no command row, outbox event or physical command is created. Residual risk includes compromised admin identity, incorrect facility mapping or a race after role revocation. Mitigate with MFA, monitoring, transactionally consistent authorization, key controls and periodic access review.

---

# Course 6 — Data Systems and Databases

## Problem 1. Functional dependencies and BCNF (20 marks)
A relation `Enrollment(StudentID, CourseID, InstructorID, InstructorOffice, Grade)` has dependencies `(StudentID, CourseID) → Grade`, `InstructorID → InstructorOffice`, and `CourseID → InstructorID`. Identify a candidate key and BCNF violations, then decompose.

### Worked solution
Assuming one instructor is assigned per course and a student has at most one enrollment per course, `(StudentID, CourseID)` determines Grade, InstructorID (via CourseID), and InstructorOffice (via InstructorID), so it is a candidate key. `InstructorID → InstructorOffice` violates BCNF because InstructorID is not a superkey of the original relation. `CourseID → InstructorID` also violates BCNF because CourseID is not a superkey. Decompose into `Course(CourseID, InstructorID)`, `Instructor(InstructorID, InstructorOffice)` and `Enrollment(StudentID, CourseID, Grade)`. Check lossless join and dependency preservation; this decomposition preserves the stated dependencies.

## Problem 2. Index choice and cost reasoning (20 marks)
A measurement table has 10 million rows. A query asks for the latest 100 readings for one sensor, ordered by event time descending. Propose an index and explain why the optimizer might still choose a sequential scan in some cases.

### Worked solution
A B-tree on `(sensor_id, event_time DESC)` supports equality on sensor and ordered retrieval by time. It may be covering if selected columns are included, but larger indexes increase storage and write cost. A sequential scan may be cheaper when the predicate matches a large fraction of the table, statistics are stale, the table is small/cached, many heap pages require random visits, or estimated selectivity is poor. Compare plans with actual rows and buffers on representative data; do not force an index solely because one exists.

## Problem 3. Conflict serializability (20 marks)
T1 performs R(A), W(A), R(B); T2 performs R(B), W(B), R(A). T1's W(A) occurs before T2's R(A), while T2's W(B) occurs before T1's R(B). Construct the precedence graph and decide whether the schedule is conflict-serializable.

### Worked solution
On A, T1's W(A) precedes T2's R(A), creating edge T1→T2. On B, T2's W(B) precedes T1's R(B), creating edge T2→T1. The graph contains a cycle; the schedule is not conflict-serializable. Strict 2PL would hold conflicting locks until commit/abort. Optimistic or MVCC schemes require their own validation protocol; MVCC alone does not imply serializability.

## Problem 4. MVCC write skew (20 marks)
Two doctors are on call. Each transaction reads that at least two doctors are on call, then updates a different doctor's row to off-call. Explain how both transactions can commit under snapshot isolation and name one correctness mechanism.

### Worked solution
Each transaction reads a snapshot where both doctors are on call. T1 updates row A and T2 updates row B; there is no direct write-write conflict, so both may commit and leave zero doctors on call. Use SERIALIZABLE isolation with serialization-failure handling or encode the invariant with a locking/constraint strategy that forces a conflict at the correct boundary. PostgreSQL 18 SERIALIZABLE can abort one transaction; retry the entire transaction. Exact behavior is DBMS-specific.

## Problem 5. WAL and recovery (20 marks)
Explain why write-ahead logging requires the relevant log record to reach durable storage before a dirty data page containing the change is flushed. Describe analysis, redo and undo conceptually, and explain why a checkpoint does not eliminate the need for recovery.

### Worked solution
If a modified page reaches disk before its log record, a crash can leave a change with no durable record explaining or recovering it. WAL preserves the ability to redo/undo. In ARIES-style recovery, analysis reconstructs transaction and dirty-page state; redo repeats history from the redo point; undo reverses effects of transactions that did not commit, recording compensation information. A checkpoint records a recovery starting point and bounds some work, but pages may still be dirty and transactions active; recovery still replays required WAL after the checkpoint. PostgreSQL uses WAL but differs in details from classic ARIES; do not equate the implementations.

---

# Exam and project assessment blueprint

For each 14-week course:

- **Midterm (15%):** 90 minutes; 30% precise definitions/model assumptions, 40% derivations or calculations, 30% applied scenario analysis.
- **Final (15%):** 120 minutes; 20% foundations, 40% unseen application, 20% limitations/assurance, 20% integrated case.
- **Project (25%):** individually explainable artefacts; assess correctness, evidence, reproducibility, edge cases and design rationale. An implementation that runs but has no correctness argument is incomplete.

The remaining weights are weekly problem sets (20%) and labs (25%). An instructor may reweight only if substantive theory, practical work and individual ownership checks remain. The exact reader and lab rubrics govern course-specific criteria.

## Minimum quality gate for any submitted solution

A solution is complete only when the student can: (1) restate the problem and assumptions; (2) derive or justify the method; (3) execute or inspect the artifact; (4) compare expected and observed results; (5) explain edge cases and limitations; and (6) defend the work without relying on the answer key.

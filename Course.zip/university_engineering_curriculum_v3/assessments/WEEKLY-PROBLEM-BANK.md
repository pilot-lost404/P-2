# Weekly Problem Bank and Worked Checkpoints — Carried Forward into Edition 3

**Coverage:** 6 courses × 14 weeks = 84 weekly problems with solution checkpoints.  
**Level:** Advanced undergraduate / introductory graduate.  
**How to use:** Attempt each problem before reading its checkpoint. Show assumptions, units, derivations, diagrams, counterexamples and evidence. A checkpoint is a model answer outline; full-credit submissions must justify each step and discuss limitations. Problems are original and are not copied from university assessments.

## Marking standard

Each weekly problem is worth 10 formative marks: model and assumptions (2), method/derivation (4), result or artifact (2), interpretation and limitations (2). The six-course exam-style problem sets in `PROBLEM-SETS-AND-SOLUTIONS-V2.md` provide five longer worked problems per course (30 total). This bank supplies one aligned exercise for every teaching week (84 total).

---

# Course 1 — Distributed Systems

### Week 1 — System model and performance
**Problem.** A service receives 800 requests/s and has a mean end-to-end latency of 125 ms while stable. Estimate mean in-flight requests. State three assumptions required to interpret the result and explain what changes when arrivals exceed service capacity.

**Worked checkpoint.** Little's Law gives \(L=\lambda W=800\times0.125=100\) in-flight requests on average. The observation window must represent a stable population; throughput and latency must refer to the same boundary; the system must not be accumulating an unbounded queue. Under sustained overload, the steady-state assumptions fail and queue length grows unless admission is limited, load is shed or capacity rises.

### Week 2 — RPC, retries and idempotency
**Problem.** A client sends `close-valve(command_id=K)`. The server persists the command and closes the modeled valve, but its response is lost. The client retries. Specify the server-side state and duplicate-request behavior required to avoid repeating the effect. Include the case where K is reused with a different payload.

**Worked checkpoint.** Persist `(scope, command_id, request_hash, status, result)` atomically with the business effect or in the same durable state-machine transition. A retry with the same key and hash returns the original terminal result without reapplying the effect. A retry with the same key and a different hash is rejected and audited. A response cache in process memory is insufficient across restart. A separate external actuator needs its own idempotency/acknowledgement contract; a local database transaction cannot guarantee exactly-once behavior across an unrelated external system.

### Week 3 — Logical time
**Problem.** Events are: P1 sends message m at local Lamport time 4; Q receives m at time 2; Q later sends n at time 5; P receives n at time 4. Apply Lamport receive rule and compute each receive timestamp. Identify the happens-before relationships and explain why the original local values may be inconsistent with the receive rule.

**Worked checkpoint.** On receive, set local time to `max(local, message_time)+1`. Q receives m at `max(2,4)+1=5`, so its event at time 2 cannot already be the receive event in a consistent execution; the statement must be interpreted as Q's pre-receive clock. If Q's send n occurs after that receive, it must have a timestamp greater than 5. Therefore a send at 5 is also inconsistent if the events are strictly ordered. The correct answer identifies the inconsistent trace rather than blindly calculating. A corrected trace has Q receive at 5 and then send n at 6; P receives n at `max(4,6)+1=7`.

### Week 4 — Replication and state-machine replication
**Problem.** Two replicas process the same ordered commands, but command `set_threshold = current_temperature * random()` calls a local RNG at execution time. Explain why replica state can diverge and give two valid design corrections.

**Worked checkpoint.** The command is nondeterministic: each replica may generate a different result. Make the command input deterministic by selecting the random value before ordering and including it in the replicated log; or use a deterministic state-machine algorithm with an identical seeded/persisted PRNG state and deterministic execution semantics. Replicas must also agree on serialization, time inputs and external reads. Replication copies ordered intent; it does not automatically make nondeterministic code deterministic.

### Week 5 — Consistency models
**Problem.** A write `x=1` returns successfully at replica A. A subsequent read by the same client at replica B returns `x=0`. Classify the observation against eventual consistency and read-your-writes session guarantees. State what additional evidence is needed to claim a linearizability violation.

**Worked checkpoint.** The read can be permitted under an eventually consistent model while replicas converge later. It violates read-your-writes if the client session guarantee is promised. For a linearizability violation, establish a real-time completed write before the read invocation, that both operations address the same register, and that the sequential specification requires the read to return 1 or a later value. Record invocation/response intervals and concurrent operations; a single stale observation without timing/specification is not a complete proof.

### Week 6 — Failure detectors and availability
**Problem.** A node is declared failed after 500 ms without a heartbeat, but the network can delay messages by up to 900 ms during congestion. Explain the false-positive mechanism and propose a policy that separates failure suspicion from safe action.

**Worked checkpoint.** A delayed but healthy node can be suspected after 500 ms; in an asynchronous system, timeout alone cannot distinguish crash from delay. Use adaptive suspicion based on observed latency and missed-heartbeat history, but treat suspicion as a probabilistic input rather than proof. Safety-critical actions require fencing/epochs, quorum or a local fail-safe rule; do not authorize two leaders or unsafe actuation merely because a timeout fired. Availability and safety objectives must be stated separately.

### Week 7 — Raft consensus
**Problem.** A cluster has five voters. A candidate with log `(lastTerm=3,lastIndex=10)` requests votes from a majority; one voter has `(lastTerm=4,lastIndex=8)`. Explain how the up-to-date comparison works and why majority size alone is insufficient.

**Worked checkpoint.** Raft compares last-log term first; only if terms are equal does index decide. Term 4 at index 8 is more up to date than term 3 at index 10, so that voter must reject the candidate. A majority intersection argument depends on the up-to-date voting restriction, one vote per term, term monotonicity, AppendEntries consistency and commit rules. The voter prevents a candidate missing a potentially committed entry from becoming leader. Majority size without log constraints does not establish leader completeness.

### Week 8 — Durable logs and recovery
**Problem.** A storage node acknowledges an append before the log record reaches durable media. Power fails immediately. The client assumes the operation committed. Identify the violated contract and describe a write-ahead logging sequence that prevents this acknowledgement error.

**Worked checkpoint.** The node acknowledged durability without durable evidence, violating the promised commit contract. The system must append a complete, checksummed log record; flush the WAL through the record's LSN to stable storage; only then acknowledge commit. Data pages can be flushed later, but recovery must redo committed log records from a valid checkpoint. Define what a commit acknowledgement guarantees and distinguish OS page cache, device cache and durable media semantics.

### Week 9 — Distributed transactions
**Problem.** A 2PC coordinator has collected `PREPARED` from all participants and then crashes before sending `COMMIT`. Explain the blocking risk and compare a compensating saga with atomic distributed commit.

**Worked checkpoint.** Prepared participants must retain locks/resources because they cannot independently decide commit or abort without coordinator decision under classic 2PC. This can block progress. A saga is a sequence of local commits with compensating actions; it offers business-level recovery, not atomic rollback. Use 2PC when atomic cross-resource commit is mandatory and blocking/availability costs are acceptable; use sagas when compensation is valid and intermediate states can be exposed safely.

### Week 10 — Sharding and rebalancing
**Problem.** A database has 12 equal shards. One tenant produces 35% of all writes and is mapped entirely to one shard. Explain why uniform hashing of tenant IDs does not solve the hot-tenant problem. Propose two mitigations and state their consistency costs.

**Worked checkpoint.** Hashing distributes tenant IDs, not load within a single tenant. A hot tenant still maps to one shard. Split that tenant using a compound key or sub-partitioning, or isolate/migrate it to dedicated capacity. Both change query routing and may require fan-out, aggregation or cross-shard transactions. Salting keys can distribute writes but complicates reads and ordering. Measure per-key skew and storage/CPU separately.

### Week 11 — Stream processing
**Problem.** An event-time window is 10:00–10:05. A record timestamped 10:04:50 arrives at processing time 10:12. Explain how a watermark policy determines whether it is accepted, corrected or dropped.

**Worked checkpoint.** The event is 7 minutes 10 seconds late relative to window end. If the watermark has passed 10:05 and allowed lateness is 2 minutes, the window is closed and the record is dropped or sent to a side output. If allowed lateness is 10 minutes, the system can update/retract the prior aggregate. State whether outputs are provisional/final, whether downstream consumers support retractions, and how duplicate event IDs are handled.

### Week 12 — Coordination and distributed locking
**Problem.** A worker acquires a lease, pauses for 20 seconds due to a long GC event, and resumes after its lease expired and a new worker took ownership. Explain why the old worker can still corrupt shared state and how fencing tokens address the issue.

**Worked checkpoint.** Lease expiration is not a physical stop signal; the old process may resume and write. Each grant should issue a monotonically increasing fencing token. The resource validates the token and rejects writes from older tokens after a newer owner has been accepted. A lease without resource-side fencing is insufficient against paused/stale clients. Token persistence and monotonicity must survive coordinator restart.

### Week 13 — Reliability and operations
**Problem.** A service has 99.9% monthly availability. Estimate downtime allowance in a 30-day month. The monthly error budget is consumed in 12 days. Recommend operational actions and explain why availability does not measure every user-visible quality dimension.

**Worked checkpoint.** A 30-day month has 43,200 minutes; 0.1% downtime is 43.2 minutes. Consuming the budget in 12 days signals an error-budget burn rate materially above plan. Freeze or narrow risky changes, investigate dominant error classes, reduce overload/failure exposure and publish an incident review with corrective actions. Availability can hide latency, partial failure, data correctness, tenant-specific impact and safety failures; define SLI coverage carefully.

### Week 14 — Design review
**Problem.** Prepare a five-minute defense of your integrated distributed design. State the failure model, consistency guarantee, durability boundary, retry semantics, overload policy and one counterexample that your tests are designed to detect.

**Worked checkpoint.** A satisfactory defense defines process crash, message loss/delay/duplication and network partition assumptions; gives an explicit guarantee (for example, linearizable commands under a quorum and durable log); states when acknowledgement is returned; explains idempotency retention and payload mismatch; includes bounded queues/deadlines; and shows a failing schedule, such as leader crash after quorum append but before client reply, followed by retry to a new leader. Claims without a trace or test oracle earn limited credit.

---

# Course 2 — Model-Based Systems Engineering

### Week 1 — System boundaries
**Problem.** For a remote tank-monitoring system, identify the system of interest, at least five external entities and three boundary assumptions. Explain how changing the boundary changes the hazard analysis.

**Worked checkpoint.** The system of interest can include tank instrumentation, local controller, communications gateway, cloud API, database and dashboard; external entities include operator, maintenance technician, power supply, physical inflow, downstream process and telecom network. Boundary assumptions could state that mains power is external, the tank structure is existing infrastructure and an independent mechanical relief device is outside the software system. Moving the relief device inside changes ownership, requirements, verification and responsibility for failure analysis. A boundary is a modeling decision, not merely a drawing line.

### Week 2 — Stakeholders and operational concept
**Problem.** Three stakeholders request conflicting behaviors: operators want remote open/close, safety personnel require local high-high shutdown, and maintenance wants a bypass mode. Write one operational scenario and list the decisions that cannot be resolved by the modeler alone.

**Worked checkpoint.** The scenario must show normal remote command, local protective override, alarm/acknowledgement and authorized maintenance. Stakeholder decisions include what conditions allow bypass, maximum bypass duration, required two-person approval, which controls remain active, alarm escalation and restoration criteria. Capture rationale, owner and verification evidence. A model should expose conflict instead of silently inventing policy.

### Week 3 — Requirements quality
**Problem.** Rewrite “the tank must be safe and responsive” into two measurable requirements, one safety-related and one performance-related. Identify the assumptions that need sponsor approval.

**Worked checkpoint.** Example: “When an independent high-high sensor asserts, the local controller shall issue a close command within 100 ms” and “Under 100 concurrent dashboard sessions and a defined 10 Mbps/50 ms network profile, 95% of dashboard requests shall complete within 2.0 s.” Thresholds are illustrative assumptions requiring stakeholder approval. Define measurement points, environmental envelope, sensor validity, valve response and failure behavior.

### Week 4 — Model semantics and abstraction
**Problem.** A block diagram shows a controller connected to a valve but says nothing about response time or failure. Explain two semantic properties a model needs before it can support a performance/safety argument.

**Worked checkpoint.** Add explicit interface direction/units/protocol and behavior/state transitions with guards; add timing constraints and failure states where relevant. Define whether `close` means command issued, actuator moved or flow stopped. A diagram can be syntactically valid but semantically incomplete. State which properties are assumptions and which are analyzed or measured.

### Week 5 — Structural architecture
**Problem.** Allocate level sensing, command authorization, valve closure and event logging to system elements. Identify at least two allocation errors that would create a single point of failure or responsibility gap.

**Worked checkpoint.** Level sensing and local high-high protection should have an explicitly independent path where safety analysis requires it; cloud role checking belongs at the remote command boundary; local controller retains local protective authority; event logging may be split between local durable buffer and cloud persistence. An allocation error includes giving the cloud exclusive responsibility for overflow prevention or failing to allocate the physical valve feedback signal to any component. Trace each allocated function to interface and requirement.

### Week 6 — Behavioral modeling
**Problem.** Model states `Normal`, `HighHigh`, `EmergencyStop` and `MaintenanceBypass`. Identify a transition that must be forbidden and propose guards for leaving the protective state.

**Worked checkpoint.** A transition directly from `EmergencyStop` to `ValveOpen` without reset/clearance is forbidden. Leaving `HighHigh` requires valid level below a reset threshold with hysteresis, healthy sensor path and authorized reset; emergency stop may require local physical confirmation. Avoid a single threshold that causes rapid oscillation. Check all transitions for reachability and dead states.

### Week 7 — SysML v2 and requirements integration
**Problem.** In a SysML v2 model, explain the difference between defining a requirement, asserting it for a subject and recording a verification case. Propose a trace chain for a high-high shutdown requirement.

**Worked checkpoint.** A requirement definition states reusable obligation semantics; a requirement usage asserts it in a particular model context/subject; a verification case describes how evidence is produced. The chain is stakeholder need → system requirement usage → local controller/independent sensor allocation → test case with threshold/timing oracle → recorded result and configuration. Exact syntax must be checked against the chosen tool/parser and OMG specification version.

### Week 8 — Interfaces and contracts
**Problem.** The sensor sends `level=72` while the receiver assumes percentage and another producer means litres. Specify a data contract that prevents this ambiguity and list failure responses.

**Worked checkpoint.** Define field name, unit (e.g. percent of calibrated usable volume), numeric type/precision, allowed range, calibration ID, timestamp/time basis, sequence number, quality/status, source identity and schema version. Reject or quarantine invalid/out-of-range values; do not silently reinterpret. Interface requirements need error semantics and backward compatibility, not only a message shape.

### Week 9 — Parametrics
**Problem.** A cylindrical tank has cross-sectional area 5 m². Inflow is 0.02 m³/s and outflow is 0.005 m³/s. Derive the idealized time to raise level by 1.2 m, ignoring nonlinear effects.

**Worked checkpoint.** Net volume flow is 0.015 m³/s. Volume change is area × level change = 5×1.2=6 m³. Time is 6/0.015=400 s (6 min 40 s). Units cancel to seconds. State assumptions: constant cross-sectional area, constant flows, no leakage, no actuator delay and accurate level measurement. The model does not predict dynamic pressure/flow effects.

### Week 10 — Trade studies
**Problem.** Architecture A scores 4,3,5 on reliability, cost and maintainability; B scores 3,5,3. Weights are 0.5,0.3,0.2. Calculate both weighted scores, then state one sensitivity analysis and one hard constraint that may override the weighted sum.

**Worked checkpoint.** A = 4(0.5)+3(0.3)+5(0.2)=3.9. B = 3(0.5)+5(0.3)+3(0.2)=3.6. A wins under these weights. Vary weights across stakeholder-approved ranges and evaluate score uncertainty. A hard minimum safety integrity/availability requirement may disqualify a low-scoring option regardless of aggregate.

### Week 11 — Model V&V and QA
**Problem.** A model contains an unconnected flow port, a requirement without verification link and a part with no allocated function. Define three automated or review checks and distinguish syntax from semantic quality.

**Worked checkpoint.** Check port compatibility and connection completeness; find requirements missing a verification case; find functions with no performer or justified external allocation. Parsing confirms syntax/structural validity; semantic checks inspect consistency, completeness, units, multiplicities and intended engineering meaning. Model quality also requires stakeholder review and version/configuration context.

### Week 12 — Configuration and change impact
**Problem.** The tank target changes from 70% to 80%. Trace the change through requirement, parametric model, valve/control design, hazard analysis, database/dashboard and verification. Identify at least two regression tests.

**Worked checkpoint.** Update source requirement and baseline; revise capacity/timing equations and alarm thresholds; inspect overfill margin and sensor calibration; update API/data labels and dashboard interpretation; revisit FMEA/FTA/STPA; update verification limits and trace links. Regression tests include maximum safe fill time and high-high trip independent of cloud state. Reassess every downstream artifact through trace links, not manual search alone.

### Week 13 — Digital engineering thread
**Problem.** A design report was exported from a model but manually edited without recording the change. Explain why this breaks the digital thread and propose a controlled publication process.

**Worked checkpoint.** The report is no longer an auditable projection of the authoritative model. Generate versioned reports from a tagged model baseline, include generation timestamp/tool version/configuration, restrict manual modifications or record controlled overrides, and trace reported values back to model elements. A digital thread requires identity and consistency across tools/artifacts, not just an exported diagram.

### Week 14 — Model review
**Problem.** Prepare a model review package with one requirement, one state machine, one parametric equation, one interface contract and one change-impact example. State which claims were parser-validated and which were only reviewed.

**Worked checkpoint.** A strong submission includes the model file, environment/version, successful import/render output, consistency checks, exported diagrams/tables and trace matrix. It distinguishes syntax validation from semantic correctness and engineering approval. In this pack, the supplied SysML v2 text is a starter and has not been validated by an installed tool; learner evidence must fill that gap.

---

# Course 3 — Safety and Risk Analysis

### Week 1 — Safety fundamentals
**Problem.** Distinguish a loss, hazard, accident scenario and risk estimate for a tank overflow that damages adjacent electrical equipment. State why “the sensor fails” is not itself a complete hazard statement.

**Worked checkpoint.** Loss: injury/equipment damage/environmental harm. Hazard: tank contents exceed safe containment boundary while exposed equipment is energized. Scenario: level sensor stuck low, controller continues inflow, independent shutdown unavailable. Risk combines likelihood/frequency and consequence under an explicit model. A component failure is a cause, not necessarily the system-level hazardous condition.

### Week 2 — Preliminary hazard analysis
**Problem.** Rate three hazards using a 5×5 severity/likelihood matrix: (a) false high reading that stops filling, (b) undetected overflow, (c) stale telemetry that hides state. Explain why matrix scores are not calibrated probabilities.

**Worked checkpoint.** A defensible ranking puts undetected overflow at high severity and potentially high likelihood depending on controls; false high may be lower consequence but still operationally important; stale telemetry can contribute to delayed response. Exact cells require local definitions and evidence. Ordinal multiplication does not produce a calibrated probability or expected loss. Record rationale, uncertainty and assumptions for each rating.

### Week 3 — FMEA
**Problem.** For a level sensor, list three failure modes, local effects, system effects, detection methods and controls. Explain one limitation of ranking solely by RPN.

**Worked checkpoint.** Examples: stuck-low → indicated level remains low → overfill hazard; stuck-high → false trip/no fill; drift → biased level/control margin degraded. Detection includes range/rate checks, redundant comparison and proof testing; controls include independent high-high switch and plausibility checks. RPN can hide a high-severity failure behind low occurrence or poor detection scoring; track severity and mandatory controls separately.

### Week 4 — FMECA and criticality
**Problem.** A component has failure rate \(\lambda=2\times10^{-6}\) per hour, failure-mode fraction \(\alpha=0.4\), mission time \(t=1000\) h. Under a simple constant-rate approximation, estimate mode probability and explain the approximation.

**Worked checkpoint.** Mode rate is \(\alpha\lambda=8\times10^{-7}\) per hour. Probability over mission is \(1-e^{-\alpha\lambda t}=1-e^{-0.0008}\approx0.0007997\). This assumes constant hazard rate, independent mode occurrence and no repair/maintenance; it is not a field failure prediction without validated data and confidence bounds.

### Week 5 — Fault tree analysis
**Problem.** Top event T occurs if sensor failure S occurs, or both controller failure C and valve-stuck-open V occur. Given independent probabilities P(S)=0.01, P(C)=0.02, P(V)=0.03, calculate P(T).

**Worked checkpoint.** P(C∧V)=0.02×0.03=0.0006. Since S is independent of C and V, P(T)=P(S)+P(C∧V)-P(S)P(C∧V)=0.01+0.0006-0.000006=0.010594. Do not simply add the events without subtracting overlap. If dependencies/common cause exist, independence is invalid and a joint model is needed.

### Week 6 — Event tree analysis
**Problem.** An initiating event occurs with frequency 0.01/year. A shutdown succeeds with probability 0.98; if it fails, a containment barrier succeeds with probability 0.90. Calculate the frequency of the final consequence assuming independent barrier outcomes conditional on reaching each branch.

**Worked checkpoint.** Final consequence requires shutdown failure (0.02) and containment failure (0.10): `0.01 × 0.02 × 0.10 = 0.00002/year`. The value is conditional on event-tree structure and independence/conditional-probability assumptions. Include common-cause failure, barrier demand dependence and uncertainty in a real analysis.

### Week 7 — STPA unsafe control actions
**Problem.** A controller issues `OPEN_VALVE`. Give one unsafe-control-action example for each STPA category: not provided when needed, provided when unsafe, too early/late or wrong order, and stopped too soon/continued too long.

**Worked checkpoint.** (1) No open command during safe low-level refill when needed, causing service loss (context-specific). (2) Open at high-high or during emergency stop. (3) Open before valid sensor data or after a delayed stale command. (4) Continue opening after high-high trip or stop opening before required minimum refill without an operational reason. Define context and loss; labels without context are not analysis.

### Week 8 — Causal scenarios
**Problem.** The high-high controller does not trip because the operator disables an alarm during a noisy maintenance window. Construct a causal scenario with feedback/mental-model/authority factors and derive two constraints.

**Worked checkpoint.** Noisy alarm → nuisance-alarm response → operator disables shared alarm path → independent trip notification is also suppressed → fill continues. Consider inadequate alarm prioritization, lack of role separation, maintenance procedure and feedback visibility. Constraints: maintenance suppression must not disable independent protective channels; time-limited bypass requires authorization, local indication and compensating monitoring. Validate the scenario with operators and system interfaces.

### Week 9 — Human factors
**Problem.** An operator must acknowledge 40 alarms during a shift. Identify how alarm flooding, mode confusion and fatigue can affect safety; propose measurable design/operational mitigations.

**Worked checkpoint.** Alarm flooding masks priority; mode confusion leads to actions inconsistent with current controller state; fatigue slows detection and increases error. Mitigations include prioritization/rationalization, suppression only for redundant alarms, explicit mode annunciation, role-appropriate displays, shift handover and workload limits. Measure nuisance alarm rate, priority distribution, acknowledgement latency and operator task load; validate with realistic scenarios.

### Week 10 — Safety requirements
**Problem.** Convert “prevent overfill” into two verifiable safety constraints with distinct control paths. State the evidence each requires.

**Worked checkpoint.** Example: independent high-high device de-energizes/commands inlet isolation within specified response time; local controller prevents remote or stale commands from reopening the inlet while trip is latched. Evidence includes architecture independence analysis, sensor/actuator response test, fault injection, proof-test coverage, reset test and traceability to hazard. Thresholds and timing need system-specific validation.

### Week 11 — Safety cases
**Problem.** Build a top-level claim, two subclaims and supporting evidence for “the simulated system prevents the modeled overflow hazard within the stated operating envelope.” Give one defeater.

**Worked checkpoint.** Top claim scoped to the simulation model and stated envelope. Subclaims: hazardous inflow is detected by independent sensing; protective closure occurs within the modelled response limit and cannot be overridden by cloud failure. Evidence: hazard analysis, requirements, model traceability, fault-injection tests and test results. Defeater: model omits valve mechanical failure or sensor common-cause effects. A safety case is only as strong as its scope and evidence.

### Week 12 — Standards and lifecycle
**Problem.** Explain why citing IEC 61508 or a safety lifecycle standard does not prove the project compliant. List the evidence that would be required before making a conformity claim.

**Worked checkpoint.** A standard contains normative lifecycle, process and technical requirements; a reference citation is not evidence of implementation. A claim needs applicable scope/edition, hazard and risk classification, competent roles, lifecycle plans, safety requirements, verification/validation evidence, configuration/change records, independence/assessment records and gaps/justified tailoring. Some normative texts are licensed; use official access.

### Week 13 — Operational safety management
**Problem.** Define three leading indicators for deteriorating protection performance and a threshold-triggered response for each. Explain the difference between a leading and lagging indicator.

**Worked checkpoint.** Examples: overdue proof tests, rising sensor disagreement rate, increasing number/duration of active bypasses. A lagging indicator is actual overflow or trip-induced downtime. Leading indicators signal weakening controls before a loss; set thresholds from baseline data and owner review, not arbitrary universal cutoffs. Record corrective actions and effectiveness.

### Week 14 — Integrated risk assessment
**Problem.** Present one bow-tie or equivalent integrated hazard argument linking initiating causes, preventive controls, top event, mitigations and residual risk. Identify one uncertainty that could change the recommendation.

**Worked checkpoint.** The diagram should show causes, threat controls, top event, consequence controls and losses with unique references to requirements and tests. Residual risk includes uncertainty in failure rates, common-cause behavior, human intervention or physical dynamics. State whether the conclusion is qualitative, probabilistic or only a simulation observation; do not claim certified safety.

---

# Course 4 — Verification and Validation

### Week 1 — V&V foundations
**Problem.** For a valve-control API, provide one verification question and one validation question. Explain why both are needed even when every requirement test passes.

**Worked checkpoint.** Verification: “Does the API reject an expired command with the specified error and audit event?” Validation: “Does the command workflow support an operator's intended safe maintenance task?” Requirements compliance can coexist with a product that solves the wrong problem; validation tests fitness for intended use with representative users and environments.

### Week 2 — Requirement testability
**Problem.** Given “the service shall be reliable and easy to use,” list missing attributes and rewrite it as one measurable performance requirement and one task-success requirement.

**Worked checkpoint.** Missing: workload, duration, service boundary, reliability measure, user population, task, success criterion and environment. Example performance: 99.9% of valid API requests complete within 500 ms at 100 requests/s over a specified workload. Example usability: 90% of representative trained operators complete the acknowledgement task without assistance within 60 s. Thresholds are assumptions until stakeholder-approved.

### Week 3 — Verification methods
**Problem.** Select test, analysis, inspection or demonstration for: (a) maximum enclosure dimensions, (b) cryptographic library configuration, (c) API idempotency, (d) operator workflow suitability. Justify each and state evidence.

**Worked checkpoint.** Dimensions: inspection/measurement with calibrated instrument. Crypto configuration: inspection plus analysis against approved configuration; functional tests alone cannot establish strength. Idempotency: dynamic test with duplicate/retry/crash schedules plus durable state inspection. Workflow suitability: representative-user demonstration/validation. A requirement may need multiple methods and independent evidence.

### Week 4 — Test design
**Problem.** A field accepts an integer from 0 to 100 inclusive. Identify equivalence classes and boundary values, then write a minimal test set that includes invalid type and missing input.

**Worked checkpoint.** Valid class: integers [0,100]; invalid low: below 0; invalid high: above 100; invalid type: non-integer/null/string depending contract; missing field. Boundary values: -1,0,1,99,100,101. Test 0 and 100 explicitly, plus one representative interior value and each invalid class. Validate parsing/canonicalization separately from range checking.

### Week 5 — Integration testing
**Problem.** The API unit tests pass, but the integration test shows the database commit succeeds while the message broker publish fails. Explain why unit tests missed the problem and propose two correct transactional designs.

**Worked checkpoint.** Unit tests mock independent dependencies and do not exercise atomicity across real database/broker boundaries. Use transactional outbox: commit business row + outbox row together, then publish/retry idempotently; or use a true distributed transaction only if both systems support the required semantics and availability trade-offs are acceptable. Add crash/retry tests and reconciliation.

### Week 6 — System and acceptance validation
**Problem.** Write an acceptance scenario for “an operator can safely close the inlet during a cloud outage.” Include preconditions, action, expected result and objective evidence.

**Worked checkpoint.** Preconditions: local controller healthy, independent safety channel active, cloud link disconnected, valve initially open in simulation. Action: operator uses local control or trip is triggered. Expected: local close command occurs within approved bound, valve state/feedback reaches closed, event is buffered and later reconciled. Evidence includes timestamped state trace, fault-injection record and physical/simulator feedback. Validation also asks users whether the procedure is usable.

### Week 7 — Reproducible test environments
**Problem.** Two test runs yield different results because one uses a stale database snapshot and the other uses a new schema. Define an environment manifest with six fields and a reset strategy.

**Worked checkpoint.** Record source commit/hash, application build, schema/migration version, DB/runtime version, configuration/secrets references (not secret values), dataset seed/snapshot, external dependency versions and clock/network assumptions. Reset with disposable database/container, deterministic seed, isolated accounts, fixed time where possible and recorded test order. Preserve raw logs and evidence hashes.

### Week 8 — Performance and statistical evidence
**Problem.** A load test reports p95=400 ms and p99=2.5 s over 10,000 requests. Explain why the mean is not enough, name three confounders and define a repeatable measurement plan.

**Worked checkpoint.** Tail latency exposes a slow fraction hidden by mean. Confounders include warm/cold cache, network conditions, background load, request mix, GC, connection pool state and sample size. Fix workload/concurrency/ramp/duration, repeat runs, report histograms and p50/p95/p99, errors, throughput, saturation and environment, and compare confidence/variation rather than one isolated point estimate.

### Week 9 — Security and safety tests
**Problem.** Design negative tests for a remote valve command API that cover broken object-level authorization, replay, stale telemetry and emergency-stop priority. State the expected failure behavior.

**Worked checkpoint.** Cross-facility object ID must be denied and audited; duplicate/replayed command ID must return original outcome or reject expired nonce; stale telemetry must not satisfy safety precondition; emergency stop must dominate remote open regardless of role. Assert state does not change, no unauthorized effect occurs, error/audit event is produced and no sensitive data is leaked.

### Week 10 — Formal methods and model checking
**Problem.** Specify invariant `EmergencyStop ⇒ ¬ValveOpen` for a finite state model. Construct one violating transition trace and describe what a shortest-counterexample checker proves and does not prove.

**Worked checkpoint.** Counterexample trace: `(Normal, ValveClosed) → (EmergencyStop, ValveClosed) → (EmergencyStop, ValveOpen)`. A breadth-first explicit-state checker can show a shortest path in the supplied finite graph to a state violating the invariant. It does not prove the model contains all real states, that the transition relation is correct or that continuous physical dynamics are safe.

### Week 11 — Automation and CI
**Problem.** A test passes locally but fails intermittently in CI due to sleep-based synchronization. Explain the race and give two deterministic testing techniques.

**Worked checkpoint.** Fixed sleeps assume scheduling/time bounds that are not guaranteed. Use explicit channels/latches/barriers or condition variables to signal readiness; use virtual/fake clocks where timeouts are part of the logic; bound waits and collect goroutine/thread traces on failure. Repeat under race detector/parallel stress but do not interpret non-detection as proof of no race.

### Week 12 — Coverage and anomalies
**Problem.** A suite has 95% line coverage but does not test cross-facility authorization. Explain why coverage is a weak proxy and define a traceability review for this security property.

**Worked checkpoint.** Line coverage says code executed, not that meaningful conditions or forbidden paths were tested. Link security requirement → policy rule → API handler/resource query → positive same-facility test → negative foreign-facility test → audit evidence. Include role revocation, tenant boundary and error-path assertions. Report coverage type and uncovered risks separately.

### Week 13 — Release decision
**Problem.** One medium-severity defect remains in dashboard color contrast; all safety-critical command tests pass but restore rehearsal has not been done. Decide whether to release, defer or block and state what evidence governs the decision.

**Worked checkpoint.** The answer depends on intended release scope and risk acceptance authority. The uncompleted restore rehearsal means recovery objective is unverified; block any release whose resilience requirements include proven recovery until restore is tested, or limit the release explicitly to a noncritical simulation with approved risk acceptance. Contrast issue requires accessibility criteria and mitigations. A release decision must list evidence, unresolved risks, owners and authorization.

### Week 14 — Assurance report
**Problem.** Prepare a V&V conclusion with one verified claim, one validated claim, one unresolved anomaly and one limitation. State why “all tests passed” is not a sufficient summary.

**Worked checkpoint.** Separate requirements compliance from fitness for intended use; identify baseline and test environment; summarize coverage, severity, deviations, failed/skipped tests and residual risks. A green test suite only reports behavior under executed inputs/configurations and oracles. It does not imply completeness, correctness of requirements or adequacy of the test model.

---

# Course 5 — Security Engineering

### Week 1 — Security objectives and assets
**Problem.** Identify confidentiality, integrity and availability objectives for sensor telemetry, operator credentials and actuator commands. Rank the likely impact of command integrity loss versus dashboard confidentiality loss in the water-tank case.

**Worked checkpoint.** Telemetry integrity/availability affect control decisions; credentials require confidentiality/integrity; actuator commands require integrity, authenticity, authorization and freshness. A forged open command may create direct physical risk, while dashboard confidentiality loss may be serious but is not necessarily equivalent. Rank using system context, safety consequence and threat capability, not generic CIA labels.

### Week 2 — Trust boundaries and data flows
**Problem.** Draw the data flow from sensor to local gateway to cloud API to database to dashboard. Mark trust boundaries and identify one spoofing, tampering and information-disclosure threat per boundary.

**Worked checkpoint.** Boundaries include field bus↔gateway, gateway↔public network, API↔database, user browser↔API and tenant/user scopes. Threats include spoofed sensor identity, tampered command payload, stolen bearer token, SQL/data exposure and cross-tenant reads. Document data classification, identity/authentication mechanism and validation at each trust crossing.

### Week 3 — Risk and requirements
**Problem.** For a command-replay threat, write one security requirement with measurable acceptance criteria and map it to a test. Explain why a risk score cannot replace threat modeling.

**Worked checkpoint.** Example: “The command service shall reject commands with expired timestamps or previously consumed nonces and shall persist the command ID and result atomically.” Tests submit valid, expired, duplicate and reused-ID/different-payload commands and inspect state plus audit. Threat modeling identifies assets, actors, paths and preconditions; a numeric score only prioritizes and can hide uncertainty.

### Week 4 — Authentication and sessions
**Problem.** A JWT is signed and expires in one hour. A user is disabled after five minutes. Explain why signature verification and `exp` alone do not enforce prompt account revocation. Give two mitigations.

**Worked checkpoint.** A valid token may remain cryptographically valid until expiry. Use short token lifetimes with refresh/session revocation, a token/session version or revocation list checked by the API, and account-state checks at sensitive authorization boundaries. Balance revocation freshness, availability and state-store dependency. Verify issuer, audience, algorithm allowlist, signature, time claims and key rotation.

### Week 5 — Authorization and tenant isolation
**Problem.** An `OPERATOR` may read/command resources in facility A but not facility B. Design an authorization predicate and list two negative tests that catch insecure direct object reference.

**Worked checkpoint.** Permit only if principal is active, role grants action and resource facility matches the authorized facility scope. Object lookup should combine object ID and authorized facility rather than fetch then trust the client. Test by changing path/query/body resource IDs to facility B and by using a valid facility-A token against a B-owned object. Expect deny, no side effect and audit record.

### Week 6 — Cryptography and key lifecycle
**Problem.** Explain why encrypting a database field with a hard-coded AES key in source code is not a secure key-management design. Specify storage, rotation, access and backup requirements.

**Worked checkpoint.** Source code can be copied, logged and distributed; one static key creates a large blast radius. Use an appropriate KMS/HSM or protected secret manager, envelope encryption where suitable, least-privilege access, key IDs/version metadata, rotation/re-encryption plan, audit and break-glass process. Back up key-encryption material separately and test recovery. Choose authenticated encryption (AEAD) and manage nonces correctly; avoid inventing cryptographic primitives.

### Week 7 — Input and application vulnerabilities
**Problem.** A query concatenates `sensor_id` from a request parameter into SQL. Show the class of vulnerability, then list a parameterized version and two additional controls.

**Worked checkpoint.** Concatenation can permit SQL injection if attacker-controlled syntax reaches the query. Use a prepared statement parameter (`WHERE sensor_id = $1` in PostgreSQL) and allowlist expected identifier formats. Enforce database least privilege and validate object ownership. Escaping is context-sensitive and is not the preferred substitute for parameterization.

### Week 8 — API and distributed command security
**Problem.** A command is correctly signed but an attacker replays it after the original user has lost authorization. Explain why integrity does not imply authorization or freshness.

**Worked checkpoint.** A signature proves possession of signing key and protects integrity under assumptions; it does not establish current user authorization or prevent replay if message is validly signed. Include authenticated subject, scoped target, action, unique ID/nonce, issued/expiry times, audience, policy version and server-side deduplication. Recheck authorization at execution boundary and validate freshness/sequence state.

### Week 9 — Privacy, data protection and secrets
**Problem.** The dashboard logs full JWTs and sensor messages to diagnose errors. Identify risks and specify a privacy-preserving observability alternative.

**Worked checkpoint.** Full tokens enable impersonation; payloads may expose personal/operational data; logs replicate sensitive data into a wider-access system with long retention. Redact credentials/secrets, log stable request IDs and selected metadata, classify payload fields, restrict access, encrypt storage/transport, define retention and audit access. Preserve enough evidence for incident response without logging bearer credentials.

### Week 10 — Defense in depth
**Problem.** A design has TLS, a web application firewall and a password policy, but no facility authorization, no local actuator interlock and no rate limiting. Explain why the listed controls do not compensate for the missing controls.

**Worked checkpoint.** Controls address transport confidentiality, some traffic patterns and credential quality; they do not authorize object-level access, enforce physical safety constraints or control abuse/overload. Defense in depth requires controls at distinct threat boundaries and layers, including server-side authorization, local fail-safe interlock and rate/resource limits. Map each threat to preventive, detective and recovery controls.

### Week 11 — Secure development and supply chain
**Problem.** A dependency scan reports no known CVEs, but the package version is no longer maintained and its source provenance is unknown. Explain what the scan omits and define a fuller dependency review.

**Worked checkpoint.** CVE matching does not establish maintenance, provenance, malicious-release risk, license compatibility, transitive exposure or secure configuration. Record source/repository, release signatures/checksums, maintainer status, dependency graph, license, update policy, vulnerability advisories, build provenance and reproducible build evidence. Use risk-based exceptions with expiry and owner.

### Week 12 — Security verification
**Problem.** Design a minimal ASVS-mapped test set for authentication, authorization, input validation and sensitive-data protection. Explain why passing a checklist cannot prove the system secure.

**Worked checkpoint.** Select version-pinned ASVS requirements applicable to the architecture; test session expiry/rotation, role/facility denial, parameterized inputs and absence of tokens in logs. Record requirement IDs, setup, expected result, raw evidence and tool version. Standards-based verification reduces known gaps but cannot prove absence of unknown vulnerabilities or validate threat-model assumptions.

### Week 13 — Incident response
**Problem.** A service account key is leaked and suspicious actuator commands appear. Outline the first response sequence and identify evidence that must be preserved. Use current NIST incident-response guidance.

**Worked checkpoint.** Triage/declare incident, contain by disabling/rotating credentials and restricting command authority, preserve immutable audit/logs/config snapshots and timestamps, determine scope/affected facilities, eradicate persistence and vulnerable secrets, recover from known-good state, validate actuator safety, notify authorized stakeholders and conduct lessons learned. Maintain chain of custody and avoid destroying evidence during rotation. Tailor to NIST SP 800-61 Rev. 3 and organizational plans.

### Week 14 — Security design review
**Problem.** Present a threat model for the integrated project, one critical abuse case, mapped control, negative test, residual risk and risk owner. State the scope of any security claim.

**Worked checkpoint.** A strong answer traces threat → requirement → architecture control → executable test → evidence and residual-risk decision. Scope must state assets, interfaces, deployment, version and tests covered. A local authorization-policy test does not constitute penetration testing or full-stack assurance; do not generalize beyond evidence.

---

# Course 6 — Data Systems and Databases

### Week 1 — Database architecture
**Problem.** A monitoring application has transactional command data and a historical analytics workload. Propose an architecture separating OLTP and analytical workloads, and state one consistency issue created by the separation.

**Worked checkpoint.** Use a normalized OLTP store for commands/current state and a derived analytical store or warehouse for history/aggregations, fed by CDC/outbox/stream. Replication is asynchronous, so analytical data can lag; publish freshness watermark and do not use the analytics store for immediate actuator authorization. Define lineage and reconciliation.

### Week 2 — Keys and integrity
**Problem.** A `measurement` relation has `(sensor_id, measured_at, sequence_no, value)`. Propose a candidate key and two integrity constraints. Explain why timestamp alone may not be unique.

**Worked checkpoint.** Candidate key can be `(sensor_id, sequence_no)` if sequence is monotonic and unique per sensor, or a generated measurement ID plus a unique business constraint. Require sensor foreign key and `value`/quality domain checks; timestamps can collide due to clock resolution, retransmissions or clock skew. Define nullability and timezone semantics.

### Week 3 — Functional dependencies and normalization
**Problem.** Relation `R(sensor_id, facility_id, facility_name, sequence_no, value)` has FDs `sensor_id → facility_id`, `facility_id → facility_name`, `(sensor_id, sequence_no) → value`. Find a candidate key, identify a transitive dependency and propose a lossless decomposition.

**Worked checkpoint.** Candidate key is `(sensor_id, sequence_no)` because it determines `facility_id`, then `facility_name`, and `value`. `sensor_id → facility_id → facility_name` is transitive relative to the key. Decompose into `Sensor(sensor_id,facility_id)`, `Facility(facility_id,facility_name)` and `Measurement(sensor_id,sequence_no,value)` with foreign keys. Check lossless join and dependency preservation against declared FDs.

### Week 4 — Relational algebra and SQL
**Problem.** Express “latest valid reading per sensor” using relational reasoning and give one SQL approach. Explain why a naive `GROUP BY sensor_id, MAX(measured_at)` may not return the matching value row correctly.

**Worked checkpoint.** Conceptually select valid measurements, group by sensor to find maximum timestamp, then join the result back to the valid relation on sensor and timestamp. In PostgreSQL, `DISTINCT ON (sensor_id) ... ORDER BY sensor_id, measured_at DESC, sequence_no DESC` is one option; a `row_number()` window is portable in many systems. `MAX` alone returns only the time, not the other columns and can produce ties.

### Week 5 — Storage layout
**Problem.** A page is 8 KiB, page header and slot metadata consume 256 bytes, and fixed-length records are 100 bytes. Estimate the maximum number of records if records cannot span pages and each slot needs 4 bytes. Ignore alignment/fragmentation.

**Worked checkpoint.** Usable bytes = 8192−256=7936. Per-record bytes including slot = 104. Floor(7936/104)=76 records (7904 bytes), leaving 32 bytes. Real page layout includes alignment, tuple header, line pointers, free-space management and page-special metadata, so the result is an idealized bound.

### Week 6 — Indexes and query planning
**Problem.** A B+ tree has fan-out 200 and leaf capacity 100 records. Estimate how many records could be addressed at height 3 in the ideal full tree. Explain why real trees have lower occupancy.

**Worked checkpoint.** If height 3 means three levels total (root, one internal level, leaves), the ideal leaf count is `200^2=40,000`; at 100 records/leaf this is 4,000,000 entries. State the height convention explicitly: if “height 3” means three edges/three internal levels, the value differs (`200^3×100`). In real workloads nodes split before capacity, are not fully populated, and key/pointer sizes and page overhead constrain fan-out. Explain planner cost is estimated, not measured.

### Week 7 — ACID and transaction boundaries
**Problem.** A command handler updates `command_status` and `valve_state` in separate autocommit statements. A crash occurs between them. Explain the inconsistency and define the atomic transaction boundary.

**Worked checkpoint.** One record may say command succeeded while modeled state remains unchanged, or vice versa. Put both changes plus idempotency result/outbox event in one transaction when they represent one business transition. If the physical valve is external, transaction cannot atomically include it; model command intent/acknowledgement separately and reconcile with an idempotent protocol.

### Week 8 — Isolation and serializability
**Problem.** Two doctors are marked on-call. Transaction A reads count=2 and turns doctor 1 off; transaction B reads count=2 and turns doctor 2 off. Both commit under snapshot isolation. Explain the write-skew anomaly and two prevention methods.

**Worked checkpoint.** Each transaction updates a different row, so no write-write conflict necessarily occurs, yet the invariant “at least one on-call doctor” becomes false. Prevention options: enforce invariant through a database constraint/serialized representation, acquire a common predicate/guard lock, or use SERIALIZABLE isolation and retry serialization failures. Validate behavior on the selected DBMS; snapshot/serializable semantics vary by engine.

### Week 9 — WAL and recovery
**Problem.** A transaction changes a page and commits. The page is not flushed before crash, but its WAL commit record is durable. Explain how redo recovery reconstructs the committed update and why WAL must be flushed before the data page.

**Worked checkpoint.** The log contains enough ordered change information to redo the update. Recovery starts from a valid checkpoint/redo LSN and replays required WAL to database pages. WAL-before-data ensures the durable log record exists before an affected dirty page can reach stable storage; otherwise the page could reflect an update for which recovery evidence is missing. Exact redo/undo protocol depends on DBMS implementation (e.g., ARIES-style analysis/redo/undo).

### Week 10 — Migrations
**Problem.** A large `NOT NULL` column must be added to a table with 50 million rows while the service remains online. Propose an expand-migrate-contract sequence and identify rollback risks.

**Worked checkpoint.** Add nullable column/backward-compatible schema; deploy code that writes both old and new fields; backfill in batches with progress/checkpoint and throttling; validate no missing rows; add constraint using engine-supported low-lock procedure; switch reads; later remove old field after all clients migrate. Rollback requires compatibility with mixed application versions and backfill idempotency. Measure lock duration and replication lag.

### Week 11 — Quality, lineage and governance
**Problem.** An analytics dashboard shows an incorrect “current tank level” because delayed events overwrite newer values. Define data-quality rules and lineage metadata to detect and prevent the error.

**Worked checkpoint.** Enforce monotonically increasing `(sensor_id, sequence_no)` or valid event-time ordering, preserve ingestion and measurement timestamps, reject/quarantine stale/out-of-order events, and record source/calibration/schema version. Dashboard reports freshness and selected event timestamp. Lineage links source event → transform/version → aggregate/output. Monitor late/duplicate/rejected rates.

### Week 12 — Distributed data systems
**Problem.** A replicated store has N=7 replicas, read quorum R=4 and write quorum W=3. Determine whether every read quorum must intersect every write quorum. Explain why this alone does not provide linearizability.

**Worked checkpoint.** `R+W=7`, which is not greater than N, so disjoint read and write quorums are possible; guaranteed intersection requires `R+W>N`. Even with intersection, freshness/version ordering, concurrent writes, leader epochs, replica repair and failure semantics are required for a full linearizability protocol.

### Week 13 — OLTP, analytics and streaming
**Problem.** A dashboard query scans 500 million historical records every time an operator opens the page. Recommend an analytical design and define a freshness contract.

**Worked checkpoint.** Pre-aggregate or materialize recent/historical metrics, partition by time, use columnar/warehouse storage for scans and stream/CDC ingestion to update aggregates. Keep immediate control state in OLTP and clearly separate from analytical view. Define freshness such as “95% of telemetry visible within 30 s” and expose watermark/last-updated time; dashboards must show stale status rather than imply real-time current state.

### Week 14 — Database design review
**Problem.** Defend the schema, query/index design, isolation level, recovery strategy, retention and access controls of the integrated project. Name one engine-specific behavior you observed and one behavior you must not generalize.

**Worked checkpoint.** Show FDs/normal forms, constraints, workload-to-index rationale, EXPLAIN ANALYZE evidence with rows/buffers, transaction schedule results, backup/restore outcome and privilege model. Record exact PostgreSQL version and settings. Distinguish PostgreSQL-specific MVCC/serialization errors from SQL-standard terminology or other engines' behavior. In this runtime, PostgreSQL execution is pending, so the pack does not claim an observed result.

---

## Instructor / self-assessment checklist

- [ ] Learner attempted all 84 weekly problems before viewing checkpoints.
- [ ] Quantitative work shows units, assumptions and rounding.
- [ ] Diagrams have boundaries, legends and traced identifiers.
- [ ] Software exercises include test oracle, negative case and reproducibility record.
- [ ] Security exercises are restricted to local intentionally vulnerable labs or explicitly authorized systems.
- [ ] Safety conclusions remain scoped to the modeled system and validated evidence.
- [ ] Tool-specific exercises include exact version, raw outputs and deviations.
- [ ] Final assessment distinguishes demonstrated facts from assumptions, estimates and unresolved risks.

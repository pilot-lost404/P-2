# Course III — Requirements Engineering

**Academic level:** Upper-division undergraduate / introductory graduate  
**Suggested duration:** 13 teaching weeks  
**Prerequisites:** Software development life cycle, basic system modelling and written technical communication  
**Core question:** How do we discover, analyse, specify, validate and control what a system must do and the conditions it must satisfy?

---

## Course description

Requirements engineering (RE) is the disciplined process of discovering stakeholder needs, transforming them into an agreed specification, validating that specification, and managing it as the system evolves. It connects the problem domain to design, implementation, testing, deployment and operations.

Poor requirements are not merely a documentation problem. They cause incorrect scope, architecture rework, contract disputes, weak acceptance tests, security omissions, inaccessible workflows and systems that satisfy their written specification but fail in use. Good requirements engineering is therefore socio-technical: it combines elicitation, analysis, modelling, negotiation, formalisation, validation and change management.

The course uses a secure file-sharing and campus equipment platform as recurring examples. It studies both plan-driven and agile environments. The objective is not to prescribe one document format; it is to produce a coherent, testable and traceable set of requirements appropriate to a system's risk and complexity.

## Learning outcomes

By the end of the course, a student should be able to:

1. Distinguish stakeholder needs, business objectives, system requirements, design decisions and implementation tasks.
2. Identify stakeholders, establish context and select appropriate elicitation methods.
3. Analyse conflicts, assumptions, constraints, risks, dependencies and incomplete information.
4. Write clear, atomic, necessary, feasible, unambiguous and verifiable requirements.
5. Specify functional, interface, data, quality-attribute, security, safety and operational requirements.
6. Use context diagrams, use cases, scenarios, state models, data models and acceptance criteria to clarify behaviour.
7. Structure a Software Requirements Specification (SRS) or equivalent requirements baseline.
8. Validate requirements for stakeholder correctness, completeness and consistency.
9. Derive verification methods, test conditions and traceability relationships.
10. Prioritise requirements and negotiate scope under constraints.
11. Manage changes, versions, baselines, dependencies and requirements status through a life cycle.
12. Apply requirements techniques to iterative, agile and hybrid development.

## Lecture sequence

| Lecture | Topic | Required output |
|---:|---|---|
| 1 | Requirements engineering and problem framing | Problem statement and system context |
| 2 | Stakeholders and elicitation | Elicitation plan and evidence record |
| 3 | Analysis, modelling and negotiation | Context, use-case and state models |
| 4 | Requirements classification and structure | Requirements taxonomy and hierarchy |
| 5 | Requirement quality and specification language | Reviewed requirement set |
| 6 | Functional behaviour, data and interfaces | Behaviour and data specification |
| 7 | Quality attributes and constraints | Quality-attribute scenarios |
| 8 | SRS structure and requirements baselines | Draft SRS |
| 9 | Validation, verification and acceptance | Acceptance criteria and verification matrix |
| 10 | Prioritisation and conflict resolution | Prioritised release baseline |
| 11 | Traceability, change and configuration management | Change-impact analysis |
| 12 | Agile/hybrid RE and integrated case | Requirements package and review |

---

# Part I — Foundations and discovery

## 1. What is a requirement?

A requirement is a documented, agreed or otherwise authoritative statement of a condition or capability that a system, product, service or process must satisfy to meet a need or obligation. Requirements may be imposed by stakeholders, laws, contracts, standards, physical constraints, operational concepts or higher-level system requirements.

Requirements exist at different abstraction levels:

1. **Business or mission objectives:** why the organisation is investing in a capability.
2. **Stakeholder needs:** what relevant stakeholders need to achieve or avoid.
3. **System requirements:** what the system of interest must do or satisfy.
4. **Subsystem or software requirements:** how responsibilities are allocated to constituent elements.
5. **Verification conditions:** the evidence that will demonstrate conformance.
6. **Design and implementation:** how engineers choose to realise the requirements.

These levels are related but not interchangeable. “Use PostgreSQL” is usually a design decision, not a stakeholder need. It may become a constraint if the organisation has a mandated technology platform. “Users need secure access to their files” is a need, but it is too broad to serve as a single verifiable system requirement.

### 1.1 Need, requirement, design and implementation

Consider the need: “Students must be able to share project files with their team.”

A possible set of requirements might state that the system shall allow an authenticated owner to grant access to named collaborators, allow the owner to revoke access, record access-control changes, and reject access from unauthorised principals. A design decision might choose a particular identity protocol or policy engine. An implementation task might create a permission endpoint and database migration.

The requirement should explain the required outcome and constraints without prematurely dictating a design unless the design is itself constrained by an approved architecture, standard or contract.

## 2. Requirements engineering as a life-cycle process

Requirements work is iterative. It usually includes:

- **Elicitation:** discover needs, constraints, assumptions and problems.
- **Analysis:** organise, model, classify, prioritise and resolve conflicts.
- **Specification:** express requirements in an agreed structure and level of precision.
- **Validation:** determine whether the requirements represent stakeholder needs and intended use.
- **Verification:** check whether requirement statements conform to quality rules and have sufficient evidence conditions.
- **Management:** control status, traceability, baselines, versions, changes and relationships.

These activities influence one another. A validation review may reveal a missing stakeholder. An architecture study may reveal that a requirement is infeasible. A test-design exercise may reveal ambiguity in a statement. RE should therefore continue through development and operation rather than ending at document approval.

## 3. Stakeholders and context

Before asking what the system must do, establish who has a legitimate interest and how the system fits into the existing environment.

A stakeholder register can include role, goal, influence, exposure, authority, assumptions, constraints and engagement method. A context diagram shows the system boundary and interactions with external actors or systems. A glossary defines domain-specific terms so that requirements do not use the same word with different meanings.

### 3.1 Stakeholder identification methods

Useful techniques include:

- **Document analysis:** contracts, policy, regulations, manuals, support tickets, incident reports and existing process descriptions.
- **Interviews:** structured, semi-structured or open-ended conversations with stakeholders.
- **Workshops:** group sessions to identify goals, resolve conflicts and build shared models.
- **Observation / contextual inquiry:** watching users perform real tasks to discover workarounds and unspoken needs.
- **Surveys:** collecting structured input across a large stakeholder population; useful for breadth, weaker for uncovering complex causal detail.
- **Prototyping:** using sketches, paper flows or executable prototypes to expose misunderstandings.
- **Interface analysis:** examining the behaviour and assumptions of external systems.
- **Data analysis:** using operational logs, analytics and failure records to identify patterns, with care about privacy and representativeness.

No technique is sufficient alone. Interviews may produce idealised accounts; observation may be affected by observer presence; surveys can constrain answers to the questions asked; logs capture only behaviour that the system records.

### 3.2 Asking effective elicitation questions

A good interview asks about goals, context, exceptions and evidence, not only feature requests. Useful prompts include:

- What are you trying to accomplish?
- What triggers this task?
- What information do you need before starting?
- What happens when a required item or service is unavailable?
- What do you do when the normal process fails?
- Who else is affected by this action?
- Which decisions are reversible?
- What information must be recorded for audit or later investigation?
- What would make the system unacceptable even if the main workflow worked?

Ask about current workarounds. A spreadsheet, shared mailbox or informal approval process may encode important policy that is not present in official documentation.

### 3.3 Elicitation evidence and provenance

Record where a requirement came from. Each candidate requirement should have a source such as a stakeholder interview, contract clause, regulation, incident report, architecture constraint or operational scenario. The source is not automatically correct; it records why the requirement exists and who can clarify it.

Maintain unresolved questions and assumptions separately from approved requirements. An assumption that later proves false can invalidate a large portion of the design. Assign an owner and a resolution date to important assumptions.

## 4. Analysis, models and negotiation

Analysis turns raw statements into a coherent description of the required system. It identifies conflicts, redundancy, missing information, feasibility problems, dependencies, risks and ambiguous terminology.

### 4.1 Context and use-case models

A use case describes a goal-oriented interaction between an actor and a system. It should identify the actor, trigger, preconditions, main success flow, alternate flows, exceptions and postconditions.

Example: **Share a file with a project team**

- Primary actor: file owner.
- Trigger: owner selects “Share”.
- Preconditions: owner is authenticated and has permission to manage the file.
- Main flow: owner selects collaborators, chooses access level, confirms and receives a record of the change.
- Alternate flow: collaborator is not found; owner lacks permission; policy disallows external sharing.
- Exception flow: identity service is unavailable or the change cannot be committed.
- Postcondition: access policy is updated exactly once and an auditable event is recorded.

A use case does not replace detailed requirements. It provides a structured scenario from which requirements and tests can be derived.

### 4.2 State models

State models are important when behaviour depends on an entity's current state. A file may be `private`, `shared`, `revoked`, `quarantined` or `deleted`. A reservation may be `requested`, `confirmed`, `collected`, `returned`, `cancelled` or `overdue`.

A state model should define valid states, events, guards, actions and transitions. It prevents contradictory requirements such as allowing a deleted file to be shared or allowing equipment to be both under maintenance and available for collection.

### 4.3 Data and information models

An information model defines relevant entities, relationships, identifiers, attributes, constraints, ownership and lifecycle. For example, a reservation might relate one user to one equipment item over a time interval. Requirements must state whether equipment identity is stable, whether reservation intervals are inclusive or exclusive, how time zones are handled, what data is retained and who may update it.

Data models are not simply database schemas. They represent domain meaning. A system may use relational tables, documents or events while retaining the same domain semantics.

### 4.4 Resolving conflicts

Requirements conflicts often arise because stakeholders optimise different outcomes. A finance department may want a deposit; students may need frictionless access; accessibility staff may oppose a process that creates barriers; security may want strict identity verification.

A structured negotiation process:

1. identify the exact conflict and the stakeholders affected;
2. determine whether it is a true contradiction, a different operating scenario or an ambiguity;
3. identify non-negotiable legal, safety or policy constraints;
4. generate alternatives;
5. compare consequences and residual risk;
6. obtain a decision from the correct authority;
7. record rationale and affected requirements.

Do not resolve a conflict by averaging two incompatible requirements. Often the correct solution is conditional behaviour for different operating modes or stakeholder classes.

## 5. Requirement classification and hierarchy

A useful requirements taxonomy includes:

- **Functional requirements:** capabilities, actions, transformations and observable system behaviour.
- **Quality-attribute requirements:** measurable conditions for performance, availability, security, usability, modifiability, portability, reliability, safety and other qualities.
- **Interface requirements:** exchanges with users, external systems, devices, networks and other subsystems.
- **Data requirements:** schema semantics, ownership, retention, integrity, confidentiality, quality and migration.
- **Constraints:** imposed design, technology, regulatory, contractual, physical, budgetary or schedule limits.
- **Operational requirements:** monitoring, support, maintenance, training, recovery, deployment and service management.
- **Transition requirements:** migration, coexistence, rollout, training and decommissioning needed to move from the current environment to the target system.

A requirement can belong to more than one analytical category, but classification should not become a rigid taxonomy that hides the verification condition.

## 6. Quality of an individual requirement

A strong requirement should be:

1. **Necessary:** it expresses a real need, obligation or justified constraint.
2. **Appropriate:** it is stated at the correct level of abstraction.
3. **Unambiguous:** a competent reader should interpret it consistently.
4. **Singular / atomic:** it expresses one primary obligation or condition.
5. **Complete:** it contains the information needed to understand and verify it, or references controlled definitions.
6. **Consistent:** it does not contradict other requirements or defined terminology.
7. **Feasible:** it can be achieved within technology, resources, time and external constraints.
8. **Verifiable:** there is an objective way to determine whether it is satisfied.
9. **Traceable:** it has a source and relationships to higher-level needs, design elements and verification evidence.
10. **Prioritised:** its relative importance is known.

The requirement should identify the subject, required behaviour or property, conditions and measurable threshold where necessary.

### 6.1 Avoid vague and subjective language

Words such as `fast`, `secure`, `user-friendly`, `robust`, `seamless`, `appropriate`, `minimal` and `easy` are not measurable by themselves. They can be retained as goals, but must be decomposed into observable conditions.

Weak: “The service shall respond quickly.”

Better: “Under the specified normal-load profile of 500 concurrent sessions and a defined data set, the service shall return a successful reservation response within 800 ms at the 95th percentile, excluding external identity-provider time.”

The threshold in the improved example is illustrative. A real threshold must come from stakeholder need, operational analysis and technical feasibility. A precise but unjustified number is not a good requirement.

### 6.2 Use conditions carefully

Avoid mixing multiple behaviours with `and/or`, `as appropriate` or long lists of hidden conditions. Split requirements when separate parts can pass or fail independently. Define terms such as `normal operating conditions`, `authorised user`, `business day`, `available` and `critical incident` in a glossary or referenced policy.

### 6.3 Requirement statement patterns

A disciplined statement often uses:

> The [system / element] shall [observable action or property] [under stated condition] [within measurable bound].

For event-driven requirements, specify the trigger, system response and required outcome. For continuous or quality requirements, define the operating profile, measurement point and time window.

EARS-style patterns can help structure common forms:

- **Ubiquitous:** The system shall ...
- **Event-driven:** When [event], the system shall ...
- **State-driven:** While [state], the system shall ...
- **Optional feature:** Where [feature is enabled], the system shall ...
- **Unwanted behaviour:** If [condition], then the system shall ...

These templates reduce some grammatical ambiguity, but do not guarantee correctness, feasibility or completeness.

## 7. Writing and structuring requirements

An SRS or equivalent requirements baseline should be tailored to the system. A practical structure is:

1. purpose, scope and audience;
2. product perspective and system context;
3. stakeholders and user classes;
4. operational environment and assumptions;
5. glossary and referenced policies;
6. system modes and high-level scenarios;
7. functional requirements;
8. data and interface requirements;
9. quality-attribute requirements;
10. security, privacy and safety requirements;
11. operational, deployment and transition requirements;
12. constraints and external dependencies;
13. verification approach and acceptance criteria;
14. traceability and change history.

A document should not repeat the same requirement in many places. Give requirements unique identifiers and use references to preserve a single controlled source. Avoid mixing requirements, design decisions, project tasks and test procedures in the same requirement list without clear classification.

### 7.1 Requirement attributes

Typical metadata includes identifier, statement, rationale, source, owner, status, priority, type, fit criterion, verification method, dependencies, safety/security classification, version, change history and trace links. The metadata should support actual decisions and audits. More fields do not automatically produce better requirements management.

## 8. Quality attributes and non-functional requirements

Quality attributes describe how well a system performs or behaves under defined conditions. They are often system-level properties that emerge across components. A quality-attribute requirement should have a measurable scenario.

A useful scenario structure is:

1. **Stimulus source:** who or what produces the event?
2. **Stimulus:** what event occurs?
3. **Environment:** under what operating condition?
4. **Artifact:** which system or element is affected?
5. **Response:** what should the system do?
6. **Response measure:** how will the response be measured?

Example performance scenario:

- Source: authenticated student.
- Stimulus: submits an equipment reservation request.
- Environment: normal operation at the agreed peak load.
- Artifact: reservation service.
- Response: validates eligibility, availability and booking constraints, then returns a result.
- Measure: 95% of valid requests complete within the agreed latency objective; conflicting reservations are not both committed.

Important quality areas include:

- **Performance:** latency, throughput, resource use, capacity and tail behaviour.
- **Availability:** ability to provide required service over a defined interval and operating profile.
- **Reliability:** probability of performing required functions without failure for a stated time and condition.
- **Security:** confidentiality, integrity, authentication, authorisation, accountability and resistance to threats.
- **Privacy:** lawful and appropriate collection, use, retention, disclosure and deletion of personal data.
- **Usability and accessibility:** effectiveness, efficiency, learnability and inclusive access for defined user groups.
- **Modifiability:** effort and risk of changing a system in response to a defined change.
- **Interoperability:** ability to exchange and correctly use information with other systems.
- **Safety:** freedom from unacceptable risk of harm in a defined context.
- **Maintainability and supportability:** ability to diagnose, repair, upgrade and operate the system.

Quality attributes can conflict. Stronger encryption may increase latency or operational complexity. Higher availability may require redundancy and greater cost. More customisation can improve user fit but increase maintenance burden. Requirements analysis should expose these conflicts early.

## 9. Verification, validation and acceptance criteria

**Verification** evaluates whether a requirement statement or system element meets its specified conditions. **Validation** evaluates whether the requirements and delivered system represent stakeholder needs and intended use. Requirements themselves need both.

Requirement verification can use inspections, model analysis, consistency checks, automated linting, formal analysis or review against a quality checklist. System verification may use test, demonstration, analysis and inspection. System validation uses operational scenarios, user acceptance, prototypes, pilot studies and stakeholder review.

### 9.1 Acceptance criteria

Acceptance criteria define observable conditions for accepting a requirement, feature or system increment. In agile environments they may be examples, rules, boundaries or Given/When/Then scenarios. They should cover normal cases, edge cases, error behaviour, permissions, data integrity and non-functional constraints where relevant.

Example:

**Given** an item is available and a user is eligible,  
**When** the user confirms a reservation for a valid time interval,  
**Then** the system creates one confirmed reservation, records an audit event and removes the item from conflicting availability results.

Additional scenarios should cover simultaneous requests, stale availability, duplicate submission, cancelled reservations, unavailable identity service and user ineligibility.

Acceptance criteria are not a substitute for design or implementation tests. They express expected behaviour from the stakeholder or product perspective; technical test cases may decompose them further.

### 9.2 Verification cross-reference matrix

Each requirement should map to a planned verification event and evidence. A matrix can include:

| Requirement | Verification method | Test / analysis | Acceptance criterion | Evidence |
|---|---|---|---|---|
| Prevent overlapping bookings | Test + concurrency analysis | Concurrent reservation test | At most one conflicting reservation commits | Test report and database log |
| Restrict access to owner/team | Test + security analysis | Authorisation matrix | Unauthorised requests are denied | Security test evidence |
| Preserve audit history | Test + inspection | Update/delete attempts | Required events are retained and attributable | Audit query and review |

A requirement without an identified verification approach is a warning. It may be unverifiable, poorly specified or missing necessary design constraints.

## 10. Prioritisation and release planning

Prioritisation allocates limited time, budget and attention. It should consider value, risk, dependency, urgency, regulatory obligations, uncertainty and cost.

Methods include:

- **MoSCoW:** Must, Should, Could, Won't (for this timebox).
- **Kano analysis:** basic, performance and delighter characteristics.
- **Value versus effort:** useful for preliminary release planning, but it can underweight risk and architecture work.
- **Weighted scoring:** compares alternatives using defined criteria.
- **Risk-based prioritisation:** addresses high-consequence uncertainty early.
- **Dependency-aware planning:** respects prerequisites and enabling capabilities.

A “Must” label should mean something precise, not “someone important asked for it.” Mandatory legal and safety obligations should be distinguished from stakeholder preferences.

## 11. Traceability and change management

Traceability records relationships among needs, requirements, architecture, design elements, implementation, tests, risks and evidence. It supports change impact analysis, verification completeness, audit and project communication.

Useful trace directions include:

- backward: What stakeholder need or obligation justifies this requirement?
- forward: Which design elements and tests implement or verify it?
- horizontal: Which other requirements depend on it or constrain it?
- allocation: Which system element is responsible for satisfying it?

Traceability is not a goal in itself. Excessive manual trace links become stale. Use identifiers, model relationships and automation where feasible, but review links for semantic correctness.

### 11.1 Baselines and configuration management

A baseline is an approved, controlled set of requirements or related artefacts at a point in time. A baseline allows a project to distinguish the approved scope from proposed changes. It does not mean requirements can never change.

A change request should include:

- change description and reason;
- source and affected stakeholders;
- urgency and priority;
- affected requirements and dependencies;
- architecture, implementation and test impact;
- cost, schedule and risk impact;
- privacy, safety, security and operational impact;
- decision authority and approval;
- updated versions and traceability.

### 11.2 Change impact analysis

Suppose the platform changes its reservation policy so an item can be held for a student for only 15 minutes after the start time. The change affects the reservation time model, state transitions, notifications, staff collection workflow, audit log, test cases, reporting and potentially accessibility needs. A local edit to a single requirement is insufficient.

Change impact should follow trace links in both directions. A requirement with many dependants may be architecturally significant. A requirement affecting legal or safety obligations requires the appropriate review authority.

## 12. Agile and hybrid requirements engineering

Agile delivery changes how requirements are discovered, represented and prioritised; it does not remove the need for requirements reasoning. User stories are useful for capturing user goals and supporting conversation, but a story alone may omit quality attributes, security, data retention, interface constraints and system-level behaviour.

A common story form is:

> As a [role], I want [capability], so that [benefit].

The story should be accompanied by acceptance criteria, examples, relevant constraints and links to broader requirements. Epics and features organise work, while scenarios and tests clarify behaviour.

### 12.1 Product backlog versus system baseline

A backlog is a prioritised set of work candidates. It is not automatically a complete specification or a controlled system requirement baseline. In a regulated or long-lived system, the project may need stable higher-level requirements and traceability even while lower-level backlog items evolve.

Hybrid approaches can maintain stable stakeholder and system requirements while using iterative stories, prototypes and tests to discover detailed behaviour. The degree of formality should follow risk, contractual need and system lifetime.

### 12.2 Definition of Ready and Definition of Done

A team may use a Definition of Ready to ensure a work item is sufficiently understood before implementation. It may require a clear user outcome, acceptance criteria, known dependencies, test data and design constraints. A Definition of Done can require code review, automated tests, accessibility checks, security review, documentation, observability and deployment evidence.

These are team policies, not universal standards. They should be reviewed when they create bottlenecks or allow critical quality attributes to be neglected.

## 13. Integrated case: secure file sharing

### 13.1 Initial problem

A university wants project teams to share files. Existing practice uses email attachments and public links. Incidents include unauthorised disclosure, access that remains after team membership changes, and confusion about the current document version.

The project begins with a context diagram, stakeholder interviews, policy analysis, current-state workflow observation and incident-log analysis. It should not assume that “build cloud storage” is the requirement.

### 13.2 Candidate requirements

The following are examples, not universal thresholds:

- **REQ-AUTH-01:** The system shall require a recognised identity before granting access to non-public project files.
- **REQ-AUTH-02:** The system shall evaluate access based on the current owner and collaboration policy for the file.
- **REQ-AUTH-03:** The system shall record every successful grant and revocation of file access with actor, target principal, file identifier and timestamp.
- **REQ-SHARE-01:** When an owner grants access to a named collaborator, the system shall make the file accessible to that collaborator only after the access policy change is committed.
- **REQ-SHARE-02:** The system shall provide an owner with a means to revoke collaborator access.
- **REQ-SEC-01:** The system shall deny access when the request principal does not satisfy the file's current access policy.
- **REQ-OPS-01:** The service shall provide an operational procedure for restoring file metadata and access-control records to an agreed recovery point.

Each statement needs a source, rationale, owner, priority, verification method and links to applicable policies. The quality-attribute thresholds and recovery objectives require stakeholder agreement and operational analysis.

### 13.3 Trace example

Need N-01 (team members must access current project files) derives REQ-SHARE-01 and REQ-SHARE-02. These map to access-control service and file metadata service. Verification includes positive access, denied access, revocation latency, concurrent policy update, identity-provider outage and audit review. Validation asks a representative team to complete the project-sharing workflow without unsafe workarounds.

## 14. Problem set

### Problems

**1.** Explain the difference between a need, a system requirement, an architectural decision and an implementation task. Give one example of each for a secure file-sharing system.

**2.** Identify at least eight stakeholder groups for a university equipment reservation platform. For each group, name one desired outcome and one possible conflict.

**3.** Rewrite the statement “The system shall be easy to use and secure” into at least four candidate requirements. Explain which additional stakeholder evidence is needed before choosing numerical thresholds.

**4.** Construct a state model for an equipment reservation. Include normal states, cancellation, overdue return, damage and maintenance hold. Identify invalid transitions.

**5.** Draft a six-part quality-attribute scenario for availability and one for modifiability.

**6.** Create an acceptance-test scenario for a reservation race in which two users attempt to reserve the same item for overlapping time periods.

**7.** A requirement is changed from 24-hour to 12-hour notification lead time. List the artefacts and stakeholders to inspect during impact analysis.

**8.** Explain why a user story is not a substitute for system-level security requirements.

### Solution sketches

**1.** Need: team members must collaborate on current project files. Requirement: the system shall permit an owner to grant access to named collaborators. Architecture decision: use a central policy service. Implementation task: create the `POST /shares` endpoint. Explain that the requirement should not necessarily prescribe the policy-service design.

**2.** Students, instructors, equipment staff, IT operations, identity administrators, finance, accessibility services, security, procurement and maintenance suppliers are reasonable groups. Conflicts may include convenience versus auditability, availability versus maintenance windows, accessibility versus one-size-fits-all workflows, and cost versus supportability.

**3.** Candidate statements could address keyboard navigation, screen-reader semantics, authentication, authorisation, audit logging and measurable response time. Thresholds require usability testing, accessibility needs, threat analysis, workload profiles and stakeholder agreement.

**4.** Valid transitions may include `requested → confirmed`, `confirmed → cancelled`, `confirmed → collected`, `collected → returned`, `collected → overdue`, `returned → inspection_required`, `inspection_required → available` or `maintenance`. Invalid transitions include `cancelled → collected` without an explicit recovery workflow, or `maintenance → available` without a release criterion.

**5.** Availability: source is a student; stimulus is a reservation request; environment is normal peak load with one notification dependency unavailable; artifact is the reservation service; response is to complete a valid reservation and queue notification; measure includes successful reservation rate and a defined response time. Modifiability: a policy change is requested; environment is the current supported deployment; artifact is the booking-policy component; response is an update without modifying unrelated inventory modules; measure is defined engineering time and regression impact.

**6.** Run two simultaneous requests for the same item and overlapping interval. The acceptance condition is that no more than one request reaches confirmed state, the other receives a conflict response, and the system records one authoritative outcome. Repeat under retries and duplicate submissions.

**7.** Inspect ConOps, notification requirements, user expectations, time-zone handling, state transitions, templates, scheduled-job design, load profile, test data, operational support, external communication and any regulatory or contractual obligations.

**8.** A story may capture one user goal but omit cross-cutting requirements such as identity assurance, audit retention, data privacy, revocation, threat handling, availability and administrative access. These apply across multiple stories and need explicit system-level treatment.

## 15. Practical assignment

Prepare an SRS for a campus equipment reservation platform. Deliver:

1. problem statement, context diagram and stakeholder register;
2. elicitation plan and evidence log;
3. needs list and requirements hierarchy;
4. functional and quality-attribute requirements;
5. use-case descriptions and state model;
6. data/interface requirements and glossary;
7. quality-attribute scenarios;
8. acceptance criteria and verification cross-reference matrix;
9. traceability matrix;
10. change request and impact-analysis example;
11. review log showing how ambiguous, conflicting or infeasible requirements were resolved.

## Further reading and primary course materials

- Klaus Pohl, *Requirements Engineering: Fundamentals, Principles, and Techniques*, 2nd ed. (2025). Comprehensive reference; consult publisher or library access.
- Karl Wiegers and Joy Beatty, *Software Requirements*, 3rd ed. (2013). Practical software RE reference.
- [IREB Certified Professional for Requirements Engineering](https://cpre.ireb.org/en): syllabuses and professional body material.
- DTU / Ludwig-Maximilians-Universität, [RED requirements engineering teaching material](https://www.pst.ifi.lmu.de/~stoerrle/RED/teaching.html): openly licensed lecture slides and 13-chapter course structure.
- Gothenburg course material, [Requirements Engineering Course Material for First-Year Software Engineering Students](https://ceur-ws.org/Vol-2857/openre2.pdf), with teaching resources referenced in the paper.
- [NASA Formal Requirements Elicitation Tool (FRET)](https://github.com/NASA-SW-VnV/fret): formalisation and analysis support.
- ISO, [ISO/IEC/IEEE 29148:2018](https://www.iso.org/standard/72089.html): requirements engineering processes and information items. The published 2018 edition should be distinguished from any later draft edition; verify status before contractual use.
- [SEBoK](https://sebokwiki.org/): system requirements and life-cycle context.


---

# Advanced lecture notes and worked extensions

## 16. Formalising requirements without losing stakeholder meaning

Natural-language requirements are accessible to stakeholders but can be ambiguous. Formal methods can reduce ambiguity for selected high-consequence properties, but formal notation also introduces assumptions and a learning cost. The objective is not to formalise every sentence; it is to formalise the behaviours where precision has a high value.

A useful progression is:

1. describe the stakeholder goal in ordinary language;
2. model context, actors and operating scenarios;
3. identify states, events and invariants;
4. write testable natural-language requirements;
5. formalise selected properties where logic or concurrency makes ambiguity dangerous;
6. connect the formal model to verification evidence.

For a reservation service, an invariant can be expressed informally as: “No two confirmed reservations for the same item may overlap.” A mathematical form is:

\[
\forall r_i,r_j,\quad (r_i\neq r_j\land r_i.item=r_j.item\land Confirmed(r_i)\land Confirmed(r_j))\Rightarrow (r_i.end\leq r_j.start\lor r_j.end\leq r_i.start)
\]

This statement clarifies the domain but still leaves questions: are interval endpoints inclusive, what is the time-zone basis, how are cancelled reservations treated, and what does “confirmed” mean during a failed transaction? Formalisation reveals questions; it does not automatically answer them.

## 17. State, event and temporal requirements

Requirements that describe a changing object should define legal state transitions. For each transition specify:

- source state;
- triggering event;
- guard condition;
- resulting state;
- action or side effect;
- audit evidence;
- failure and retry behaviour.

A reservation may move from `requested` to `confirmed` only if eligibility and availability checks pass and the authoritative transaction commits. A notification failure should not necessarily reverse the reservation. A cancellation after collection may be invalid or require a return workflow. These rules should be explicit.

Temporal requirements describe when something must happen, how long a state may persist or how quickly the system must respond. A statement such as “notify users promptly” must become a threshold and measurement definition, for example a percentile of time from committed reservation to notification-provider acceptance. The system should distinguish provider acceptance from final email delivery.

## 18. Requirements for security and privacy

Security requirements should be derived from assets, threats, trust boundaries, policies and misuse cases. Important areas include:

- identity proofing and authentication strength;
- service-to-service authentication;
- authorisation and least privilege;
- session handling and revocation;
- input validation and abuse prevention;
- audit event integrity and retention;
- data confidentiality and integrity;
- key and secret management;
- vulnerability and dependency management;
- incident detection and response.

Privacy requirements should state the purpose for which data is collected, the minimum necessary data, access roles, retention schedule, correction and deletion behaviour, disclosure controls and audit requirements. “Comply with privacy law” is a high-level obligation, not a testable system requirement. It must be translated into the applicable jurisdiction and policy context by qualified stakeholders.

## 19. Requirements completeness and consistency analysis

A requirements set can contain individually well-written statements and still be incomplete or inconsistent. Review at the set level:

- Are all operational modes covered?
- Are normal, degraded and exceptional cases represented?
- Are all relevant user classes and administrative roles represented?
- Are interfaces and data dependencies defined?
- Are quality requirements quantified?
- Are assumptions and constraints explicit?
- Do requirements contradict one another?
- Are there duplicated obligations with different thresholds?
- Are there unowned responsibilities between systems?
- Is every stakeholder need addressed or explicitly deferred?

Use tables, models and automated checks to make gaps visible. Automated requirement linting can identify missing identifiers, prohibited vague words, missing rationale or missing verification fields. It cannot prove that the requirement is necessary or correct.

## 20. A worked SRS fragment: equipment reservation

### 20.1 Scope and context

The reservation subsystem manages requests for uniquely identified equipment items. It integrates with identity, inventory, maintenance and notification services. It does not itself determine the university's eligibility policy; it consumes an approved eligibility result.

### 20.2 Functional requirements

- **RSV-001:** The reservation service shall accept a reservation request containing a user identity, equipment identifier and start/end timestamps.
- **RSV-002:** The reservation service shall reject a request when the equipment identifier does not identify an active inventory item.
- **RSV-003:** The reservation service shall reject a request when the eligibility service returns an explicit ineligible result.
- **RSV-004:** The reservation service shall create a confirmed reservation only when the equipment is eligible for reservation and no conflicting confirmed reservation exists for the requested interval.
- **RSV-005:** The reservation service shall assign a unique reservation identifier to each committed reservation.
- **RSV-006:** The reservation service shall record the actor, time, operation and outcome for each reservation state change.
- **RSV-007:** The reservation service shall provide an authorised cancellation operation for reservations that have not entered a state in which cancellation is prohibited.

### 20.3 Quality and interface requirements

- **QOS-001:** Under the agreed normal workload profile, the reservation service shall complete the defined valid reservation request within the approved p95 latency target.
- **QOS-002:** The system shall preserve the no-overlap reservation invariant during concurrent reservation attempts.
- **SEC-001:** The service shall reject reservation modification requests from principals that do not have the required permission for the target reservation.
- **AUD-001:** Reservation state changes shall be retained in the audit record according to the approved retention policy.
- **INT-001:** The reservation service shall treat an identity-provider timeout as an indeterminate or unavailable eligibility result and shall not infer eligibility from the absence of a response.

Thresholds, load profiles and retention periods must be agreed with stakeholders. This fragment deliberately avoids inventing those numbers.

### 20.4 Acceptance criteria

For RSV-004:

1. Given an item with no conflicting confirmed reservation and an eligible user, when the user submits a valid interval, then exactly one confirmed reservation is committed.
2. Given an item with an overlapping confirmed reservation, when another user submits a conflicting interval, then the request is rejected with a conflict outcome.
3. Given two concurrent conflicting requests, when both are submitted, then no more than one reaches confirmed state.
4. Given the same idempotency key and the same request payload is submitted again, then the system returns the prior logical result without creating a second reservation.
5. Given an identity-provider timeout, when the request requires fresh eligibility, then the system does not create a confirmed reservation.

### 20.5 Traceability sample

Need N-01 (users must be able to reserve equipment required for scheduled work) derives RSV-001 through RSV-005. The no-overlap invariant is linked to the reservation transaction design, database constraint or serialisation strategy and concurrent integration test. Audit need is linked to RSV-006 and AUD-001, log integrity controls and retention verification.

## 21. Change impact as graph traversal

Traceability can be viewed as a graph. Nodes represent needs, requirements, models, architecture elements, code modules, tests, risks and evidence. Edges represent derivation, allocation, satisfaction, verification, dependency or change.

A change to a node should trigger review of connected nodes. The graph traversal is not fully automatic: an engineer must interpret semantic relationships. For example, changing the reservation time-zone policy may affect data models, API schemas, client display, daylight-saving handling, reports, notifications, database constraints and integration tests.

A change impact report should identify direct dependants, indirect dependants, affected stakeholders, regression risk and any links that are missing or stale.

## 22. Extended review questions

1. How can formalisation reveal missing requirements rather than simply make a statement look mathematical?
2. Why should security and privacy requirements be represented across the system rather than as one late-stage checklist?
3. What does it mean for a requirements set to be complete enough for a design review?
4. How would you detect a gap between a stakeholder need and the system verification matrix?
5. Why can high automated test coverage coexist with poor requirements quality?
6. What is the difference between a change request being implemented and the change being verified and validated?
## 23. Elicitation strategy: triangulate evidence, do not just collect opinions

Elicitation is an investigation into the problem, context, stakeholders, goals, constraints and candidate solution space. No single technique reliably reveals all requirements. Interviews reveal individual goals and concerns; observation reveals workarounds and hidden tasks; document analysis reveals policy and existing contracts; workshops expose disagreements; prototypes reveal interaction issues; operational data reveal frequency and failure patterns.

### 23.1 Select the technique for the uncertainty

| Uncertainty | Useful technique | Main risk to control |
|---|---|---|
| Users describe a task differently | Contextual interview and observation | Treating one user's process as universal |
| Policy is unclear | Document analysis plus policy-owner workshop | Assuming an outdated document is authoritative |
| Users cannot articulate interface needs | Low-fidelity prototype and task walkthrough | Mistaking reactions to a mock-up for validated policy |
| Stakeholders disagree on outcomes | Goal modelling and facilitated negotiation | Allowing hierarchy to silence legitimate constraints |
| Existing workflow has many exceptions | Event/log analysis and exception sampling | Missing rare but safety-critical cases |
| External system behaviour is uncertain | Interface-owner interview and contract analysis | Designing to undocumented assumptions |

A good elicitation plan states the question being investigated, the stakeholder or evidence source, the technique, the expected artefact and how conflicting evidence will be resolved. Keep a provenance record: who supplied the information, when, in what context and with what confidence.

### 23.2 Worked example — equipment return workflow

A user says: “I return the equipment at the desk.” Observation shows that users sometimes leave equipment in a secure drop box after hours. Staff then inspect the item the next morning, update condition and quarantine damaged equipment. The actual process includes a physical custody transfer, an after-hours state, inspection and exception handling. A single interview would likely miss these branches.

Model the workflow as states and events before writing requirements. Possible states include `checked_out`, `return_pending_inspection`, `available`, `quarantined` and `maintenance`. The event `drop_box_deposit` does not necessarily imply that the item is immediately available to another borrower. This distinction affects inventory semantics, user notifications, staff responsibilities and audit evidence.

## 24. Requirements quality assurance at the statement and set levels

An individual requirement should be necessary, singular, unambiguous, feasible, verifiable, traceable and consistent with the agreed scope. Where appropriate, it should avoid prescribing a design prematurely. These are review criteria, not a mechanical score that proves quality.

| Criterion | Review question | Typical defect |
|---|---|---|
| Necessary | Which stakeholder need, constraint or risk justifies it? | “Nice-to-have” requirement with no rationale |
| Atomic | Does it express one obligation? | Multiple independent behaviours joined by “and” |
| Unambiguous | Would two reviewers derive the same interpretation? | “Quickly”, “user-friendly”, “as needed” |
| Verifiable | Can inspection, analysis, demonstration or test produce evidence? | “The system shall be robust” |
| Feasible | Is it achievable under stated resource and environment constraints? | Impossible response target under unmodelled load |
| Traceable | Is its source and downstream satisfaction path known? | Orphan requirement |
| Consistent | Does it conflict with another requirement or policy? | Contradictory retention periods |
| Implementation-independent | Does it state the required outcome rather than an unneeded mechanism? | Naming a specific database without an approved constraint |

### 24.1 Review a set, not just the sentences

A complete-looking list can still omit normal, degraded and recovery modes. Review the set for stakeholder coverage, operating modes, boundary conditions, data life cycle, external interfaces, access-control roles, quality attributes, exception handling, monitoring, migration and retirement. Look for conflicting requirements, duplicated obligations, missing ownership and unsupported assumptions.

A useful completeness matrix has rows for stakeholders or system modes and columns for function, data, interface, security, performance, availability, usability, audit, support and recovery. Mark each cell as addressed, not applicable with rationale, or unresolved. Blank cells are prompts for investigation, not automatic proof of a defect.

### 24.2 Requirements linting and human review

Automated linting can flag missing IDs, missing rationale, vague terms, compound statements, unbounded quantities, missing verification methods and broken trace links. It cannot decide whether the requirement is necessary, whether a stakeholder was omitted, or whether a quality target reflects actual value. Use tools for repeatable checks and human review for semantic validity.

## 25. Requirements-based test derivation

Every high-priority requirement should have a verification strategy before implementation is complete. The verification method determines the evidence: inspection, analysis, demonstration or test. A requirement that cannot be verified with the planned method should be rewritten, refined or explicitly accepted as a qualitative design objective.

For a stateful feature, derive tests from the transition model:

1. one test for each allowed transition;
2. one test for each prohibited transition;
3. boundary-value tests for guards and time limits;
4. tests for repeated and duplicate events;
5. tests for failures between state change and external side effect;
6. tests for authorisation and audit requirements;
7. tests for recovery and reconciliation.

**Worked trace:** `RSV-004` requires that a reservation be confirmed only if no conflicting confirmed reservation exists. The verification strategy includes a single valid request, a single conflicting request, two simultaneous conflicting requests, duplicate submission after a lost response, a transaction rollback, and reconciliation after an ambiguous outcome. The acceptance criterion is not “the API returns 201”; the actual invariant is that no two conflicting reservations become confirmed.

## 26. Additional examination problems

1. Choose elicitation techniques for discovering hidden after-hours equipment returns. State the uncertainty each technique reduces and its bias risk.
2. Review the sentence “The platform shall quickly notify all users when equipment is available.” Identify the missing definitions and rewrite it as a verifiable requirement while clearly labelling assumed thresholds.
3. Construct a completeness matrix for normal borrowing, after-hours return, damaged-item quarantine and identity-provider outage.
4. Explain why a requirement linting tool can improve consistency but cannot validate stakeholder intent.


## 27. Sustainability requirements as system requirements

Sustainability is not a decorative non-functional requirement appended at the end of a specification. It changes the system boundary, stakeholder set, life-cycle model, architecture, procurement criteria, operational metrics and retirement obligations. A sustainability requirement should identify the impact, life-cycle stage, affected stakeholder or resource, operating condition, measurable threshold and evidence method.

A useful analysis distinguishes at least three dimensions:

- **Environmental:** energy use, greenhouse-gas emissions, water, material consumption, repairability, e-waste, logistics and end-of-life treatment.
- **Social:** accessibility, safety, inclusion, worker impacts, service availability across user groups, privacy and distribution of benefits/burdens.
- **Economic:** total cost of ownership, maintainability, useful life, supply-chain resilience and the cost of keeping the system operational.

These dimensions can conflict. A longer retention period may improve auditability but increase storage, energy and privacy exposure. A high-availability architecture may increase resource use. A low-cost device may have a short useful life or inaccessible interface. Requirements engineering must make these trade-offs explicit and obtain decisions from accountable stakeholders.

### 27.1 From sustainability goal to verifiable requirement

A weak goal is “the platform shall be environmentally friendly.” A stronger candidate requirement is:

> For the defined production workload and measurement boundary, the service shall report energy consumed per 1,000 successfully completed reservation transactions over a rolling 30-day period, with infrastructure and measurement method documented.

This is measurable but is not yet a target. Stakeholders must establish a justified threshold using a baseline, procurement constraints, life-cycle context and a feasible measurement method. Do not invent a performance target simply to make the sentence look verifiable.

For social sustainability, an example is:

> For each supported user group in the agreed accessibility test plan, the reservation workflow shall allow completion of the critical booking and cancellation tasks using the documented assistive-technology combinations, with no critical task-blocking defect.

This is a testable acceptance condition, but its sufficiency depends on representative users, assistive technologies and task selection. A checklist-only evaluation is not equivalent to validation with affected users.

For economic sustainability, an example is a requirement to publish a supported export format and migration procedure before service retirement, with a defined maximum transition period and verified data integrity. This addresses exit cost and vendor dependence rather than only initial purchase cost.

### 27.2 Sustainability traceability

Extend the requirements traceability matrix with impact category, life-cycle phase, affected stakeholder, measurement boundary, baseline, target source, evidence method and residual uncertainty. A sustainability claim without a defined boundary is not comparable: “energy per transaction” can change depending on whether it includes idle infrastructure, identity providers, data storage, network transfer or end-user devices.

## 28. Current syllabus alignment and responsible use of standards

The course is not an IREB certification preparation course, but its foundation topics can be cross-checked against IREB syllabi. As checked on 21 November 2026, the official IREB download centre lists the **CPRE Foundation Level syllabus v3.3.0** and the **RE@Agile syllabus v2.3.0**. These should be used as current cross-reference baselines for topic coverage, not as a claim that this course satisfies every training-hour, examination or certification requirement.

| Course topic | CPRE Foundation Level v3.3.0 cross-reference | RE@Agile v2.3.0 cross-reference |
|---|---|---|
| Requirements basics, value and principles | Terms, requirements types, RE process and principles | Agile requirements context and principles |
| Stakeholders, context and elicitation | Context, stakeholder identification and elicitation | Collaborative discovery, stakeholder involvement and feedback |
| Documentation and quality | Natural-language requirements, documentation and quality criteria | Backlog items, acceptance criteria and agile documentation |
| Modelling and analysis | Requirements modelling, analysis and validation | Models and examples used at an appropriate agile level |
| Prioritisation and negotiation | Prioritisation, conflicts and negotiation | Value, prioritisation, refinement and planning |
| Validation and management | Validation, traceability, change and requirements management | Continuous validation, evolving requirements and change |

This mapping is a thematic crosswalk, not a clause-by-clause certification map. The learner should consult the official syllabus outcomes and glossary directly before using it for exam preparation. IREB's syllabus may change; re-check the official download page before a future cohort.

**Official references:** [IREB CPRE Downloads and Resources](https://cpre.ireb.org/en/downloads-and-resources/downloads); [CPRE Foundation Level syllabus v3.3.0](https://hub.ireb.org/media/pages/resources/cpre-foundation-level-syllabus/9c084b1cfd-1787039954/cpre_foundationlevel_syllabus_en_v.3.3.0.pdf); [RE@Agile syllabus v2.3.0](https://hub.ireb.org/media/pages/resources/cpre-re-agile-syllabus/9867656237-1787039983/syllabus_cpre_al_re%40agile_it_2.3.pdf); [ISO/IEC/IEEE 29148:2018 status page](https://www.iso.org/standard/72089.html). The ISO page lists the 2018 edition as current while also flagging a draft replacement process; verify the status and edition before a contractual or compliance decision.

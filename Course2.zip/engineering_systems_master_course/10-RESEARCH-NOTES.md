# Research Notes, Source Evaluation and Provenance

**Research date:** 21 November 2026  
**Programme scope:** six university-style study courses in systems thinking, systems engineering, requirements engineering, software system design/distributed systems, software architecture/trade-off analysis, and reliability/SRE/incident response.

This file documents how the external resources were found and checked. It is not a substitute for the teaching texts. The course documents are original instructional synthesis; they do not reproduce substantial sections of commercial textbooks, paywalled standards or third-party lecture slides.

## 1. Research questions

The research pass looked for more than textbooks and course titles. For each of the six courses, it considered:

- Canonical books and handbooks, with authors, editions and access conditions.
- Full university courseware: syllabus, lecture recordings, notes, assignments, problem sets, labs and projects.
- Open textbooks and educational resources.
- Professional bodies, standards catalogues and bodies of knowledge.
- Official technical documentation for implementation-dependent topics.
- Interactive tools, simulation environments and practical repositories.
- Seminal papers and practitioner case studies.
- Free lecture/video series and conference tutorials where they add real instructional value.

The purpose was to identify sources that can support a rigorous curriculum and to check topic coverage. Resource discovery alone does not prove that the resulting course text is correct or complete; technical claims are therefore written from established concepts and checked against primary references where appropriate.

## 2. Tools and sources used

### EFT research sequence

The user's requested EFT workflow is Exa → Firecrawl → TinyFish. All three stages were completed in this research cycle:

1. **Exa:** searched by topic and by resource type, using an alternate connected profile. Search workstreams targeted textbooks, university courseware, lectures, software engineering curricula, systems engineering handbooks, requirements-engineering teaching packs, distributed-systems labs, architecture evaluation and reliability/SRE resources.
2. **Firecrawl:** searched and extracted selected primary pages, including FMHY Educational, MIT 15.871, MIT 16.842, Edinburgh distributed systems material, Brown CS1380 lecture schedule, and Google SRE Classroom. It was also used for targeted requirements-engineering and architecture discovery.
3. **TinyFish:** the previously queued deep-research job completed and its report was retrieved and reviewed. The run ID was `01a1fd4c-292d-763f-b8b8-424eb3ef1bd7`. It produced a cross-topic resource landscape with source references, access labels, course outlines, gaps and a suggested study sequence. It was used as a discovery/synthesis input, not as a substitute for checking primary sources.

### Context7 technical documentation

Context7 was resolved to official documentation sources and used for four implementation-sensitive topics:

| Library/source | Topics queried | How it informs the teaching material |
|---|---|---|
| [PostgreSQL documentation](https://www.postgresql.org/docs/current/) | MVCC, concurrency control, WAL, replication, backup, continuous archiving and point-in-time recovery | Course IV database correctness and Course VI recovery concepts |
| [Apache Kafka documentation](https://kafka.apache.org/documentation/) | Partition replication, producer idempotence, transactions, processing guarantees and consumer offsets | Course IV message delivery and exactly-once scope |
| [Kubernetes documentation](https://kubernetes.io/docs/) | Startup/liveness/readiness probes, resources, StatefulSets and disruption concepts | Course IV service deployment and Course VI operational resilience |
| [OpenTelemetry documentation](https://opentelemetry.io/docs/) | Metrics, traces, logs, context propagation, semantic conventions and Collector | Course IV observability and Course VI SRE practice |

Important nuances preserved in the course text:

- Kafka idempotence and transactions provide guarantees within Kafka's defined producer/consumer/Streams scope; arbitrary external database or business side effects are not magically part of the Kafka transaction.
- PostgreSQL point-in-time recovery depends on a usable base backup and a continuous required WAL archive chain; recovery needs to be tested.
- Kubernetes readiness, liveness and startup probes serve different purposes. A readiness failure removes an instance from service endpoints; liveness is a restart decision and should not be made dependent on every external dependency.
- OpenTelemetry standardises telemetry APIs, SDKs, protocols, components and conventions. It is not itself the long-term metrics/logs/traces backend or dashboard product.

## 3. Course coverage and principal academic anchors

### Course I — Systems Thinking and System Dynamics

- **MIT 15.871, Introduction to System Dynamics (Fall 2013):** core course anchor. Its course material includes systems-thinking and modelling content, problem sets, case studies, downloadable files and video material. [Course](https://ocw.mit.edu/courses/15-871-introduction-to-system-dynamics-fall-2013/)
- **MIT 15.879, Building Serious System Dynamics Models from Scratch (Spring 2025):** advanced modelling complement with ten listed session videos, weekly lecture notes, programming assignments, selected solutions, model files and student projects. [Course](https://ocw.mit.edu/courses/15-879-building-serious-system-dynamics-models-from-scratch-spring-2025/)
- **John Sterman, Business Dynamics:** advanced textbook anchor for formal system dynamics modelling. It is a commercial/library text, not reproduced in the notes. [Author's faculty page](https://mitmgmtfaculty.mit.edu/jsterman/business-dynamics/)
- **Donella Meadows, Thinking in Systems:** conceptual foundation for feedback, stock/flow thinking, leverage points and systems traps. [Publisher](https://www.chelseagreen.com/product/thinking-in-systems/)
- **System Dynamics Society learning road maps:** progressive free exercises for feedback, stock-flow structures, delays, model testing and sensitivity. [Road maps](https://systemdynamics.org/learning/road-maps/)

### Course II — Systems Engineering Fundamentals

- **MIT 16.842, Fundamentals of Systems Engineering (Fall 2015):** graduate-level course covering stakeholder analysis, requirements, system modelling languages, architecture, concept generation, tradespace, integration, V&V, commissioning and operations. Its materials include lecture videos, notes and design projects. [Course](https://ocw.mit.edu/courses/16-842-fundamentals-of-systems-engineering-fall-2015/)
- **NASA Systems Engineering Handbook:** official lifecycle and technical-process reference, including requirements, architecture, integration, verification and validation. [NASA Handbook](https://www.nasa.gov/reference/systems-engineering-handbook/)
- **SEBoK:** stewarded body of knowledge for system life-cycle processes, systems science, architecture, MBSE and related disciplines. [SEBoK](https://sebokwiki.org/)
- **INCOSE Systems Engineering Handbook, 5th edition:** authoritative practitioner reference; publisher/member access conditions may apply. [INCOSE page](https://www.incose.org/resources-publications/technical-publications/se-handbook/)

### Course III — Requirements Engineering

- **IREB CPRE:** professional syllabus and learning objectives provide a structured map for elicitation, analysis, specification, validation and management. Certification is paid; syllabus and some learning material are publicly accessible. [IREB](https://cpre.ireb.org/en)
- **DTU Requirements Engineering course / RED teaching resources:** published lecture material and course outline cover elicitation, stakeholder goals, context, requirements quality, feature and quality-attribute specification, modelling, transition to design and requirements management. The teaching slides are stated to be Apache 2.0 licensed on the teaching page. [Teaching material](https://www.pst.ifi.lmu.de/~stoerrle/RED/teaching.html)
- **Gothenburg requirements-engineering and UX teaching pack:** the course paper describes lecture slides, modelling exercises, case descriptions and assignments for DIT045/DAT355. The online teaching artefacts are described as CC BY-NC 4.0; verify the individual Zenodo record metadata before redistribution. [Course paper](https://ceur-ws.org/Vol-2857/openre2.pdf) · [Associated resource DOI](https://doi.org/10.5281/zenodo.4621264)
- **Chalmers/LUT Open RE course:** a separate semester-long graduate course with public YouTube lectures, slides, readings and team assignments to produce a requirements specification. The teaching materials are described by the authors as CC BY-SA 4.0. [Course paper](https://ceur-ws.org/Vol-2857/openre1.pdf) · [FOSS2Serve portal](https://foss2serve.org/).
- **ISO/IEC/IEEE 29148:** used as a standards reference, not reproduced. As of the research date, the 2018 edition was the current published version checked; the third-edition DIS draft was not yet a published replacement. [Published edition](https://www.iso.org/standard/72089.html) · [Draft record](https://www.iso.org/standard/94091.html)

### Course IV — Software System Design and Distributed Systems

- **MIT 6.5840 Distributed Systems:** programming-oriented distributed systems course with labs and papers. [Course](https://pdos.csail.mit.edu/6.824/)
- **Brown CS1380 Distributed Systems (Spring 2023):** public lecture notes and recordings on time/order, replication, consistency, partitioning, consensus, distributed processing, transactions and Byzantine fault tolerance. [Lecture schedule](https://cs.brown.edu/courses/cs138/s23/lectures.html)
- **University of Edinburgh Distributed Systems:** course outline on architecture, RPC, fault tolerance, causality, distributed transactions, consistency, replication and storage. The page is an outline, not a complete open course. [Course outline](https://opencourse.inf.ed.ac.uk/ds)
- **Designing Data-Intensive Applications, 2nd edition:** advanced commercial textbook reference for data models, storage, replication, transactions, distributed systems, batch/streaming and governance. [Publisher](https://www.oreilly.com/library/view/designing-data-intensive-applications/9781098119058/)
- **System Design Primer:** practical catalogue of system design topics and design questions. Use it as a supplementary exercise source, not as the formal theory text. [Repository](https://github.com/donnemartin/system-design-primer)

### Course V — Software Architecture and Trade-off Analysis

- **CMU Software Architecture courses (2026):** current course outline and lecture material on architectural drivers, patterns, tactics, documenting views, design alternatives and evaluation. [Syllabus](https://mse.s3d.cmu.edu/0_documents/syllabi/17633-software-architectures-syllabus-2026.pdf)
- **CMU SEI Architecture Tradeoff Analysis Method collection:** free technical reports on ATAM, architecture quality attributes, risk, trade-offs and evaluation. [Collection](https://www.sei.cmu.edu/library/architecture-tradeoff-analysis-method-collection/)
- **Software Architecture in Practice, 4th edition:** principal commercial textbook reference for quality attributes, architecture tactics, ADD and evaluation. [Publisher](https://www.informit.com/store/software-architecture-in-practice-9780136886099)
- **C4 Model:** original author's open reference for context, container, component and code views. [C4](https://c4model.com/)
- **arc42:** open architecture documentation template and guidance. [arc42](https://docs.arc42.org/home/)
- **Architecture Decision Records:** open templates and community practice. [ADR resources](https://adr.github.io/)

### Course VI — Reliability Engineering, SRE and Incident Response

- **Google SRE Classroom:** hands-on workshops for large-scale system design, distributed PubSub, ImageServer and SLOs. The classroom page identifies CC BY 4.0 licensing for these materials. [SRE Classroom](https://sre.google/classroom/)
- **Google SRE book and Workbook:** online text with operational guidance for SLOs, monitoring, incidents, postmortems and production practices. [SRE book](https://sre.google/sre-book/table-of-contents/) · [Workbook](https://sre.google/workbook/table-of-contents/)
- **Google Site Reliability Engineering, 2nd edition (2026):** newer commercial textbook/reference; it should not be confused with the earlier freely readable online edition. [Google SRE books page](https://sre.google/books/)
- **Practical Reliability Engineering, 6th edition:** paid/library reference for reliability estimation, life-data analysis, maintainability, testing and reliability engineering methods. [Wiley](https://www.wiley.com/-p-9781394199969)
- **Python reliability library:** open documentation and computational methods for reliability distributions, Weibull analysis and reliability models. [Documentation](https://reliability.readthedocs.io/)
- **NIST SP 800-61 Rev. 3:** cybersecurity incident-response guidance; relevant to security incident handling but narrower than general operational incident management. [NIST publication](https://csrc.nist.gov/pubs/sp/800/61/r3/final)

## 4. FMHY inspection and use policy

The [FMHY Educational page](https://fmhy.net/educational) was fetched directly. It lists legitimate learning discovery routes such as MIT OpenCourseWare, edX, Khan Academy, Gresham College, OpenLearn, Saylor Academy, CMU Open Learning Initiative, OpenHPI, Yale Courses, VideoLectures.net, Class Central and OpenCulture. It also points to general learning indexes and programming-learning resources.

FMHY's page has a separate “Downloading” section that includes torrent and course-copy/access-bypass routes. Those are not appropriate sources for this course and are explicitly excluded. The resource library links directly to official course, university, author, publisher or project-maintainer pages rather than mirrors. FMHY is treated as a discovery index, not a quality-assurance authority.

## 5. Quality-evaluation method

Resources were favoured when they had one or more of the following:

- Institutional, government, standards-body, professional-society, original-author or project-maintainer provenance.
- Explicit syllabus or table of contents that maps to course outcomes.
- Lecture notes, recorded lectures, problem sets, worked examples, code labs, projects or case studies.
- Clear edition, date, version and access conditions.
- Technical explanations that discuss assumptions and limitations rather than only promoting a technology or framework.

Search-result snippets and deep-research summaries were used to find resources. The strongest anchors were then checked against the corresponding primary course, official documentation, publisher, or standards page when available. A syllabus-only page is labelled as such; it is not presented as a full course. A public webpage is not assumed to be freely redistributable.

## 6. Known resource gaps

Several subjects have excellent free university courseware, but not a complete free textbook equivalent at the depth of the leading commercial reference:

- Systems dynamics: MIT course materials are excellent; Sterman's *Business Dynamics* remains a deeper integrated text.
- Requirements engineering: open course packs and professional syllabuses exist, but no single free text was identified that replaces all of the canonical books.
- Data-intensive systems: public lectures, labs and papers are strong; *Designing Data-Intensive Applications* remains a useful integrated reference, but it is commercial.
- Software architecture: C4, arc42, ADRs and SEI ATAM reports are free; comprehensive treatment of quality-attribute tactics and ADD is stronger in *Software Architecture in Practice*.
- Classical reliability engineering: free computational libraries and online references help, but advanced FMEA/FTA/Weibull/life-data theory is still well served by commercial/library texts.

The programme therefore teaches foundational theory directly and uses open materials where possible, while clearly marking where library access to a commercial reference is beneficial.

## 7. Limitations

- This is a curated, evidence-backed selection, not a claim that every resource on the Internet has been found.
- The TinyFish report was used as broad discovery and synthesis. Not every URL it mentioned was independently deep-read.
- Some course pages expose only older offerings. Their conceptual content remains useful, but software versions and operational practices must be checked against current official documentation.
- Standards are linked for identification and scope; their normative text may require purchase or institutional access.
- “Free to read” does not automatically mean “free to redistribute”. Respect each source's licence and attribution conditions.
- The six course texts are original instructional synthesis for independent study. They are not accredited university modules and do not confer credit.


## 8. Deep academic audit and technical verification (21 November 2026)

### EFT follow-up

The follow-up audit used the user's EFT sequence: Exa for broad targeted discovery; Firecrawl for current primary-source search and direct-page extraction; TinyFish for a cross-source research report and a follow-up academic-audit run. The prior TinyFish landscape report was retrieved from the correct connected profile. A new audit run was submitted as a continuation of that report; its output was not yet available to this revision, so this package does not attribute any claims to that pending run. Core revisions below are based on directly inspected source content.

### University teaching benchmarks inspected

- **MIT 15.871, Fall 2013:** graduate introduction to system dynamics; assignment requires documentation of diagrams/equations, variable definitions, parameter sources, link polarities, loop names, units and dimensional consistency. https://ocw.mit.edu/courses/15-871-introduction-to-system-dynamics-fall-2013/
- **MIT 15.879, Spring 2025:** graduate “Building Serious System Dynamics Models from Scratch”; used as an advanced practical benchmark. https://ocw.mit.edu/courses/15-879-building-serious-system-dynamics-models-from-scratch-spring-2025/
- **MIT 15.879 Research Seminar, Spring 2014:** syllabus explicitly lists model critique, sensitivity/Monte Carlo, optimisation, model calibration and parameter estimation. https://ocw.mit.edu/courses/15-879-research-seminar-in-system-dynamics-spring-2014/pages/syllabus/
- **NASA Systems Engineering Handbook, NASA/SP-2016-6105 Rev. 2:** checked the official handbook contents, including stakeholder expectations, requirements definition, logical decomposition, design solution, integration, verification, validation, transition and technical management. https://essp.larc.nasa.gov/EVI-6/pdf_files/NASA_SystemsEngineeringHandbookRev2.pdf
- **OMG SysML:** official OMG page identifies SysML 2.0 as formal and published September 2025; SysML 1.7 was published June 2024. https://www.omg.org/spec/SysML/2.0/About-SysML
- **DTU RED / Requirements Engineering 02264:** public teaching page lists 13 course chapters, extensive practical exercises, and an Apache 2.0 licence for the public slide materials. The page distinguishes public materials from the full restricted course page. https://www.pst.ifi.lmu.de/~stoerrle/RED/teaching.html
- **OpenRE course materials paper:** describes open requirements-engineering teaching artifacts including lectures, assignments and exercises. https://ceur-ws.org/Vol-2857/openre2.pdf
- **MIT 6.5840, Spring 2026:** 12-unit graduate distributed systems course; current public site lists five cumulative labs, optional project, midterm and final; course prerequisites are explicit. https://pdos.csail.mit.edu/6.824/
- **Brown CS1380, Spring 2023:** archived lecture materials used as supplementary coverage of distributed time, snapshots, consensus, transactions and Byzantine fault tolerance. https://cs.brown.edu/courses/cs138/s23/lectures.html
- **CMU 17-635, Spring 2026:** public architecture syllabus inspected for quality-attribute scenarios, tactics/patterns, architecture views and grade structure (60% individual homework, 30% recitations, 10% participation). Full course content is behind CMU course access. https://mse.s3d.cmu.edu/0_documents/syllabi/17635-software-architectures-2026-syllabus-v1.01.pdf
- **UMD ENRE 602:** official listing describes a 3-credit reliability analysis course and lists it as offered through Fall 2026; its subject summary includes FTA, RBD, FMEA, event trees and reliability data analysis. https://me.umd.edu/course-schedule/course/ENRE602
- **Google SRE Classroom:** official practical workshop suite covers distributed PubSub, image serving and SLOs; the page states CC BY 4.0. https://sre.google/classroom/

### Context7 checks

Resolved and queried high-reputation official documentation sources: PostgreSQL `/websites/postgresql`, Kubernetes `/websites/kubernetes_io` and OpenTelemetry `/websites/opentelemetry_io`. Technical refinements include PostgreSQL READ COMMITTED statement snapshots, REPEATABLE READ transaction snapshots and SERIALIZABLE abort/retry semantics; Kubernetes startup/liveness/readiness behaviour; and OpenTelemetry signal/context-propagation architecture. For PostgreSQL SERIALIZABLE failures, retry the complete transaction. Kubernetes readiness failure removes a Pod from Service traffic; liveness/startup failure causes container restart according to policy. Do not make liveness depend on an optional external dependency.

### FMHY review

Inspected https://fmhy.net/educational. The Education page indexes legitimate learning platforms including MIT OpenCourseWare, edX, OpenLearn, Saylor, OpenHPI, CMU Open Learning Initiative, Yale Courses, VideoLectures and related open learning directories. It also has a separate “Downloading” section with torrents, unauthorised course repositories and redirect/access-bypass material. Those entries were excluded from the course. FMHY is a discovery directory, not a technical authority; each adopted resource must be checked at its own official site for content, availability and licence.

### Technical examples rechecked

- Forward Euler for `dx/dt=0.05x`, `x(0)=100`, `t=10`: step `h=1` gives `100(1.05)^10 ≈ 162.889`; exact solution is `100e^0.5 ≈ 164.872`; relative error is about 1.20%. A smaller step reduces this numerical error for the stated smooth equation but does not validate the model structure.
- Exponential life-data example: five failures at 40, 60, 75, 80 and 90 days plus three right-censored observations at 100 days gives total exposure 645 unit-days; under a constant-hazard exponential model, `λ̂=5/645≈0.007752/day` and mean `≈129 days`. Censored units contribute exposure, not an observed failure.
- Zero-failure bound: under a homogeneous Poisson/exponential model, the one-sided 95% upper rate bound after exposure `T` is `−ln(0.05)/T≈2.996/T`. It is not a claim of zero risk.
- Reliability calculations: independent series components 0.99, 0.98, 0.995 produce 0.965349; two independent parallel components each at 0.90 produce 0.99. Common-cause dependencies invalidate these simple products.
- 99.9% availability over a 30-day month permits 43.2 minutes of error budget, assuming a continuous 30×24×60-minute month.

### Limitations and provenance

Search and synthesis tools are discovery aids; primary source text was inspected where a material claim was carried into the revision. Standards, textbooks and some course materials remain paywalled. Public syllabi do not mean all associated lectures/exercises are openly licensed. No accreditation, faculty grading, cohort pilot or independent formal proof review has been carried out. The new sample examinations and answer keys are original assessments for this independent programme, not copied university papers.


## 9. Reproducible practical implementation references (21 November 2026)

The executable teaching examples use the Python and Go standard libraries. Their APIs and teaching patterns were cross-checked against official documentation through Context7; no third-party package is required to run the core labs.

- [Python `unittest`](https://docs.python.org/3/library/unittest.html) and [Python `random`](https://docs.python.org/3/library/random.html): test discovery and independent seeded random-number generators used in deterministic resampling.
- [Go memory model](https://go.dev/ref/mem), [Go `sync`](https://pkg.go.dev/sync), [Go `context`](https://pkg.go.dev/context), [Go `net/http`](https://pkg.go.dev/net/http), and [Go race detector guide](https://go.dev/doc/articles/race_detector): synchronization, cancellation, HTTP handler construction and race testing.
- [SimPy resources](https://simpy.readthedocs.io/en/latest/topical_guides/resources.html) and [SimPy monitoring](https://simpy.readthedocs.io/en/latest/topical_guides/monitoring.html): optional extension references for learners who later want process-based discrete-event simulation. SimPy is not a dependency of the supplied stock-flow model.

The tested environment recorded in the verification report is Python 3.13.5 and Go 1.23.2. The stated compatibility floors in the practical README files govern use; re-run the tests on the exact runtime in your own environment. A successful run in one environment does not guarantee identical behaviour across every runtime or operating system.

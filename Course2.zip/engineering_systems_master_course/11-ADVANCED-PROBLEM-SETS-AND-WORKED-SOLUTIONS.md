# Advanced Problem Sets and Worked Solutions

This workbook supplements the six course texts. It is intended for university-level practice: several questions require a derivation, a model, an engineering argument or a justified decision rather than recall. Attempt every problem before reading its worked solution.

**Notation:** all numerical data are illustrative unless explicitly identified as a standard definition or model. Do not transfer illustrative thresholds into a real system without domain evidence.

---

# Unit I — Systems Thinking and System Dynamics

## Problem 1. Backlog dynamics with rework

A service begins a month with 240 unresolved requests. It receives 32 new requests per day. The team attempts to complete 40 requests per day, but 15% of the attempted completions are reopened because the problem was not actually resolved. Assume constant rates for 12 days.

1. Define the net outflow from the backlog.
2. Calculate the backlog after 12 days.
3. Explain why counting attempted completions as successful outflow overstates performance.
4. State two reasons the constant-rate assumption might fail.

### Worked solution

The stated 40 requests/day is an attempted-completion rate. If 15% reopen, only 85% leave the unresolved backlog permanently. The effective net resolution rate is:

\[
C_{net}=40(1-0.15)=34\;\text{requests/day}
\]

The stock-flow equation is:

\[
\frac{dB}{dt}=A-C_{net}=32-34=-2\;\text{requests/day}
\]

With constant rates over 12 days:

\[
B(12)=240+(-2)(12)=216\;\text{requests}
\]

A dashboard that reports 40 completed requests/day hides the reopened work and may suggest that capacity comfortably exceeds demand. The net outflow is only 34/day, so the backlog decreases slowly. The constant-rate assumption may fail if arrival volume is seasonal, if high backlog increases follow-up messages, if complex cases take longer, or if fatigue increases rework.

## Problem 2. Determine loop polarity and identify the delay

Consider the following proposed causal structure:

- backlog increases waiting time;
- waiting time increases follow-up messages;
- follow-up messages increase interruption load;
- interruption load reduces effective resolution capacity;
- effective resolution capacity reduces backlog.

1. Determine the sign of every link.
2. Determine the overall loop polarity.
3. Explain how delays could intensify the reinforcing deterioration and distinguish loop polarity from stability.
4. Identify a policy that might damp the oscillation.

### Worked solution

The links are positive from backlog to waiting time, waiting time to follow-up messages, and follow-up messages to interruption load. The link from interruption load to effective capacity is negative. The link from effective capacity to backlog is also negative, because more capacity reduces the stock of unresolved work. The product therefore contains two negative links, so the loop is reinforcing. A larger backlog increases interruptions, interruptions reduce effective capacity, and reduced capacity further increases backlog. This is a reinforcing deterioration loop (a vicious cycle). Delays can intensify the deterioration or cause later interventions to overshoot, but they do not change the loop polarity. A policy could reduce unnecessary follow-up through clearer status communication, reduce rework, protect focused resolution time, or shorten training delays. The model should be simulated before claiming that any intervention stabilises the system.

## Problem 3. Queueing nonlinearity

A single-server support desk receives requests at an average rate of 8 per hour. The service rate is 10 per hour. Assume an M/M/1 queue.

1. Calculate utilisation.
2. Calculate expected time in the system.
3. Repeat when arrival rate rises to 9.5 per hour.
4. Explain why adding capacity near saturation can produce a disproportionate reduction in delay.

### Worked solution

For an M/M/1 model, stability requires \(\lambda<\mu\), utilisation is \(\rho=\lambda/\mu\), and mean time in the system is:

\[
W=\frac{1}{\mu-\lambda}
\]

At \(\lambda=8\), \(\mu=10\):

\[
\rho=8/10=0.8,\qquad W=1/(10-8)=0.5\;\text{hour}
\]

At \(\lambda=9.5\):

\[
\rho=9.5/10=0.95,\qquad W=1/(10-9.5)=2\;\text{hours}
\]

A rise in arrival rate of only 18.75% increases mean time in the system by a factor of four. The effect occurs because little spare capacity remains to absorb variability. The M/M/1 assumptions—Poisson arrivals, exponential service times, one server, FCFS discipline and a stable system—must be stated. Real service systems may require simulation or measured queueing analysis.

## Problem 4. Structural uncertainty and policy ranking

Two models both reproduce the observed six-month backlog series. Model A assumes rising demand is driven by increased adoption. Model B assumes demand is stable but a growing fraction of work is reopened. The models recommend different interventions.

Describe a defensible analysis plan. Your answer must distinguish parameter uncertainty from structural uncertainty and identify evidence that could discriminate between the models.

### Worked solution

Parameter uncertainty concerns values within a chosen structure—for example, the arrival rate, service rate or reopen fraction. Structural uncertainty concerns which causal relationships and feedback mechanisms exist. Varying the reopen fraction inside Model A would not necessarily test the missing rework mechanism; that is a structural issue.

The analysis should preserve both candidate models, identify observations that differ under their causal hypotheses, and compare predictions against new evidence. Useful data include new-user cohorts, total work initiated, reopen rate, reopen reason, case complexity and changes after quality interventions. Policies should be tested across both structures. If Model A favours demand restriction but Model B favours quality improvement, the decision should remain conditional until the evidence distinguishes the mechanisms. Historical fit alone is insufficient because multiple structures can reproduce the same time series.

---

# Unit II — Systems Engineering Fundamentals

## Problem 1. Lifecycle cost and discounting

A proposed system has an initial development cost of 90 cost units at time zero. Estimated operating costs are 40, 50 and 55 units at the end of years 1, 2 and 3. Use a 6% discount rate.

1. Calculate the present value of the three-year cost stream.
2. Explain why the cheapest development concept may not be the lowest-cost lifecycle concept.
3. Identify at least three uncertainties that should be included in a sensitivity analysis.

### Worked solution

The present-value equation is:

\[
PV=C_0+\sum_{t=1}^{n}\frac{C_t}{(1+r)^t}
\]

Substituting:

\[
PV=90+\frac{40}{1.06}+\frac{50}{1.06^2}+\frac{55}{1.06^3}
\]

\[
PV\approx90+37.736+44.500+46.178=218.414
\]

The development cost is only one component. A design that is inexpensive to build may require expensive support, licensing, training, infrastructure, maintenance, migration or manual operation. Sensitivity analysis should consider demand growth, staff cost, service-life duration, failure rate, vendor price change, integration effort and disposal cost. The cost boundary and whether costs are nominal or real must be stated.

## Problem 2. Verification, validation and acceptance

A reservation system passes a test proving that it rejects overlapping reservations for the same physical equipment item. In a pilot, students still fail to obtain equipment before scheduled laboratory sessions because the collection workflow is confusing and the technician does not receive a clear handover list.

1. Which property has been verified?
2. Why has validation not been demonstrated?
3. Propose three additional validation activities.

### Worked solution

The overlap test verifies one specified system behaviour: the system enforces a non-overlap rule for the tested conditions. It does not establish that the service meets the stakeholder's actual goal of providing the correct equipment at the correct location and time. The operational concept includes staff workflow, collection location, notification, inspection and training. Validation should therefore include scenario-based trials with students and technicians, observation of end-to-end collection, measurement of equipment readiness before sessions, and review of alternate cases such as late return or maintenance hold. Acceptance must be defined by the authorised stakeholder using observable evidence.

## Problem 3. Trade study with mandatory constraints

Three design concepts are scored from 1 (poor) to 5 (strong). Criteria and weights are:

| Criterion | Weight | Concept A | Concept B | Concept C |
|---|---:|---:|---:|---:|
| Operational performance | 0.35 | 4 | 5 | 3 |
| Lifecycle cost | 0.25 | 5 | 2 | 4 |
| Modifiability | 0.20 | 3 | 5 | 4 |
| Supportability | 0.20 | 4 | 2 | 5 |

1. Calculate the weighted scores.
2. Concept B violates a mandatory security constraint. What should the decision process do?
3. Explain why score precision should not be confused with evidence quality.

### Worked solution

Concept A:

\[
S_A=0.35(4)+0.25(5)+0.20(3)+0.20(4)=4.00
\]

Concept B:

\[
S_B=0.35(5)+0.25(2)+0.20(5)+0.20(2)=3.65
\]

Concept C:

\[
S_C=0.35(3)+0.25(4)+0.20(4)+0.20(5)=3.85
\]

Concept A ranks first among the scored concepts. However, Concept B violates a mandatory security constraint and must be rejected or redesigned before weighted preference is considered. A high score cannot compensate for a non-negotiable legal, safety, security or contractual violation. The scores are judgments supported by evidence of varying quality. Numerical formatting does not make subjective estimates objective; the rationale, source, uncertainty and sensitivity must be recorded.

## Problem 4. Interface definition

An identity system returns a Boolean field named `eligible`. The reservation platform assumes this means the student is eligible for every equipment category. The identity team defines it as “currently enrolled in any course.” Explain the interface defect and define a better interface-control record.

### Worked solution

The problem is semantic mismatch, not necessarily a transport or syntax error. Both systems exchange a valid Boolean, but they interpret it differently. The interface contract should define the eligibility scope, subject, data freshness, source authority, evaluation time, category constraints, error conditions, version and owner. A better model may provide a structured decision with reason code, policy version, category, valid-from/valid-to timestamps and correlation ID. The reservation platform should not silently infer category-specific authorisation from general enrollment status.

---

# Unit III — Requirements Engineering

## Problem 1. Rewrite vague requirements

A stakeholder proposes: “The system shall be secure, fast, easy to use and reliable.” Create four measurable candidate quality requirements. Identify what must be elicited before setting each threshold.

### Worked solution

A possible first draft is:

- **Performance:** Under a stated workload profile, 95% of successful item-availability queries shall complete within a defined response-time threshold measured at the API boundary.
- **Availability:** During the defined term-time service window, the reservation workflow shall meet an availability objective calculated from valid eligible reservation attempts.
- **Security:** A user without the required role shall be denied access to protected reservation and borrower records, and every administrative access change shall produce an auditable event.
- **Usability:** In a representative usability study, a defined proportion of participants from specified user groups shall complete a reservation task without assistance and within an agreed task-time limit.

Thresholds cannot be selected responsibly without a workload, service-window definition, threat model, data classification, user population, task definition and business-impact analysis. The statements are candidate requirements, not approved baselines. “Secure” also requires a wider threat and assurance argument; one access-control test is not a complete security requirement set.

## Problem 2. Requirement quality and ambiguity

Review the statement:

> The system shall automatically notify users about overdue equipment as soon as possible and prevent inappropriate access.

Identify at least six quality defects. Rewrite it as a set of candidate requirements.

### Worked solution

Defects include: two obligations in one statement; undefined “automatically”; undefined “overdue”; vague “as soon as possible”; undefined recipient; no delivery semantics; undefined “inappropriate access”; no roles or protected actions; no error handling; and no verification method.

A candidate decomposition might be:

- When an issued item passes its recorded return deadline and has not been returned or formally extended, the system shall create an overdue event.
- Within a defined interval after the overdue event, the system shall attempt to send a notification to the borrower through the configured channel.
- The system shall record notification attempt time, channel, result and correlation identifier.
- If notification delivery fails, the system shall retain the pending notification and apply a documented retry policy.
- The system shall allow a borrower to view only their own active and historical loan records.
- The system shall deny a user who lacks the equipment-manager role from changing inspection status.

The timing threshold, retry policy, role model and retention period require stakeholder, policy and technical evidence.

## Problem 3. Traceability and change impact

A policy change extends the reservation cancellation window from 12 hours to 24 hours. The existing artefacts include: a stakeholder need, cancellation requirement, booking API, database state machine, notification template, acceptance test, staff procedure and incident runbook. Describe a change-impact process and identify likely impacts.

### Worked solution

The change should be raised with a unique change identifier, source, reason, requested effective date, affected stakeholders and urgency. The analyst should traverse traceability links in both directions: from the policy to the requirement and from the requirement to downstream design, data, test, operational and training artefacts. Likely impacts include cancellation guard logic, API contract documentation, state transition conditions, reminder timing, acceptance tests at 12- and 24-hour boundaries, staff procedure, user communication, metrics and incident diagnosis. Evaluate backward compatibility and existing reservations. Approve the change through the relevant authority, update the baseline, implement and verify it, then close the change only when all affected artefacts are reconciled.

## Problem 4. Acceptance tests for concurrent reservations

Two students submit reservations for the same unique item and overlapping time interval. Specify the preconditions, expected outcome and at least four test cases.

### Worked solution

Precondition: the item is reservable, both students are authorised, and no overlapping reservation exists. The required invariant is that no two confirmed reservations for the same item overlap in time. Tests should include: concurrent requests arriving together; one request arriving immediately after the first commit; client retry after response loss; cancellation followed by a new reservation; different items for the same interval; and non-overlapping time windows. Expected behaviour is one confirmed reservation and one explicit conflict response for the overlapping pair. Tests should verify persisted state, not only the API response. A correct implementation typically enforces the invariant at the authoritative data/transaction boundary rather than relying solely on a prior availability read.

---

# Unit IV — Software System Design and Distributed Systems

## Problem 1. Little's Law and capacity

A service receives 12 requests per second and has an average end-to-end time in the system of 0.25 seconds. Under a stable workload, estimate the average number of in-flight requests. If concurrency increases to 6 while arrival rate remains unchanged, what does that imply about average time under the same stable conditions?

### Worked solution

Little's Law is:

\[
L=\lambda W
\]

With \(\lambda=12\) requests/s and \(W=0.25\) s:

\[
L=12(0.25)=3\;\text{requests}
\]

If average concurrency becomes 6 while the arrival rate remains 12/s, the corresponding average time is:

\[
W=L/\lambda=6/12=0.5\;\text{s}
\]

This relationship assumes a stable system and compatible definitions of arrival rate, population and time. It is not a queueing-delay formula for arbitrary distributions; it relates long-run averages.

## Problem 2. M/M/1 queue and saturation

A service receives \(\lambda=18\) requests/s and processes requests at \(\mu=24\) requests/s. Assume M/M/1 conditions.

1. Calculate utilisation.
2. Calculate mean time in system.
3. Recalculate if arrival rate rises to 22 requests/s.
4. Explain why this should not be treated as a production latency prediction without validation.

### Worked solution

\[
\rho=\lambda/\mu=18/24=0.75
\]

\[
W=1/(\mu-\lambda)=1/6\;\text{s}\approx0.167\;\text{s}
\]

At \(\lambda=22\):

\[
W=1/(24-22)=0.5\;\text{s}
\]

The model predicts a threefold rise in mean time when arrivals increase by about 22.2%. Real services have multiple workers, non-exponential service times, priorities, shared dependencies, bursty traffic, retries and finite buffers. The M/M/1 result is a teaching model and a warning about utilisation, not a substitute for workload testing and measured queueing analysis.

## Problem 3. Reservation race and authoritative invariants

Two clients read that an equipment item is available, then both attempt to create an overlapping reservation. Explain why a read-then-write application check can fail and propose a robust design.

### Worked solution

Both clients may read the same pre-transaction state before either writes. Each sees availability and proceeds; without an atomic invariant check, both can commit. A correct design places the invariant at the authoritative write boundary. Possible mechanisms include a database constraint that excludes overlapping reservations, serializable transaction with appropriate retry handling, or row locking plus a checked state transition. The application must handle a uniqueness/conflict result explicitly. It should not assume that an earlier availability query reserves the item. The decision should include transaction isolation, lock contention, retry behaviour and how to report a conflict to the client.

## Problem 4. Retry after ambiguous commit

A client sends `POST /reservations`. The server commits the reservation, but the response is lost. The client retries. Define an idempotency design and state its limits.

### Worked solution

The client sends a stable idempotency key for the logical command. The server scopes the key to the authenticated principal and operation, stores it transactionally with the result, and returns the original result when the same key is received again. The key should be bound to a request hash so reuse with different content is rejected. The retention window must exceed the realistic retry horizon and be consistent with business rules. The reservation's unique invariant remains separately enforced. Idempotency prevents duplicate effects for that key within the defined storage/retention scope; it does not guarantee that every downstream side effect occurs exactly once. Notifications should be published through an outbox or another recoverable mechanism, and consumers should be idempotent.

## Problem 5. Kafka transaction scope

A service consumes an event from Kafka, writes a row to an external PostgreSQL database and commits the Kafka offset. Explain two crash windows and propose a safe design.

### Worked solution

If the service commits the database row and crashes before the offset commit, Kafka may redeliver the event. If it commits the offset first and crashes before the database write, the event may be lost from the consumer's perspective. A Kafka transaction can atomically coordinate offsets and Kafka output records, but it does not include arbitrary writes to an external PostgreSQL database. A common design is at-least-once consumption with an idempotent database transaction: insert a processed-event identifier under a unique constraint and apply the business update in the same PostgreSQL transaction. A transactional outbox can be used for events emitted from a database transaction. The exact design depends on the required semantics and failure model.

## Problem 6. Read/write quorum intersection

A replicated store has \(N=3\) replicas. A design selects read quorum \(R=2\) and write quorum \(W=2\). Explain the quorum-intersection intuition and why this arithmetic alone does not prove linearizability.

### Worked solution

For this configuration, \(R+W=4>N=3\), so every read quorum and write quorum must overlap by at least one replica if the quorum sets are formed from the same replica set. This can help a read encounter a replica that has participated in a recent write. However, intersection alone does not guarantee that the intersecting replica returns the newest value or that concurrent writes are ordered consistently. The protocol also needs versioning, conflict resolution or a leader/consensus rule, well-defined acknowledgement semantics and appropriate handling of concurrent operations. Linearizability is a property of operation histories, not just a quorum-size inequality.

---

# Unit V — Software Architecture and Trade-off Analysis

## Problem 1. Quality-attribute scenario

A campus platform must support a registration peak. Construct a six-part performance scenario and state what evidence is required to accept the architecture.

### Worked solution

One possible scenario:

- **Source:** authenticated student clients.
- **Stimulus:** registration opens and reservation traffic rises sharply.
- **Environment:** peak term-time operation with normal database and identity dependencies.
- **Artifact:** reservation API and authoritative reservation store.
- **Response:** system admits valid requests, rejects conflicts correctly, controls overload and preserves the reservation invariant.
- **Response measure:** a stakeholder-approved percentile latency and error/conflict rate at a defined arrival profile, while no overlapping confirmed reservations are created.

Evidence should include a reproducible workload profile, load-test results, resource utilisation, database contention and query evidence, dependency latency, correctness tests under concurrency, overload behaviour and known limitations. A latency target by itself is insufficient if the system returns stale or incorrect availability.

## Problem 2. Weighted trade study and sensitivity

Use weights: correctness 0.35, availability 0.25, modifiability 0.20 and lifecycle cost 0.20. Score two alternatives from 1 to 5:

| Alternative | Correctness | Availability | Modifiability | Lifecycle cost |
|---|---:|---:|---:|---:|
| Modular monolith | 5 | 4 | 3 | 5 |
| Microservices | 4 | 4 | 5 | 2 |

1. Calculate weighted scores.
2. Repeat with weights: correctness 0.25, availability 0.20, modifiability 0.45, cost 0.10.
3. Explain what the result says about the decision.

### Worked solution

Under the first weight set:

\[
S_M=0.35(5)+0.25(4)+0.20(3)+0.20(5)=4.35
\]

\[
S_S=0.35(4)+0.25(4)+0.20(5)+0.20(2)=3.80
\]

The modular monolith ranks higher. Under the second weight set:

\[
S_M=0.25(5)+0.20(4)+0.45(3)+0.10(5)=3.90
\]

\[
S_S=0.25(4)+0.20(4)+0.45(5)+0.10(2)=4.25
\]

The ranking changes when modifiability becomes much more important and lifecycle cost less important. The architecture choice is therefore sensitive to organisational and quality-attribute assumptions. The decision record should identify what evidence could justify the revised weights, such as autonomous team ownership, independent release frequency, change coupling, on-call capability and measured cost.

## Problem 3. ADR quality

A team records: “We chose microservices because they scale better.” Identify the missing information and outline a decision record that could support a future review.

### Worked solution

The statement lacks the context, quality scenarios, alternatives, constraints, operational costs, evidence, consequences and revisit conditions. A useful ADR would identify the problem and architectural drivers; list a modular monolith, service-oriented design and event-driven alternative; describe the relevant workload and team topology; compare them against measured requirements; state the selected alternative; record positive and negative consequences; and identify triggers for review, such as a sustained need for independent scaling or release ownership. A conclusion that “scales better” is too vague because scaling can mean throughput, team independence, organisational complexity or infrastructure elasticity.

## Problem 4. ATAM-style risk analysis

An architecture uses a shared database, cache, notification queue and regional deployment. Identify at least four risks, two sensitivity points and one trade-off point. Explain how a review should expose them.

### Worked solution

Potential risks include database contention under peak writes, stale cache causing incorrect availability, queue backlog delaying operational notifications, and a regional failure affecting the application and shared state. Sensitivity points include cache time-to-live, database connection pool size, queue retention and failover time. A trade-off point may be the use of synchronous authoritative reservation validation: it supports correctness but makes reservation success sensitive to database availability and latency. An ATAM-style workshop should elicit and prioritise quality scenarios, map architectural approaches to each scenario, identify risks and non-risks, and document assumptions requiring prototypes or tests.

---

# Unit VI — Reliability Engineering, SRE and Incident Response

## Problem 1. Exponential reliability

A component has a constant failure rate of \(\lambda=2\times10^{-4}\) failures/hour.

1. Calculate reliability after 1,000 hours.
2. Calculate MTTF.
3. Explain the constant-hazard assumption.

### Worked solution

For the exponential model:

\[
R(t)=e^{-\lambda t}
\]

At 1,000 hours:

\[
R(1000)=e^{-(2\times10^{-4})(1000)}=e^{-0.2}\approx0.8187
\]

For a constant hazard, \(MTTF=1/\lambda=5,000\) hours. The model assumes the failure rate does not change with age or accumulated exposure. It is inappropriate when wear-out, early-life defects or changing operating conditions dominate unless the model is explicitly used as a local approximation.

## Problem 2. Weibull reliability and hazard shape

A population follows a two-parameter Weibull distribution with shape \(\beta=1.5\) and scale \(\eta=2,000\) hours. Calculate reliability at 1,000 hours and interpret the hazard shape.

### Worked solution

\[
R(t)=e^{-(t/\eta)^\beta}
\]

\[
R(1000)=e^{-(1000/2000)^{1.5}}=e^{-0.35355}\approx0.7022
\]

Because \(\beta>1\), the Weibull hazard increases with time under this model. The result should be interpreted together with sample size, censoring, operating conditions and parameter-estimation uncertainty. A fitted Weibull curve does not prove a physical wear-out mechanism.

## Problem 3. Availability and the series path

A repairable component has MTBF = 500 hours and MTTR = 2 hours. A critical user journey depends on three independent series components with availabilities 0.999, 0.998 and 0.997.

1. Calculate the component's simple steady-state availability.
2. Calculate the path availability under the independence assumption.
3. Identify two reasons the result may be optimistic.

### Worked solution

\[
A=\frac{MTBF}{MTBF+MTTR}=\frac{500}{502}\approx0.996016
\]

For independent series components:

\[
A_{path}=0.999(0.998)(0.997)\approx0.994011
\]

The calculation may be optimistic because the components can share failure causes (region, network, identity provider, deployment, configuration) and because availability values may not measure the same user journey, time window or failure criterion. The formula also ignores degraded modes, retries, maintenance windows and data correctness.

## Problem 4. SLO error budget and burn rate

A service has a 99.95% SLO over a rolling 30-day window. The service receives a steady 100,000 eligible requests per day. During one hour, 500 requests are bad.

1. Calculate the 30-day request error budget.
2. Calculate the observed bad-event fraction for the hour if it also received 100,000/24 requests.
3. Calculate the approximate burn rate relative to the SLO's allowed bad fraction.
4. Explain why a burn-rate alert is not identical to a user-impact severity classification.

### Worked solution

The allowed bad fraction is:

\[
1-0.9995=0.0005
\]

The 30-day request budget is:

\[
3,000,000(0.0005)=1,500\;\text{bad requests}
\]

The hourly eligible request count is approximately:

\[
100,000/24\approx4,166.7
\]

The observed hourly bad fraction is:

\[
500/4,166.7\approx0.12
\]

The approximate burn rate is:

\[
0.12/0.0005=240\times
\]

A burn-rate alert measures budget consumption speed over defined windows. Incident severity depends on affected users, functions, duration, data correctness, safety and business impact. A service may burn a small error budget while causing serious harm to a small critical user group; conversely, a high rate of errors on a low-impact endpoint may not justify the same severity. Alert policy and incident severity must be designed together but are not interchangeable.

## Problem 5. FMEA and fault-tree reasoning

For the top event “a user receives confirmation for a reservation that is not valid,” identify at least three contributing failure modes. Construct a simple fault-tree logic and propose controls.

### Worked solution

Possible contributors include: stale cache incorrectly reports availability; concurrent write path fails to enforce the unique reservation invariant; downstream confirmation is emitted before the authoritative transaction commits; idempotency key is not scoped correctly; or a manual override bypasses policy. A candidate top-event tree might be an OR gate over (A) invalid reservation committed, (B) valid reservation state rolled back while confirmation persists, and (C) confirmation incorrectly associated with another user or item. Each branch can be decomposed further. Controls include authoritative database constraints, transactionally recorded outbox events, idempotent consumers, scoped idempotency keys, invariant reconciliation, audit logs and concurrency tests. A quantitative probability calculation requires defensible failure probabilities and dependence assumptions; do not multiply guessed values as if independent.

## Problem 6. Recovery objectives and evidence

A platform claims an RTO of one hour and RPO of 15 minutes. Its database backups run nightly and the team has never completed a restore drill. Evaluate whether the claim is supported and propose a recovery validation programme.

### Worked solution

The claim is not supported by the stated evidence. Nightly backups can lose close to 24 hours of changes if no other recovery mechanism exists, so a 15-minute RPO is not demonstrated. A one-hour RTO cannot be claimed without measuring restore time for the full dependency chain. The programme should identify the failure scenarios, implement a backup plus required log-archiving or replication strategy, secure keys/configuration, document application and dependency restoration order, execute isolated restore tests, verify business invariants and data timestamps, measure actual recovery time and data loss, and remediate gaps. Repeat the test after material architecture or operational changes. The tested result, not the target alone, is the evidence.

---

# Cross-course synthesis questions

1. Select one important capstone requirement. Trace it from stakeholder need through system function, software component, architecture decision, verification test, SLO and incident procedure.
2. Identify one policy intervention in the system-dynamics model that creates a new architectural or reliability risk. Explain how the design should account for it.
3. Choose one architecture decision that would change the reliability block diagram. Show how the decision changes failure paths and operational responsibilities.
4. Select one failure scenario that could violate a requirement. Show the prevention, detection, mitigation and recovery controls, and identify which course provides the analysis method for each.
5. Identify a decision that is sensitive to uncertainty. State what additional measurement, prototype or stakeholder evidence would most reduce the uncertainty.

A complete answer integrates methods across the courses. It does not simply repeat six separate definitions.

# 17 — Worked Examples and Reference Solutions

These examples provide checkable reference calculations and artefact oracles for the executable practicals. They do not replace the fuller solution guidance in the six course texts or provide a single “correct” architecture for open-ended design problems. For open-ended work, grade the evidence, reasoning, assumptions and limitations using the published rubrics.

## 1. Course I — stock-flow equation and numerical integration

The supplied backlog model is:

\[
\dot B=\lambda+\rho q-q,\qquad q=\min(C,B/\Delta t)
\]

\[
\dot C=\frac{C_0+g\max(B-B_T,0)-C}{\tau}.
\]

Here backlog \(B\) is measured in requests, arrivals \(\lambda\) and completions \(q\) in requests/day, the rework fraction \(\rho\) is dimensionless, capacity \(C\) is requests/day, and \(\Delta t\) is the numerical integration step in days. Both sides of the first equation therefore have units of requests/day. The capacity adjustment equation has units of requests/day² on both sides because the difference in capacity is divided by a time constant.

Forward Euler updates a state by:

\[
B_{k+1}=\max(0,B_k+\Delta t(\lambda+\rho q_k-q_k)),
\]

\[
C_{k+1}=\max(0,C_k+\Delta t\,\dot C_k).
\]

For the supplied base parameters and 180-day run, the regression oracle is a final backlog of **696.988 requests** and a final effective capacity of **32.827 requests/day**. The alternative backlog oracles are 445.445 (training), 569.199 (rework reduction) and 413.248 (demand smoothing). Reproduce these before changing the model. Then halve the step size and examine whether trajectories converge. The numerical oracle confirms the implementation, not the causal assumptions, parameter validity or real-world predictive accuracy.

A defensible validation record separates: (a) implementation verification, (b) numerical convergence, (c) dimensional and extreme-condition tests, (d) historical fit/calibration if data exist, and (e) structural validation with subject-matter experts. Passing (a)–(c) cannot substitute for (d)–(e).

## 2. Course II — present value and constraint-first decision analysis

A cost of 100 occurs now, followed by costs 25, 30 and 35 at the end of years 1, 2 and 3. At a 5% discount rate:

\[
PV=100+\frac{25}{1.05}+\frac{30}{1.05^2}+\frac{35}{1.05^3}
=181.2547241119.
\]

The result is **181.25 cost units** to two decimal places. It is not 181.8. Show the time of each cash flow and state whether costs are nominal or real; the discount rate must be consistent with that basis.

In the supplied trade study, availability ≥99.5% and lifecycle cost ≤₹15 lakh are feasibility constraints. A and B satisfy the constraints; C does not. Only A and B proceed to preference scoring. With the baseline weights (0.45/0.25/0.30) and supplied preference scores, the result is A = 4.200 and B = 4.100. Under the alternate weights (0.15/0.45/0.40), the scores become A = 3.700 and B = 4.700, so the ranking reverses to B, then A. The important engineering finding is not which alternative “wins”; it is that the decision is sensitive to stakeholder priorities. Record who owns each weight and score, what evidence supports them, uncertainty, and how a change in the threshold changes the feasible set.

A weighted average must not allow a high preference score to compensate for failing a mandatory safety, legal, security or interface constraint. If no candidate passes all mandatory constraints, report **no feasible alternative** and return to concept development or constraint negotiation; do not silently relax a threshold to force a winner.

## 3. Course III — interpreting the requirements checker

The supplied well-formed CSV is expected to produce zero automated findings. The deliberately defective review sample produces four findings: two errors and two warnings. Read each finding against the row and rule that triggered it; never rewrite a requirement merely to silence a warning.

A requirements pre-checker can identify missing fields, duplicate identifiers and selected lexical patterns. It cannot reliably determine stakeholder intent, completeness, feasibility, consistency with system physics, safety integrity, test adequacy, legal compliance or whether a threshold is supported by evidence. The correct disposition of an automated finding is one of: confirmed defect, justified exception with rationale, or false positive. Record the reviewer and resolution. Deliberately add at least one false negative to the sample and document it; a clean machine report is not a requirements-quality certificate.

## 4. Course IV — concurrency invariant and linearisation point

The Go practical enforces the invariant:

\[
0\leq \text{used}(s)\leq \text{capacity}(s)
\]

for each slot \(s\). The `Store.Reserve` critical section protects the capacity check, increment and idempotency-record insertion together under one mutex. The successful state update inside that critical section is the operation's linearisation point for this in-memory sequential specification. Two concurrent requests cannot both observe the final unit as unused and then both commit an increment through this code path.

An exact retry with the same idempotency key, slot and user returns the original reservation. Reusing the key with a different payload returns conflict. This is **idempotent request handling in one process**, not “exactly-once delivery”: requests and responses may still be lost, clients may retry, and the process can crash. The store is neither durable nor shared between instances. In a production design, define a durable idempotency record and enforce the resource invariant in the authoritative transactional persistence layer (for example, a unique/conditional write or serializable transaction with retry), then analyse commit/timeout/retry and recovery histories.

The tests use 100 concurrent requests for one available unit and assert exactly one success, plus tests for replay, conflicting key reuse, cancelled contexts and HTTP validation. `go test -race` checks the exercised code paths for data races; it does not prove linearizability for every possible history or durability under crash. The written concurrency histories and fault model remain required assessment evidence.

## 5. Course V — architecture dependency fitness function

The supplied example defines four conceptual layers: domain (rank 0), application (1), and presentation/infrastructure (2). Dependencies must point inward to a strictly lower-numbered layer. The checker reports a dependency on an undeclared module, an outward/equal-layer dependency and a dependency cycle.

A fitness-function result is a policy check against the declared model. It cannot tell whether the chosen layers are the right architecture, whether a dependency is semantically justified, whether a module has high cohesion, or whether latency/security/availability goals are met. Before changing the layer order or adding a new layer, state the architecture principle and exception rule. A passing check indicates that the model conforms to this chosen rule, not that the architecture is good.

## 6. Course VI — right censoring and reliability likelihood

The synthetic dataset contains failures at 40, 60, 75, 80 and 90 days and three units still operating when observation ends at 100 days. Total exposure is:

\[
T=40+60+75+80+90+100+100+100=645\text{ unit-days}.
\]

For independent exponentially distributed lifetimes with constant rate \(\lambda\), the right-censored log-likelihood (ignoring constants) is:

\[
\ell(\lambda)=r\log\lambda-\lambda T,
\]

where \(r=5\) observed failures and \(T=645\) total time on test. Differentiating and setting the score to zero gives:

\[
\hat\lambda=\frac{r}{T}=\frac{5}{645}=0.00775194\text{ failures per unit-day},
\qquad \widehat{MTTF}=1/\hat\lambda=129\text{ days}.
\]

The three censored items contribute exposure up to 100 days. They are not failures at day 100. Treating them as failures would change the event count to eight and bias the rate upward under this example.

The two-parameter Weibull MLE for these same observations in the supplied implementation is approximately shape \(\hat\beta=3.168451\) and scale \(\hat\eta=99.134984\) days. The Weibull survival function is:

\[
S(t)=\exp[-(t/\eta)^\beta].
\]

It gives approximately \(S(30)=0.977596\) and \(S(60)=0.815689\). The fitted shape above one corresponds to an increasing hazard in this fitted model. With only five failures, it is not persuasive evidence of a physical wear-out mechanism. Plot the data, assess fit and uncertainty, and seek more observations across representative populations and operating conditions.

The reported exponential bootstrap 95% percentile interval (0.00247969, 0.01845645) per-day is generated under the practical's explicit common administrative censoring assumptions with 2,000 parametric replicates and a fixed seed. It is broad and method-dependent. It is not a generic confidence interval for Weibull parameters, not appropriate for informative censoring or heterogeneous/staggered-entry populations, and not a basis for a real safety decision without a design-specific statistical review.

## 7. Self-marking rubric for worked calculations

| Criterion | Full-credit evidence | Common loss of credit |
|---|---|---|
| Model selection | Names the model and states why its assumptions suit the question | Applies a formula without identifying assumptions |
| Derivation | Shows substitutions, units and intermediate steps | Gives only a final number |
| Computation | Reproduces the reference oracle at stated precision | Hidden rounding or unexplained discrepancy |
| Interpretation | Explains practical meaning without overclaiming | Treats an illustrative model as field truth |
| Sensitivity/uncertainty | Varies assumptions and reports effect | Reports a single “best” result only |
| Limitations | Identifies what evidence is missing | Uses a generic “more research needed” disclaimer |

For design artefacts, use the course-specific rubric and the CLO traceability matrix. A plausible answer is not automatically a defensible answer: make the evidence chain visible.

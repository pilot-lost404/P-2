# Engineering Systems and Software Architecture — University-Level Study Programme

**Programme type:** Independent university-style study sequence  
**Academic level:** Advanced undergraduate to introductory graduate  
**Structure:** Six sequential courses, each with its own lecture sequence, textbook-style notes, problems, applied assignment and recommended academic resources  
**Indicative duration:** 13 weeks per course; 78 weeks for all six when studied sequentially  
**Indicative workload:** 8–12 hours per week per active course, including reading, problem solving, labs and revision

> This is an independently authored study programme informed by university course structures, recognised textbooks, standards bodies and official technical documentation. It is not an accredited degree, a university-issued syllabus or a substitute for instructor assessment. The material is intended to provide the teaching content for self-study; the linked resources are supporting sources, not the main curriculum.

---

## 1. Programme purpose

The programme develops the ability to reason about complex systems, engineer system life cycles, specify stakeholder needs, design software systems, evaluate architecture and operate reliable services. These disciplines are taught in sequence because later decisions depend on earlier reasoning:

1. Systems thinking explains how structure, feedback and delay generate behaviour.
2. Systems engineering manages the transformation from needs to an integrated, verified and operated system.
3. Requirements engineering turns needs into clear, testable and controlled specifications.
4. Software system design develops correct interfaces, data and distributed behaviours under workload and failure.
5. Software architecture organises the system around its most consequential quality and change requirements.
6. Reliability engineering and SRE quantify and improve dependable operation, recovery and learning from failure.

The capstone combines all six disciplines in one system. The intent is not to memorise technology names. Students must be able to explain why a design is appropriate, what assumptions it depends on, what can fail, what evidence would demonstrate correctness and how the system will evolve.

## 2. Programme-level outcomes

On completion, a student should be able to:

- model a problem as an interacting system and explain behaviour over time;
- identify system boundaries, stakeholders, operational concepts and life-cycle constraints;
- translate needs into requirements that are clear, measurable, traceable and verifiable;
- design APIs, data models, transactions and distributed workflows with explicit correctness guarantees;
- choose architecture alternatives using quality-attribute scenarios, evidence and trade-off analysis;
- quantify reliability and availability using appropriate probability models;
- establish SLOs, monitoring, incident command, recovery objectives and tested restore procedures;
- present an engineering argument that connects requirements, design decisions, verification evidence, operational outcomes and residual risk.

## 3. The six courses

| Course | Main subject | Detailed teaching text | Primary academic anchors |
|---|---|---|---|
| I | Systems Thinking and System Dynamics | [Course I](01-systems-thinking-fundamentals.md) | Meadows, Sterman, MIT 15.871 and 15.879, System Dynamics Society |
| II | Systems Engineering Fundamentals | [Course II](02-systems-engineering-fundamentals.md) | NASA SE Handbook, INCOSE SE Handbook, SEBoK, MIT 16.842, ISO/IEC/IEEE 15288 |
| III | Requirements Engineering | [Course III](03-requirements-engineering.md) | Pohl, Wiegers & Beatty, IREB/CPRE, DTU RED course, OpenRE, ISO/IEC/IEEE 29148 |
| IV | Software System Design and Distributed Systems | [Course IV](04-software-system-design-fundamentals.md) | Kleppmann & Riccomini, MIT 6.5840, Brown CS1380, PostgreSQL, Kafka, Kubernetes, OpenTelemetry docs |
| V | Software Architecture and Trade-off Analysis | [Course V](05-architecture-and-trade-off-analysis.md) | Bass, Clements & Kazman, CMU architecture courses, SEI ATAM, C4, arc42, ADRs |
| VI | Reliability Engineering, SRE and Incident Response | [Course VI](06-reliability-and-incident-response.md) | O'Connor & Kleyner, Modarres et al., Google SRE, SRE Workbook, NIST SP 800-61 Rev. 3 |

Each course file is intended to stand alone as a teaching unit. It contains a course description, prerequisites, learning outcomes, lecture sequence, core explanations, formal models or design methods, worked examples, an integrated case study, problem set with solution guidance, practical assignment and further reading.

## 4. Entry requirements and prerequisite knowledge

The programme assumes:

- algebra, functions, graphs and basic calculus or the willingness to learn the required mathematics;
- elementary probability and statistics for reliability and risk analysis;
- programming experience and familiarity with data structures;
- basic relational database and networking knowledge before Course IV;
- technical writing skills sufficient to define assumptions, requirements and evidence.

Where a topic requires a prerequisite, the course explains the relevant idea or points to an appropriate supporting reference. Students should not skip the prerequisite merely because a tool can produce a result.

## 5. Recommended study workload and method

For each 13-week course, plan approximately 8–12 hours per week. The full sequence therefore represents approximately 624–936 hours of independent study. A productive weekly cycle is:

| Activity | Suggested time | Expected result |
|---|---:|---|
| Read the course text and assigned source | 2–3 h | Written notes and terminology |
| Reproduce diagrams and derivations | 1–2 h | A diagram, equation or model explained in your own words |
| Solve problem-set questions | 2–3 h | Worked solutions with assumptions and units |
| Complete lab or case-study work | 2–3 h | A technical artefact and evidence |
| Review and self-assess | 1 h | Error log, glossary and unanswered questions |

Do not treat a lecture video as a substitute for solving the associated exercise. For technical subjects, the learning test is whether you can reproduce the reasoning without following the source step by step.

### 5.1 How to study a technical concept

For every major concept, record:

1. its precise definition;
2. the problem it is intended to solve;
3. the assumptions under which it works;
4. a worked example;
5. a failure mode or counterexample;
6. how it connects to the other course topics;
7. one question that tests whether you truly understand it.

For each calculation, state units and assumptions. For each architecture decision, state alternatives and consequences. For each requirement, identify its source and verification method. For each reliability measure, define the observation window and operating conditions.

## 6. Assessment model

A university-style assessment mix for each course is suggested below. The percentages are programme design recommendations, not an official university grading scheme.

| Assessment | Weight | What it tests |
|---|---:|---|
| Problem sets / short quizzes | 20% | Terminology, mathematical reasoning, model critique and conceptual accuracy |
| Practical labs | 25% | Ability to build or analyse models, specifications, interfaces and operational procedures |
| Mid-course assessment | 15% | Individual mastery of core methods and derivations |
| Major assignment / project | 25% | Integration of concepts into a defensible engineering artefact |
| Final written examination | 10% | Individual transfer of theory to unfamiliar technical problems |
| Oral defence | 5% | Ability to defend assumptions, evidence, trade-offs and limitations |

A strong submission does not merely show that a tool ran. It explains what the result means, what it does not prove and which assumptions could change the conclusion.

The six 100-mark sample final examinations, answer keys, project rubrics and oral-defence guide are in [13 — University-Style Assessment Bank](13-UNIVERSITY-ASSESSMENTS.md). The complete learner protocol is in [14 — Self-Study Learner Handbook](14-SELF-STUDY-LEARNER-HANDBOOK.md). Course learning outcomes are mapped to teaching, formative checks, labs, exam questions and capstone evidence in [15 — CLO Assessment Traceability](15-CLO-ASSESSMENT-TRACEABILITY.md). The programme-level audit findings are in [12 — Academic Quality Audit](12-ACADEMIC-AUDIT.md).

## 7. Integrated capstone — Campus Equipment and Inventory Platform

### 7.1 Problem statement

Design a service that allows eligible university users to discover, reserve, collect and return shared equipment. The system must maintain an authoritative inventory, prevent conflicting reservations, track condition and maintenance, integrate with identity and notification services, support staff workflows, preserve audit history and recover from infrastructure failure.

This is intentionally a socio-technical system. Its success depends on software, databases, physical equipment, staff, users, policy, identity providers, network infrastructure, operating procedures and recovery capability.

### 7.2 Initial assumptions to challenge

For an initial exercise, assume:

- several departments share equipment;
- equipment has maintenance and availability states;
- students and staff have different permissions;
- reservations use start and end times;
- external identity and notification services may be unavailable;
- the system has a registration peak and quieter operating periods;
- the university requires auditability and a tested recovery process.

The assumptions are deliberately incomplete. Students must identify what needs stakeholder confirmation rather than silently treating assumptions as facts.

### 7.3 Capstone progression across courses

| Course | Capstone artefact |
|---|---|
| I — Systems Thinking | Boundary statement, behaviour-over-time graphs, causal-loop diagram and stock-flow model of demand/backlog/maintenance |
| II — Systems Engineering | Stakeholder register, ConOps, system requirements, functional architecture, interface register and trade study |
| III — Requirements Engineering | Reviewed SRS, use cases, state models, quality scenarios, acceptance criteria and traceability matrix |
| IV — Software System Design | API contract, data model, transaction invariant, queue/event design, consistency analysis, failure handling and observability plan |
| V — Architecture | Candidate architectures, C4 views, ADRs, ATAM-style evaluation, cost-benefit analysis and fitness functions |
| VI — Reliability and SRE | Reliability model, FMEA/FTA, SLOs, alerting, incident plan, postmortem and backup/restore evidence |

### 7.4 Final submission

The final capstone should contain:

1. project purpose, scope, assumptions and stakeholders;
2. systems-thinking model and policy analysis;
3. ConOps and operational scenarios;
4. stakeholder needs and system requirements;
5. functional and logical architecture;
6. API, data and interface specifications;
7. architecture views and ADRs;
8. trade study and risk register;
9. verification and validation plan;
10. reliability analysis and SLO specification;
11. incident, disaster recovery and backup/restore procedures;
12. final report and oral defence describing residual risk and unresolved questions.

## 8. Academic standards for your submissions

A submission should:

- distinguish sourced facts from assumptions and engineering judgments;
- cite books, papers, standards and online documentation accurately;
- distinguish a published standard from a draft or a course-specific convention;
- avoid unsupported quantitative thresholds;
- use a model only within its assumptions and stated purpose;
- avoid confusing an availability objective with correctness or safety;
- explain uncertainty and missing evidence;
- make every major recommendation traceable to a requirement, stakeholder goal or risk.

The resource companion marks access conditions and identifies which sources are course materials, textbooks, standards or supplementary references. A free course page does not mean the course grants credit or instructor feedback. A public standard catalogue entry does not mean the standard's full text is openly licensed.

## 9. Recommended order and pacing

Take the courses sequentially. Courses I–III establish systems reasoning and specification. Courses IV–V build on requirements and design. Course VI uses the architecture and system behaviour defined in previous courses.

For a full programme, allocate:

- 13 weeks for each course;
- 1 week between courses for review and capstone integration;
- additional time for the final capstone and oral defence.

This produces an approximately 72–84 week learning programme plus review and project time. A shorter 24-week schedule would be a compressed survey, not the depth intended here.

## 10. Completion criteria

You have completed the programme when you can independently:

- explain the dynamic behaviour of the capstone system;
- derive its system requirements from stakeholder needs;
- design and defend its data, API and distributed interaction model;
- compare architecture alternatives and explain consequences;
- calculate and interpret its reliability measures and SLOs;
- restore its critical data within a demonstrated recovery objective;
- defend its design using traceable evidence rather than unsupported preference.

---

## 11. Self-study and practical companion files

- [14 — Self-Study Learner Handbook](14-SELF-STUDY-LEARNER-HANDBOOK.md): prerequisite diagnostics, weekly method, feedback loops and mastery gates.
- [15 — CLO Assessment Traceability](15-CLO-ASSESSMENT-TRACEABILITY.md): learning-outcome-to-evidence matrix.
- [16 — Lab Environment and Reproducibility](16-LAB-ENVIRONMENT-AND-REPRODUCIBILITY.md): exact commands, tool assumptions and reproducibility protocol.
- [17 — Worked Examples and Reference Solutions](17-WORKED-EXAMPLES-AND-REFERENCE-SOLUTIONS.md): numerical oracles, full solutions and common failure analysis.
- `labs/`: six runnable practical tracks; each contains source, tests, input data and a local README.

## Course companion files

The [academic audit](12-ACADEMIC-AUDIT.md) records scope, findings, outcome mapping and limitations. The [assessment bank](13-UNIVERSITY-ASSESSMENTS.md) provides exam blueprints, sample papers, answer keys and rubrics.

- [Resource library](07-RESOURCE-LIBRARY.md) — books, courses, lecture archives, official documentation, standards, tools, papers and legal access notes.
- [Laboratory manual and capstone](08-LABS-AND-CAPSTONE.md) — structured practical work and integrated project assessment.
- [Study plan](09-STUDY-PLAN.md) — suggested progression and milestones.
- [Research notes and source-quality record](10-RESEARCH-NOTES.md) — research method, current source checks, gaps and limitations.
- [Advanced problem sets and worked solutions](11-ADVANCED-PROBLEM-SETS-AND-WORKED-SOLUTIONS.md) — additional quantitative and design problems with detailed solutions.


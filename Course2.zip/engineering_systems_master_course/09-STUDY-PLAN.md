# Six-Course Study Plan — 78-Week Sequence

This plan is for a serious independent programme, not a 24-week survey. It allocates **13 weeks to each of the six courses** (78 weeks total), with approximately **8–12 hours per week**. The pace may be adjusted, but do not compress the problem sets and labs into passive reading.

The six course texts are the primary teaching material. External lectures, books and documentation provide alternative explanations, specialist depth and practical demonstrations. You do not need to complete every optional reference in the Resource Library.

## Weekly study protocol

| Activity | Typical time | What to do |
|---|---:|---|
| Core reading | 2–3 h | Study the relevant sections of the course text; derive equations and recreate diagrams yourself. |
| External lecture/reading | 1–2 h | Use the mapped university material or textbook chapter to deepen one topic. |
| Problem solving | 2 h | Work through numerical problems, proofs, modelling questions or design exercises without looking at solutions first. |
| Laboratory/project | 2–4 h | Build or analyse the artefact specified in the lab manual. |
| Review | 30–60 min | Write a concise concept summary, glossary updates and unresolved questions. |

A strong study session should produce an artefact or a solved problem, not just a video watch history.

## Course I — Systems Thinking and System Dynamics (Weeks 1–13)

| Week | Main topics | Study work | Practical checkpoint |
|---:|---|---|---|
| 1 | Systems, boundaries, purpose and emergence | Course I §§1–2; Meadows introduction | Lab 1 boundary statement |
| 2 | Events, patterns, structure and reference modes | Build behaviour-over-time graphs from a stated problem | Stakeholder map and three reference modes |
| 3 | Causal structure and link polarity | MIT 15.871 introductory system dynamics material | Draw and explain positive/negative causal links |
| 4 | Reinforcing and balancing loops | Study loop dominance and loop interactions | Lab 2 first causal-loop model |
| 5 | Delays and unintended consequences | Study policy resistance and archetypes | Identify two delayed effects in the case |
| 6 | Stocks, flows and integral equations | Derive the backlog balance equation | Lab 3 model structure and units |
| 7 | Dynamic behaviour and nonlinear response | Study exponential growth, goal-seeking and overshoot | Run a base-case simulation |
| 8 | Model construction and parameterisation | MIT 15.879 selected modelling session | Document model equations and assumptions |
| 9 | Model testing and validation | Dimensional, extreme-condition and boundary tests | Complete validation log |
| 10 | Calibration, sensitivity and uncertainty | Explore parameter variation and model fit | Sensitivity plots and robustness discussion |
| 11 | Alternative modelling methods | Compare system dynamics, discrete-event and agent-based models | Justify a modelling method for a second scenario |
| 12 | Policy design and leverage | Compare structural intervention with parameter change | Policy experiment report |
| 13 | Integration and assessment | Review the entire course and solve the problem set | Submit Labs 1–3 and a short oral defence |

**Course completion standard:** explain the system structure, build a dimensionally consistent model, conduct credible tests and defend the limits of the model. A diagram alone is not sufficient.

## Course II — Systems Engineering Fundamentals (Weeks 14–26)

| Week | Main topics | Study work | Practical checkpoint |
|---:|---|---|---|
| 14 | System of interest, systems context and complexity | Course II §§1–2; SEBoK introduction | Define system boundary and interfaces |
| 15 | Lifecycle models and V-model | MIT 16.842 lifecycle material; NASA handbook | Lifecycle process map |
| 16 | Stakeholder analysis and needs | MIT 16.842 stakeholder lectures | Stakeholder register and need statements |
| 17 | Concept of operations | NASA tutorial and Course II ConOps section | Lab 4 draft ConOps |
| 18 | Requirements, functions and decomposition | MIT 16.842 requirements and architecture | Functional hierarchy |
| 19 | Functional flow and interface management | Study interface registers and N²/sequence views | Lab 5 interface control artefact |
| 20 | Architecture synthesis and concepts | Compare at least two candidate system concepts | Allocation and architecture rationale |
| 21 | Trade-space exploration and decision methods | Work a weighted trade study | Sensitivity analysis of the decision |
| 22 | MBSE and SysML | SEBoK MBSE material; Gaphor tutorials | System context and block/structure model |
| 23 | Risk, safety and human systems integration | Hazard identification and risk treatment | Risk register and preliminary hazard analysis |
| 24 | Integration and verification | Define integration strategy and verification methods | Verification cross-reference matrix |
| 25 | Validation, technical reviews and transition | SRR/PDR/CDR/TRR/ORR evidence | Mini-PDR package |
| 26 | Operations, maintenance and retirement | Review lifecycle closure and supportability | Submit Labs 4–5 and defend lifecycle choices |

**Course completion standard:** produce a coherent system concept, lifecycle, functional architecture, interface set and evidence-based review package.

## Course III — Requirements Engineering (Weeks 27–39)

| Week | Main topics | Study work | Practical checkpoint |
|---:|---|---|---|
| 27 | What requirements are and why they fail | Course III §§1–2; IREB CPRE syllabus | Distinguish need, requirement and design |
| 28 | Context and stakeholder identification | DTU RED and Gothenburg OpenRE materials | Lab 6 stakeholder map and context model |
| 29 | Elicitation techniques and evidence | Interviews, observation, workshops, document analysis | Elicitation plan and source register |
| 30 | Analysis, scope and negotiation | Goals, conflicts, assumptions and constraints | Negotiation and decision record |
| 31 | Requirements modelling | Use cases, state models, data models and scenarios | Create linked context and behaviour models |
| 32 | Individual requirement quality | Atomicity, necessity, feasibility, clarity and verifiability | Quality review of draft requirements |
| 33 | SRS structure and specification | Requirement attributes, numbering, baselines | Lab 6 initial SRS |
| 34 | Functional and interface requirements | Define system behaviour and interface contracts | Requirement-to-interface mapping |
| 35 | Quality requirements | Performance, availability, security, modifiability and usability | Measurable quality scenarios |
| 36 | Verification, validation and acceptance | Test design and acceptance criteria | Lab 7 use cases and test suite |
| 37 | Prioritisation and release planning | Value, risk, dependency and effort | Prioritised requirement baseline |
| 38 | Traceability and change management | Impact analysis, configuration and version control | Change-impact analysis |
| 39 | Agile/hybrid requirements and assessment | IREB RE@Agile and Course III review | Submit Labs 6–7 and defend SRS quality |

**Course completion standard:** produce a baseline that is understandable, verifiable, traceable and sufficiently complete to guide architecture and testing.

## Course IV — Software System Design and Distributed Systems (Weeks 40–52)

| Week | Main topics | Study work | Practical checkpoint |
|---:|---|---|---|
| 40 | Workloads, latency, throughput and capacity | Course IV §§1–2 | Workload model with explicit assumptions |
| 41 | API contracts and interface evolution | REST, idempotency, error semantics and versioning | Lab 8 API contract |
| 42 | Data modelling and relational constraints | Schema normalisation and business invariants | ER model and relational schema |
| 43 | Indexes, storage engines and query plans | B-trees, LSM trees and PostgreSQL EXPLAIN | Index rationale and query plan analysis |
| 44 | Transactions and isolation | ACID, MVCC and concurrency anomalies | Transaction boundary design |
| 45 | Caching and read optimisation | Cache invalidation, consistency and staleness | Cache policy and invalidation model |
| 46 | Queues, messaging and event streams | Kafka topics, partitioning, delivery semantics | Message flow and delivery guarantee analysis |
| 47 | Distributed failure models | Timeouts, retries, jitter, deadlines and idempotency | Lab 9 failure matrix |
| 48 | Replication and consistency | Leader-based and leaderless replication, read guarantees | Consistency selection matrix |
| 49 | Partitioning, sharding and load distribution | Hot keys, routing, rebalancing and failure domains | Partitioning design |
| 50 | Coordination and consensus | Logical time, ordering, Raft and distributed transactions | Consensus and ordering problem set |
| 51 | Observability, deployment and resilience | Kubernetes, OpenTelemetry and service dependencies | Instrumentation/deployment plan |
| 52 | Integration and assessment | MIT 6.5840/Brown CS1380 selected lectures/labs | Submit Labs 8–9 and Lab 16; defend correctness guarantees |

**Course completion standard:** reason about workload, interfaces, data correctness, concurrency and partial failure. A technology diagram without failure semantics is incomplete.

## Course V — Software Architecture and Trade-off Analysis (Weeks 53–65)

| Week | Main topics | Study work | Practical checkpoint |
|---:|---|---|---|
| 53 | Architecture scope and drivers | Course V §§1–2; CMU architecture lectures | Architectural driver register |
| 54 | Quality attributes and scenarios | Performance, availability, security and modifiability | Quality scenario set |
| 55 | Architectural styles | Layered, hexagonal, modular monolith, services and events | Compare structurally different alternatives |
| 56 | Architecture tactics | Availability, performance, security and modifiability tactics | Tactic-to-scenario map |
| 57 | Modularity and dependency structure | Coupling, cohesion, boundaries and change propagation | Dependency map |
| 58 | Architecture views and documentation | C4, 4+1 and documentation concerns | C4 context/container views |
| 59 | Attribute-Driven Design | ADD design iteration and scenario refinement | Architecture design iteration |
| 60 | Architecture decisions | ADR context, alternatives, consequences and revisiting | Three ADRs |
| 61 | Architecture evaluation and ATAM | QAW, utility trees, risks, sensitivity and trade-off points | ATAM-style review plan |
| 62 | Cost-benefit and uncertainty | CBAM, lifecycle cost and sensitivity analysis | Weighted decision and uncertainty report |
| 63 | Architecture fitness functions | Static/dynamic conformance, performance budgets and policy tests | Fitness-function specification |
| 64 | Architecture debt and evolution | Migration, deprecation, reversibility and governance | Evolution plan |
| 65 | Integration and assessment | Review CMU/SEI case material | Submit Lab 10 and defend architecture selection |

**Course completion standard:** compare alternatives against measurable requirements, document decisions, expose risks and show why the selected architecture is appropriate under stated assumptions.

## Course VI — Reliability Engineering, SRE and Incident Response (Weeks 66–78)

| Week | Main topics | Study work | Practical checkpoint |
|---:|---|---|---|
| 66 | Reliability concepts and probability | Course VI §§1–2 | Reliability function and hazard calculations |
| 67 | Exponential and Weibull models | Life-data analysis and censoring | Fit/interpret reliability distribution; complete Lab 17 censored-data analysis |
| 68 | Maintainability and availability | MTTF/MTBF/MTTR and limitations | Availability calculation |
| 69 | RBD and redundancy | Series, parallel and common-cause failure | Lab 11 RBD |
| 70 | FMEA/FMECA and fault trees | Severity/occurrence/detection and minimal cut sets | Lab 11 FMEA and FTA |
| 71 | Reliability growth and FRACAS | Test evidence, corrective action and closure | FRACAS record |
| 72 | Service reliability and error budgets | Google SRE book/workbook | Service reliability model |
| 73 | SLI/SLO design | User journeys, windows, burn rates and policy | Lab 12 SLO specification |
| 74 | Monitoring and observability | Metrics, logs, traces, telemetry costs and privacy | Dashboard and alert design |
| 75 | Incident response and command | Google SRE Classroom and incident management | Lab 13 incident simulation |
| 76 | Postmortems and organisational learning | Causal analysis and corrective action | Postmortem report |
| 77 | Backup, recovery, RTO/RPO | PostgreSQL backup/restore and recovery planning | Lab 14 restore test/tabletop |
| 78 | Integrated capstone defence | Synthesize all six courses | Submit Lab 15 dossier and oral defence |

**Course completion standard:** quantify reliability with explicit assumptions, design user-centred SLOs, run a disciplined incident process and demonstrate that recovery procedures are credible.

## Major programme milestones

| End of week | Required evidence |
|---:|---|
| 13 | Dynamic model, equations, validation and policy experiment |
| 26 | ConOps, lifecycle, functional architecture, interface register and PDR package |
| 39 | SRS, acceptance tests, traceability matrix and change baseline |
| 52 | Workload/API/data model, transaction design and distributed failure analysis |
| 65 | C4 views, architecture alternatives, ADRs, trade study and ATAM-style review |
| 78 | Reliability analysis, SLOs, incident record, restore evidence and integrated dossier |

## Assessment cadence for each 13-week course

Use the following pattern in addition to the weekly artefacts above. The six sample examination papers and marking keys are in [13 — University-Style Assessment Bank](13-UNIVERSITY-ASSESSMENTS.md).

| Course week | Assessment | Evidence to retain |
|---:|---|---|
| 1–3 | Low-stakes concept quizzes and first problem set | Definitions, diagrams, derivations and error log |
| 4–6 | Second problem set and first lab checkpoint | Reproducible partial artefact and test/evidence record |
| 7 | Mid-course individual assessment (15% of course grade) | Timed written answers under controlled conditions |
| 8–10 | Remaining problem sets and main lab work | Versioned artefact, test oracle, results and critique |
| 11–12 | Major course project (25%) and lab dossier (25%) | Technical report, source files, test results and traceability |
| 13 | Final written examination (10%) and oral defence (5%) | Timed paper and individual defence notes |

The 20% problem-set/quiz component is assessed throughout the course. Final exam papers in the assessment bank are 100 marks each; their course-grade contribution is 10%. The remaining 90% is assessed by the other components in the master syllabus.

## How to use the external resources without losing the course structure

- Use the **course text first** to understand the topic sequence and terminology.
- Use one primary external course as a second explanation: MIT 15.871/15.879, MIT 16.842, DTU/Gothenburg RE material, MIT 6.5840/Brown CS1380, CMU/SEI architecture resources, and Google SRE Classroom.
- Read textbook chapters when a topic needs deeper formal treatment. A library copy is preferable to searching for unauthorised scans.
- Use official documentation for implementation-specific behaviour, and record the version consulted.
- Do not try to watch every video or read every link. The objective is mastery of the learning outcomes and the ability to defend the submitted artefacts.

## Progress tracking

For each week, record:

- Concepts mastered (explain from memory, not merely recognise).
- Problems completed without solution guidance.
- Artefacts produced and revision/version.
- Tests or evidence collected.
- Assumptions that remain unverified.
- Topics to revisit before the next course.

A course is complete only when its problem set and required practical submissions are finished and you can explain the reasoning behind them in an oral review.


## Programme audit and assessment references

Use the [academic audit](12-ACADEMIC-AUDIT.md) to understand the coverage map, source limitations and the severity-ranked revision record. Use the [assessment bank](13-UNIVERSITY-ASSESSMENTS.md) for mid-course blueprints, final examinations, answer keys, project rubrics and oral-defence criteria.

# Course IV — Software System Design and Distributed Systems

**Academic level:** Upper-division undergraduate / introductory graduate  
**Suggested duration:** 13 teaching weeks  
**Prerequisites:** Data structures, databases, operating systems and networking fundamentals; practical programming experience  
**Core question:** How do we design software systems that preserve correctness and meet performance, availability, security and operational requirements as they scale and fail?

---

## Course description

Software system design is the activity of organising software components, data, interfaces, protocols and operational mechanisms to satisfy a defined workload and set of quality requirements. Distributed systems extend this problem across processes, machines, networks and independent failure domains. Once components communicate over a network, latency, message loss, partial failure, concurrency, inconsistent clocks and independent upgrades become part of the design problem.

This course combines foundational software design with distributed-systems reasoning. It progresses from workload and interface contracts to data storage, transactions, caching, asynchronous work, replication, partitioning, consistency, consensus, resilience and observability. It emphasises the difference between a design pattern and a guarantee: a queue, replica or microservice does not automatically make a system scalable, reliable or correct.

The running case is an online equipment reservation service. The system must prevent double-booking, integrate with university identity and notifications, tolerate dependency failure, preserve audit history, and recover data after infrastructure loss.

## Learning outcomes

By the end of the course, a student should be able to:

1. Characterise workloads using concurrency, throughput, latency percentiles, data volume, access patterns and growth assumptions.
2. Define stable API contracts, semantics, versioning and failure behaviour.
3. Select data models and storage technologies based on access patterns and correctness needs.
4. Explain indexes, storage-engine trade-offs, transactions, isolation anomalies and replication lag.
5. Design caches and asynchronous workflows with explicit invalidation, ordering and delivery semantics.
6. Explain distributed-system failure models, partial failure, timeouts, retries, idempotency and clock limitations.
7. Compare replication, partitioning, consistency models and consensus protocols.
8. Explain the CAP theorem without overgeneralising it into a simplistic database-selection rule.
9. Design for load, backpressure, failure containment, observability and graceful degradation.
10. Evaluate an end-to-end design against quality scenarios and present the trade-offs.

## Lecture sequence

| Lecture | Topic | Required output |
|---:|---|---|
| 1 | Design problems, workloads and quality goals | Workload model and service profile |
| 2 | APIs, contracts and protocol semantics | API specification |
| 3 | Data modelling and storage selection | Logical data model and access patterns |
| 4 | Indexing and storage-engine behaviour | Query-plan and index analysis |
| 5 | Transactions, isolation and concurrency | Transaction design and anomaly analysis |
| 6 | Caching and read optimisation | Cache policy and invalidation strategy |
| 7 | Queues, events and asynchronous processing | Message contract and workflow model |
| 8 | Distributed-system models and failures | Failure model and timeout policy |
| 9 | Replication, consistency and partitioning | Consistency and data-placement design |
| 10 | Consensus and coordination | Consensus safety/liveness analysis |
| 11 | Resilience, idempotency and backpressure | Failure-handling design |
| 12 | Capacity, observability and operational design | Capacity and telemetry plan |
| 13 | Integrated architecture case | Design review |
| 14 | Design critique and examination | Defended end-to-end design |

---

# Part I — Workload and interface design

## 1. Design begins with the workload

A design should be based on the problem the system must solve, the workload it must support and the quality attributes it must satisfy. Starting with a technology name reverses this reasoning.

A workload model describes:

- request types and their frequency;
- read/write ratios and access patterns;
- concurrent users and in-flight operations;
- request and response sizes;
- data volume and retention;
- burstiness and seasonal variation;
- geographical distribution;
- consistency and freshness expectations;
- dependency behaviour;
- expected growth and peak conditions.

For a reservation service, important workloads include searching inventory, viewing availability, creating reservations, cancelling reservations, checking eligibility, recording collection/return and generating audit reports. These operations differ in consistency and latency needs. A search result may tolerate slight staleness; a reservation commit must enforce the no-double-booking invariant.

### 1.1 Latency, throughput and concurrency

**Latency** is the elapsed time for an operation. **Throughput** is the rate at which operations complete. **Concurrency** is the number of operations active at a given time. They are related but not interchangeable.

Report latency as a distribution. The mean can hide a long tail. Useful values include p50, p90, p95, p99 and, for some services, p99.9. A p95 latency of 500 ms means 95% of measured requests completed in 500 ms or less over the defined sample and measurement window. It does not say that every request completes in 500 ms.

Little's Law states:

\[
L=\lambda W
\]

where \(L\) is average number of items in a stable system, \(\lambda\) is average throughput or arrival rate, and \(W\) is average time in the system. Units must be consistent. If a service completes 40 requests/second and average time in the system is 0.25 seconds, the average number of concurrent requests in the system is 10.

Little's Law is a general relationship under stable long-run conditions; it does not by itself predict queueing delay or performance under overload.

### 1.2 Queueing and utilisation

A service with arrival rate \(\lambda\) and service capacity \(\mu\) is stable only when the long-run arrival rate is below capacity in a simple single-server model. As utilisation approaches one, waiting time can increase sharply. Real systems have multiple service stages, variable task sizes, priorities and batching, so the simple M/M/1 model is a teaching approximation rather than a complete performance model.

A system should define a capacity envelope and a load-shedding or backpressure strategy. “Autoscale” is not a complete capacity plan: scaling may be limited by database locks, downstream quotas, cold starts, rate limits or stateful bottlenecks.

## 2. API design as contract design

An API is a contract between a provider and its consumers. It specifies operations, data, semantics, security, error behaviour, versioning and operational expectations.

For an HTTP API, important decisions include:

- resource and operation model;
- HTTP method and status-code semantics;
- request and response schemas;
- identifiers and pagination;
- authentication and authorisation;
- validation and error formats;
- idempotency and duplicate handling;
- rate limits and quotas;
- concurrency control;
- timeouts and retry expectations;
- versioning and compatibility.

An API should be designed from consumer tasks and domain invariants, not from database tables. Exposing internal table structure can make the API brittle and reveal unnecessary implementation details.

### 2.1 Command semantics and idempotency

An operation is idempotent if applying it multiple times has the same intended effect as applying it once. HTTP `GET` is defined as safe and idempotent; `PUT` and `DELETE` are intended to be idempotent in their semantics. `POST` is not inherently idempotent.

A create-reservation endpoint may be retried after a timeout. The client cannot tell whether the first attempt failed before commit or succeeded while its response was lost. An idempotency key allows the server to associate retries with one logical request. The server must define key scope, retention, payload matching, concurrent duplicate handling and response replay.

Pseudocode:

```text
handle_create(request, key):
    validate request
    begin transaction
    existing = lookup idempotency_record(key)
    if existing exists:
        if existing.request_hash != hash(request):
            reject key reuse with different payload
        return existing.stored_response

    reservation = enforce_invariant_and_create(request)
    response = build_response(reservation)
    store idempotency_record(key, hash(request), response)
    commit transaction
    return response
```

The idempotency record and business effect should be committed atomically where possible. Otherwise the service may create a reservation without recording the key, or record the key without creating the reservation.

### 2.2 API versioning

Backward compatibility means existing clients continue to work under the changed provider. Additive optional fields may be compatible, while changing field meaning, removing fields, narrowing accepted values or changing error semantics can break consumers. Explicit versioning, deprecation policy, contract tests and consumer communication reduce risk.

Versioning should be a managed life-cycle activity. A version number alone does not ensure compatibility.

## 3. Data modelling and storage selection

Data modelling begins with domain entities, relationships, invariants, ownership and access patterns. The choice of storage technology follows from those needs.

Relational databases are strong when the domain requires structured relationships, constraints, transactions, joins and ad hoc queries. Document stores can be suitable when aggregates are naturally accessed as documents and schema evolution is important. Key-value stores are useful for simple key-based access. Wide-column stores can support large distributed workloads with predictable partition keys. Search engines support text retrieval and relevance ranking, but should not automatically become the authoritative transactional store.

### 3.1 Relational design

A relational model describes entities and relationships using tables, keys and constraints. Normalisation reduces certain forms of redundancy and update anomalies. Denormalisation may improve read performance but introduces consistency and update complexity.

For a reservation service, a simplified schema may include:

```sql
CREATE TABLE equipment (
    equipment_id UUID PRIMARY KEY,
    status TEXT NOT NULL,
    category_id UUID NOT NULL,
    version BIGINT NOT NULL DEFAULT 0
);

CREATE TABLE reservation (
    reservation_id UUID PRIMARY KEY,
    equipment_id UUID NOT NULL REFERENCES equipment(equipment_id),
    user_id UUID NOT NULL,
    starts_at TIMESTAMPTZ NOT NULL,
    ends_at TIMESTAMPTZ NOT NULL,
    status TEXT NOT NULL,
    created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    CHECK (starts_at < ends_at)
);
```

This schema is a starting point, not a full solution. It does not alone prevent overlapping confirmed reservations. The invariant must be enforced by a database constraint or a transaction strategy appropriate to the database's concurrency semantics. In PostgreSQL, exclusion constraints over time ranges can be useful; another approach is serializable transactions or explicit locking. The chosen approach must be tested under concurrent requests.

### 3.2 Data invariants

An invariant is a condition that must remain true. Examples:

- an equipment item has a stable unique identifier;
- a reservation end time is after its start time;
- one equipment item cannot have overlapping confirmed reservations;
- a cancelled reservation does not remain eligible for collection;
- access-control updates are auditable;
- inventory state cannot be changed from maintenance to available without an authorised release procedure.

Invariants should be enforced as close to the authoritative data boundary as practical. Relying only on a UI check creates race conditions because multiple clients can observe the same stale state.

## 4. Indexing and storage engines

An index is an auxiliary data structure that improves selected access patterns at a cost in storage and write overhead. An index does not make all queries faster. The planner must choose it, and the query must match its key structure and selectivity.

### 4.1 B-trees

B-tree indexes maintain keys in an ordered, balanced structure. They are useful for equality, range scans and ordered access. A composite index on `(user_id, starts_at)` may support a query retrieving a user's reservations sorted by start time. Column order matters: the index can efficiently support predicates on the leading column and combinations of leading columns, but not every arbitrary suffix-only predicate.

### 4.2 LSM trees

Log-structured merge trees buffer writes in memory and periodically merge sorted runs on disk. They can provide high write throughput for workloads with many writes, but reads may need to check multiple structures and compaction creates write amplification. Storage engines make different trade-offs among write throughput, read amplification, space amplification, compaction and recovery.

### 4.3 Query plans

Use query plans to understand how the database executes important queries. Examine estimated versus actual rows, scan types, join methods, sort operations, buffer reads, lock waits and timing. A query plan is evidence for a particular data distribution and configuration; production data can differ from development data.

Index decisions should consider write cost, selectivity, update frequency, storage and the exact query set. Too many indexes can slow writes and increase maintenance overhead.

## 5. Transactions, ACID and concurrency control

A transaction groups operations into a unit with defined commit or rollback behaviour. ACID describes four important properties:

- **Atomicity:** all required changes in the transaction occur, or none do.
- **Consistency:** committed transactions preserve declared invariants.
- **Isolation:** concurrent transactions behave according to a defined isolation model.
- **Durability:** committed changes survive the specified failures covered by the storage system's durability guarantees.

ACID does not mean a transaction is automatically correct. The application must define the right invariants and choose an isolation level or locking strategy that preserves them.

### 5.1 Concurrency anomalies

Concurrent operations can create anomalies if the transaction model permits them:

- **Dirty read:** a transaction reads uncommitted data from another transaction.
- **Non-repeatable read:** the same row read twice returns different committed values.
- **Phantom:** repeating a predicate query returns a different set of rows because another transaction inserted or deleted matching rows.
- **Lost update:** one transaction overwrites another's change without incorporating it.
- **Write skew:** concurrent transactions read overlapping state and update different rows, jointly violating an invariant.

Different isolation levels prevent different sets of anomalies. Exact semantics depend on the database implementation. Do not assume identical labels provide identical behaviour across all DBMS products.

### 5.2 Optimistic concurrency

Optimistic concurrency uses a version, timestamp or compare-and-swap condition to detect concurrent modification. For example:

```sql
UPDATE equipment
SET status = 'reserved', version = version + 1
WHERE equipment_id = :id
  AND version = :expected_version
  AND status = 'available';
```

The application checks the number of affected rows. Zero rows means the observed version or state was no longer valid. The client must respond appropriately rather than silently assuming success.

### 5.3 PostgreSQL MVCC example

PostgreSQL uses multiversion concurrency control (MVCC). Read queries generally use snapshots of row versions, so ordinary reads do not conflict with writes in the same way as a simple read-lock model. PostgreSQL also provides a serializable isolation level using Serializable Snapshot Isolation (SSI). Applications must still understand transaction conflicts, serialization failures, row locks and retry requirements. See the [official PostgreSQL concurrency-control documentation](https://www.postgresql.org/docs/current/mvcc-intro.html).

## 6. Caching and read optimisation

Caching stores a derived or previously retrieved value closer to its consumers to reduce latency or backend load. It is a consistency design, not merely a speed feature.

Common patterns include:

- **Cache-aside:** application reads cache first, then loads from the source on a miss and populates the cache.
- **Read-through:** cache coordinates loading on a miss.
- **Write-through:** writes update cache and backing store in a coordinated path.
- **Write-behind:** writes are buffered and propagated later; this creates durability and loss risks that must be managed.
- **Refresh-ahead:** values are refreshed before expected expiry.

### 6.1 Cache invalidation

A stale cache can cause incorrect availability, unauthorised access, invalid prices or inconsistent user experience. Define:

- time-to-live and freshness requirements;
- invalidation trigger;
- cache key and tenant/user scope;
- behaviour after failed invalidation;
- consistency window;
- stampede prevention;
- cache outage behaviour;
- sensitive-data handling.

For reservation availability, the cached search view may be advisory, but the transaction that commits a reservation must check the authoritative invariant. The cache must not become the sole authority for whether an item can be booked.

## 7. Queues, events and asynchronous processing

Asynchronous messaging decouples producers from consumers in time and often reduces synchronous dependency chains. It introduces new questions: delivery semantics, ordering, duplicate handling, consumer failure, schema evolution, dead-letter handling and observability.

A message contract should define identifier, event type, schema version, timestamp semantics, partition key, producer, consumers, ordering expectation, retention and retry policy. Consumers must expect redelivery unless the platform and workflow prove stronger semantics within a defined boundary.

### 7.1 At-most-once, at-least-once and exactly-once

- **At-most-once:** a message is processed zero or one times; loss may occur.
- **At-least-once:** a message is eventually delivered or processed one or more times; duplicates may occur.
- **Exactly-once:** each intended effect occurs once within a precisely defined transaction boundary.

The phrase “exactly once” is frequently overclaimed. A broker may deduplicate producer retries or atomically commit consumed offsets and produced records within its own transactional domain. That does not automatically make an external payment, database write, email or physical equipment handover happen exactly once.

Apache Kafka's idempotent producer prevents certain retry duplicates in the Kafka log; Kafka transactions can atomically coordinate Kafka records and consumer offsets for supported flows. External side effects still require idempotent business operations, an outbox/inbox strategy or another transaction protocol. Consult [Kafka's official delivery semantics and processing guarantees](https://kafka.apache.org/documentation/#semantics).

### 7.2 Transactional outbox

The dual-write problem occurs when an application writes business data to a database and separately publishes an event. If the database transaction succeeds and event publication fails, the system becomes inconsistent. If publication succeeds and the database rolls back, consumers receive an event for a change that did not commit.

The transactional outbox stores the business change and event record in the same database transaction. A relay later publishes outbox events. The relay may publish duplicates, so consumers still need idempotent handling. The outbox avoids the unsafe assumption that two independent systems can be updated atomically without a coordination mechanism.

### 7.3 Sagas and process managers

A saga decomposes a long-running business transaction into local transactions with compensating actions. For example, reservation confirmation may reserve an item, authorise a deposit and schedule a notification. If a later step fails, the system may release the item or reverse the deposit authorisation. Compensation is not always a perfect mathematical inverse; it is a business action that restores an acceptable state.

Sagas require explicit states, timeouts, retry policies, idempotency, compensation rules and human intervention paths. They are not a substitute for ACID transactions inside a single database.

## 8. Distributed-system models and failure

A distributed system is a collection of autonomous processes that communicate over a network. Nodes execute independently and may fail independently. A network can delay, duplicate, reorder or lose messages; connections can break after a remote operation has committed; processes can pause and resume; clocks can differ.

### 8.1 Partial failure

In a local function call, a failure often appears as a return value or exception. In a distributed call, a timeout does not tell the caller whether the remote operation never started, is still executing, committed successfully or failed after commit but before replying.

This uncertainty is fundamental. A correct design must define how to handle ambiguous outcomes. Blind retry can duplicate a non-idempotent action. Treating every timeout as a failure can create duplicate reservations or payments.

### 8.2 Timeouts and deadlines

Set finite timeouts for network operations. A deadline is an end-to-end time budget; each downstream call should consume a portion of that budget. If a request has a 2-second user-facing deadline, a downstream call should not independently wait 10 seconds.

Timeouts should be informed by observed latency distributions, expected network variation and the operation's importance. Too-short timeouts create false failures; too-long timeouts keep resources occupied and worsen overload.

### 8.3 Retry policy

Retries should be bounded, use exponential backoff and jitter, respect the caller's deadline and distinguish transient from permanent errors. Retrying at multiple layers can multiply attempts. A service that retries three times and calls a downstream service that also retries three times may create many attempts per original request.

Circuit breakers, bulkheads, rate limits and load shedding help contain failure propagation. They require careful tuning and explicit recovery behaviour.

## 9. Replication, consistency and partitioning

Replication maintains copies of data across nodes or locations. It may improve availability, read capacity and disaster recovery, but creates replication lag, conflict resolution and consistency questions.

### 9.1 Leader-based replication

A leader accepts writes and propagates them to followers. Stronger acknowledgement requirements can reduce the risk of losing committed data but may increase latency and reduce write availability during network partitions. Asynchronous replication may improve response time but create a non-zero data-loss window if a leader fails before replicas receive updates.

### 9.2 Leaderless replication and quorums

In leaderless designs, multiple replicas may accept writes. Quorum read/write rules can improve the probability that reads observe recent writes under certain assumptions. If there are \(N\) replicas, read quorum \(R\) and write quorum \(W\), the condition \(R+W>N\) guarantees an overlap between read and write sets, but it does not by itself guarantee linearizability. Replica placement, concurrent writes, versioning and conflict resolution matter.

### 9.3 Consistency models

- **Strong consistency / linearizability:** operations appear to occur atomically in an order consistent with real-time ordering.
- **Sequential consistency:** operations appear in a single total order that preserves each process's program order, but not necessarily real-time ordering.
- **Causal consistency:** causally related operations are observed in an order that preserves causality.
- **Eventual consistency:** replicas converge when no new updates occur and communication/repair continues under stated assumptions.
- **Read-your-writes:** a client can observe its own completed updates.
- **Monotonic reads:** a client does not observe older state after observing newer state.

The correct model depends on business invariants. A social feed may tolerate eventual consistency; inventory allocation or a unique reservation may require stronger coordination for the decisive write.

### 9.4 CAP theorem, correctly scoped

The CAP theorem concerns trade-offs in the presence of a network partition: a distributed data system cannot guarantee both linearizable consistency and availability for every request to every non-failing node during a partition under the formal model. It does not say that every database is permanently either “CP” or “AP”, nor that developers can simply choose two of three features under normal conditions.

The engineering question is: during a partition or loss of coordination, which operations should continue, which should reject or wait, and what invariants must remain true? The answer may differ by operation within one system.

### 9.5 Partitioning and sharding

Partitioning divides a dataset into subsets. Horizontal sharding distributes rows by a partition key. A good key balances load and localises common access patterns. A poor key can create hot partitions, uneven storage or cross-shard transactions.

Partition strategies include range, hash, directory-based and tenant-based approaches. Consider rebalancing, key evolution, tenant isolation, query routing, cross-partition joins and failure domains before adopting sharding. Sharding increases operational complexity and should not be the default first step for a small service.

## 10. Consensus and coordination

Consensus is the problem of multiple processes agreeing on a value or ordered log despite failures under a defined model. It underpins leader election, replicated state machines and distributed coordination services.

Raft separates the problem into leader election, log replication and safety. A cluster typically has an odd number of voting members to provide a majority with a single failure-domain interpretation. A majority quorum can continue after a minority failure, but not when a majority is unavailable. Correct implementations must follow the protocol's term, log-matching and commitment rules.

Consensus does not eliminate network partitions or make a system globally available. It provides safety and liveness properties under assumptions about the failure model, stable storage and communication. During a partition, only the side with a majority can make progress for consensus-controlled state.

Students should read the original [Raft paper](https://raft.github.io/raft.pdf) and implement or simulate leader election and log replication before relying on consensus as a black-box concept.

## 11. Reliability patterns and data correctness

A robust distributed design uses several complementary controls:

- explicit timeouts and propagated deadlines;
- bounded retries with backoff and jitter;
- idempotency for repeated commands;
- circuit breakers for failing dependencies;
- bulkheads to isolate resource pools;
- backpressure to prevent unbounded queues;
- rate limiting and load shedding;
- durable message handling and dead-letter procedures;
- replication and recovery plans;
- observability across service boundaries.

These patterns have failure modes. A circuit breaker can remain open after recovery if its probe policy is wrong. A queue can hide overload while its oldest message age increases. A retry can amplify an outage. A replica can be available but stale. A cache can serve an outdated authorisation decision. Each pattern needs a quality objective and a test.

## 12. Security, privacy and observability in design

Security is a system property. Design should define trust boundaries, identities, authentication, authorisation, secrets, encryption, audit events, rate limits, input validation, dependency risk and incident response. Apply least privilege, explicit service identity and secure defaults.

Privacy requires purpose limitation, minimisation, retention and deletion rules, access logging and careful treatment of sensitive data in telemetry. Logs and traces should not accidentally expose credentials, access tokens, personal file names or confidential payloads.

Observability is the ability to infer internal system state from emitted evidence. Common telemetry signals include logs, metrics and traces. Distributed tracing links operations across services through propagated context. Metrics support aggregate and time-series analysis. Logs provide detailed event records. OpenTelemetry defines vendor-neutral APIs, SDKs, protocols and Collector components; it is not itself a complete backend for storage, querying or visualisation. See [OpenTelemetry concepts](https://opentelemetry.io/docs/concepts/).

## 13. Deployment, capacity and operational constraints

Deployment architecture influences system reliability. Consider configuration management, rollout strategy, rollback, health checks, service discovery, resource allocation, secrets, observability and environment parity.

In Kubernetes, readiness, liveness and startup probes have different meanings:

- **Startup probe:** protects slow-starting applications from premature liveness failures.
- **Readiness probe:** indicates whether a pod should receive service traffic.
- **Liveness probe:** indicates whether a container should be restarted because it is unable to make progress.

A readiness failure should normally remove a pod from service traffic; it does not itself restart the container. A poorly designed liveness probe that fails whenever a downstream dependency is unavailable can cause restart storms. See the [Kubernetes probes documentation](https://kubernetes.io/docs/concepts/workloads/pods/probes/).

Resource requests and limits, autoscaling, disruption budgets and rollout policies are part of operational design. Scaling a stateless front end does not solve a database bottleneck. A stateful distributed service needs explicit handling of persistent volumes, identity, quorum and failure domains.

## 14. Integrated case study: reservation system under concurrency and failure

### 14.1 Invariant

For an equipment item \(e\), two confirmed reservations must not have overlapping time intervals. Define a reservation as \((e, u, s, t, status)\). The system must enforce that for two confirmed reservations \(r_1,r_2\) for the same item, either \(r_1.end \le r_2.start\) or \(r_2.end \le r_1.start\).

A UI-only availability check is insufficient. Two clients may read the same availability snapshot and submit concurrently.

### 14.2 Transactional design

The commit path should enforce the invariant in the authoritative datastore. Candidate approaches include range exclusion constraints, serializable transaction logic or explicit locking on an item/interval domain. The choice depends on database capabilities and workload. Run concurrent integration tests that deliberately create contention.

### 14.3 Notification workflow

After a reservation commits, a confirmation event should be published. Use a transactional outbox so the reservation and outbox record are committed together. A relay publishes the event. The notification consumer uses an event ID to avoid duplicate sends where the provider supports idempotency. The service should record notification status separately from reservation status; email delivery failure does not automatically invalidate the reservation.

### 14.4 Failure scenarios

- Identity provider slow: enforce an overall deadline and define fail-closed versus bounded cached-identity behaviour.
- Database commits but response is lost: client retries with an idempotency key.
- Outbox relay crashes after publish but before marking complete: event may be published again; consumer is idempotent.
- Notification provider unavailable: retain and retry messages with backoff and a dead-letter process.
- Read replica lag: reservation decision still uses authoritative state.
- Network partition: decide which operations may continue without coordination.
- Backup corruption: restore and validate from a known-good backup and archived logs.

The system's correctness depends on the combination of transactional invariants, distributed messaging semantics and operational recovery.

## 15. Problem set

### Problems

**1.** A service handles 60 requests/second and has average response time 0.4 seconds. Estimate the average number of requests in the system using Little's Law. State the conditions under which the relationship is useful.

**2.** Explain why p99 latency is important when composing a request that calls five downstream services in parallel and waits for all five.

**3.** Design an API contract for creating a reservation. Include idempotency, error semantics and concurrency behaviour.

**4.** Describe the lost-update and write-skew anomalies. Give a reservation or inventory example for each.

**5.** Explain why a cache must not be the final authority for whether an item can be reserved.

**6.** Compare at-most-once and at-least-once message delivery. Design a consumer that safely handles duplicate events.

**7.** A data store has \(N=5\) replicas, a read quorum of 3 and a write quorum of 3. Does \(R+W>N\)? What does that overlap condition establish, and what does it not establish?

**8.** Explain the CAP theorem for a reservation service during a network partition. Which operations could be rejected and why?

**9.** Explain why a timeout does not prove that a remote operation failed.

**10.** Distinguish readiness and liveness probes, and describe one way a liveness probe can make an outage worse.

### Solution sketches

**1.** \(L=\lambda W=60\times0.4=24\) requests on average. Use consistent units and a stable observation period. It is not a complete queueing model and does not provide a latency percentile.

**2.** The aggregate request completes only after the slowest required dependency. Even if each dependency has a high probability of meeting a target, the probability that all meet it is lower. Tail latency compounds. Measure the end-to-end path and identify whether the operation truly needs all five dependencies synchronously.

**3.** Use an authenticated `POST /reservations` with validated item and time fields, an idempotency key, a clear conflict response, an explicit policy for duplicate payloads, and a defined transaction outcome. The API must not report success until the authoritative state is committed.

**4.** Lost update: two staff members read item state `available`; each writes `reserved`, overwriting one another's intent without detecting the conflict. Write skew: two transactions each observe that two staff members are on duty and independently remove one from the rota; both commit and leave no staff on duty, violating a cross-row invariant.

**5.** Availability data can become stale or two requests can race. The cache can guide the user interface, but the authoritative transaction must re-check and enforce the booking invariant.

**6.** At-most-once may drop an event; at-least-once may redeliver. A safe consumer stores processed event IDs or makes the business operation idempotent within the same transaction as its state update. A separate “processed” flag without atomicity can itself create failure windows.

**7.** \(R+W=6>5\), so any read quorum and write quorum intersect in at least one replica under the simple set model. This overlap alone does not prove linearizability, resolve concurrent writes or guarantee the application reads the latest value; protocol and timing assumptions matter.

**8.** If a partition prevents nodes from coordinating, the system may reject reservation commits on a minority side to preserve the no-double-booking invariant. Search or browsing may continue from stale data with a visible freshness warning. Different operations can have different policies.

**9.** The operation may have committed while the reply was lost or delayed. The caller's view is uncertain. Resolve through an idempotency key, operation status query or reconciliation process rather than blindly repeating a non-idempotent command.

**10.** Readiness controls whether traffic should be sent to a pod. Liveness controls restart. If liveness depends on an external database that is temporarily unavailable, every pod may restart repeatedly and make recovery harder.

## 16. Practical assignment

Design a reservation service and implement a small prototype. Required deliverables:

1. workload model with request rates, peak concurrency, latency goals and data growth;
2. API contract with idempotency and error handling;
3. logical data model and database schema;
4. concurrency invariant and enforcement strategy;
5. query and index plan;
6. cache design with invalidation and freshness policy;
7. asynchronous event workflow using an outbox or equivalent;
8. failure-mode table for timeout, retry, duplicate delivery and partition;
9. replication/consistency decision record;
10. trace, metric and log instrumentation;
11. load test, race test and failure-injection report;
12. architecture review explaining what the prototype does not prove.

## Further reading and primary technical documentation

- Martin Kleppmann and Chris Riccomini, *Designing Data-Intensive Applications*, 2nd ed. (2026). Advanced distributed data systems reference; publisher/library access.
- MIT, [6.5840 Distributed Systems](https://pdos.csail.mit.edu/6.824/): lectures, reading material and programming labs.
- Brown University, [CS1380 Distributed Systems lecture archive](https://cs.brown.edu/courses/cs138/s23/lectures.html): recordings, lecture notes and paper readings.
- University of Edinburgh, [Distributed Systems course](https://opencourse.inf.ed.ac.uk/ds): topic outline and learning outcomes.
- [System Design Primer](https://github.com/donnemartin/system-design-primer): broad study guide and design examples; use as a supplement, not a replacement for distributed-systems theory.
- [PostgreSQL official documentation](https://www.postgresql.org/docs/current/): data modelling, MVCC, indexes, WAL, replication, backup and point-in-time recovery.
- [Apache Kafka documentation](https://kafka.apache.org/documentation/): streaming, partitions, delivery semantics and transactions.
- [Kubernetes documentation](https://kubernetes.io/docs/): deployment, services, probes, resources and stateful workloads.
- [OpenTelemetry documentation](https://opentelemetry.io/docs/): instrumentation, signals, context propagation and Collector.
- Diego Ongaro and John Ousterhout, [Raft: In Search of an Understandable Consensus Algorithm](https://raft.github.io/raft.pdf).


---

# Advanced lecture notes and worked extensions

## 17. Distributed-system models and the limits of time

A distributed system has no perfectly shared global clock. Each machine observes time through a local clock that may drift, jump or be adjusted. A timestamp from one host cannot always be used to determine the true order of events on another host.

### 17.1 Physical clocks and clock uncertainty

Physical clocks are useful for human-readable timestamps and approximate event timing, but distributed applications must account for clock skew and uncertainty. Network time synchronisation reduces error but does not eliminate it. A system should not assume that two events with timestamps 10:00:00.010 and 10:00:00.020 necessarily occurred in that order on different machines unless the clock-error bounds and measurement model justify the inference.

For time-critical requirements, define whether a timestamp represents event occurrence, event receipt, transaction commit, or a client observation. Store a consistent time basis and retain the source of the timestamp.

### 17.2 Logical clocks and causality

A Lamport clock assigns logical timestamps that respect the happened-before relation. If event A causally precedes event B, then the logical timestamp of A is less than that of B. The converse is not guaranteed: a lower timestamp does not prove causality.

A process increments its counter before each local event. When sending a message, it includes the counter. On receiving a message with timestamp \(t\), the receiver sets its counter to \(\max(local,t)+1\). This gives a partial ordering consistent with causal precedence.

Vector clocks carry a vector of counters and can distinguish causally related events from concurrent events under a known process set. They are useful for explaining conflict detection and causal histories, although practical deployments may use variants with changing membership or compressed metadata.

### 17.3 Why timeouts are not failure detectors

A timeout indicates that a response did not arrive within a chosen time. It does not prove the remote process has failed. The response may be delayed, the network may be congested, the caller's thread may be paused, or the operation may have committed while its reply was lost.

A failure detector based on timeouts trades detection speed against false suspicions. Short timeouts detect problems quickly but can declare healthy nodes failed under transient delay. Long timeouts reduce false suspicion but increase recovery time. Distributed protocols must be designed for this uncertainty.

## 18. Queueing theory as a performance tool

For an M/M/1 queue, arrivals are Poisson with rate \(\lambda\), service times are exponential with rate \(\mu\), and one server handles requests. The utilisation is:

\[
\rho=\frac{\lambda}{\mu}
\]

The queue is stable when \(\rho<1\). Expected number in the system is:

\[
L=\frac{\rho}{1-\rho}
\]

Expected time in the system is:

\[
W=\frac{1}{\mu-\lambda}
\]

and Little's Law gives \(L=\lambda W\).

For \(\lambda=8\) requests per second and \(\mu=10\) requests per second, utilisation is 0.8 and expected time in the system is 0.5 seconds. If arrivals rise to 9.5 requests per second while service capacity stays 10, expected time becomes 2 seconds. The queue is not necessarily overloaded yet, but it has little spare capacity and is highly sensitive to bursts.

These equations are not a full model of a production API. Real workloads may have heavy-tailed service times, multiple servers, priorities, retries and correlated arrivals. They provide a conceptual basis for capacity headroom and load-shedding decisions.

## 19. Backpressure and overload control

When arrival rate persistently exceeds service capacity, a queue grows. If queues are unbounded, memory or storage can be exhausted and latency can become unacceptable long before the process crashes.

Backpressure communicates that a downstream consumer cannot accept more work at the current rate. Strategies include bounded queues, request rejection, producer throttling, admission control, load shedding and prioritisation.

A system should distinguish:

- work that can be delayed safely;
- work that can be rejected and retried by clients;
- work that must be prioritised;
- work that must never be dropped;
- work that can be coalesced or recomputed.

For an event pipeline, monitor queue depth and oldest-message age. A stable depth can still conceal a failing consumer if throughput is low and incoming work is also low.

## 20. Consistency choices by operation

A single application can use several consistency models for different data. For equipment reservations:

- search availability may be eventually consistent if the user sees a clear indication that availability is provisional;
- the authoritative reservation commit must enforce no-overlap consistency;
- audit events must be durable and attributable;
- notification delivery may be asynchronous and at-least-once;
- reporting may use an eventually consistent read model.

This is more precise than labelling the entire system “strongly consistent” or “eventually consistent.” For each operation, identify the invariant, acceptable stale interval, failure response and reconciliation strategy.

### 20.1 Read-your-writes and monotonic reads

A user who successfully reserves an item should be able to see their own reservation, even if a read replica has not yet received the update. The system can route that user's subsequent read to the leader, wait for replication, or return the committed result from the write path. The choice has latency and availability consequences.

Monotonic reads prevent a user from seeing a newer state and then an older state on a later read. Client affinity or version tokens can help, but need an explicit design and test.

## 21. Raft at a conceptual level

Raft is a consensus algorithm that maintains a replicated log across a group of servers. It uses terms, leader election and log replication. A candidate requests votes; a majority is needed to become leader. The leader accepts log entries and replicates them to followers. Once an entry is committed according to the protocol's rules, the state machine applies it.

Three important properties are:

- **Election safety:** at most one leader can be elected in a given term.
- **Log matching:** if two logs contain an entry with the same index and term, preceding entries match under the protocol invariants.
- **Leader completeness:** entries committed in a prior term are preserved in future leaders' logs.

Students should understand why a majority is required and why a minority partition cannot safely commit independent writes for the same replicated state. They should not attempt to implement production consensus from a lecture summary; the original paper and a lab provide the required detail.

## 22. Storage and data-lifecycle design

A system's data architecture should define:

- authoritative source for each data element;
- ownership and update authority;
- schema and event evolution;
- integrity constraints;
- retention, archive and deletion;
- backup and recovery;
- access, privacy and audit;
- migration and compatibility.

A common failure is to create a cache, search index, analytics warehouse and operational database without defining which is authoritative. When they disagree, operators need reconciliation rules. Derived data should be reproducible or have a documented recovery process.

### 22.1 Schema evolution

For event streams and distributed services, consumers and producers may deploy at different times. Schema changes should preserve compatibility according to a defined policy: backward compatibility, forward compatibility or full compatibility. Renaming a field, changing units or reusing an enum value can break a consumer even if the serialized format remains valid.

Treat schema versions as contracts. Test old and new producers against old and new consumers where rolling deployment requires mixed-version operation.

## 23. Extended design review questions

1. Why can a timestamp order be incorrect across two hosts?
2. How does a Lamport clock preserve causal order, and what can it not tell us?
3. Explain the trade-off between short and long timeouts.
4. Why should queue age be monitored in addition to queue depth?
5. Give an example of an operation that can be eventually consistent in a reservation platform and one that cannot.
6. What guarantees does a majority quorum support in a replicated consensus group?
7. Why must consumers be idempotent even when a message broker offers producer deduplication?
8. What is the authoritative source for an inventory item's status in your proposed design, and how are derived views rebuilt?
## 24. Safety and liveness properties for distributed applications

Distributed-systems correctness is easier to reason about when properties are stated as safety or liveness claims.

- A **safety property** says that something bad never happens. A violation can be demonstrated by a finite execution prefix. Example: two overlapping reservations for the same unique item are never both confirmed.
- A **liveness property** says that something good eventually happens. Its truth depends on assumptions about scheduling, communication, failures and recovery. Example: a valid reservation request eventually receives a terminal outcome when the service is healthy and the request is not permanently blocked.

A system can preserve safety by rejecting operations during a partition, while losing liveness for users on the disconnected side. It can improve apparent liveness by accepting writes on both sides, while violating the no-double-booking safety property. State which property is required, for which operation, under which failure assumptions.

### 24.1 Define the invariant before choosing a database or protocol

For each equipment item, let confirmed reservations be intervals \([s_i,e_i)\). The half-open interval convention means one reservation ending at 11:00 does not conflict with another beginning at 11:00. For every pair of distinct confirmed reservations for the same item:

\[
(r_i.item=r_j.item)\Rightarrow(e_i\leq s_j\lor e_j\leq s_i)
\]

This is a domain invariant. The database constraint, transaction isolation level, lock strategy or consensus protocol is an implementation mechanism that must preserve it under concurrency and failure.

## 25. Operation histories and linearizability

A history records client invocations and responses. Operations may overlap in real time. Linearizability requires that each completed operation appear to take effect at one instant between its invocation and response, and that this single order respect real-time precedence: if operation A completes before operation B begins, A must appear before B.

Consider two clients that concurrently submit overlapping reservations for the same item. Both requests are invoked before either returns. If one returns `confirmed` and the other returns `conflict`, there is a legal sequential order: the successful reservation takes effect first. If both return `confirmed`, no legal sequential ordering can satisfy the no-overlap invariant. The service is not linearizable with respect to that reservation operation.

A test should record invocation time, response time, operation, arguments and result. A test oracle searches for a legal sequential history that respects real-time order and the operation specification. For a small history, manual checking is possible; larger histories require a checker or a deliberately modelled state-machine test harness.

### 25.1 Linearizability, sequential consistency and serializability

These terms are related but not interchangeable:

- **Sequential consistency** requires one total order consistent with each process's program order; it need not preserve real-time order between non-overlapping operations.
- **Linearizability** adds real-time ordering for concurrent operations and is commonly used to specify object-level distributed APIs.
- **Serializability** concerns whether concurrent database transactions are equivalent to some serial execution. It does not, by itself, require the serial order to match real-time order.
- **Strict serializability** combines serializability with real-time ordering between transactions. It is a strong transaction-level property.

Do not label an application “linearizable” merely because its database uses transactions. The isolation level, transaction boundaries, read/write path, replica routing, external side effects and API semantics all matter.

## 26. PostgreSQL transaction semantics applied to reservation correctness

PostgreSQL uses multiversion concurrency control (MVCC). `READ COMMITTED` gives each statement a snapshot of rows committed before that statement began. `REPEATABLE READ` keeps a transaction-level snapshot, but applications must not assume that every possible cross-row invariant is serializable. `SERIALIZABLE` detects executions that could produce a serialization anomaly and aborts one transaction with a serialization failure; the application must be prepared to retry the entire transaction.

A transaction retry must re-run the decision logic from a fresh transaction. Do not retry only the final `INSERT` after a serialization failure, and do not perform irreversible external side effects inside a transaction that may be retried. Use an outbox or another idempotent boundary for notifications and external workflows.

Three implementation approaches for the no-overlap invariant are:

1. **Database-enforced constraint:** use a suitable database constraint where the schema and data types support it. This makes the invariant authoritative at the storage boundary.
2. **Explicit locking:** lock the relevant item or conflict range in a carefully defined transaction. This can be effective but may reduce concurrency and requires deadlock handling.
3. **Serializable transaction:** express the business decision in a serializable transaction and retry serialization failures with a bounded policy.

The correct choice depends on data model, workload, database capabilities and invariant scope. A read-then-write check at `READ COMMITTED` without an enforcing constraint or appropriate lock is vulnerable to a race.

Official reference: [PostgreSQL concurrency control](https://www.postgresql.org/docs/current/mvcc-intro.html), [transaction isolation](https://www.postgresql.org/docs/current/transaction-iso.html), and [SET TRANSACTION](https://www.postgresql.org/docs/current/sql-set-transaction.html). Pin the PostgreSQL major version used by a real project and re-check the documentation for that version.

## 27. Raft safety properties and test strategy

Raft is a consensus algorithm for managing a replicated log. A correct implementation is not simply one in which a leader is elected and key/value requests appear to work in a happy-path demonstration. Students should be able to explain the protocol's safety properties and design tests that attempt to falsify them.

The core properties include:

- **Election Safety:** at most one leader is elected in a given term.
- **Leader Append-Only:** a leader does not overwrite or delete entries in its log; it only appends.
- **Log Matching:** if two logs contain an entry with the same index and term, the logs are identical up through that entry.
- **Leader Completeness:** a committed entry appears in the logs of leaders elected in later terms.
- **State Machine Safety:** if a server applies a log entry at a given index, no other server applies a different entry at that index.

Testing should include leader crash, follower crash, network partition, delayed and reordered messages, duplicate requests, restart from persisted state, snapshot installation and concurrent clients. A passing happy-path test is not enough. Repeat tests under varied schedules and retain the random seed or event trace needed to reproduce a failure.

## 28. Distributed-systems practical sequence benchmark

The Spring 2026 MIT 6.5840 course publishes five cumulative programming labs: MapReduce, a key/value server, Raft, a key/value service built on Raft, and a sharded key/value service. The course is a 12-unit graduate subject with readings, labs, an optional project, a midterm and a final. This sequence is a useful benchmark for the practical depth expected in a serious distributed-systems course.

Use the labs as optional external implementations rather than copying solutions. The self-study objective is to reproduce the reasoning and the required properties. Source: [MIT 6.5840 Spring 2026](https://pdos.csail.mit.edu/6.824/). The official site publishes lab specifications and tests; the grading service and enrolled-student support are not part of the open self-study materials.

## 29. Kubernetes health probes and failure handling

Kubernetes distinguishes three probe purposes:

- **Startup probe:** checks whether the application has completed startup. While it has not succeeded, liveness and readiness probes are not run for that container. A startup failure eventually causes the kubelet to kill the container and apply its restart policy.
- **Liveness probe:** checks whether a container should be restarted. It should detect a process that cannot recover by itself, not merely an unavailable dependency.
- **Readiness probe:** checks whether the Pod should receive traffic. Failure marks the Pod unready so it stops receiving traffic through matching Services; it does not, by itself, restart the container.

A dangerous anti-pattern is making liveness depend on a shared database or identity provider. A database outage can then cause every application replica to restart, reducing capacity precisely when recovery requires it. Readiness may depend on whether the service can safely serve its intended request class; liveness should normally focus on local process health and deadlock detection. Probe thresholds, termination grace periods and graceful shutdown behaviour must be tested together.

Official references: [Kubernetes probe concepts](https://kubernetes.io/docs/concepts/workloads/pods/probes/) and [probe configuration task](https://kubernetes.io/docs/tasks/configure-pod-container/configure-liveness-readiness-startup-probes/).

## 30. Observability as a distributed contract

OpenTelemetry is a vendor-neutral framework and specification for collecting telemetry. Its signals include traces, metrics and logs; context propagation carries correlation information across service boundaries. The API, SDK, OTLP protocol, Collector and semantic conventions are distinct parts of the architecture. A collector pipeline can receive, process and export telemetry, but it cannot compensate for missing instrumentation or poor attribute design.

For the reservation platform, define:

- traces for the request path across API, database, outbox relay and notification provider;
- metrics for request rate, error rate, latency distributions, queue depth, oldest-message age, serialization retries and reservation conflicts;
- structured logs for state transitions and failure context, while excluding secrets and unnecessary personal data;
- stable resource attributes such as service name, version and deployment environment;
- explicit sampling policy and retention/cost limits.

Do not use unbounded identifiers such as user ID, reservation ID or raw URL as metric labels. High-cardinality dimensions can make metrics prohibitively expensive. Put operation-specific identifiers in traces or appropriately protected logs instead.

Official reference: [OpenTelemetry documentation](https://opentelemetry.io/docs/) and [specification status](https://opentelemetry.io/docs/specs/status/).

## 31. Additional examination problems

1. State the reservation safety invariant and a separate liveness property. Give a failure scenario that preserves the first but prevents the second.
2. Given a history in which two conflicting reservation requests both return `confirmed`, explain why no legal linearization exists.
3. Distinguish serializability from linearizability. Give one example where a database transaction schedule is serializable but the API may still violate a real-time guarantee.
4. Explain why a PostgreSQL serializable transaction can abort and why the whole transaction must be retried.
5. Explain why a failed readiness probe should not have the same consequence as a failed liveness probe.
6. Map one trace, metric and log event to the reservation invariant without introducing high-cardinality metric labels.


## 32. Consensus: what the guarantees require

Consensus is a fault-tolerant agreement problem. A replicated state machine uses an agreement protocol to choose an ordered sequence of commands; replicas apply the same deterministic state transition function to the same committed log prefix. The protocol does not make arbitrary application code deterministic, nor does it remove the need to define command semantics, persistence, snapshots, membership changes and client retry behaviour.

Three properties must be distinguished:

- **Agreement / safety:** two correct participants do not decide different values for the same decision slot, or two committed logs do not diverge at an already committed position.
- **Validity:** a decided value must satisfy the protocol's validity condition; an implementation must state which proposals can be chosen.
- **Termination / liveness:** correct participants eventually decide, under the model's assumptions about failures, synchrony and communication.

The FLP result shows that in a fully asynchronous message-passing model, no deterministic consensus algorithm can guarantee termination in every execution if even one process may crash. It does not say that practical consensus is impossible. Real systems use timing assumptions, failure detectors, randomisation or partial synchrony for liveness, while maintaining safety across a wider range of schedules.

### 32.1 Paxos and Raft at the right abstraction level

Paxos and Raft are families of protocols for replicated agreement/state-machine replication. They are not merely “leader plus replication.” Their safety depends on quorum intersection, persistent protocol state, term/ballot or epoch rules, log-prefix constraints, and carefully specified rules for when entries are committed and applied. Raft is often introduced through leader election, log replication and safety; Paxos is commonly introduced through proposer/acceptor/learner roles and ballot numbers. A correct explanation must connect the rules to the safety proof, not only list components.

A majority quorum in a fixed group of \(N=2f+1\) replicas intersects every other majority quorum in at least one replica. That intersection is a necessary ingredient in many crash-fault-tolerant consensus protocols; it is not by itself a complete proof of safety. The protocol's state persistence and voting rules determine whether the intersecting replica prevents conflicting decisions.

Do not conflate crash fault tolerance with Byzantine fault tolerance. A crash-fault model assumes a failed process stops or becomes unavailable; a Byzantine model allows arbitrary or adversarial behaviour. Quorum sizes and protocol assumptions differ. A three-replica majority protocol should not be described as tolerating one Byzantine replica unless the design actually provides Byzantine agreement.

### 32.2 What the FLP result means for engineering decisions

A timeout is an imperfect suspicion, not proof of failure. A node that appears unreachable may be slow, partitioned or paused. Two nodes can each believe they are leader if the system uses a weak election or stale lease. Therefore, time-based leader ownership should be paired with fencing or an epoch/term rule that the resource enforcing writes can validate. A monotonically increasing fencing token lets a resource reject a write from a stale holder after it has observed a newer token.

The engineering question is not “is the service highly available?” in isolation. It is “which operations continue on which partition, with what consistency guarantee, and what invariant may be violated or protected?” Availability, latency and correctness must be stated per operation.

### 32.3 Verification strategy

A distributed-system claim needs more than unit tests. Use several layers:

1. unit tests for deterministic state transitions and protocol rules;
2. property-based or generative tests for histories, message ordering and duplicate delivery;
3. fault injection for crash, delay, loss, partition and recovery cases;
4. model checking for bounded state spaces and temporal invariants;
5. integration tests against the chosen persistence and network stack;
6. operational tests for restart, restore, membership and version transitions.

The Go practical in this package tests a single-process atomic reservation invariant and idempotency. It does not implement Raft or prove multi-node consensus. Lab 16 remains a separate fault-model and protocol-analysis assignment. This boundary is deliberate: a small honest model is more educational than a deceptively complete “distributed database” exercise.

## 33. A disciplined test for reservation histories

For each operation, define an abstract sequential specification first. For a reservation operation, the specification may accept a request only if the time interval is free and the actor is eligible; otherwise it returns a conflict or rejection. A history record should include invocation time, response time, arguments, result and client identity.

A history is linearizable only if there exists a legal sequential ordering that:

- contains all completed operations (and handles pending operations according to the checker model);
- respects real-time precedence for non-overlapping calls;
- satisfies the abstract sequential specification.

For the single-slot concurrent Go lab, the key invariant is that at most one unique reservation can be created for a slot. A test with many simultaneous callers is a useful executable check, but finite test runs do not prove the invariant for all executions. The mutex-protected critical section provides the implementation argument in this in-memory example; a real multi-instance deployment must move the invariant to an authoritative transactional or consensus-backed boundary.

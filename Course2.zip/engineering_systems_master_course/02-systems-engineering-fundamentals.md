# Course II — Systems Engineering Fundamentals

**Academic level:** Upper-division undergraduate / introductory graduate  
**Suggested duration:** 13 teaching weeks  
**Prerequisites:** Systems thinking, basic engineering design, elementary probability and project planning  
**Core question:** How do we transform stakeholder needs into a verified, operable system over its entire life cycle?

---

## Course description

Systems engineering (SE) is an interdisciplinary approach to designing, integrating, verifying, validating and evolving systems whose behaviour depends on interacting technical, human, organisational and environmental elements. It is not simply project management, requirements writing or architecture diagramming. It coordinates those activities around a coherent system definition and a life-cycle view.

The course uses a campus equipment and inventory platform as a running case. The platform combines software, devices, identity services, staff workflows, physical storage, network connectivity and university policies. The case is intentionally broader than a web application: a technically correct service can still fail if equipment is unavailable, users cannot access it, maintenance is neglected, staff procedures conflict with the design, or recovery processes are untested.

The main organising model is the systems-engineering life cycle. Needs and constraints inform requirements. Requirements and operational scenarios inform architecture. Architecture is realised through components and processes. Integration, verification and validation provide evidence that the system conforms to its definition and is fit for its intended use. Operations and feedback reveal new needs and drive controlled change.

## Learning outcomes

By the end of this course, a student should be able to:

1. Explain the role, scope and value of systems engineering in complex projects.
2. Compare life-cycle models and explain how technical processes interact across a system life cycle.
3. Identify stakeholders, model their needs and develop a credible concept of operations (ConOps).
4. Translate stakeholder needs into system requirements and allocate requirements to architectural elements.
5. Decompose a system functionally and structurally while preserving interfaces and end-to-end behaviour.
6. Perform a structured trade study using performance, cost, risk, schedule, operability and uncertainty.
7. Explain model-based systems engineering (MBSE), model purposes and the role of SysML and related notations.
8. Plan technical risk management, safety analysis, human-systems integration and configuration management.
9. Distinguish verification from validation and select appropriate inspection, analysis, demonstration and test evidence.
10. Define life-cycle reviews and explain their entry criteria, exit criteria and evidence.
11. Evaluate the system through transition, operations, maintenance, evolution and retirement.

## Lecture sequence

| Lecture | Topic | Required output |
|---:|---|---|
| 1 | Systems engineering as an integrating discipline | System-of-interest definition |
| 2 | Life-cycle processes and engineering governance | Tailored life-cycle model |
| 3 | Stakeholders, needs and operational context | Stakeholder register and context diagram |
| 4 | Concept of operations and mission scenarios | ConOps and operational scenarios |
| 5 | Requirements definition and allocation | Requirements hierarchy and traceability links |
| 6 | Functional analysis, decomposition and interfaces | Functional architecture and interface register |
| 7 | Architecture synthesis and design alternatives | Candidate architecture models |
| 8 | Trade studies, life-cycle cost and uncertainty | Decision analysis report |
| 9 | MBSE, SysML and model governance | Integrated model package |
| 10 | Risk, safety and human-systems integration | Preliminary risk and hazard assessment |
| 11 | Integration, verification and validation | Verification and validation plan |
| 12 | Reviews, transition, operation and retirement | Review package and life-cycle strategy |

---

# Part I — The discipline and its life cycle

## 1. What systems engineering does

A system is a combination of interacting elements organised to achieve an objective that cannot be achieved as effectively by the elements operating independently. Elements may include hardware, software, people, data, facilities, procedures, services, external systems and the environment.

Systems engineering addresses three recurring difficulties:

1. **Emergent behaviour:** system-level properties arise from interactions, not simply from component properties. A set of individually reliable devices can still produce an unreliable service if their interfaces, timing or maintenance dependencies are poorly designed.
2. **Competing objectives:** performance, cost, schedule, safety, security, maintainability, usability and environmental impact rarely improve together without trade-offs.
3. **Life-cycle effects:** decisions made during concept development influence manufacture, integration, training, operations, upgrade, support and retirement. An inexpensive design may impose high operational cost or create an unavailable specialist dependency.

Systems engineering therefore creates and maintains a reasoned relationship between stakeholder needs, requirements, architecture, design decisions, implementation evidence and operational outcomes.

### 1.1 System of interest and system context

The **system of interest (SoI)** is the system whose development or analysis is being managed. Its context includes external actors, systems, policies, infrastructure, operating environments and constraints with which it interacts.

For the campus equipment platform, a system context diagram should show at least students, teaching staff, equipment staff, university identity, payment or deposit services if applicable, network infrastructure, physical storage, asset-management systems and external maintenance suppliers. The diagram should make interfaces visible without implying that every external system is under project control.

Context is not the same as architecture. Context describes the environment and interactions. Architecture describes the internal organisation of the system and its relationship to that environment.

### 1.2 Systems of systems

A system of systems (SoS) is a set of independently useful systems that cooperate to produce capabilities that none could produce alone. The constituent systems may have independent owners, schedules, governance and technical roadmaps. This creates challenges in interface stability, authority, data ownership, interoperability and change coordination.

A university platform that integrates identity, finance, access control, equipment inventory and learning management is partly an SoS problem. A project team cannot assume it can freely modify all constituent services. It must manage contracts, service-level dependencies, data semantics and evolution across organisational boundaries.

### 1.3 Technical versus organisational complexity

Technical complexity concerns interactions among components, algorithms, interfaces, states and physical processes. Organisational complexity concerns authority, incentives, stakeholder conflict, procurement, regulation, training and the distribution of responsibility. They interact. A technically elegant architecture may fail when no team owns an interface or the organisation cannot support its operational model.

## 2. The systems life cycle

A life-cycle model organises the stages and processes through which a system is conceived, developed, realised, used and retired. Different domains use different phase labels, but the engineering logic is broadly similar:

1. concept and opportunity identification;
2. stakeholder needs and operational concept;
3. system requirements and architecture;
4. design and implementation;
5. integration and verification;
6. validation and transition;
7. operation, maintenance and evolution;
8. retirement and disposal.

These phases should not be interpreted as a universal waterfall. Iterative and incremental development can perform the same engineering processes in repeated cycles. A project may prototype an interface, test an operational concept, update requirements and revise architecture before committing to a detailed design.

### 2.1 Technical processes and management processes

Systems engineering uses technical processes to define and realise the system. Common technical processes include business or mission analysis, stakeholder needs definition, requirements definition, architecture definition, design definition, system analysis, implementation, integration, verification, transition, validation, operation, maintenance and disposal.

Technical management processes govern the work and its evidence: planning, assessment, decision management, risk management, configuration management, information management, measurement, quality assurance and technical reviews. The distinction matters. A project may have an excellent architecture model but still lack configuration control, so different teams implement different versions of the system.

### 2.2 The V-model as a reasoning tool

The V-model is a way to show how decomposition and realisation on the left relate to integration and verification on the right. On the left, stakeholder needs are refined into system requirements, architecture and lower-level design. At the bottom, components or subsystems are realised. On the right, the system is integrated and verified at progressively broader levels, followed by validation against operational needs.

The V-model does not require all work to occur once in a fixed sequence. Its central lesson is traceability between a definition and the evidence that demonstrates it. A requirement introduced at system level should have an owner, a verification method and a place in the integration strategy. A stakeholder need should be linked to validation evidence, not merely to a document paragraph.

### 2.3 Tailoring the life cycle

A life-cycle process must be tailored to the system's scale, novelty, risk, uncertainty, regulation and contractual context. A small internal tool may need a concise ConOps, explicit security and data requirements, interface definitions, automated tests and an operational support plan. A safety-critical transport system needs much more formal hazard analysis, independent assurance, configuration control, review evidence and regulatory engagement.

Tailoring means selecting and adapting processes with reasons. It does not mean omitting difficult activities because the schedule is tight. A tailoring record should state the process, the degree of application, rationale, residual risk and approval authority.

## 3. Stakeholder needs and operational context

A stakeholder is an individual, group or organisation that can affect, be affected by, or perceive itself to be affected by the system. Stakeholder analysis identifies different objectives and different definitions of success.

For the campus equipment platform, students may value availability and speed; equipment staff may value accountability and manageable workload; instructors may value correct allocation before a class; finance may require auditable deposits; IT security may require least-privilege access; procurement may require approved suppliers; accessibility staff may require equivalent access for users with disabilities.

A common error is to treat the sponsor as the only stakeholder. Sponsors fund projects, but daily users, maintainers, support personnel, external service owners and affected communities may experience the consequences of design decisions.

### 3.1 Stakeholder identification and analysis

A stakeholder register should include:

| Field | Purpose |
|---|---|
| Stakeholder / group | Identifies the party |
| Role and relationship | Describes how they interact with the system |
| Desired outcomes | Captures success from their perspective |
| Constraints | Identifies legal, operational, financial or technical limits |
| Influence / authority | Records decision and approval power |
| Impact / exposure | Records how they may be affected |
| Engagement method | Specifies interview, workshop, survey, observation or review |
| Owner and status | Assigns accountability for follow-up |

Power-interest or influence-impact grids can help plan engagement, but they should not be used to dismiss stakeholders with little formal power. A group can have low influence and high exposure to harm.

### 3.2 Stakeholder needs are not system requirements

A need expresses a desired outcome in stakeholder language. A system requirement expresses a necessary, testable condition that the system must satisfy. For example:

- Need: “Students must be able to obtain the equipment required for a scheduled practical session.”
- Candidate requirement: “For an equipment item marked available, the reservation service shall prevent two confirmed reservations from overlapping for the same item.”

The second statement is more precise but does not fully satisfy the need. Other requirements may be needed for identity, opening hours, equipment readiness, accessibility, collection, return, exceptions, maintenance and support.

Needs are analysed, negotiated and decomposed. They should not be converted mechanically into one requirement each.

## 4. Concept of operations (ConOps)

A ConOps describes how stakeholders expect to use and operate a proposed system within a real environment. It connects mission, actors, scenarios, operating modes, constraints and responsibilities. It is a shared model for stakeholders, engineers, operators and decision-makers.

A useful ConOps includes:

1. purpose and scope;
2. mission or business objectives;
3. operational environment and context;
4. stakeholder roles and responsibilities;
5. normal operational scenarios;
6. degraded, emergency and recovery scenarios;
7. modes, states and transitions;
8. external interfaces and dependencies;
9. operational constraints and assumptions;
10. measures of success and unresolved questions.

### 4.1 Scenario structure

A scenario should describe an actor, a trigger, the expected sequence of interactions, system responses, exceptions and outcome. For example:

**Scenario: reserve equipment for a laboratory session**

- Trigger: an authenticated student searches for a specified equipment type.
- Preconditions: the student is eligible; the course permits the equipment; inventory data is current enough for the decision.
- Main flow: the student selects an item, checks the time window, submits a reservation and receives a confirmation.
- Alternate flows: the item is unavailable; the student's eligibility has expired; a maintenance hold is applied; the identity provider is unavailable; the reservation conflicts with an existing booking.
- Postconditions: one reservation is recorded, the item is no longer offered to conflicting reservations, and the relevant staff workflow is updated.

Scenarios reveal missing requirements. A normal-flow-only ConOps often fails to describe what happens when a dependency is unavailable, a user is late, equipment is damaged or data is incorrect.

## 5. Requirements, functions and architecture

Systems engineering distinguishes what the system must achieve from how the design achieves it. Requirements capture necessary conditions. Functional analysis identifies what functions must be performed. Architecture allocates functions and responsibilities to elements and defines their interfaces.

### 5.1 Functional decomposition

Functional decomposition breaks an end-to-end capability into smaller functions. For an equipment platform:

- manage identity and eligibility;
- publish equipment status;
- search and select equipment;
- evaluate reservation constraints;
- create and modify reservations;
- issue collection instructions;
- record collection and return;
- detect damage and maintenance status;
- reconcile inventory;
- notify users and staff;
- retain audit records.

A functional hierarchy should be neither too coarse nor too detailed. If a function is still a broad outcome, the team may not be able to allocate or verify it. If it describes individual code statements, the architecture may be prematurely tied to implementation.

### 5.2 Functional flow and allocation

A functional flow describes the sequence and conditions under which functions interact. A functional allocation table maps each function to a system element, identifies inputs and outputs, and records constraints or verification needs.

| Function | Candidate element | Input | Output | Critical concern |
|---|---|---|---|---|
| Authenticate user | Identity integration | Credentials / token | Identity and claims | Trust boundary |
| Check eligibility | Eligibility service | Identity, course data | Eligibility decision | Stale data |
| Reserve item | Reservation service | Item, user, time window | Reservation result | Concurrency |
| Change item status | Inventory service | Staff action, sensor or inspection | Availability state | Auditability |
| Send confirmation | Notification service | Reservation event | Message | Delivery retry |

Allocation is provisional. An architecture alternative may place some functions in one service or split them across services. The allocation must be justified by quality attributes, ownership, security, scaling and change considerations.

### 5.3 Interface management

An interface is a shared boundary across which systems exchange information, material, energy or services. Interface failures often occur because two teams interpret a data field differently, use different units, disagree on error semantics or assume incompatible timing.

An interface-control description should define:

- interface owner and counterpart;
- purpose and scope;
- physical, logical or organisational boundary;
- data schema, units, naming and validation;
- protocol, timing, sequencing and state assumptions;
- error conditions, retries and timeout behaviour;
- security, privacy and access-control expectations;
- versioning and compatibility policy;
- verification method and acceptance evidence.

An interface is not complete merely because an endpoint URL or wire connector exists. The contract includes semantics, constraints, failure behaviour and lifecycle ownership.

## 6. Architecture synthesis and design alternatives

Architecture synthesis turns requirements and functions into a candidate arrangement of system elements, interfaces, interactions and operating concepts. The architect should generate credible alternatives before committing to one design.

For the equipment platform, possible alternatives include:

- a single application with a relational database;
- a modular monolith with well-defined internal modules;
- separate services for inventory, reservations and identity integration;
- a managed platform combined with limited custom software;
- centralised inventory control with offline-capable collection terminals.

No option is universally superior. A microservice design may improve independent deployment or team autonomy, but it introduces network failure, distributed data consistency, observability, deployment and operational complexity. A monolith may simplify transactions and operations but may create scaling or organisational constraints as the system grows.

Architecture selection requires a set of quality goals, not technology fashion.

## 7. Trade studies and decision analysis

A trade study compares alternatives using criteria that matter to the mission and stakeholders. The process is:

1. Define the decision and the scope of alternatives.
2. Identify mandatory constraints and eliminate infeasible options.
3. Define measurable criteria and units.
4. Establish stakeholder priorities and weights.
5. Collect evidence or estimates for each alternative.
6. Score alternatives using a documented method.
7. Perform sensitivity and uncertainty analysis.
8. Record the decision, rationale, risks and revisit triggers.

### 7.1 Weighted decision model

A simple weighted score is:

\[
S_j=\sum_{i=1}^{n} w_i r_{ij}
\]

where \(S_j\) is the score of alternative \(j\), \(w_i\) is the normalised weight of criterion \(i\), and \(r_{ij}\) is the normalised rating of alternative \(j\) on criterion \(i\). Weights should sum to one. Ratings must use a consistent scale and have written definitions.

Example: compare three architecture alternatives against cost, availability, changeability and operational burden. If the weights are 0.25, 0.30, 0.25 and 0.20, and alternative A scores 4, 3, 4 and 5 on a five-point benefit scale, then:

\[
S_A=0.25(4)+0.30(3)+0.25(4)+0.20(5)=3.80
\]

This score is not an objective truth. It depends on the alternatives, weights, scale, evidence and assumptions. It should support a decision conversation, not replace engineering judgment.

### 7.2 Sensitivity and uncertainty

A decision is robust when a reasonable change in assumptions does not reverse the recommendation or create unacceptable risk. Recalculate the score under plausible weight ranges. Identify thresholds at which another alternative becomes preferred. Where inputs are uncertain, use ranges, scenarios or probabilistic analysis rather than false point precision.

A weighted score also needs safeguards:

- Non-negotiable safety or legal constraints should not be traded away by a high score elsewhere.
- Criteria should avoid double-counting the same quality attribute.
- Scores should not hide severe weaknesses in a critical criterion.
- Stakeholder weights should be justified and contested openly.
- Include life-cycle cost, not only acquisition cost.

### 7.3 Life-cycle cost

Life-cycle cost includes acquisition, development, integration, training, operation, maintenance, support, upgrades, downtime, transition and disposal. A low purchase price can be offset by high licensing, support or replacement cost. Costs should be estimated over a stated period, with assumptions for inflation, discounting, utilisation and uncertainty.

A common present-value form is:

\[
PV=\sum_{t=0}^{T}\frac{C_t}{(1+d)^t}
\]

where \(C_t\) is cost in period \(t\), \(d\) is the discount rate and \(T\) is the analysis horizon. Use a consistent real or nominal basis and make the perspective clear. A public institution may also need to account for non-monetary effects such as accessibility, resilience and environmental impact.

## 8. Model-based systems engineering (MBSE)

MBSE uses formal or semi-formal models as primary engineering artefacts to support requirements, architecture, analysis, verification and communication. It does not mean “draw every diagram in a tool.” A model should represent a defined viewpoint, preserve relationships and support a task that would otherwise be error-prone or ambiguous.

Different models answer different questions:

- requirements models capture requirement structure, derivation, satisfaction and verification;
- structural models describe system elements and relationships;
- behavioural models describe states, activities, sequences and interactions;
- parametric models describe equations, constraints and performance relationships;
- interface models describe exchanges across boundaries.

### 8.1 SysML and modelling languages

SysML provides modelling constructs for requirements, structure, behaviour, constraints and parametrics. UML is widely used for software structure and behaviour. Other languages include Capella/Arcadia, Modelica and domain-specific modelling languages.

A modelling language is a notation with defined semantics. The tool is an implementation of that language and associated workflows. A diagram exported as an image is not necessarily a governed model: it may have no unique identifiers, trace links, version history or validation rules.

### 8.2 Model governance

A model-based project needs:

- a modelling purpose and scope;
- agreed viewpoints and conventions;
- unique identifiers and naming rules;
- ownership and review responsibilities;
- configuration and version control;
- traceability rules;
- model-quality checks;
- export and interoperability strategy;
- clear links between model elements and test evidence.

Avoid creating an elaborate model that nobody maintains. Model detail should be proportionate to system complexity, risk and expected reuse.

## 9. Risk, safety and human-systems integration

Risk is often characterised through uncertainty about an event or condition and its consequences. A risk register should identify the cause, uncertain event, consequence, likelihood or frequency basis, severity, owner, existing controls, mitigation, residual exposure and monitoring trigger.

A risk statement should be causal and specific. “Database risk” is not useful. “If the identity provider is unavailable during equipment collection, staff may be unable to confirm eligibility, causing missed laboratory sessions” identifies an initiating condition, system consequence and stakeholder impact.

### 9.1 Hazard analysis

A hazard is a condition that can lead to harm. Safety analysis identifies hazards, causal scenarios, controls and evidence. Methods include preliminary hazard analysis, failure mode and effects analysis (FMEA), fault-tree analysis (FTA), event-tree analysis (ETA), system-theoretic process analysis (STPA) and domain-specific safety cases.

For a physical equipment locker, hazards might include incorrect release, entrapment, electrical fault, unsafe storage or loss of emergency access. For software-only systems, hazards can still arise from incorrect control decisions, data corruption, unsafe automation or failure to provide critical information.

Do not assume that every risk score is quantitative. A low-probability/high-severity event may require special treatment even if a simple product of likelihood and impact looks modest. Safety requirements should have explicit rationale, verification evidence and accountable approval.

### 9.2 Human-systems integration

Human-systems integration considers the people who operate, maintain, support, train on or are affected by the system. It includes human factors, ergonomics, staffing, workload, fatigue, accessibility, training, procedures, organisational roles and automation boundaries.

A system that is correct under ideal use may fail under realistic conditions: interruptions, low lighting, time pressure, novice staff, poor connectivity, language differences or emergency operations. Scenarios and usability testing should include these conditions. Human error should trigger investigation of system design, workload and organisational context rather than automatic blame.

## 10. Integration, verification and validation

**Integration** combines elements and checks whether their interfaces and interactions work together. **Verification** asks whether an element or system meets its specified requirements. **Validation** asks whether the integrated system satisfies stakeholder needs and intended use in the operational context.

The familiar shorthand is:

- Verification: “Did we build the system right?”
- Validation: “Did we build the right system?”

The shorthand is useful but incomplete. Both require defined criteria, representative environments, controlled configurations and recorded evidence.

### 10.1 Verification methods

Four common methods are:

- **Inspection:** visual or documentary examination of an element or artefact.
- **Analysis:** mathematical, logical or model-based demonstration.
- **Demonstration:** operation of an element to show a capability without detailed quantitative measurement.
- **Test:** controlled measurement under defined conditions to evaluate one or more requirements.

A verification cross-reference matrix maps every requirement to its verification method, planned event, acceptance criteria, environment, configuration and evidence record.

### 10.2 Verification planning

A verification procedure should specify preconditions, test configuration, inputs, instrumentation, steps, expected results, tolerances, pass/fail rules, data retention and safety precautions. Avoid vague acceptance statements such as “works reliably.” Replace them with measurable conditions and a defined sample or operating profile.

### 10.3 Validation planning

Validation should involve representative stakeholders, operational tasks, representative data, training conditions, support procedures and realistic operating environments. A system may satisfy every written requirement and still fail validation because the requirements omitted a critical need or reflected an incorrect understanding of the operation.

## 11. Technical reviews and evidence gates

Technical reviews are structured decision points, not slide presentations. They examine whether the system definition and evidence are mature enough to proceed.

| Review | Main question | Typical evidence |
|---|---|---|
| System Requirements Review (SRR) | Are stakeholder needs understood and requirements adequate? | ConOps, stakeholder register, requirement baseline, verification concepts, risk register |
| Preliminary Design Review (PDR) | Is the proposed architecture feasible and sufficiently mature? | Architecture, trade studies, interface definitions, preliminary analysis, risk posture |
| Critical Design Review (CDR) | Is the detailed design ready for implementation or build? | Detailed design, interface control, analysis, verification procedures, configuration baseline |
| Test Readiness Review (TRR) | Is the test configuration and procedure safe and adequate? | Test plan, procedures, instrumentation calibration, environment, entry criteria |
| Operational Readiness Review (ORR) | Is the system, support organisation and recovery process ready for use? | Training, procedures, monitoring, support rota, backup and recovery evidence, known issues |

A review should define entry criteria, decision authority, required reviewers, action tracking, exit criteria and any accepted residual risks. A review can result in approval, conditional approval, rework or cancellation.

## 12. Transition, operation, maintenance and retirement

Transition moves a system or capability into its intended operating environment. It includes installation, data migration, configuration, user training, operator training, acceptance, support readiness, communications and rollback planning.

Operations are not an afterthought. An engineering design should identify service hours, capacity, monitoring, security responsibilities, escalation paths, maintenance windows, incident procedures, change control and service objectives. Maintenance includes corrective, preventive and adaptive work. A design that is difficult to diagnose or upgrade creates future operational risk.

Retirement should address data retention and disposal, interfaces to successor systems, physical asset handling, supplier exit, license termination, record preservation and user migration. Safe retirement is a life-cycle engineering activity.

## 13. Integrated case study: campus equipment service

### 13.1 Mission and context

Mission: enable eligible users to reserve, collect, return and maintain shared equipment with auditable availability and safe operation.

Stakeholders include students, instructors, equipment staff, IT, security, finance, accessibility services, procurement and external maintainers. External systems include identity, course schedules, email/SMS, building access and asset-management systems.

### 13.2 Derived top-level requirements

The requirements below are illustrative and must be refined through stakeholder analysis:

- **SYS-001:** The system shall allow an eligible user to request an equipment reservation for an available item and a specified time interval.
- **SYS-002:** The system shall prevent conflicting confirmed reservations for the same uniquely identified item.
- **SYS-003:** The system shall record every change to reservation and equipment status with actor, timestamp and reason.
- **SYS-004:** The system shall prevent release of equipment to an unauthorised user.
- **SYS-005:** The system shall identify items under maintenance as unavailable for reservation.
- **SYS-006:** The system shall provide an operator workflow for recording collection, return, damage and missing equipment.
- **SYS-007:** The system shall support recovery of reservation and audit data within approved recovery objectives.

Notice that each requirement has a verification question. “Support recovery” is not complete until the recovery point, recovery time, scope and evidence are defined.

### 13.3 Architecture candidates

Candidate A is a modular monolith with a relational database. Candidate B separates inventory, reservation and notification services. Candidate C uses a managed equipment-management platform with custom identity and reporting integrations.

Candidate A may simplify transactional correctness and operations. Candidate B may support independent scaling and team ownership but increases distributed failure modes. Candidate C may reduce initial development but may create vendor, integration and data-portability risk. A trade study should use validated operational needs and cost data, not abstract preferences.

### 13.4 Engineering assurance

The project should produce a requirements baseline, architecture and interface definitions, hazard/risk assessment, verification matrix, test evidence, operational procedures, training materials, backup/restore results, deployment/rollback plan and an ORR decision. The assurance package makes the system's readiness reviewable.

## 14. Problem set

### Problems

**1.** Explain why a campus equipment platform should be treated as a system rather than as a web application. Name at least six non-software elements or stakeholders that affect its success.

**2.** Write a boundary statement for the platform. Identify three external systems and describe the interface risk associated with each.

**3.** Convert the need “staff must know which equipment is safe to issue” into a set of stakeholder needs and candidate system requirements. Separate the operational policy from software functionality.

**4.** Draw a functional decomposition for equipment reservation and return. Ensure that the functions describe outcomes rather than specific classes or database tables.

**5.** Compare the modular monolith and microservice alternatives. Identify one measurable quality scenario for modifiability, availability and performance.

**6.** A project estimates development cost of 100 units and operating costs of 25, 30 and 35 units in years 1–3. At a 5% discount rate, calculate the present value of the costs, treating development cost as time zero.

**7.** Distinguish verification from validation using a concrete example of a reservation system.

**8.** Propose the minimum evidence required to approve an Operational Readiness Review.

### Solution sketches

**1.** Success depends on inventory condition, physical storage, staff workflows, eligibility rules, network, identity, building access, maintenance and support. The software is only one element in the service system.

**2.** A boundary might include reservation logic, inventory records, staff workflows and notifications. Identity, course schedule and building access may remain external. Risks include token expiry or outage, stale eligibility data, and door-access state not matching reservation state. Specify timeouts, fallback, data freshness and ownership.

**3.** Needs might include knowing the inspected condition, recording inspection time and preventing unsafe issue. Candidate requirements could require a controlled status vocabulary, an inspection record with staff/time and a reservation guard for unsafe states. The safety policy defining who can inspect and approve is an organisational constraint, not solely a software feature.

**4.** A defensible flow includes identify user, check eligibility, identify item, check availability, check constraints, create reservation, confirm reservation, verify identity at collection, record handover, record return and assess condition. Decomposition should show alternate flows for cancellation, damage and late return.

**5.** A measurable modifiability scenario might specify adding a new item category within a given change window and bounded regression effort. Availability might state the required service continuity during loss of notification service. Performance might state a percentile latency for reservation confirmation at a defined load. Compare where each architecture meets or fails each scenario and account for operational costs.

**6.** \(PV=100+25/1.05+30/1.05^2+35/1.05^3\approx181.2547\) cost units. Rounding depends on the chosen precision.

**7.** Verification checks that the system blocks overlapping reservations for a unique item. Validation checks that the workflow actually enables a student to obtain the correct equipment before the practical session, including staff and physical collection processes.

**8.** Evidence includes deployment baseline, security approvals, monitoring and alert routing, staff training, operating procedures, support ownership, incident escalation, backup/restore tests, capacity assessment, known defects, rollback plan and acceptance by operational stakeholders.

## 15. Practical assignment

Develop an SE definition package for the campus equipment service. Include:

1. system-of-interest definition and context diagram;
2. stakeholder register and needs analysis;
3. ConOps with normal, degraded and emergency scenarios;
4. a hierarchical requirements baseline with traceability;
5. functional decomposition and interface register;
6. at least three architecture alternatives;
7. a weighted trade study with sensitivity analysis;
8. preliminary risk and hazard analysis;
9. verification and validation plan;
10. PDR-style review presentation and written decision record.

## Further reading and primary course materials

- MIT OCW, [16.842 Fundamentals of Systems Engineering](https://ocw.mit.edu/courses/16-842-fundamentals-of-systems-engineering-fall-2015/): full graduate course with lectures, notes and project assignments.
- NASA, [Systems Engineering Handbook](https://www.nasa.gov/reference/systems-engineering-handbook/): public technical handbook.
- [SEBoK](https://sebokwiki.org/): Systems Engineering Body of Knowledge.
- INCOSE, [Systems Engineering Handbook](https://www.incose.org/resources-publications/technical-publications/se-handbook/): professional handbook; check publisher/library access.
- ISO, [ISO/IEC/IEEE 15288:2023](https://www.iso.org/standard/81702.html): life-cycle process standard; standard text may require purchase.
- OMG, [SysML](https://www.omg.org/sysml/): modelling language specification and resources.
- NASA Science, [Systems Engineering Tutorial](https://science.nasa.gov/toolkit/systems-engineering-tutorial/): mission life-cycle tutorial.


---

# Advanced lecture notes and worked extensions

## 16. Stakeholder value, needs decomposition and requirement allocation

Stakeholder needs often conflict because different stakeholders optimise different outcomes. A useful systems-engineering practice is to express stakeholder value in terms of desired outcomes and observable measures rather than treating each request as a feature.

For example, “equipment must always be available” is not a feasible requirement if items require maintenance and are shared. A more useful need might be that required equipment is available for scheduled sessions at an acceptable rate, with clear alternatives when an item is unavailable. The resulting requirements may include availability data freshness, reservation lead time, maintenance release, substitution workflow and notification.

### 16.1 From needs to requirements

A defensible decomposition process is:

1. capture the stakeholder's desired outcome;
2. identify the operational scenario in which the outcome matters;
3. identify the external conditions and constraints;
4. derive the system-level capability required;
5. define measurable success and failure conditions;
6. allocate the requirement to a system element or process;
7. identify verification and validation evidence;
8. maintain traceability back to the original need.

Decomposition should preserve intent. A lower-level requirement is not valid merely because it is technically precise; it must contribute to an approved higher-level outcome or obligation.

### 16.2 Requirement allocation is not a mechanical split

Suppose a top-level requirement says that the system shall prevent conflicting reservations. The responsibility may be distributed among the reservation interface, application logic, authoritative database constraint and concurrency test. If the architecture assigns the invariant only to a user-interface availability check, it has allocated the requirement incorrectly because concurrent requests can bypass the check.

Allocation needs a model of interactions and failure states. It should include external dependencies and human procedures where they contribute to system behaviour.

## 17. Interface control and configuration management

Interface problems frequently arise because two parties believe they agree while using different assumptions. An interface-control record should capture both technical and organisational details:

- identifier, owner and version;
- interface purpose and boundary;
- data format, units, field semantics and validation;
- protocol, timing and sequencing;
- operating modes and error behaviour;
- security, safety and privacy constraints;
- compatibility and deprecation policy;
- test method and acceptance evidence;
- configuration baseline and change process.

A data field such as `available=true` is ambiguous unless the system defines whether availability means physically inspected, not reserved, not in maintenance, not checked out, or all of these. Semantic agreement is as important as transport compatibility.

Configuration management maintains the approved versions of technical artefacts. It should identify what is controlled, who can approve a change, how versions are related, how implementation states are recorded and how an audit can reconstruct the system configuration used for a test or incident.

## 18. Technical risk management

Risk management is a continuous engineering process, not a one-time spreadsheet exercise. It should connect uncertainty to an event, consequence, owner, control and evidence.

A useful risk statement has the form:

> Because [cause or uncertain condition], [event] may occur, resulting in [consequence].

Example:

> Because the identity provider is managed by a separate university team and has no agreed availability commitment, it may be unavailable during equipment collection, preventing eligibility verification and delaying laboratory sessions.

The statement is better than “identity integration risk” because it identifies the causal path and the stakeholder effect.

### 18.1 Risk treatment options

Common options include avoiding the risk, reducing its likelihood, reducing its consequence, transferring or sharing exposure, accepting residual risk, or monitoring it. Acceptance must be made by an authority with appropriate accountability. A project team should not silently accept a risk that belongs to an operational owner or safety authority.

### 18.2 Risk burndown and evidence

A risk is not closed merely because an action item was completed. The control must be verified. If the risk was “unrecoverable data after database failure,” completing a backup configuration is not enough; a restore test must demonstrate that the data can be recovered within the objective.

## 19. Integration strategy and verification planning

Integration planning determines the order in which elements are combined and the evidence needed to show that the resulting system behaves correctly. A top-down strategy can test high-level behaviour early using stubs. A bottom-up strategy can prove lower-level components before full system assembly. Incremental integration often combines both.

A good integration plan defines:

- integration sequence and dependencies;
- interface readiness criteria;
- test harnesses and stubs;
- configuration and version identifiers;
- representative datasets;
- failure injection and recovery cases;
- entry/exit criteria for each integration event;
- defect triage and regression strategy.

### 19.1 Verification coverage

A verification matrix should support analysis in both directions:

- every requirement has a verification approach;
- every test or analysis is linked to the requirement it supports;
- every critical requirement has passed evidence or an approved waiver;
- failed results lead to defect disposition and re-verification.

Coverage alone does not mean quality. A test suite may cover every requirement but use unrealistic data, insufficient concurrency or an invalid environment. Verification procedures should be representative of the conditions stated in the requirement.

## 20. Worked trade study: centralised versus distributed reservation state

Two candidate designs are considered for reservation state:

- **Alternative A:** one relational database is authoritative for all reservation commits.
- **Alternative B:** reservation state is split by department, with each department operating an independent service and store.

Illustrative criteria are cost (lower is better), correctness risk (lower is better), independent scaling and change autonomy. A benefit-scale score from 1 to 5 may be used after evidence is collected. Example weights are 0.30 for correctness risk, 0.25 for operating cost, 0.25 for change autonomy and 0.20 for scale isolation.

| Criterion | Weight | A score | B score |
|---|---:|---:|---:|
| Correctness risk | 0.30 | 5 | 3 |
| Operating cost | 0.25 | 5 | 2 |
| Change autonomy | 0.25 | 3 | 5 |
| Scale isolation | 0.20 | 3 | 5 |
| Weighted score | 1.00 | 4.10 | 3.75 |

Under these illustrative scores, Alternative A is preferred. But a decision review must ask whether the weights reflect stakeholder priorities, whether the scores have evidence and whether Alternative A meets the maximum acceptable workload. If scale isolation becomes more important, Alternative B may become preferable. A design with a hard failure against correctness or safety requirements should be eliminated regardless of weighted score.

The preferred alternative should also be stress-tested for change. A modular centralised design may support a future split if data ownership boundaries are clear, but extraction is not free: it requires data migration, consistency design, service contracts, operational support and new failure handling.

## 21. Reviews and technical maturity

A review should evaluate technical maturity, not presentation quality. For a PDR package, reviewers should be able to trace the mission or stakeholder need to system requirements, see credible architecture alternatives, inspect interface definitions, understand key analyses and identify high risks. A CDR package should have enough design detail and verification planning to support implementation or build.

Review actions should be classified as blocking, required before the next milestone, advisory or accepted risk. Each action needs an owner and closure evidence. A finding should not disappear merely because it is inconvenient to the schedule.

## 22. Extended review questions

1. Why is requirement allocation a technical judgment rather than a clerical decomposition?
2. How can an interface-control document prevent operational failures that are not visible in source code?
3. What evidence is needed before closing a high-severity risk?
4. Describe one case in which a system can pass verification but fail validation.
5. How would you tailor the V-model for a small iterative software project without losing traceability?
6. What are the consequences of a technical review that lacks independent reviewers or defined exit criteria?
## 23. SysML v2 and the current MBSE baseline

The course introduces model-based systems engineering as an engineering approach, not as a diagramming exercise. A model is useful when it carries consistent engineering meaning across requirements, system structure, behaviour, interfaces, analysis and verification. The model must support decisions and evidence that would otherwise be fragmented across disconnected documents.

### 23.1 Version status and why it matters

The Object Management Group lists **SysML 2.0 as a formal specification adopted in September 2025**. The official specification describes a general-purpose language for representing requirements, system structure, behaviour, analysis cases and verification cases. SysML 1.7 remains a formal earlier version, adopted in June 2024. This means a course that only says “learn SysML” without naming the version is incomplete for current study.

Official specification and history: [OMG SysML 2.0](https://www.omg.org/spec/SysML/2.0/About-SysML). The OMG page provides separate normative language and v1-to-v2 transformation documents. Treat those normative documents as the source of language semantics; vendor tutorials and tool examples are implementation guidance, not a replacement for the specification.

### 23.2 What to learn conceptually

The objective is not to memorise the surface syntax of one tool. Students should be able to:

- distinguish a model element from its graphical or textual representation;
- represent system requirements and relationships to design and verification;
- represent system structure, parts, connections and interfaces;
- represent behaviour, states, actions, interactions and constraints;
- link analysis and verification cases to the system elements they assess;
- maintain identifiers, ownership, units, assumptions, versions and trace links;
- explain what a model proves, what it merely describes and what remains an engineering judgement.

A model can be syntactically valid and still be semantically incomplete. For example, a requirement may be linked to a block but have no verification case, measurable acceptance criterion or operational context. A model that contains many diagrams but no traceable argument is not automatically a mature MBSE implementation.

### 23.3 SysML v1-to-v2 transition exercise

For the campus equipment platform:

1. identify the SysML version supported by the chosen modelling tool and the exact release of that tool;
2. create a small model covering a stakeholder requirement, a system requirement, a structural element, a behaviour and a verification case;
3. export or exchange the model using a documented format supported by the tool;
4. inspect identifiers, units, relationships and requirement-to-test links after exchange;
5. document any unsupported feature or transformation loss;
6. decide whether to remain on v1 for a project, migrate to v2, or maintain a controlled transition plan.

Do not claim that a tool is fully SysML v2 conformant merely because it uses the phrase “SysML v2” in marketing. Record the specific language subset, implementation status, interchange support and limitations that were actually tested.

## 24. Technical reviews as evidence gates

A technical review is not a presentation in which a team shows diagrams. It is a structured decision about whether the available evidence is sufficient to proceed, proceed with actions, repeat analysis or stop.

| Review | Principal question | Evidence expected |
|---|---|---|
| Mission/Concept review | Is the need real and the system boundary defensible? | Need statement, stakeholder analysis, ConOps, alternatives, assumptions |
| System Requirements Review | Are the requirements sufficiently complete, consistent and verifiable? | Requirements baseline, rationale, traceability, validation record, open issues |
| Preliminary Design Review | Is the selected architecture feasible and does it address the drivers? | Architecture, interfaces, analyses, risk register, verification strategy |
| Critical Design Review | Is the design sufficiently mature for implementation? | Detailed design, interface baselines, analysis, safety/security evidence, test procedures |
| Test Readiness Review | Is the test safe, repeatable and capable of producing valid evidence? | Approved procedures, calibrated equipment, configuration, expected results, rollback plan |
| Operational Readiness Review | Can the system be operated and supported? | Training, runbooks, monitoring, spares, backup/restore evidence, support ownership |

Entry and exit criteria must be set before the review. Open actions need an owner, due date, severity and closure evidence. A review decision should state residual risk and any conditions for proceeding. “Reviewed” is not a verification result.

### 24.1 Verification cases and validation arguments

A verification case links a requirement to a method, procedure, configuration, expected result, observed result and disposition. A validation argument explains why the system, when used in its intended environment, satisfies the stakeholder's real need. Verification can show that a reservation API returns the specified response under a test; validation must establish that the entire equipment-lending service supports the university's actual borrowing process.

**Worked trace:** Need `N-04: reduce time spent finding available equipment` derives to requirement `REQ-AV-03: provide availability search for an authorised user`. The architecture allocates the search to the inventory query service. Verification includes functional results, authorisation tests, defined workload and freshness checks. Validation includes a representative user task with real equipment categories and staff workflow. A successful unit test alone closes neither the system-level verification obligation nor the stakeholder validation question.

## 25. Extended review questions

1. Why is a SysML version and tool implementation status part of the model's configuration baseline?
2. Give an example of a syntactically valid model that is semantically incomplete.
3. What evidence should allow a project to pass a System Requirements Review?
4. Why is a Test Readiness Review different from a demonstration that a test script runs?
5. How would you defend a decision to delay migration from SysML v1 to SysML v2?


## 26. Technical review gates as decision instruments

A technical review is not a status meeting and not a slide presentation. It is a structured decision about whether the system definition or design is sufficiently mature to enter the next phase. The review board needs evidence that the product, its interfaces, risks and verification strategy are understood well enough for the decision being requested.

A review should have four explicit elements:

1. **Entry criteria:** the minimum artefacts, maturity and configuration state required before the review begins.
2. **Review objectives:** the technical questions the board must resolve.
3. **Exit criteria:** measurable conditions for approval, conditional approval or rejection.
4. **Action closure:** named owners, dates, objective closure evidence and a record of residual risk.

A common sequence is SRR (System Requirements Review), PDR (Preliminary Design Review), CDR (Critical Design Review), TRR (Test Readiness Review), ORR (Operational Readiness Review) and a transition/acceptance review. Exact names and sequencing vary by domain and organisation; tailor the review system rather than copying acronyms mechanically.

| Review | Decision being supported | Typical evidence | Example exit condition |
|---|---|---|---|
| SRR | Is the need understood and the requirements baseline credible? | ConOps, stakeholder needs, requirements, constraints, traceability, risk register | Critical requirements have owners, rationale and a verification approach; unresolved ambiguity is recorded. |
| PDR | Is the preliminary architecture feasible and sufficiently defined for detailed design? | Functional and logical architecture, allocated requirements, interface concepts, trade studies, preliminary hazard analysis | Every critical function and interface has an allocation; feasibility risks have funded treatment actions. |
| CDR | Is the detailed design ready for implementation/fabrication? | Detailed design, interface-control data, analyses, implementation plans, test procedures, configuration baseline | Design is internally consistent, buildable and verifiable; open issues have disposition and owners. |
| TRR | Is the test article and environment ready for a valid test? | Test plan/procedures, configuration, instrumentation calibration, safety checks, test data plan | Preconditions, pass/fail criteria, rollback and anomaly handling are approved. |
| ORR | Can the service be operated and supported safely? | Runbooks, on-call ownership, monitoring, capacity, training, restore evidence, security and support approvals | Critical operational procedures have been exercised; no unaccepted release-blocking risk remains. |

A review board should distinguish **open actions** from **waivers**. An open action means evidence is still required. A waiver is an explicit decision to accept deviation from a stated requirement or criterion, with an authorised owner and rationale. A conditional approval must name its conditions and the authority that verifies closure.

### 26.1 Worked example — a PDR evidence question

Suppose the architecture allocates reservation confirmation to a service that calls an external identity provider, writes a reservation record and publishes a notification. The PDR should not accept a component diagram alone. It should ask:

- What is the authoritative transaction that makes the reservation confirmed?
- Can a notification be sent twice? Can it be lost after the reservation commits?
- What happens when the identity provider times out after accepting a request?
- Which component owns idempotency and conflict detection?
- Which interfaces have defined error semantics, deadlines, authentication and data ownership?
- What evidence will show that concurrent requests cannot reserve the same unique item twice?

The review may approve the architecture with an action to demonstrate concurrency safety before CDR. This is a defensible gate because it does not confuse conceptual completeness with verified implementation.

## 27. Engineering economics: discounting, feasibility and sensitivity

For a cost or benefit stream, net present value is:

\[
NPV=\sum_{t=0}^{T}\frac{B_t-C_t}{(1+r)^t}
\]

where benefits \(B_t\), costs \(C_t\), discount rate \(r\), and periods \(t\) must use a consistent currency, price basis and time convention. A nominal cash flow should not be discounted with a real discount rate unless inflation treatment is consistent. A sunk cost should not be allowed to distort a forward-looking alternative comparison. Uncertain estimates should be represented as ranges or distributions when they materially affect the decision.

For the example in Problem 6, with development cost 100 at time zero and operating costs 25, 30 and 35 at the ends of years 1–3, at 5%:

\[
PV=100+\frac{25}{1.05}+\frac{30}{1.05^2}+\frac{35}{1.05^3}=181.2547241
\]

Therefore the rounded answer is 181.25 cost units (or 181.3 to one decimal place). Always state the rounding precision.

A weighted score must never override a mandatory constraint. First eliminate infeasible alternatives; then compare the remaining feasible alternatives using preference criteria. If only one alternative survives, the weighted ranking is vacuous: explain that the constraint determines the selection and identify what additional feasible design or relaxation analysis would be needed to create a genuine trade study.

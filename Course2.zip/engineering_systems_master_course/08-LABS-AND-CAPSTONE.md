# Laboratory Manual and Integrated Capstone

**Companion to the six university-level course texts**  
**Purpose:** turn theory into engineering artefacts that can be inspected, tested and defended.

This manual is designed for individual study or a small project team. It does not replace the lecture texts: complete the relevant course sections before starting each lab. Some labs use a simulated system and synthetic data; label all such evidence as simulated. Do not represent simulated results as production measurements.

## How to use the laboratory manual

Each lab follows the same protocol:

1. **Prepare:** read the stated course topics and record the assumptions you will use.
2. **Construct:** produce the model, analysis or implementation specified in the task.
3. **Challenge:** test boundary cases, alternative explanations or failure conditions.
4. **Interpret:** explain what the result means and what it does not establish.
5. **Submit:** include the artefact, method, evidence, limitations and a short reflection.

Use a version-controlled project folder. Keep source files for diagrams and models rather than submitting only screenshots. Every quantitative result must include the equation, units, input data and assumptions. Every design recommendation must state the quality attributes and constraints it optimises.

## Practical types and executable companion mapping

The 17 numbered exercises do not all claim to be software laboratories. They are deliberately classified as follows:

| Original lab | Type | Executable companion / evidence |
|---:|---|---|
| 1–2 | Modelling/design studio | Drawings, stakeholder evidence and structured critique; no code is required |
| 3 | Executable numerical model | `labs/course1_system_dynamics/` — forward-Euler stock/flow simulation and tests |
| 4–5 | Systems-engineering design studios | ConOps, decomposition, interface register and review package |
| 6–7 | Requirements analysis + executable aid | `labs/course3_requirements/` — CSV requirements pre-checker; human review remains mandatory |
| 8–9 | API/data design + executable concurrency practical | `labs/course4_distributed_systems/` — Go HTTP reservation service and race tests |
| 10 | Architecture trade study + executable decision aid | `labs/course2_systems_engineering/` — constraint-first screening and weighted scoring |
| 11–14 | Reliability/SRE design studios | `labs/course6_reliability/` supports quantitative life-data work; FMEA, FTA, SLO and incident artefacts remain analytical submissions |
| 15 | Integrated capstone | Full engineering dossier, evidence map and oral defence |
| 16 | Distributed-systems design studio | Operation histories, invariants and fault model; it is **not** implemented as a consensus or replicated-database lab by the Go practical |
| 17 | Executable statistical practical | `labs/course6_reliability/` — right-censored exponential and Weibull estimation |

The additional executable architecture check in `labs/course5_architecture/` supports the Course V fitness-function and governance topics. Each companion README states commands, expected output and test limits. The full environment contract is in [16 — Lab Environment and Reproducibility](16-LAB-ENVIRONMENT-AND-REPRODUCIBILITY.md); worked numerical and code-oracle examples are in [17 — Worked Examples and Reference Solutions](17-WORKED-EXAMPLES-AND-REFERENCE-SOLUTIONS.md).

A passing executable test suite is evidence about the tested implementation and cases only. It is not evidence that a system meets stakeholder needs, is secure, is safe, survives untested faults or is production-ready. Design studios are assessed on argument quality, completeness, evidence and limitations rather than on the presence of code.

## Lab sequence at a glance

| Lab | Course | Theme | Main submission |
|---:|---|---|---|
| 1 | I | System boundary and reference mode | Boundary statement, stakeholder map and behaviour-over-time graph |
| 2 | I | Feedback and unintended consequences | Causal-loop diagram and policy analysis |
| 3 | I | Stock-flow model and validation | Executable model, equations and validation record |
| 4 | II | ConOps and lifecycle | Operational scenarios and lifecycle model |
| 5 | II | Functional architecture and interfaces | Functional decomposition, allocation and interface register |
| 6 | III | Needs to verifiable requirements | Stakeholder catalogue and requirements baseline |
| 7 | III | Behavioural models and acceptance | Use cases, state model and acceptance tests |
| 8 | IV | API and data design | API contract, data model and invariants |
| 9 | IV | Transactions and distributed failures | Failure-injection report and consistency argument |
| 10 | V | Architecture alternatives | C4 views, quality scenarios, ADRs and trade study |
| 11 | VI | Reliability quantification | Reliability model, FMEA and fault tree |
| 12 | VI | SLO and observability | SLI/SLO specification, dashboard plan and alert policy |
| 13 | VI | Incident command and learning | Incident timeline, command log and postmortem |
| 14 | VI | Backup and recovery | Recovery plan and restore-test evidence |
| 15 | All | Integrated capstone review | Complete engineering dossier and oral defence |
| 16 | IV | Replicated reservation service | Invariant specification, operation histories and fault-injection report |
| 17 | VI | Reliability estimation with censored data | Reproducible life-data analysis and assumptions report |

---

# Part A — Systems thinking laboratories

## Lab 1 — Boundary, stakeholders and reference mode

**Course preparation:** Course I, Sections 1–3.  
**Estimated effort:** 4–6 hours.

### Problem

A university reports that equipment-loan requests are taking longer to fulfil. Students complain about long waits; technicians report increasing workload; finance reports that unused equipment is also increasing. The university initially proposes buying more equipment.

### Learning objectives

- Define a system of interest and distinguish it from its environment.
- Identify stakeholders whose goals may conflict.
- Distinguish an event from a recurring behavioural pattern.
- Construct a reference mode using observable quantities.

### Tasks

1. Write a boundary statement that identifies the system of interest, its purpose, external actors, major inputs, major outputs and exclusions.
2. Create a stakeholder table with at least six groups. For each group, state its objectives, influence, information needs and potential conflict with another group.
3. Define three measurable variables: request waiting time, equipment utilisation and unfulfilled demand. State each unit, measurement method and sampling interval.
4. Draw a behaviour-over-time graph for each variable. Use hypothetical data only if actual data are unavailable; mark it **illustrative** and state that it is not evidence about the real university.
5. Compare two possible boundaries: the loan desk alone, and the wider equipment lifecycle including purchasing, maintenance, teaching demand and disposal.
6. Explain how changing the boundary changes the proposed intervention.

### Required deliverables

- One-page boundary and purpose statement.
- Stakeholder analysis table.
- Three reference-mode graphs with units and assumptions.
- A 500–700-word boundary justification.

### Review questions

- Which important feedback loops disappear when purchasing and maintenance are outside the boundary?
- Could improving utilisation make waiting time worse?
- Which variables would need to be measured before buying additional inventory?

### Assessment criteria (20 points)

Boundary and exclusions (5), stakeholder completeness (5), measurable reference modes (5), quality of reasoning and limitations (5).

## Lab 2 — Causal-loop modelling and policy resistance

**Course preparation:** Course I, Sections 3, 5 and 6.  
**Estimated effort:** 5–7 hours.

### Problem

To reduce the visible queue, the university adds temporary staff to the loan desk. The queue drops initially, but after several months the queue returns and staff turnover rises.

### Tasks

1. Define the central dynamic problem and the behaviour that a successful policy should change.
2. Construct a causal-loop diagram with at least two reinforcing loops and two balancing loops. Include staffing, training, fatigue, service rate, rework, demand and waiting time.
3. Mark each causal link as positive or negative and justify the polarity using a “when A increases, what happens to B, all else equal?” sentence.
4. Label loop polarity and explain whether the loop is reinforcing or balancing.
5. Identify at least two delays. Explain why removing a delay from the diagram would change the policy conclusion.
6. Compare three policies: temporary staffing, training and workflow simplification, and demand smoothing through reservations.
7. Identify at least one unintended consequence for each policy.
8. Conduct a boundary critique: identify a stakeholder or variable that the first version omitted and explain whether the diagram changes.

### Required deliverables

- Editable causal-loop diagram.
- A loop register explaining each loop.
- Policy comparison table.
- A 700–1,000-word analysis of policy resistance.

### Review questions

- Does the diagram confuse correlation with causation?
- Are any links actually conditional or nonlinear?
- Which loop dominates in the short run, and which may dominate in the long run?

### Assessment criteria (25 points)

Causal correctness (8), loop logic (5), treatment of delays (4), policy comparison (5), boundary critique (3).

## Lab 3 — Stock-flow simulation and model validation

**Course preparation:** Course I, Sections 4, 7 and 8.  
**Estimated effort:** 8–12 hours.

### Problem

Build a small stock-flow model for the equipment-loan request backlog. Use a simulation tool such as Insight Maker or Vensim. A spreadsheet model is acceptable if its time-step calculations are explicit and reproducible.

### Model specification

At minimum, include:

- Backlog as a stock, measured in open requests.
- Arrivals as an inflow, measured in requests/day.
- Completions as an outflow, measured in requests/day.
- Effective service capacity, with a delayed response to training or staffing changes.
- Rework or reopened requests, if justified by the model boundary.

A minimal stock equation is:

\[
B(t)=B(0)+\int_0^t[A(\tau)-C(\tau)]\,d\tau
\]

where all rates are expressed in requests/day and time is measured in days.

### Tasks

1. Draw the stock-flow structure and annotate all units.
2. Define equations for arrivals and completions. Explain whether arrivals are exogenous, seasonal, or affected by backlog.
3. Choose an explicit service-capacity response function. For example, capacity may rise toward a target after a training delay; state the functional form and parameters.
4. Run a base case and plot backlog, arrivals, completions and waiting-time proxy over time.
5. Run at least three policy experiments: additional staff, training, and demand smoothing. Keep the initial conditions consistent.
6. Perform dimensional-consistency checks on every equation.
7. Test extreme conditions: zero arrivals, zero capacity, and a temporary doubling of arrivals.
8. Conduct a sensitivity analysis on at least three uncertain parameters. State whether the policy ranking is robust.
9. Compare the simulation behaviour with the causal-loop hypothesis from Lab 2. Explain any mismatch.

### Required deliverables

- Model file and equations.
- Variable dictionary with units.
- Base-case and policy-run graphs.
- Validation log with at least four tests.
- Short report describing model limitations and what data would be needed for calibration.

### Assessment criteria (30 points)

Structure and unit consistency (8), correct implementation (6), appropriate tests (7), policy interpretation (5), limitations and reproducibility (4).

---

# Part B — Systems engineering laboratories

## Lab 4 — Concept of operations and lifecycle analysis

**Course preparation:** Course II, Sections 2–4.  
**Estimated effort:** 5–7 hours.

### Tasks

1. Define the system-of-interest and its operational environment.
2. Write three operational scenarios: normal loan, high-demand period, and service disruption.
3. For each scenario, identify initiating event, actors, preconditions, nominal flow, alternate flow, exception flow and postconditions.
4. Identify operational modes and transitions, including startup, normal operation, degraded operation, recovery and retirement.
5. Draw a context diagram showing external systems, human roles and interfaces.
6. Develop a lifecycle model from concept exploration through disposal. Include maintenance, upgrades, training, support and data retention.
7. Identify assumptions that must be validated with actual stakeholders.

### Required deliverables

ConOps document (3–5 pages), context diagram, scenario table and lifecycle model.

### Review questions

- Does the ConOps describe what the system must accomplish without prematurely selecting a design?
- Are abnormal and degraded modes treated as first-class operational cases?
- Who is responsible when an external dependency fails?

### Assessment criteria (25 points)

Operational completeness (8), scenario quality (6), system boundary/interface clarity (5), lifecycle coverage (4), assumptions and evidence (2).

## Lab 5 — Functional decomposition, allocation and interface control

**Course preparation:** Course II, Sections 5–8.  
**Estimated effort:** 6–8 hours.

### Tasks

1. Convert the ConOps scenarios into a functional hierarchy. Use verb–object labels such as “validate borrower eligibility” or “record equipment return”.
2. Produce a functional flow showing sequence, concurrency and alternate paths.
3. Allocate functions to candidate system elements: user interface, identity service, loan service, inventory database, notification service, and human operations. These are candidates, not assumed final architecture.
4. Identify physical, logical, data, control and human interfaces.
5. Create an interface register with identifier, producer, consumer, data/control exchanged, protocol or mechanism, units/format, timing, failure behaviour and owner.
6. Identify interface risks: incompatible identifiers, inconsistent timestamps, duplicate messages, unavailable identity services and unclear responsibility boundaries.
7. Trace every major function to a stakeholder outcome or requirement.
8. Conduct a preliminary design review (PDR-style) in which you present the functional architecture, interfaces, risks and unresolved decisions.

### Required deliverables

Functional decomposition diagram, functional-flow diagram, allocation matrix, interface register and review minutes.

### Assessment criteria (25 points)

Functional completeness (7), allocation rationale (5), interface quality (7), traceability (3), review evidence (3).

---

# Part C — Requirements engineering laboratories

## Lab 6 — From stakeholder needs to a verifiable requirements baseline

**Course preparation:** Course III, Sections 1–8.  
**Estimated effort:** 8–10 hours.

### Tasks

1. Compile at least eight stakeholder needs from the ConOps and stakeholder register. Each need must identify the stakeholder, desired outcome, context and source.
2. Separate needs, constraints, assumptions, design proposals and requirements.
3. Derive functional requirements and quality requirements from the needs.
4. Assign stable identifiers, rationale, owner, source, priority, verification method, status and revision.
5. Apply an atomicity and verifiability review. Rewrite vague words such as “fast”, “easy”, “robust” and “user-friendly” as measurable conditions where evidence supports a target.
6. Create a quality-attribute scenario for performance, availability, security and modifiability.
7. Identify conflicting stakeholder needs and document the negotiation decision.
8. Create traceability links from stakeholder need to system requirement to validation evidence.
9. Baseline the resulting SRS and record the configuration state.

### Required deliverables

Stakeholder-needs register, SRS, quality-attribute scenario set, requirements traceability matrix and baseline/change record.

### Assessment criteria (30 points)

Need provenance (5), requirement quality (10), measurable quality attributes (5), conflict resolution (4), traceability and baseline discipline (6).

## Lab 7 — Behavioural models and acceptance testing

**Course preparation:** Course III, Sections 4, 9 and 12.  
**Estimated effort:** 6–8 hours.

### Tasks

1. Write one fully dressed use case for issuing equipment and one for returning damaged equipment.
2. Construct a state machine for an equipment item. Include available, reserved, issued, overdue, maintenance, quarantined and retired states, or justify alternatives.
3. Define events and guards for all state transitions.
4. Create a decision table for eligibility and reservation approval.
5. Write acceptance criteria using Given–When–Then for normal, boundary and failure cases.
6. Create at least eight acceptance tests, including duplicate submission, stale reservation, unauthorised borrower, damaged return and identity-service outage.
7. Map each acceptance test to requirement identifiers.
8. Review the tests for ambiguity, untestable expected outcomes and unexamined exception paths.

### Required deliverables

Use-case descriptions, state diagram, decision table, acceptance-test suite and traceability matrix.

### Assessment criteria (25 points)

Behavioural completeness (7), state logic (5), acceptance-test precision (8), traceability (3), exception handling (2).

---

# Part D — Software system design laboratories

## Lab 8 — API contract and data model

**Course preparation:** Course IV, Sections 1–5.  
**Estimated effort:** 8–12 hours.

### Tasks

1. Define three workload profiles: normal term, registration peak and incident recovery. Estimate arrival rate, concurrency, request mix, payload size and latency objective. Mark estimates as assumptions.
2. Design API contracts for creating a reservation, issuing equipment, returning equipment and reporting damage.
3. Define authentication, authorisation, error semantics, pagination and versioning rules.
4. Identify operations requiring idempotency. Define the idempotency key scope, retention interval and response replay behaviour.
5. Design a relational schema with primary keys, foreign keys, unique constraints and explicit status-transition rules.
6. State invariants: one active reservation for a defined resource/time window, no issue of unavailable equipment, and no return recorded for a non-issued item.
7. Choose transaction boundaries and explain isolation requirements.
8. Add indexes based on stated query patterns; explain the write and storage cost of each index.
9. Write representative SQL queries and inspect execution plans in PostgreSQL, or analyse equivalent plans from a documented example.

### Required deliverables

API specification, sequence diagram, ER diagram, schema DDL or schema pseudocode, invariants, representative queries and index rationale.

### Assessment criteria (30 points)

Workload assumptions (4), API contract (7), data correctness (8), transaction design (6), index/query reasoning (5).

## Lab 9 — Concurrency, retries and distributed failure

**Course preparation:** Course IV, Sections 5–10.  
**Estimated effort:** 8–12 hours.

### Experimental scenarios

Use a local application, a controlled simulator or a written state-machine model. Do not test against a production service.

1. Two users reserve the same equipment item at nearly the same time.
2. The server commits a reservation, but the client loses the response and retries.
3. A database transaction commits but a downstream notification event is not published.
4. A consumer processes a message and crashes before committing its offset.
5. A replica lags behind the leader and serves a stale read.
6. A dependency becomes slow and causes a retry storm.

### Tasks

For each scenario:

- Draw the message/transaction sequence.
- Identify the possible externally visible outcomes.
- State the required invariant or consistency guarantee.
- Propose a mitigation: transaction/constraint, optimistic version check, idempotency key, transactional outbox, consumer deduplication, bounded retry with jitter, circuit breaker, read-after-write routing or another justified mechanism.
- Distinguish what is prevented, detected, retried or compensated.
- Explain residual risks and operational signals.

For one selected scenario, implement or simulate the mitigation and demonstrate the failing case before the fix and the corrected case after it.

### Required deliverables

Failure matrix, sequence diagrams, mitigation rationale, experiment record and regression tests or simulator traces.

### Assessment criteria (30 points)

Correct failure model (8), correctness invariant (6), mechanism choice (7), experimental evidence (5), limitations (4).

---

# Part E — Software architecture and trade-off laboratories

## Lab 10 — Architecture alternatives and evidence-based selection

**Course preparation:** Course V, Sections 1–10.  
**Estimated effort:** 10–14 hours.

### Tasks

1. Consolidate architectural drivers from the SRS. Identify the small set that will materially change the architecture.
2. Construct quality-attribute scenarios with stimulus, source, environment, affected component, response and measurable response measure.
3. Develop at least three distinct architecture alternatives, for example: modular monolith, service-oriented decomposition and event-driven modular platform. Ensure alternatives differ structurally, not only by technology vendor.
4. Draw C4 context and container views for each alternative. Draw component views for the leading alternative.
5. Compare alternatives against performance, availability, modifiability, security, operability, cost and team capability.
6. Explain where a style or tactic improves one quality but harms another.
7. Create at least three ADRs using a consistent template. Include context, constraints, options, decision, positive/negative consequences and revisit conditions.
8. Conduct a lightweight ATAM-style review: identify risks, sensitivity points, trade-off points and non-risks.
9. Perform sensitivity analysis on uncertain weights or estimates. State whether the recommended architecture changes.
10. Write an architecture recommendation that includes explicit conditions under which the decision should be revisited.

### Required deliverables

Architecture driver register, quality scenario set, three alternatives, C4 views, trade-off matrix, ADRs, ATAM-style review and recommendation.

### Assessment criteria (35 points)

Architectural distinctness (6), quality scenarios (7), trade-off reasoning (8), ADR quality (5), ATAM analysis (5), uncertainty/sensitivity (4).

---

# Part F — Reliability engineering and SRE laboratories

## Lab 11 — Reliability quantification, FMEA and fault tree analysis

**Course preparation:** Course VI, Sections 1–8.  
**Estimated effort:** 8–12 hours.

### Tasks

1. Define the system boundary and success/failure criterion for a reservation-and-issue transaction.
2. Calculate reliability for an exponential component model using a stated constant failure rate. Show all units and assumptions.
3. Fit or analyse a Weibull model using a supplied or simulated life dataset. Explain shape parameter, scale parameter and censoring.
4. Draw a reliability block diagram for the critical service path. Calculate series and parallel reliability where independence is assumed.
5. Identify common-cause failures that violate independence assumptions.
6. Complete an FMEA with function, failure mode, effect, cause, detection control, severity, occurrence, detectability, recommended action and owner.
7. Construct a fault tree for “reservation cannot be completed”. Use AND/OR gates and estimate top-event probability only when the necessary independence and probability assumptions are justified.
8. Identify minimal cut sets and rank the most important contributors.
9. Propose reliability-growth and FRACAS actions. State what evidence would demonstrate that corrective action reduced recurrence.

### Required deliverables

Reliability calculations, dataset/model record, RBD, FMEA, FTA, minimal-cut-set analysis and corrective-action register.

### Assessment criteria (35 points)

Model assumptions (6), correct calculations (8), RBD/FTA logic (8), failure analysis (7), corrective-action evidence (6).

## Lab 12 — SLI/SLO design and observability plan

**Course preparation:** Course VI, Sections 9–11; Course IV observability section.  
**Estimated effort:** 6–8 hours.

### Tasks

1. Identify the critical user journeys: browse availability, reserve item, issue item and return item.
2. Define an SLI for each critical journey. State numerator, denominator, eligible events, exclusions and measurement window.
3. Propose SLO targets and justify them from user expectations, system capability and business cost. Do not choose “three nines” without an argument.
4. Calculate the allowed bad-event budget for a stated request volume and SLO.
5. Calculate a simple burn rate and propose multi-window alert conditions. Explain the difference between an SLO violation and an actionable alert.
6. Define telemetry: structured logs, metrics and traces. Include trace/context propagation across service boundaries.
7. Define dashboard panels for user-visible health, dependency health, saturation, latency distribution and error budget.
8. Define cardinality and privacy controls. Do not put secrets, tokens or unnecessary personal data in telemetry.
9. Create a runbook entry for each alert, including owner, diagnostic steps, mitigation and escalation.

### Required deliverables

SLI/SLO specification, error-budget calculations, telemetry specification, dashboard wireframe and alert/runbook table.

### Assessment criteria (30 points)

SLI validity (8), SLO rationale (6), budget/burn calculation (5), observability coverage (6), alert/runbook quality (5).

## Lab 13 — Incident command and blameless post-incident review

**Course preparation:** Course VI, Sections 12–13.  
**Estimated effort:** 5–7 hours.

### Scenario

At peak registration, the inventory service begins returning stale availability. Some users reserve the same item. The notification queue grows, and support receives multiple complaints. A recent deployment changed cache invalidation logic.

### Tasks

1. Establish incident severity using user impact, scope, duration and data correctness risk.
2. Assign incident commander, technical lead, communications lead and scribe. Define role boundaries.
3. Create an incident timeline with detection, declaration, mitigation, recovery and closure.
4. Write an initial internal update and a user-facing status update. Avoid speculation and unsupported root-cause claims.
5. Choose safe mitigations. Consider disabling reservations, bypassing stale cache, reverting the deployment, or placing affected items into quarantine. State risks of each action.
6. Preserve evidence and identify which actions must not be taken during the incident.
7. After recovery, construct a causal timeline and contributing-factor analysis. Avoid single-person blame and simplistic “human error” explanations.
8. Produce corrective actions classified as prevention, detection, mitigation and recovery. Each action needs an owner and verification criterion.
9. Identify systemic conditions: inadequate test data, missing invariant monitoring, release process weaknesses, operational overload or unclear ownership.

### Required deliverables

Incident record, role assignment, timestamped timeline, communications log, mitigation record and blameless postmortem.

### Assessment criteria (25 points)

Command clarity (5), safe mitigation (6), communication (4), evidence-based timeline (5), actionable learning (5).

## Lab 14 — Backup, restore and recovery objectives

**Course preparation:** Course VI recovery sections; PostgreSQL backup/restore documentation.  
**Estimated effort:** 6–10 hours.

### Tasks

1. Define business-impact scenarios for accidental deletion, database corruption, regional outage and compromised credentials.
2. Assign a proposed Recovery Time Objective (RTO) and Recovery Point Objective (RPO) for each scenario. Justify them; do not assume every system needs the same values.
3. Map backups, WAL/archive logs, replicas, encryption keys, credentials and infrastructure configuration to the recovery dependencies.
4. Draw the restoration sequence and identify the single points of failure in the recovery process.
5. Conduct a controlled restore test in an isolated environment. If you cannot operate a database, use a documented tabletop exercise with a clearly stated limitation.
6. Verify restored records using checksums, row counts, referential constraints, sampled business invariants and application-level checks.
7. Measure elapsed recovery time and the latest recoverable data timestamp.
8. Record discrepancies, missing dependencies and corrective actions.
9. Write a recovery runbook with decision points, approval boundaries and communication requirements.

### Required deliverables

Recovery strategy, dependency map, restore evidence, RTO/RPO measurement, recovery runbook and corrective-action record.

### Assessment criteria (30 points)

Objectives and rationale (6), dependency completeness (6), restore method (8), verification evidence (6), runbook quality (4).

---

# Part G — Integrated capstone

## Lab 15 — Engineering dossier and design review

**Course preparation:** all six course texts and Labs 1–14.  
**Estimated effort:** 20–30 hours, excluding earlier lab work.

### Capstone brief

Design a university equipment-loan and inventory platform that supports students, lecturers, technicians, inventory managers and finance. It must support discovery, reservation, issue, return, maintenance, damaged-item handling, notifications, auditing and management reporting. It must remain understandable to operators and recoverable after component failures.

The objective is not to build the largest architecture. The objective is to demonstrate a traceable engineering argument from need to design, implementation evidence, reliability analysis and operation.

### Required dossier structure

1. **Problem definition:** boundary, purpose, stakeholders, reference modes and assumptions.
2. **System dynamics:** causal-loop model, stock-flow model, validation record and intervention analysis.
3. **Systems engineering:** ConOps, lifecycle, functional decomposition, allocation, interfaces, risks and review records.
4. **Requirements:** baselined SRS, quality scenarios, acceptance tests and traceability matrix.
5. **Software design:** workload model, API contract, data model, invariants, transaction boundaries, failure scenarios and recovery semantics.
6. **Architecture:** alternatives, C4 views, ADRs, trade study, ATAM-style risk/sensitivity analysis and conditions for revisiting decisions.
7. **Reliability:** failure model, reliability calculations, RBD, FMEA, FTA, reliability actions and assumptions.
8. **Operations:** SLI/SLOs, telemetry plan, capacity assumptions, incident roles, postmortem template, backup/restore procedure and RTO/RPO evidence.
9. **Verification plan:** requirement-to-test map, architecture fitness checks, reliability tests and recovery validation.
10. **Limitations:** unresolved uncertainty, untested assumptions, risks requiring professional/domain review and areas deliberately out of scope.

### Oral defence questions

- Which boundary decision most strongly affected the system design?
- Which requirement is most architecturally significant, and how can you prove it?
- What is the most consequential trade-off in the chosen architecture?
- Which invariant could be violated by a retry or partial failure?
- What exactly does the system guarantee about message delivery and external side effects?
- Which reliability calculation depends most heavily on an independence assumption?
- Which SLI best represents the critical user journey, and what does it omit?
- What is your evidence that a restore procedure will work under pressure?
- What evidence would cause you to reverse one of your major architecture decisions?
- Which assumptions remain unverified, and what experiment would reduce the uncertainty?

## Capstone evaluation rubric

| Dimension | Weight | Evidence expected |
|---|---:|---|
| Problem framing and systems model | 10% | Clear boundary, reference modes, causal/stock-flow reasoning and model tests |
| Systems engineering | 10% | ConOps, lifecycle, functional architecture, interfaces and risk treatment |
| Requirements quality | 10% | Atomic, verifiable requirements, SRS, acceptance tests and traceability |
| Software design | 15% | Workload, API/data model, invariants, transaction correctness and failure semantics |
| Architecture reasoning | 15% | Distinct alternatives, quality scenarios, ADRs, trade-offs and ATAM-style findings |
| Reliability analysis | 15% | Quantitative assumptions, RBD/FTA/FMEA and corrective actions |
| Operations and recovery | 10% | SLOs, telemetry, incident plan, backup/restore and measurable objectives |
| Technical communication and defence | 10% | Reproducibility, limitations, clear evidence and response to critique |
| Completeness and traceability | 5% | Consistent identifiers and links across all artefacts |

**Total: 100%.** A polished diagram cannot compensate for unsupported assumptions. A technically sophisticated architecture cannot compensate for missing requirements or absent recovery evidence.

## Submission checklist

- [ ] Every diagram has a title, scope and legend.
- [ ] Every variable and numerical quantity has a unit.
- [ ] Every model has stated assumptions and at least one validation test.
- [ ] Every important requirement has a verification method and traceability link.
- [ ] Every architecture alternative is evaluated against the same quality scenarios.
- [ ] Every ADR records consequences and conditions for reconsideration.
- [ ] Every reliability estimate explains its failure and independence assumptions.
- [ ] Every alert has a response owner and actionable runbook.
- [ ] Every recovery objective has a tested or explicitly tabletop-validated procedure.
- [ ] Simulated evidence is clearly distinguished from real measurements.
- [ ] Known gaps and unresolved risks are documented rather than hidden.


## Laboratory reproducibility standard

Apply this standard to every lab, including Labs 1–17. A lab is not complete merely because a diagram or application runs once.

**Preconditions:** record operating system, tool/runtime version, dependencies, configuration, input data and prior knowledge. Where software versions matter, pin them or state a tested range.

**Procedure:** provide ordered steps, expected intermediate states, reset instructions and a safe way to reproduce failures. Do not include secrets or personal data in submitted artefacts.

**Test oracle:** state what constitutes a correct result. Use assertions, invariants, expected output, a reference calculation, a documented review checklist or a controlled measurement protocol. Distinguish a test passing from the broader claim it supports.

**Evidence:** submit source/configuration files, raw measurements or logs, screenshots only where they add evidence, test output, analysis, known limitations and a short reproduction guide. Label assumptions and distinguish measured data from synthetic data.

**Review:** another person should be able to reproduce the main result from the submitted materials. A failed reproduction is a finding to investigate, not something to conceal.

## Lab 16 — Replicated reservation service: safety under concurrency and partition

**Course:** Software System Design and Distributed Systems. **Level:** Advanced. **Suggested time:** 15–25 hours. **Assessment:** 40 points.

### Purpose

Build or simulate a replicated reservation service and test the no-overlap invariant under concurrent requests and partial failure. The focus is correctness reasoning, not deploying a large production cluster.

### Preconditions

Students must understand transaction isolation, concurrent programming, API idempotency, logical/physical time and the distinction between safety and liveness. A simple key/value or relational prototype is acceptable; an implementation of consensus is an optional extension.

### Tasks

1. Write the reservation state machine and the no-overlap invariant using half-open intervals.
2. Define operation history records with invocation, response, arguments and result.
3. Run at least 100 concurrent attempts to reserve overlapping intervals for the same item. Record whether the invariant is ever violated.
4. Repeat with two distinct items and with non-overlapping intervals to check that the implementation is not over-serialising valid work.
5. Inject request timeouts after a possible database commit; retry using the same idempotency key.
6. Simulate a network partition between replicas. State which side may accept writes and why.
7. Check the resulting histories for linearizability or provide a rigorous counterexample.
8. Document how the design restores liveness after the failure is removed.

### Required deliverables

Invariant specification; state-machine model; test harness; recorded operation histories; test output; fault-injection procedure; analysis of safety and liveness; recovery/reconciliation design; and a two-page engineering conclusion.

### Assessment criteria (40 points)

- Correct invariant and state model: 8
- Concurrency and duplicate-request tests: 10
- Fault injection and reproducibility: 8
- Linearizability/safety reasoning: 8
- Honest limitations and evidence quality: 6

**Acceptance gate:** no conflicting reservations may both commit as confirmed in the tested history. If the test reveals a violation, the submission must explain and reproduce it; hiding the failure is an academic-integrity violation.

## Lab 17 — Reliability estimation with censored life data

**Course:** Reliability Engineering, SRE and Incident Response. **Level:** Advanced. **Suggested time:** 8–12 hours. **Assessment:** 35 points.

### Data set

Eight independent units are observed under the same operating profile. Five failures are observed at 40, 60, 75, 80 and 90 days. Three units are still operating when observation ends at 100 days. The last three observations are right-censored, not failures.

### Tasks

1. Create a table identifying observation time and event indicator \(\delta_i\).
2. Calculate total unit-time exposure and the exponential maximum-likelihood failure-rate estimate.
3. Calculate the reciprocal mean under the exponential model and state the constant-hazard assumption.
4. Recalculate the estimate incorrectly treating censored observations as failures, then explain the direction of bias.
5. Explain why a Weibull model may be more appropriate if hazard changes with age, and what additional analysis is required to estimate its parameters.
6. Explain how the analysis would change if each unit could be repaired and experience repeated failures.
7. State the limitations caused by small sample size, identical-profile assumptions and potentially informative censoring.

### Expected numerical check

Total exposure is 645 unit-days and the number of observed failures is five. Under the exponential model, \(\hat\lambda=5/645\approx0.007752\) failures per unit-day and the reciprocal mean is about 129 days. This is a model-based estimate, not a guarantee that each unit will last 129 days.

### Required deliverables

Data table; equations; reproducible calculation file or notebook; assumptions; comparison with the incorrect censoring treatment; discussion of the alternative Weibull/recurrent-event models; and a one-page decision note.

### Assessment criteria (35 points)

- Correct event/censor classification: 6
- Correct likelihood and exposure calculation: 10
- Interpretation and assumptions: 8
- Alternative model discussion: 6
- Reproducibility and communication: 5

# 18 — Self-Study Upgrade: Quality and Verification Report

**Verification date:** 21 November 2026  
**Purpose:** record what was changed, what was run, and what remains outside the evidence.

## 1. Delivery scope

The revision converts the prior six-text course bundle into a more complete independent study programme. It retains the original six-course academic sequence and strengthens its supporting study apparatus rather than replacing the existing course texts. The six primary course texts now contain approximately **47,629 words** in total; the 21 top-level Markdown files contain approximately **89,693 words**, with a further set of runnable code, tests and data files.

Added or materially expanded:

- A self-study learner handbook with prerequisite diagnostic, weekly study loop, mastery gates, remediation and independent grading guidance.
- A 30-outcome course learning outcome (CLO) traceability matrix linking course outcomes to sections, formative work, labs, exam evidence and capstone submissions.
- Six low-dependency executable practicals, one per major area: system dynamics, engineering decision analysis, requirements review, Go concurrency/API design, architecture fitness functions and reliability statistics.
- A lab environment and reproducibility contract with exact commands, tool versions, expected outputs, data provenance and limitations.
- Worked numerical examples and reference interpretations for the main executable oracles.
- A lab taxonomy that distinguishes code-based practicals from design studios and analysis assignments.
- A re-audit that retains the original baseline and records the improvements and residual gaps.

The 17 original labs remain in the course sequence. They are not all represented as coding exercises: ConOps, interface control, FMEA/FTA, ATAM, incident command, recovery planning and the capstone remain design, modelling or analytical submissions where that is the educationally appropriate method.

## 2. Test environment

| Tool | Version used |
|---|---|
| Python | 3.13.5 |
| Go | go1.23.2 linux/amd64 |
| Python third-party dependencies | None |
| Go external modules | None required |

The compatibility requirements are documented in each practical README. The stated local environment is the one verified here; it does not imply testing on every supported operating system or runtime release.

## 3. Executable verification results

### Python unit tests

| Practical | Tests | Result |
|---|---:|---|
| Course I — dynamic backlog model | 4 | PASS |
| Course II — constraint-first trade study | 5 | PASS |
| Course III — requirements pre-checker | 4 | PASS |
| Course V — architecture fitness function | 4 | PASS |
| Course VI — censored reliability data | 7 | PASS |
| **Total** | **24** | **24 passed** |

The commands run in each practical directory were:

```bash
python -m unittest discover -v
```

### Go unit, concurrency and static checks

The Course IV service has six named tests, including a 100-concurrent-request test against a capacity-one slot. The following commands were run with test-cache bypass for the test and race runs:

```bash
go test -count=1 ./...
go test -race -count=1 ./...
go vet ./...
```

All three commands completed successfully. A live HTTP smoke test also returned `201 Created` for the first reservation, `200 OK` with the same reservation ID for an exact retry, and `409 Conflict` for a competing request against the full slot. The race test passing is evidence about the exercised code and platform; it is not a formal proof of all concurrency histories or distributed correctness.

### Python bytecode compilation

```bash
python -m compileall -q labs
```

Completed successfully for the Python practical sources.

## 4. Reference outputs reproduced

### Course I — 180-day dynamic model

| Scenario | Final backlog | Final capacity |
|---|---:|---:|
| Base | 696.988 requests | 32.827 requests/day |
| Training | 445.445 requests | 33.130 requests/day |
| Rework reduction | 569.199 requests | 30.956 requests/day |
| Demand smoothing | 413.248 requests | 28.634 requests/day |

### Course II — decision analysis

```text
status=RANKED
feasible: A, B
infeasible: C
1. A: weighted_score=4.200
2. B: weighted_score=4.100
alternate_weight_ranking=B, A
present_value=181.2547241119
```

The present value is 181.2547241 cost units (181.25 to two decimal places). The revised exam has two feasible alternatives under its stated 99.5% hard availability threshold.

### Course III — requirements pre-checker

- Acceptable reference register: 0 findings, exit status 0.
- Deliberately defective register: 4 findings (2 errors, 2 warnings), exit status 1 as intended.

### Course V — architecture fitness function

The reference architecture file produced 0 findings. Separate unit tests exercise an outward dependency, an unknown dependency and a dependency cycle.

### Course VI — right-censored life data

```text
n=8 failures=5 censored=3
total_exposure=645.000 unit-days
exponential_rate=0.00775194 per-day
exponential_mttf=129.000 days
weibull_shape=3.168451
weibull_scale=99.134984 days
exponential_bootstrap_95pct_ci=(0.00247969, 0.01845645) per-day
weibull_survival_at_30d=0.977596
weibull_survival_at_60d=0.815689
```

The Weibull estimator was also cross-checked during development against SciPy 1.17 optimisation on this dataset. The SciPy runtime was used only as an independent development check; it is not required by the practical.

## 5. Content consistency checks

The package was checked for:

- all six course texts declaring a 13-week course duration;
- 78-week sequence consistency (six 13-week blocks);
- 30 CLO rows in the assessment traceability matrix;
- correction of the Course II present-value answer;
- consistency of the Course II trade-study constraints with the final-exam marking key;
- correction of Course IV heading numbering and explicit distinction between the single-process Go lab and consensus/replication theory;
- internal Markdown relative links (58 checked; zero missing);
- sequential, non-duplicated numbered H2 sections in all six primary course texts;
- absence of accidental temporary test files in the final archive.

## 6. Evidence boundaries and remaining limitations

1. Passing unit tests does not prove correctness beyond the tested assertions and inputs.
2. The systems dynamics parameters and reliability data are synthetic teaching examples, not field evidence.
3. The requirements checker is a deliberately narrow heuristic; human semantic and set-level review is required.
4. The architecture fitness function checks only the explicitly modelled dependency policy.
5. The Go service is a single-process in-memory teaching example. It does not implement durability, replication, Raft, consensus or a distributed database.
6. The more open-ended design studios and capstone require a knowledgeable human reviewer for credible grading. Self-assessment cannot supply independent feedback.
7. The package has not undergone a cohort pilot, external examination, independent specialist review, accreditation process or formal validation of learning gain.

## 7. Overall quality judgement

The updated internal diagnostic score is **4.2/5 (approximately 8.4/10)** for the study pack as an independent learning resource. This is a reasoned author assessment, not an externally calibrated grade. The largest improvements are practical reproducibility, study guidance, CLO-to-assessment alignment and reference solutions. A literal 10/10 or equivalence to a complete graduate degree would overstate the evidence. The clearest remaining gap is independent expert feedback and validated assessment, not the number of pages or links.

## 8. Reproduction commands from a clean checkout

Start in the root of the extracted package and run the commands from `16-LAB-ENVIRONMENT-AND-REPRODUCIBILITY.md`. Run each practical from its own folder. The Course III defective sample is expected to exit non-zero; do not treat that expected diagnostic as a suite failure. Retain runtime versions, exact commands, output files and test logs with any submitted work.

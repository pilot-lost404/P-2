# Resource Library

An annotated catalogue of books, university courses, lecture series, official documentation, standards, open learning sites, practical tools, research papers and practitioner material for the six course units.

**Access labels**

- **Free/open:** publicly usable without a course fee; check individual content licenses before redistribution.
- **Free online content:** the reading/lecture website is public, but the publisher may sell a print or electronic edition.
- **Free course materials:** lecture notes, videos, assignments or labs are publicly accessible; this does not imply credit or instructor feedback.
- **Paid/paywalled:** publisher text or instructor-led training generally requires purchase, subscription or institutional access.
- **Syllabus/outline only:** useful to structure study, but not a complete taught course.
- **Freemium / account required:** core material may be available without payment; account or paid features may exist.

A public course page is not necessarily a complete course. The annotations below say what was actually found: videos, notes, exercises, slides, case studies, tools or only a syllabus.

---

## Start here: highest-value resources across the curriculum

| Priority | Resource | Type and access | Why it belongs in this course |
|---:|---|---|---|
| 1 | [MIT OpenCourseWare](https://ocw.mit.edu/) | University course library · Free/open materials | The most complete combination found for systems thinking and systems engineering: lectures, notes, assignments, projects and supporting files. |
| 2 | [NASA Systems Engineering Handbook and tutorial](https://www.nasa.gov/reference/systems-engineering-handbook/) · [NASA tutorial](https://science.nasa.gov/toolkit/systems-engineering-tutorial/) | Government handbook/course tutorial · Free | A strong practical backbone for lifecycle engineering, requirements, technical processes, reviews, verification and operations. |
| 3 | [SEBoK](https://sebokwiki.org/) | Online body of knowledge · Free online | Broad systems-engineering knowledge map; use it to find topics and cross-links rather than read every page linearly. |
| 4 | [Google SRE Classroom](https://sre.google/classroom/) | Hands-on workshops · Free/open, CC BY 4.0 | Includes design exercises for a distributed PubSub and ImageServer plus SLO practice. |
| 5 | [Brown CS1380 Distributed Systems](https://cs.brown.edu/courses/cs138/s23/lectures.html) | University lectures, recordings and slides · Free materials | A well-sequenced lecture archive for replication, ordering, consistency, partitioning, transactions, consensus and distributed processing. |
| 6 | [Distributed Systems, 4th edition](https://www.distributed-systems.net/index.php/books/) | Textbook · Free download from authors' site | A legally free, substantial textbook that supports distributed-systems theory and algorithmic reasoning. |
| 7 | [Designing Data-Intensive Applications, 2nd edition](https://www.oreilly.com/library/view/designing-data-intensive-applications/9781098119058/) | Canonical commercial book · Paid/library | A deep treatment of storage, data models, replication, transactions, distributed-systems limits, streaming and data governance. |
| 8 | [Software Architecture in Practice, 4th edition](https://www.informit.com/store/software-architecture-in-practice-9780136886099) | Canonical commercial book · Paid/library | Strong reference for quality attributes, architecture structures, tactics and evaluation. |
| 9 | [System Dynamics Society learning road maps](https://systemdynamics.org/learning/road-maps/) | Exercises and learning maps · Free | Progressive practice in causal feedback, stock-flow thinking, delays, model testing and sensitivity. |
| 10 | [FMHY Educational](https://fmhy.net/educational) | Curated discovery index · Mixed | Useful for finding course platforms and lecture archives; it is not itself a quality-assured curriculum. Use only the legitimate education/learning entries described below. |

## 1. Systems thinking and system dynamics

### Books

| Resource | Access | Recommended use | Quality / limitations |
|---|---|---|---|
| Donella H. Meadows, [*Thinking in Systems: A Primer*](https://www.chelseagreen.com/product/thinking-in-systems/) | Paid / library; publisher information public | First book for boundaries, stocks, flows, feedback, delays, leverage points and system traps. | Clear conceptual introduction by a foundational systems thinker. It does not replace quantitative modelling practice. |
| John D. Sterman, [*Business Dynamics: Systems Thinking and Modeling for a Complex World*](https://mitmgmtfaculty.mit.edu/jsterman/business-dynamics/) | Paid / library | Advanced reference for causal structures, stock-flow models, simulation, model testing and policy design. | A core MIT teaching text; demanding, but directly paired with MIT 15.871 and 15.879. |
| Nancy Roberts et al., *Introduction to Computer Simulation: The System Dynamics Approach* | Library / used-book access | Alternative guided path into simulation and feedback structures. | Older text; check library availability and edition. The System Dynamics Society road maps reference selected chapters and exercises. |

### Complete university courses and lectures

| Resource | What it contains | Access / best use |
|---|---|---|
| [MIT 15.871 — Introduction to System Dynamics (Fall 2013)](https://ocw.mit.edu/courses/15-871-introduction-to-system-dynamics-fall-2013/) | Graduate course by John Sterman and Hazhir Rahmandad; systems-thinking lectures/insights, problem sets, epidemic modelling, problem conceptualization, stock-flow mapping, product adoption and management simulation. | Free course materials. **Core course.** Start here after reading the chapter. The [download page](https://ocw.mit.edu/courses/15-871-introduction-to-system-dynamics-fall-2013/download/) includes downloadable course files and video. |
| [MIT 15.879 — Building Serious System Dynamics Models from Scratch (Spring 2025)](https://ocw.mit.edu/courses/15-879-building-serious-system-dynamics-models-from-scratch-spring-2025/) | Advanced course with 12 sessions, lecture videos, notes, programming assignments, solutions, model files and student projects; includes epidemiology, energy, predator-prey, drug pipelines, Ponzi schemes, market growth and endogenous diffusion. | Free course materials. **Deepening / advanced.** Do this after 15.871 or equivalent foundations. The [independent learner guide](https://ocw.mit.edu/courses/15-879-building-serious-system-dynamics-models-from-scratch-spring-2025/pages/introduction-for-independent-learners/) estimates substantial work (roughly 10–15 hours per class) and explicitly recommends mastering the basics first. |
| [System Dynamics Society — Road Maps](https://systemdynamics.org/learning/road-maps/) | Sequential PDFs and beginner exercises on feedback, stock-and-flow, mental simulation, delays, S-shaped growth, generic structures, validation and sensitivity. | Free. **Core practice supplement.** Particularly useful when you need small exercises between MIT lectures. |

### Modelling tools and interactive practice

- [Vensim](https://vensim.com/) — system-dynamics modelling environment used in MIT coursework. Check current edition and license terms; the MIT course references Vensim PLE. Start with simple stocks, flows and feedback loops rather than learning every tool feature.
- [Insight Maker](https://insightmaker.com/) — browser-based modelling and simulation for system dynamics and causal-loop maps. Freemium / account terms may apply.
- [Stella Architect](https://www.iseesystems.com/store/products/stella-architect.aspx) — commercial system-dynamics modelling environment; optional, not required for this curriculum.
- [PhET](https://phet.colorado.edu/) — free interactive simulations, useful for intuition in connected quantitative topics; it is not a dedicated system-dynamics curriculum.

### Recommended sequence

1. Read Meadows for conceptual vocabulary.
2. Work through the first half of MIT 15.871 and recreate the examples.
3. Complete System Dynamics Society beginner exercises.
4. Finish MIT 15.871 problem sets and make your own model.
5. Take selected MIT 15.879 assignments when the first model is understood.

## 2. Systems engineering fundamentals

### Books and handbooks

| Resource | Access | Recommended use | Quality / limitations |
|---|---|---|---|
| [NASA Systems Engineering Handbook, NASA/SP-2016-6105 Rev. 2](https://www.nasa.gov/reference/systems-engineering-handbook/) | Free government publication | Main reference for lifecycle processes, technical management, stakeholder needs, requirements, architecture, integration, verification and validation. | High-authority government source; mission context and NASA process details need tailoring to ordinary software projects. |
| [SEBoK — Systems Engineering Body of Knowledge](https://sebokwiki.org/) | Free online | Broad reference to systems concepts, lifecycle, methods, specialties and application. | Maintained knowledge base; pages have different contributors and update dates, so inspect page references. |
| Kossiakoff et al., [*Systems Engineering: Principles and Practice*, 3rd ed.](https://onlinelibrary.wiley.com/doi/book/10.1002/9781119516699) | Paid / library | Comprehensive textbook on systems engineering principles, processes and practice. | Strong canonical book; use the library if the publisher edition is expensive. |
| [INCOSE Systems Engineering Handbook, 5th ed.](https://www.incose.org/resources-publications/technical-publications/se-handbook/) | Paid / member / institutional access may apply | Reference for lifecycle processes and good practice aligned with ISO/IEC/IEEE 15288:2023. | Industry handbook; the official page describes its scope but the full handbook is not an open-text substitute. |
| [NASA Handbook: Systems Modeling](https://standards.nasa.gov/standard/NASA/NASA-HDBK-1009) | Free government publication | Supports model-based systems engineering and the role of models in engineering processes. | Check document version/status on the official NASA standards page before applying in a real project. |

### Complete courses and lectures

| Resource | What it contains | Access / best use |
|---|---|---|
| [MIT 16.842 — Fundamentals of Systems Engineering (Fall 2015)](https://ocw.mit.edu/courses/16-842-fundamentals-of-systems-engineering-fall-2015/) | Graduate course by Olivier de Weck; lectures/notes on stakeholder analysis, requirements, SysML, architecture and concept generation, trade-space exploration, design optimization, MBSE, integration/interfaces, safety, V&V, commissioning and lifecycle management. The project develops a PDR-level CanSat design. | Free course materials. **Core course.** Study the [readings](https://ocw.mit.edu/courses/16-842-fundamentals-of-systems-engineering-fall-2015/pages/readings/) and [course downloads](https://ocw.mit.edu/courses/16-842-fundamentals-of-systems-engineering-fall-2015/download/) alongside the chapter. |
| [MIT ESD.33 — Systems Engineering (Summer 2004)](https://ocw.mit.edu/courses/esd-33-systems-engineering-summer-2004/) | Older graduate course with lecture notes on frameworks, lean/set-based design, axiomatic design, QFD, Pugh selection, design of experiments, robust design, physics-based modelling and case studies. | Free lecture notes and assignments. **Deepening.** Older material, but useful for design methods and real engineering cases. |
| [NASA Systems Engineering Tutorial](https://science.nasa.gov/toolkit/systems-engineering-tutorial/) | Guided explanation of NASA mission lifecycle from concept through operations and decommissioning. | Free. **Core supplement** if lifecycle stages are new to you. |
| [NASA Systems Engineering Handbook online references](https://www.nasa.gov/reference/systems-engineering-handbook/) | Practical descriptions of technical processes and systems-engineering management. | Free. Use as a reference while completing the PDR exercise. |

### Standards and modelling language

- [ISO/IEC/IEEE 15288:2023](https://www.iso.org/standard/81702.html) — international system life-cycle process standard. **Paid/paywalled.** Use the public catalogue description to understand scope; do not treat a web summary as the standard text.
- [OMG Systems Modeling Language (SysML)](https://www.omg.org/sysml/) — official language and specification resources. Check current version and publication access on the OMG site.
- [NASA Systems Engineering Standards](https://standards.nasa.gov/) — NASA standards and handbooks, useful examples of controlled technical publications.

## 3. Requirements engineering

This topic has a wider set of open university teaching packs than a simple search suggests. They are not all identical: some contain lecture slides and exercises; others provide videos and semester projects. Use the open packs for instruction and practice, and keep the textbooks as deeper references.

### Books and standards

| Resource | Access | Recommended use | Quality / limitations |
|---|---|---|---|
| Klaus Pohl, [*Requirements Engineering: Fundamentals, Principles, and Techniques*, 2nd ed. (2025)](https://link.springer.com/book/9783662692042) | Paid / institutional access | Comprehensive reference for context, elicitation, documentation, negotiation, validation and management. | Current major textbook; not an open book. |
| Karl Wiegers and Joy Beatty, [*Software Requirements*, 3rd ed.](https://www.pearson.com/en-gb/subject-catalog/p/software-requirements/P200000000686/9780735679627) | Paid / library | Practical requirements development, quality, prioritization, validation and management. | Widely used practitioner-oriented book; publication is older, so combine with current standards and agile practice. |
| [ISO/IEC/IEEE 29148:2018](https://www.iso.org/standard/72089.html) | Paid/paywalled | Requirements engineering processes and requirements information items. | As checked on 21 Nov 2026, 2018 remains the current published edition; the third edition DIS is in development and is not yet the published standard. See the [DIS page](https://www.iso.org/standard/94091.html). |

### Open courses, lecture packs and university material

| Resource | What it contains | Access / best use |
|---|---|---|
| [DTU 02264 Requirements Engineering — RED teaching material](https://www.pst.ifi.lmu.de/~stoerrle/RED/teaching.html) | A 13-chapter course sequence: elicitation, interaction design/validation, stakeholders/goals, context and structure, requirements QA, feature and quality-attribute specifications, function/process modelling, information modelling, transition to design, management and closure. Includes downloadable lecture slides; course page also describes case-study and exercise material. | The teaching page states that the downloadable lecture material is licensed **Apache 2.0**. Some DTU course pages/exam resources remain student-only. The RED tool itself is described inconsistently across the project pages (one page calls it Apache-licensed/open source, another says it is not yet open source but is free to use); do not infer the tool license from the slide license. **Core slides.** |
| [OpenRE teaching materials — Gothenburg / CEUR-WS paper](https://ceur-ws.org/Vol-2857/openre2.pdf) | Published account of a bachelor's course with lecture slides, requirements modelling exercises, assignments, case descriptions and exam-related material. Topics include scope, context/goals, use cases, requirement quality, elicitation and verification. | Describes online teaching artifacts under **CC BY-NC 4.0**; access the [linked Zenodo record](https://doi.org/10.5281/zenodo.4621264) for the actual material. **Core practical pack.** |
| [Free for All: Open RE Course — Chalmers / CEUR-WS paper](https://ceur-ws.org/Vol-2857/openre1.pdf) | Description of a semester-long Master's-level requirements-engineering course with YouTube lectures, slides, readings and team assignments that produce a complete requirements specification. Includes adapting specifications for existing open-source systems. | The authors describe the teaching materials under **CC BY-SA 4.0**; the CEUR paper itself carries a separate **CC BY 4.0** notice. The paper points to the [FOSS2Serve materials portal](https://foss2serve.org/). **Core course discovery**, but inspect the portal's live links and availability. |
| [IUS SE322 — Software Requirements Analysis](https://ecampus.ius.edu.ba/syllabus/se322-software-requirements-analysis) | Current course outline covering stakeholder needs, requirement classes, scope, elicitation, SRS, use cases/UML, validation, negotiation, prioritisation, traceability, management and agile requirements. | Public syllabus/outline; not a complete open video course. |
| [University of Victoria SENG321 — Requirements Engineering](https://course-outlines.uvic.ca/ban/course-outlines/public-outline?banner_term=202509&course_number=321&subject=SENG) | Course outline covering requirements modelling, formal specification, agile methods, testing/BDD, V&V, risk, feasibility, negotiation and prototyping. | Public syllabus/outline; use to check coverage, not as a full course substitute. |

### Tools and practice material

- [NASA FRET — Formal Requirements Elicitation Tool](https://github.com/NASA-SW-VnV/fret) — open-source tool for writing and analyzing structured requirements, with formalization and analysis capabilities. Use after learning to write clear natural-language requirements. It is a specialist tool; it does not replace stakeholder elicitation or domain review.
- [FRET tutorial paper](https://ceur-ws.org/Vol-2584/PT-paper4.pdf) — open paper explaining formal requirements elicitation/analysis with FRET.
- [RED Requirements Editor](https://www.pst.ifi.lmu.de/~stoerrle/RED/) — requirements modelling/editor family built to support hands-on teaching; check current repository and license details before installation.
- [ReqIF overview and specification entry point](https://www.omg.org/spec/ReqIF/) — exchange format for requirements information. Useful for understanding tool interoperability; specification access may have terms.
- Your own requirements matrix in Markdown/CSV is sufficient for the capstone. Store requirement ID, source, text, rationale, priority, verification method, linked design element, linked test and current status.

### Recommended sequence

1. Read the requirements chapter and use the DTU course pack as its topic checklist.
2. Work through OpenRE exercises: scope/context, modelling and writing requirements.
3. Build one SRS and acceptance-test set for the capstone.
4. Use FRET for a small set of formalized requirements after natural-language quality is good.
5. Use ISO 29148 as a terminology/process reference if you have institutional access.

## 4. Software system design and distributed systems

### Books

| Resource | Access | Recommended use | Quality / limitations |
|---|---|---|---|
| Martin Kleppmann and Chris Riccomini, [*Designing Data-Intensive Applications*, 2nd ed. (2026)](https://www.oreilly.com/library/view/designing-data-intensive-applications/9781098119058/) | Paid / library | Main advanced text for data-intensive architecture, storage, transactions, replication, partitioning, consistency, batch/stream processing and data governance. | Excellent breadth; demanding. Read in alignment with the chapter rather than front to back before building anything. |
| Maarten van Steen and Andrew S. Tanenbaum, [*Distributed Systems*, 4th ed.](https://www.distributed-systems.net/index.php/books/) | **Free download from authors' site** | Formal foundations: communication, architecture, coordination, consistency, replication, fault tolerance and distributed algorithms. | Strong legal open textbook; more theoretical than a practical software-design guide. |
| Amy Brown and Greg Wilson, [*The Architecture of Open Source Applications*, Volumes I and II](https://aosabook.org/en/) | Free online | Study how real open-source systems are structured and why maintainers made specific design choices. | Original chapters by project contributors; case studies vary in technical level and date. Excellent for architecture discussions. |
| [OpenCSF — Computer Systems Fundamentals](https://opencsf.org/Books/csf/html/) | Free online | Supporting foundations for concurrency, IPC, system models, communication and architecture styles. | Good reference for lower-level computing foundations, not a replacement for distributed-systems theory. |

### University courses and lecture series

| Resource | What it contains | Access / best use |
|---|---|---|
| [Brown CS1380 — Distributed Systems (Spring 2023)](https://cs.brown.edu/courses/cs138/s23/lectures.html) | Public lecture recordings and slides; covers distributed architecture/programming, nodes, time and ordering, leaderless replication, consistency, partitioning, routing, MapReduce, consensus (Paxos/Raft), transactions and Byzantine fault tolerance. | Free recordings/slides. **Core lecture course.** Use with the free distributed-systems textbook and the software design chapter. |
| [University of Edinburgh — Distributed Systems](https://opencourse.inf.ed.ac.uk/ds) | Detailed Level 11 course outline for scaling, RPC, load balancing, failure models, recovery, causality, transactions, concurrency control, consensus, replication, distributed storage and testing. | Public course outline. It is not a complete set of lecture videos or labs on the page. **Coverage checklist.** |
| [MIT 6.5840 — Distributed Systems (Spring 2026)](https://pdos.csail.mit.edu/6.5840/) | Graduate course with lectures, readings, programming labs, optional project and exams. The 2026 labs build MapReduce, Raft, a key-value service and sharded storage. | Free course materials, but substantial systems-programming prerequisites are expected. **Advanced practical course.** Start with [Lab 1: MapReduce](https://pdos.csail.mit.edu/6.5840/labs/lab-mr.html) and [Lab 3: Raft](https://pdos.csail.mit.edu/6.5840/labs/lab-raft1.html) after the Brown lectures and free textbook. |
| [UC Berkeley CS162](https://cs162.org/) | Operating systems and systems programming foundations: processes, concurrency, synchronization, memory, filesystems and networking. | Public course materials vary by term; many assignments are course-scoped. **Foundation**, not a dedicated architecture course. |

### Official technical documentation and labs

| Resource | What to study | Access / caveats |
|---|---|---|
| [PostgreSQL documentation](https://www.postgresql.org/docs/current/) | Data modelling, SQL, indexes, query planning, transactions/isolation, WAL, replication, backup, continuous archiving and point-in-time recovery. | Free official docs. **Reference by the deployed major version**; do not apply a configuration setting from another release without checking. |
| [Apache Kafka documentation](https://kafka.apache.org/documentation/) | Topics/partitions, producers, consumers, consumer groups, replication, delivery guarantees, transactions, Kafka Connect and Streams. | Free official docs. Kafka's idempotence/transaction guarantee has a defined scope; it does not automatically make arbitrary external database side effects exactly-once. |
| [Kubernetes documentation](https://kubernetes.io/docs/) | Deployments, Services, probes, resource requests/limits, autoscaling, disruption budgets, rollout/rollback and health checks. | Free official docs. Use version-matched documentation and distinguish tutorials from production operational policy. |
| [Docker documentation](https://docs.docker.com/) | Images, containers, volumes, networking, builds and Compose for local repeatable labs. | Free official docs. Useful for local environments before adding orchestration. |
| [OpenTelemetry documentation](https://opentelemetry.io/docs/) | Traces, metrics, logs, context propagation, semantic conventions, instrumentation and Collector pipelines. | Free official docs. Start with one application, then propagate context across an HTTP or messaging boundary. |
| [Raft paper and visual resources](https://raft.github.io/) | Leader election, log replication, safety and consensus. | Free research/learning resources. Use after understanding replication and failure assumptions. |
| [Google MapReduce paper](https://static.googleusercontent.com/media/research.google.com/en//archive/mapreduce-osdi04.pdf) | Distributed data-processing architecture and fault-tolerant execution. | Free research paper; foundational and historical, not a recommendation to use MapReduce for every data task. |

## 5. Software architecture and trade-off analysis

### Books and reference works

| Resource | Access | Recommended use | Quality / limitations |
|---|---|---|---|
| Len Bass, Paul Clements and Rick Kazman, [*Software Architecture in Practice*, 4th ed.](https://www.informit.com/store/software-architecture-in-practice-9780136886099) | Paid / library | Architecture fundamentals, quality attributes, tactics, documentation and evaluation. | Primary canonical text associated with CMU SEI. |
| Mark Richards and Neal Ford, [*Fundamentals of Software Architecture*](https://www.oreilly.com/library/view/fundamentals-of-software/9781492043447/) | Paid / library | Accessible companion for styles, architecture characteristics, modularity and trade-offs. | Practitioner-facing companion; check newer editions and available library access. |
| Michael Nygard, [*Release It!*](https://pragprog.com/titles/mnee2/release-it-second-edition/) | Paid / library | Production-oriented architecture patterns for stability, failure containment and operational design. | Complements SRE and resilience topics; not a formal architecture evaluation method. |

### University lectures and formal training

| Resource | What it contains | Access / best use |
|---|---|---|
| [CMU 17-633 / 17-882 — Architectures for Software Systems (Spring 2026)](https://mse.s3d.cmu.edu/0_documents/syllabi/17633-software-architectures-syllabus-2026.pdf) | Course objectives and syllabus for architectural drivers, styles/patterns/tactics, alternatives, documentation and evaluation. | Public syllabus. **Important:** the Spring 2026 syllabus says lectures are not recorded; do not confuse it with the separate [public CMU architecture playlist](https://www.youtube.com/playlist?list=PLRqKmfi2Jh3vVyZ0TcK9myDAGy03LQGwe) from an earlier course. A [2026 course-introduction video](https://www.youtube.com/watch?v=1DvaPZ_4sh0) is available, but it is not a complete recording archive. |
| [George Mason University — Software Design and Architecture](https://people.cs.gmu.edu/~tlatoza/teaching/swe621s25/home.html) | Public course page with outcomes around architecture, styles, design patterns, reuse and design evaluation. | Syllabus/course site; inspect its term-specific page for current slides and assignments. |
| [University of Texas at El Paso CS5386 — Software Architecture](https://www.cs.utep.edu/isalamah/CS5386.php) | Public syllabus, architecture document template, lecture slides on quality attributes, architecture tactics and views, and an AADL car demonstration. | Public materials; verify individual downloads and current course status. |
| [CMU Software Engineering Institute — Architecture Design and Analysis](https://www.sei.cmu.edu/training/software-architecture-design-analysis/) | Instructor-led training for QAW, ATAM and lightweight architecture evaluation methods. | Paid training. Use the free SEI papers below as the open alternative. |

### Free architecture guides and templates

- [SEI ATAM collection](https://www.sei.cmu.edu/library/architecture-tradeoff-analysis-method-collection/) — original method material, reports, papers and case studies for evaluating decisions against quality attributes.
- [C4 model](https://c4model.com/) — practical hierarchy for software architecture diagrams: system context, containers, components and code. Free documentation.
- [arc42](https://arc42.org/) — open architecture documentation template that helps structure goals, constraints, context, solution strategy, building blocks, runtime views, deployment, decisions and risks.
- [Structurizr documentation](https://docs.structurizr.com/) — architecture-as-code tooling around C4. The DSL/CLI is useful for learning; hosted features may be commercial.
- [Microsoft Azure Architecture Center](https://learn.microsoft.com/en-us/azure/architecture/) — reference architectures, design patterns and architecture decision guidance. Vendor-specific examples should be generalized rather than copied without context.
- [AWS Well-Architected Framework](https://docs.aws.amazon.com/wellarchitected/latest/framework/framework.html) — principles and trade-off questions across operational excellence, security, reliability, performance efficiency, cost optimization and sustainability. Cloud-specific; use it as a review lens, not a universal architecture standard.
- [Google Cloud Architecture Framework](https://docs.cloud.google.com/architecture/framework) — cloud design principles and reliability/security/operations guidance. Vendor-specific examples require adaptation.

### Recommended sequence

1. Learn quality-attribute scenarios and architectural drivers from the chapter and CMU lectures.
2. Draw C4 context and container views for the capstone.
3. Document the architecture with arc42 and record decisions as ADRs.
4. Study SEI's QAW/ATAM material and perform a small architecture review with two competing alternatives.
5. Compare against one cloud well-architected framework only after writing vendor-neutral requirements.

## 6. Reliability engineering, SRE and incident response

### Books and standards

| Resource | Access | Recommended use | Quality / limitations |
|---|---|---|---|
| Google, [*Site Reliability Engineering*, 2nd ed. (2026)](https://sre.google/books/) | Commercial book; selected online resources available | Modern SRE practices, production reliability, cloud systems, service ownership and the evolution of operations. | The new edition is a major rewrite. Use the openly available first-edition material and Workbook as immediate study supplements. |
| Google, [*The Site Reliability Workbook*](https://sre.google/workbook/index/) | Free online chapters; print/ebook commercial | Hands-on SLO, monitoring, incident response, postmortem, release and production exercises. | Strong practical companion written from Google's engineering experience. |
| Patrick O'Connor and Andre Kleyner, [*Practical Reliability Engineering*, 6th ed.](https://www.wiley.com/-p-9781394199969) | Paid / library | Classical reliability analysis: life data, probability distributions, Weibull, reliability prediction, FTA, RBD, maintainability and testing. | Strong hardware/system reliability reference; deeper than an SRE primer. |
| [NIST SP 800-61 Rev. 3](https://csrc.nist.gov/pubs/sp/800/61/r3/final) | Free government publication | Cybersecurity incident response integrated into cybersecurity risk management. | **Cybersecurity scope**; not a complete generic service-incident management framework. |
| [NIST SP 800-184 — Guide for Cybersecurity Event Recovery](https://csrc.nist.gov/pubs/sp/800/184/final) | Free government publication | Cyber event recovery planning and exercises. | Use for security-related recovery, not as a substitute for service restoration design. |

### Courses and practical workshops

| Resource | What it contains | Access / best use |
|---|---|---|
| [Google SRE Classroom](https://sre.google/classroom/) | Free workshops on distributed PubSub, distributed ImageServer, non-abstract large system design and SLO practice; includes supplementary flashcards and links to Workbook chapters. | Free and explicitly published under **CC BY 4.0**. **Core hands-on material** for architecture and SRE together. |
| [University of Maryland ENRE 602 — Principles of Reliability Analysis](https://www.academiccatalog.umd.edu/graduate/courses/enre/) | University course catalogue entry covering reliability probability, fault trees, reliability block diagrams, FMEA, event trees, Bayesian methods and repairable-system analysis. | Public course outline/catalogue; not open lecture recordings. **Coverage reference.** |
| [UIUC CS 598XU — Cloud Scale Reliability reading list](https://cs598txu-uiuc.github.io/spring22/readings.html) | Reading list on cloud-scale reliability and distributed infrastructure. | Free list of readings; not a full current course. Useful as a paper trail into advanced material. |
| [Johns Hopkins APL / AIAA — Reliability Engineering and Analysis for Space Missions](https://edge.jhu.edu/edge-search/reliability-engineering-and-analysis-for-space-missions/) | Live/recorded instruction and downloadable notes on reliability statistics, life data, FMEA, RBD, FTA, event trees, Bayesian data analysis and probabilistic risk assessment. | Paid course. The listed 2027 offering is scheduled for March–April 2027; verify current schedule and fees with provider. |

### Official documentation for practical SRE labs

- [Google SRE Workbook](https://sre.google/workbook/index/) — SLO design, monitoring, alerting, incident response, postmortem culture and operational practices.
- [OpenTelemetry](https://opentelemetry.io/docs/) — instrumentation and correlated traces, metrics and logs. Context propagation is essential for following a request across service boundaries.
- [Kubernetes health probes](https://kubernetes.io/docs/concepts/configuration/liveness-readiness-startup-probes/) — readiness, liveness and startup probes have different operational meanings; do not make every probe perform the same test.
- [PostgreSQL backup and restore](https://www.postgresql.org/docs/current/backup.html) and [continuous archiving/PITR](https://www.postgresql.org/docs/current/continuous-archiving.html) — practice an actual database restore and verify recovery points.
- [Google Cloud Reliability Pillar](https://docs.cloud.google.com/architecture/framework/reliability) — architecture-level reliability guidance, failure handling and recovery design.
- [Google Cloud Infrastructure Reliability Guide](https://docs.cloud.google.com/architecture/infra-reliability-guide) — concrete cloud deployment choices and availability trade-offs. Cloud-specific values are examples for that platform, not universal guarantees.

## 7. Cross-course learning platforms and discovery sites

FMHY's [Educational index](https://fmhy.net/educational) lists many places to discover legitimate courses, lectures and interactive learning. Use it as an index; judge each destination independently.

| Site | What it is good for | Access / quality note |
|---|---|---|
| [MIT OpenCourseWare](https://ocw.mit.edu/) | Full course materials across engineering, systems, computer science, management and mathematics. | Free/open course materials. Strongest source in this catalogue. |
| [edX](https://www.edx.org/) | Structured university and industry courses, including computer science and engineering. | Free audit availability depends on course and current policy; certificates and graded work may be paid. Check each course page. |
| [OpenLearn](https://www.open.edu/openlearn/) | Free Open University short courses and structured study. | Free learning; topic coverage varies. |
| [Saylor Academy](https://learn.saylor.org/) | Self-paced online courses and assessments. | Many courses are free; verify subject coverage and course revision. |
| [CMU Open Learning Initiative](https://oli.cmu.edu/independent-learner-courses/) | Independent-learning courses and interactive material. | Availability and access conditions vary by course. |
| [OpenHPI](https://open.hpi.de/) | Online computer science and IT courses. | Free account-based learning; schedules and enrollment windows vary. |
| [Yale Open Courses](https://oyc.yale.edu/) | Public university lecture courses. | Free lecture archive; not specifically an engineering-systems curriculum. |
| [VideoLectures.NET](https://videolectures.net/) | Academic presentations and conference lectures. | Free archive; quality, age and completeness depend on each lecture. |
| [Gresham College](https://www.gresham.ac.uk/) | Public lectures by academics and practitioners. | Free public lecture archive; use selectively for context rather than technical labs. |
| [Class Central](https://www.classcentral.com/) | Search and compare online courses from multiple providers. | Discovery/catalogue site, not the course author; verify claims and fees on the provider's page. |
| [OpenCulture](https://www.openculture.com/freeonlinecourses) | Catalogue of free lectures and courses. | Discovery index; verify availability on the source institution's site. |
| [OSSU](https://github.com/ossu/) | Community-maintained open-source computer-science curriculum. | Free curriculum map built from external resources; broad CS foundations rather than this complete systems course. |
| [Ebook Foundation — Free Programming Books and Courses](https://github.com/EbookFoundation/free-programming-books) | Curated programming books and online course links. | Community directory; verify each link's current availability and license. |
| [freeCodeCamp](https://www.freecodecamp.org/learn/) | Hands-on programming and web-development fundamentals. | Free interactive learning; useful background, not a substitute for requirements, architecture or reliability material. |
| [media.ccc.de](https://media.ccc.de/) | Conference and technical talk archive. | Many talks are freely available; choose talks with identifiable speakers, dates and primary project evidence. |
| [P2PU](https://www.p2pu.org/) | Community learning groups and self-directed study. | Free/community-led; quality and activity vary by group. |

### FMHY filtering rule

The FMHY Educational page contains both a **Courses / Streaming** and a **Learning Sites** section with legitimate public learning destinations such as MIT OCW, edX, OpenLearn, Saylor, OpenHPI, CMU OLI, Yale Open Courses, OSSU, freeCodeCamp and VideoLectures.NET. It also contains a separate **Courses / Downloading** section that includes torrent and course-copy routes, access-bypass tools and other unauthorized distribution leads. Those are **excluded** from this pack. Do not use FMHY or any other index to locate pirated book scans, paid-course mirrors, torrent copies, account sharing or access circumvention. A learning resource is included only when its official publisher, author, university or project site provides a legal route to the material.

## 8. Research papers, seminal material and case studies

These papers are not a substitute for the textbooks. Read them after the relevant concept chapter, and focus on the problem, assumptions, proposed method, evidence, limitations and design consequences.

| Paper / collection | Topic | Why read it |
|---|---|---|
| [A New Accident Model for Engineering Safer Systems — Nancy Leveson (2004)](https://doi.org/10.1016/j.ssci.2003.11.006) | Systems safety / control | Shows why accident analysis must consider control structure and system interactions, not only component failure. |
| [The Architecture of Open Source Applications](https://aosabook.org/en/) | Software architecture case studies | First-hand chapters on how real systems were structured and evolved. Read one system similar to your capstone. |
| [Raft: In Search of an Understandable Consensus Algorithm](https://raft.github.io/raft.pdf) | Distributed consensus | A clear formal algorithmic treatment of leader election and replicated logs. |
| [MapReduce: Simplified Data Processing on Large Clusters](https://static.googleusercontent.com/media/research.google.com/en//archive/mapreduce-osdi04.pdf) | Distributed processing | A foundational large-scale data processing design; study the abstraction and fault handling. |
| [Dynamo: Amazon's Highly Available Key-value Store](https://www.allthingsdistributed.com/files/amazon-dynamo-sosp2007.pdf) | Distributed databases | Explores availability, partitioning and eventual consistency under a particular design context. |
| [Formal Requirements Elicitation with FRET](https://ceur-ws.org/Vol-2584/PT-paper4.pdf) | Requirements / formal methods | Explains how to formalize and analyze structured natural-language requirements. |
| [ATAM and architecture evaluation materials](https://www.sei.cmu.edu/library/architecture-tradeoff-analysis-method-collection/) | Architecture evaluation | Use the case studies to learn how architecture decisions create risks, sensitivity points and trade-offs. |
| [System Dynamics Society Road Maps](https://systemdynamics.org/learning/road-maps/) | Model validation and dynamics | A sequence of short technical exercises that connects qualitative and quantitative modelling. |

## 9. Practitioner talks and optional listening

Use these as supplementary perspectives after you know the vocabulary. They are less structured than university courses and should not be used as the sole source for an engineering practice.

- [USENIX conference talks](https://www.usenix.org/conferences) — systems, distributed infrastructure, security and operations; choose talks with accessible slides or papers.
- [SREcon](https://www.usenix.org/conferences/srecon) — reliability engineering, SRE, incident management, production systems and operational learning.
- [InfoQ Podcasts](https://www.infoq.com/podcasts/) — software architecture and engineering discussions; check the speaker's experience and episode date.
- [Software Engineering Radio](https://se-radio.net/) — IEEE Computer Society-sponsored podcast on software engineering concepts and practice.
- [The Changelog](https://changelog.com/podcast) — practitioner conversations around software development and open-source systems; use as context, not as a technical standard.
- [QCon](https://qconferences.com/) — practitioner conference sessions and presentations; many recordings are paid or gated, so only include publicly accessible sessions in your study queue.

## 10. Recommended minimum library

If you want a compact but strong course without drowning in material, use this sequence:

1. **Systems thinking:** Meadows + MIT 15.871 + selected System Dynamics Society exercises.
2. **Systems engineering:** NASA Handbook + MIT 16.842 + selected SEBoK pages.
3. **Requirements:** DTU RED slides + Gothenburg OpenRE assignments + one of Pohl or Wiegers through a library.
4. **Software design:** free Distributed Systems textbook + Brown CS1380 + PostgreSQL documentation + selected DDIA 2e chapters.
5. **Architecture:** CMU 17-633 lecture material + C4 + arc42 + SEI ATAM collection + selected chapters of *Software Architecture in Practice*.
6. **Reliability:** Google SRE Classroom + SRE Workbook + classical reliability chapters from *Practical Reliability Engineering* + OpenTelemetry/PostgreSQL recovery docs.

That is the core learning stack. Add the remaining resources only when a concept is unclear or a project requirement demands deeper knowledge.


## 11. Newly verified primary references for the deeper revision

### Systems engineering and MBSE

- [OMG SysML 2.0 — official specification record](https://www.omg.org/spec/SysML/2.0/About-SysML): formal specification adopted September 2025. Includes normative language and v1-to-v2 transformation documents. Distinguish this from SysML 1.7, adopted June 2024. Read the formal OMG specification for language semantics; check tool-specific implementation coverage before selecting a modelling environment.
- [NASA Systems Engineering Handbook, NASA/SP-2016-6105 Rev. 2](https://essp.larc.nasa.gov/EVI-6/pdf_files/NASA_SystemsEngineeringHandbookRev2.pdf): detailed process descriptions for stakeholder expectations, technical requirements, logical decomposition, design definition, integration, product verification, validation, transition and crosscutting technical management. This is a 2016 handbook revision, not a claim of a newly published 2026 revision.
- [NASA Systems Engineering Fundamentals](https://www.nasa.gov/reference/2-0-fundamentals-of-systems-engineering/): web-accessible current handbook chapter page on the systems-engineering engine, life-cycle processes, verification/validation distinction and human-systems integration.

### Requirements engineering

- [DTU RED / Requirements Engineering teaching material](https://www.pst.ifi.lmu.de/~stoerrle/RED/teaching.html): a 13-chapter teaching outline, lecture slides, case studies and practical exercises. The teaching page states that the lecture material is licensed Apache 2.0. It describes a 10 ECTS course with substantial in-class exercise and homework expectations; use the original course page for scope and licence details.
- [OpenRE course-material paper](https://ceur-ws.org/Vol-2857/openre2.pdf): describes open educational artefacts, lecture slides, assignments and exercises for requirements engineering. Verify each associated repository or Zenodo record's own licence before redistribution.

### Distributed systems

- [MIT 6.5840, Spring 2026](https://pdos.csail.mit.edu/6.824/): current graduate course page identifies a 12-unit course with lectures, readings, five programming labs, optional project, midterm and final. The labs progress through MapReduce, a key/value server, Raft, a replicated key/value service and sharding. Course support and enrolled grading systems are separate from the open materials.
- [Brown CS1380 lecture archive, Spring 2023](https://cs.brown.edu/courses/cs138/s23/lectures.html): archived teaching material with lecture notes and readings on RPC, performance, consistent hashing, time, consensus, replication, transactions and Byzantine fault tolerance. Treat it as a strong archive, not as a current 2026 syllabus.

### Software architecture

- [CMU 17-635 Software Architecture syllabus, Spring 2026](https://mse.s3d.cmu.edu/0_documents/syllabi/17635-software-architectures-2026-syllabus-v1.01.pdf): learning objectives include six-part quality-attribute scenarios, modifiability, availability, performance, scalability, architectural structures and patterns, tactics, Attribute-Driven Design and Views-and-Beyond documentation. The published syllabus weights individual homework 60%, recitations 30% and participation 10%; full course materials are distributed through CMU's course platform.
- [CMU SEI ATAM collection](https://www.sei.cmu.edu/library/architecture-tradeoff-analysis-method-collection/): primary guidance for architecture evaluation, risks, sensitivity points and trade-off points.

### Reliability and SRE

- [University of Maryland ENRE 602 — Principles of Reliability Analysis](https://me.umd.edu/course-schedule/course/ENRE602): current catalogue description lists fault trees, reliability block diagrams, FMEA, event trees, reliability data collection/analysis and system reliability modelling; the page records offerings through Fall 2026.
- [NIST product-reliability assessment aid](https://www.itl.nist.gov/div898/handbook/toolaids/pff/apr.pdf): supplementary reference for product reliability, non-repairable populations, repairable systems and life-distribution models. Use the assumptions and scope stated in the document; do not treat a single handbook aid as a comprehensive reliability text.
- [Google SRE Classroom](https://sre.google/classroom/): practical workshops for distributed Pub/Sub, image-server architecture and SLO design. The page states CC BY 4.0 for these classroom materials; attribute Google and respect the licence terms when adapting them.

### Technical documentation checked through Context7

- [PostgreSQL MVCC and concurrency](https://www.postgresql.org/docs/current/mvcc-intro.html), [transaction isolation](https://www.postgresql.org/docs/current/transaction-iso.html), and [SET TRANSACTION](https://www.postgresql.org/docs/current/sql-set-transaction.html).
- [Kubernetes probe concepts](https://kubernetes.io/docs/concepts/workloads/pods/probes/) and [probe configuration](https://kubernetes.io/docs/tasks/configure-pod-container/configure-liveness-readiness-startup-probes/).
- [OpenTelemetry specification status](https://opentelemetry.io/docs/specs/status/), [Collector](https://opentelemetry.io/docs/collector/) and [semantic conventions](https://opentelemetry.io/docs/concepts/semantic-conventions/).


## Executable laboratory documentation

- Python official docs: [unittest](https://docs.python.org/3/library/unittest.html), [random](https://docs.python.org/3/library/random.html), [argparse](https://docs.python.org/3/library/argparse.html).
- Go official docs: [memory model](https://go.dev/ref/mem), [sync package](https://pkg.go.dev/sync), [context package](https://pkg.go.dev/context), [net/http](https://pkg.go.dev/net/http), [race detector](https://go.dev/doc/articles/race_detector).
- Optional discrete-event simulation: [SimPy resources](https://simpy.readthedocs.io/en/latest/topical_guides/resources.html), [SimPy monitoring](https://simpy.readthedocs.io/en/latest/topical_guides/monitoring.html).

Core executable labs deliberately use Python and Go standard libraries only. These references are for verification and extension, not additional mandatory reading.

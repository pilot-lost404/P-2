# 16 — Laboratory Environment and Reproducibility Contract

## Purpose

This document specifies the minimum environment, exact commands and evidence expectations for the executable companions. The practicals are intentionally low-dependency so that a learner can reproduce the core experiments without a cloud account, database server, paid software or container runtime.

## Tested environment and compatibility

| Component | Compatibility stated by practicals | Environment used for this package's verification |
|---|---|---|
| Python | Python 3.13.x; standard library only | Python 3.13.5 |
| Go | Go 1.23 or compatible newer release | Go 1.23.2 |
| Operating system | Any OS with the documented interpreter/compiler and terminal | Linux container runtime |
| External Python packages | None | None |
| External Go modules | None; `go.mod` declares Go 1.23 only | No downloaded modules required |

The package has not been tested on every operating system, CPU architecture or interpreter patch level. Record your exact runtime with `python --version` and `go version`. Do not upgrade a toolchain halfway through an assessed experiment without recording the change.

## Python practicals

Run each practical from its own directory. On Windows use `py -3.13` instead of `python` if that is how Python is installed; on Unix-like systems use `python3` where `python` is not mapped to Python 3.13.

### Course I — system dynamics

```bash
cd labs/course1_system_dynamics
python --version
python -m unittest discover -v
python model.py --scenario base --days 180 --step 1 --output output.csv
python model.py --scenario training --days 180 --step 1 --output training.csv
python model.py --scenario rework-reduction --days 180 --step 1 --output rework.csv
python model.py --scenario demand-smoothing --days 180 --step 1 --output demand.csv
```

### Course II — engineering decision analysis

```bash
cd labs/course2_systems_engineering
python -m unittest discover -v
python decision.py trade_study.json
```

### Course III — requirements review aid

```bash
cd labs/course3_requirements
python -m unittest discover -v
python linter.py requirements.csv --output findings.json
python linter.py requirements_review.csv --output review-findings.json
```

The last command intentionally exits with status 1 because the sample register is defective. That is an expected negative test, not a broken installation.

### Course V — architecture fitness function

```bash
cd labs/course5_architecture
python -m unittest discover -v
python checker.py architecture.json --output findings.json
```

### Course VI — reliability statistics

```bash
cd labs/course6_reliability
python -m unittest discover -v
python reliability.py life_data.csv
```

## Course IV — Go practical

```bash
cd labs/course4_distributed_systems
go version
go test ./...
go test -race ./...
go vet ./...
go run .
```

The HTTP server listens on `localhost:8080`. Stop it with Ctrl+C. Use the curl or PowerShell example in the course IV practical README to submit a request. The race detector is available only on supported Go/OS/architecture combinations; consult the official Go race-detector guide for platform constraints.

## Reproducibility checklist

For every submitted run, preserve:

1. Runtime and operating-system versions.
2. Exact source revision or archive hash.
3. Input files and parameter values.
4. Exact command line and exit status.
5. Standard output and error output.
6. Generated output files, including CSV/JSON reports.
7. Test output and any intentionally failing negative test.
8. Random seed and replicate count for stochastic/resampling work.
9. Units, rounding convention and assumptions.
10. A short note explaining whether the output matches the documented oracle and why a difference may have occurred.

## Data and scientific limitations

All included numerical input data are synthetic teaching data. The system-dynamics parameters are illustrative. The reliability dataset is too small to establish a field failure model or a maintenance policy. The requirements checker is a conservative heuristic, not a natural-language understanding system. The architecture checker checks a small declared dependency graph, not architectural fitness as a whole. The Go service is single-process and in-memory, not durable or distributed.

## Optional extensions

After reproducing the core work, learners may extend it using SimPy for process-based discrete-event simulation, a database for transactional persistence, and a model checker or property-based testing framework for stronger formal exploration. These are extension projects, not hidden prerequisites for the required practicals. Select and pin versions, add reproducible environment files, and retain a baseline run before extending.

# Course VI — Reliability Engineering, Site Reliability Engineering and Incident Response

**Academic level:** Upper-division undergraduate / introductory graduate  
**Suggested duration:** 13 teaching weeks  
**Prerequisites:** Probability and statistics, basic system architecture, databases and operating-systems fundamentals  
**Core question:** How do we quantify, design for, operate and restore systems that must continue to provide useful service despite faults and uncertainty?

---

## Course description

Reliability engineering studies the probability that a system performs its required function for a stated period under stated conditions. It develops models for failure, repair, redundancy, risk and life-cycle performance. Site Reliability Engineering (SRE) applies reliability and operational engineering to software services, using service-level indicators, objectives, error budgets, monitoring, incident response and systematic learning from failure.

The two disciplines overlap but are not identical. Classical reliability engineering provides probability models, failure analysis, maintainability, reliability block diagrams, Weibull analysis and failure reporting. SRE applies these concerns to changing software systems, distributed services, people and production operations. A software service can have strong component reliability but poor user-visible reliability because of dependency chains, deployment failures, overload or poor recovery procedures.

This course covers both the quantitative foundations and the operational practices. Students analyse a reservation service that experiences database failure, traffic overload, bad deployments and data corruption. They learn to measure user-visible outcomes, design recovery objectives, coordinate incidents and verify backup restoration.

## Learning outcomes

By the end of this course, a student should be able to:

1. Define reliability, failure, fault, maintainability, availability and safety using explicit conditions and time horizons.
2. Derive and interpret reliability, failure-density and hazard-rate functions.
3. Apply exponential and Weibull models to life-data and failure-time analysis.
4. Calculate series and parallel reliability and explain independence and common-cause failure limitations.
5. Construct and interpret FMEA/FMECA, fault trees, event trees and reliability block diagrams.
6. Estimate steady-state availability and explain how repair time and logistics affect it.
7. Define service-level indicators, objectives, agreements and error budgets for software services.
8. Design monitoring and alerting that reflect user-visible symptoms and actionable conditions.
9. Coordinate incident response, communicate impact and produce blameless post-incident analysis.
10. Define recovery time and recovery point objectives and build a testable backup/restore strategy.
11. Use fault injection, resilience testing and reliability growth processes to improve the system.
12. Explain the limits of data, models and metrics in high-consequence engineering decisions.

## Lecture sequence

| Lecture | Topic | Required output |
|---:|---|---|
| 1 | Reliability concepts and probability foundations | Reliability metric definitions |
| 2 | Failure distributions and hazard functions | Exponential/Weibull calculations |
| 3 | Maintainability and availability | Availability model |
| 4 | Reliability block diagrams and redundancy | Series/parallel reliability model |
| 5 | FMEA/FMECA and risk analysis | Failure-mode analysis |
| 6 | Fault trees and event trees | Top-event analysis |
| 7 | Reliability data, testing and FRACAS | Failure data and action plan |
| 8 | SRE principles and service-level objectives | SLI/SLO/error-budget specification |
| 9 | Monitoring, telemetry and capacity | Monitoring and alert plan |
| 10 | Incident command and communication | Incident response plan |
| 11 | Postmortems and learning systems | Blameless postmortem |
| 12 | Backup, recovery, RTO and RPO | Recovery design |
| 13 | Fault injection and resilience engineering | Experiment plan |
| 14 | Integrated reliability case | Reliability assurance report |

---

# Part I — Classical reliability engineering

## 1. Reliability, failure and probability

Reliability is the probability that an item performs its required function without failure for a specified time interval under specified operating conditions. Every part of that definition matters:

- **Required function:** what counts as success?
- **Failure:** what event means the item no longer meets the function?
- **Time interval:** over what duration is reliability measured?
- **Operating conditions:** under what load, environment, duty cycle and maintenance assumptions?

A server process may be “up” while the user cannot reserve equipment. A database may accept connections while returning stale or incorrect data. Reliability should be linked to the required function, not only to process health.

A **fault** is a cause or defect that may lead to an error. An **error** is an incorrect internal state. A **failure** occurs when delivered service deviates from the required function. The terms are related but not identical. A defect may exist without producing a visible failure; a failure may arise from interactions among multiple faults.

Reliability is not the same as availability. A non-repairable component may have reliability over time. A repairable service may be unavailable temporarily and later recover. Safety concerns unacceptable risk of harm and cannot be inferred from availability alone.

## 2. Reliability function and failure-rate models

Let \(T\) be a random variable representing time to failure. The reliability function is:

\[
R(t)=P(T>t)
\]

The cumulative distribution function is:

\[
F(t)=P(T\leq t)=1-R(t)
\]

If the failure-time distribution has density \(f(t)\), then:

\[
f(t)=\frac{dF(t)}{dt}=-\frac{dR(t)}{dt}
\]

The hazard rate (instantaneous failure rate conditioned on survival to time \(t\)) is:

\[
h(t)=\frac{f(t)}{R(t)}=-\frac{d}{dt}\ln R(t)
\]

Hazard is not simply the probability of failure over the next hour. It is a rate conditioned on the item surviving to the current time. For a small interval \(\Delta t\), the conditional failure probability is approximately \(h(t)\Delta t\) when the hazard is locally constant over that interval.

### 2.1 Exponential distribution

The exponential distribution assumes a constant hazard rate \(\lambda\):

\[
R(t)=e^{-\lambda t}
\]

\[
f(t)=\lambda e^{-\lambda t}
\]

\[
MTTF=\frac{1}{\lambda}
\]

The memoryless property means the conditional remaining lifetime distribution does not depend on how long the item has already survived. This is often a useful approximation for a stable random failure process, but it is not appropriate when failure risk changes with age, usage, wear or infant mortality.

**Worked example.** A component has a constant failure rate of 0.0002 failures/hour under the model. Its reliability over 1,000 hours is:

\[
R(1000)=e^{-0.0002(1000)}=e^{-0.2}\approx0.8187
\]

The model predicts approximately 81.9% probability of surviving the full 1,000-hour interval. This does not mean exactly 18.1% of a small sample must fail. It is a probability statement with model assumptions.

### 2.2 Weibull distribution

The two-parameter Weibull distribution is widely used for life-data analysis because it can represent different hazard shapes:

\[
R(t)=e^{-(t/\eta)^\beta}
\]

\[
f(t)=\frac{\beta}{\eta}\left(\frac{t}{\eta}\right)^{\beta-1}e^{-(t/\eta)^\beta}
\]

\[
h(t)=\frac{\beta}{\eta}\left(\frac{t}{\eta}\right)^{\beta-1}
\]

where \(\beta\) is the shape parameter and \(\eta\) is the scale parameter.

- \(\beta<1\): decreasing hazard, often associated with early failures or manufacturing/installation defects.
- \(\beta=1\): constant hazard, corresponding to the exponential distribution.
- \(\beta>1\): increasing hazard, often associated with wear-out or ageing.

These interpretations are diagnostic, not proof of a physical mechanism. A fitted Weibull shape does not tell the analyst why failures occur. Use engineering evidence, competing failure modes and data quality checks.

**Worked example.** A component is modelled with \(\beta=2\) and \(\eta=1,000\) hours. Reliability at 500 hours is:

\[
R(500)=e^{-(0.5)^2}=e^{-0.25}\approx0.7788
\]

At 1,000 hours:

\[
R(1000)=e^{-1}\approx0.3679
\]

Because \(\beta>1\), the model has an increasing hazard. The probability of surviving a further interval depends on current age; the memoryless property does not apply.

## 3. Reliability data and estimation

Reliability analysis requires defined failure data. Useful fields include item identifier, failure mode, time in service, operating cycles, environment, maintenance action, censoring indicator, repair duration, configuration and exposure basis.

A dataset may contain:

- **Complete failure times:** every item fails during observation.
- **Right-censored observations:** some items survive to the end of observation or are removed before failure.
- **Left-censored or interval-censored data:** failure time is only known to have occurred before or within an interval.
- **Repeated failures:** the same repairable unit fails multiple times.
- **Competing risks:** an item can fail through several mechanisms.

Ignoring censoring biases life estimates. Treating repeated failures as independent non-repairable lifetimes may be inappropriate. Combining data from different configurations or environments can create a misleading average.

### 3.1 Mean time to failure and mean time between failures

**MTTF** is the expected time to failure for a non-repairable item or a defined lifetime interval. **MTBF** is commonly used for the mean operating time between failures of a repairable item, but its precise definition should be stated because industry use varies. Neither metric describes the full failure-time distribution.

For a repairable system, availability also depends on repair duration, logistics, maintenance policy and the time the system is expected to operate. A very high MTBF may coexist with poor availability if repair takes days.

### 3.2 Testing and confidence

A zero-failure test does not prove zero failure probability. If independent identical trials are run under stable conditions, a confidence interval can be estimated for the underlying failure probability. For time-on-test data, appropriate reliability models and censoring methods should be used.

Accelerated life testing increases stress to observe failures more quickly. The stress model must be justified. Acceleration can change the failure mechanism, invalidating extrapolation. Record temperature, voltage, vibration, load, cycling and test configuration.

## 4. Maintainability and availability

Maintainability is the ability to restore an item to a required condition after failure within a stated time and under stated conditions. It depends on diagnostics, access, tools, spares, skills, procedures, logistics and system design.

For a simple repairable system in steady state, availability is often approximated by:

\[
A=\frac{MTBF}{MTBF+MTTR}
\]

where MTTR is mean time to repair or restore service under a clearly defined measurement basis. The formula assumes a simple alternating up/down process and stable rates; it does not cover all maintenance policies or complex dependencies.

**Worked example.** A service has MTBF of 1,000 hours and MTTR of 2 hours:

\[
A=\frac{1000}{1002}\approx0.998004=99.80\%
\]

Reducing MTTR to 1 hour gives:

\[
A=\frac{1000}{1001}\approx99.90\%
\]

This illustrates why restoration processes, diagnostics and automation matter. Improving failure prevention may increase MTBF; improving recovery may reduce MTTR. Operational design needs both.

Do not confuse MTTR with the total time a user experiences disruption. Detection delay, escalation, decision-making, failover, data recovery and customer communication may extend the user-visible impact.

## 5. Reliability block diagrams and redundancy

A reliability block diagram (RBD) represents how component successes combine to produce system success for a defined function. It is not a physical wiring diagram; it expresses functional dependency.

### 5.1 Series system

For a system that requires all components to function, and assuming independent failures:

\[
R_{series}=\prod_{i=1}^{n}R_i
\]

For three independent components with reliability 0.98 each:

\[
R=0.98^3\approx0.9412
\]

The system reliability is lower than the individual component reliability because every component is required.

### 5.2 Parallel system

For a system that succeeds if at least one of two independent redundant components succeeds:

\[
R_{parallel}=1-(1-R_1)(1-R_2)
\]

With two components of reliability 0.98:

\[
R=1-(0.02)(0.02)=0.9996
\]

The improvement assumes independence and a suitable switching or load-sharing arrangement. Common-cause failure, shared power, shared software, common configuration errors, shared network paths or environmental exposure can invalidate the independence assumption.

### 5.3 Common-cause failures

Common-cause failures are events that disable multiple supposedly redundant components. Examples include a shared power outage, common software defect, certificate expiry, bad deployment, regional network failure or operator error affecting all replicas.

A redundancy analysis should identify failure domains, diversity, isolation, control-plane dependencies and failover behaviour. Active-active deployment alone does not guarantee resilience.

## 6. Failure Mode and Effects Analysis (FMEA/FMECA)

FMEA is a structured, bottom-up method for identifying how elements can fail, the effects of those failure modes and potential controls. FMECA adds criticality analysis according to the selected method.

An FMEA row usually includes:

| Field | Meaning |
|---|---|
| Item / function | What is being analysed? |
| Failure mode | How can it fail? |
| Cause / mechanism | Why could it occur? |
| Local effect | What happens to the element? |
| System / end effect | What does the stakeholder or system experience? |
| Detection method | How would it be detected? |
| Existing controls | What prevents or limits it? |
| Severity | Consequence if it occurs |
| Occurrence | Frequency or likelihood basis |
| Detection rating | Difficulty of detecting it before effect |
| Recommended action | What reduces risk and who owns it? |

Example failure modes for a reservation service include stale inventory status, duplicate confirmation, incorrect eligibility, lost audit event, expired credentials, notification delay and corrupt backup.

### 6.1 Risk Priority Number limitations

Some FMEA methods calculate a risk priority number (RPN) by multiplying ordinal ratings for severity, occurrence and detection. This is a prioritisation aid, not a probability model. Ordinal scales may not have equal intervals. Different combinations can produce the same product despite very different consequences. A low RPN must not override catastrophic severity or a legal/safety constraint.

Use severity and consequence explicitly. Document the rating definitions, uncertainty and rationale. Consider action priority, criticality or quantitative analysis where appropriate.

## 7. Fault Tree Analysis and Event Tree Analysis

Fault Tree Analysis (FTA) is a top-down deductive method. It begins with an undesired top event and decomposes possible causes using logic gates.

- An **OR gate** means any input event can cause the output event.
- An **AND gate** means all input events must occur for the output event.

For independent basic events:

\[
P(A\ OR\ B)=P(A)+P(B)-P(A)P(B)
\]

\[
P(A\ AND\ B)=P(A)P(B)
\]

when events are independent. Dependence requires a different model.

**Worked example.** A service outage occurs if either the primary database and standby both fail, or if the shared identity dependency fails. Let primary and standby failures each have probability 0.01 over the defined period and assume independence only for this calculation. Joint database pair failure is 0.0001. If identity outage probability is 0.005 and independent of the database pair, total top-event probability is:

\[
P=1-(1-0.0001)(1-0.005)\approx0.0050995
\]

The shared identity dependency dominates. Adding database replicas provides little improvement if identity remains a single point of failure.

An event tree starts from an initiating event and traces success/failure of protective functions to possible outcomes. It is useful for analysing barriers, mitigation paths and accident sequences.

## 8. Failure reporting, analysis and corrective action (FRACAS)

FRACAS is a closed-loop process for recording failures, analysing causes, implementing corrective action and verifying effectiveness. The loop should capture configuration, operating exposure, failure mode, evidence, root-cause hypothesis, action owner and recurrence check.

A weak failure database records symptoms but omits configuration and exposure. This makes rates incomparable. “Three failures this month” is not meaningful without knowing units in service, usage hours, versions and the population at risk.

Root-cause analysis should distinguish proximate causes, systemic contributors and control failures. A postmortem that stops at “human error” often misses interface design, staffing, training, monitoring, workload and organisational incentives.

---

# Part II — Site Reliability Engineering

## 9. From component reliability to user-visible service reliability

SRE applies engineering methods to service operation. It treats operations as a design problem and reliability as an explicit objective. Reliability must be balanced against feature delivery, cost, capacity, security and risk.

A service may consist of many dependencies. If each dependency has high availability, the end-to-end service can still be less available because a request depends on all of them. Redundancy, caching, graceful degradation, asynchronous workflows and dependency isolation can improve resilience, but each has consequences.

SRE aims to reduce repetitive manual toil through automation and better system design, while preserving human judgment for complex incidents and changes.

## 10. SLI, SLO, SLA and error budgets

A **Service-Level Indicator (SLI)** is a quantitative measure of a service aspect from the perspective of its users. Examples include:

- availability: good requests divided by eligible total requests;
- latency: proportion of valid requests below a threshold;
- correctness: proportion of operations returning correct results;
- freshness: age of the latest available data;
- durability: probability or observed rate of data loss under a defined failure model.

A **Service-Level Objective (SLO)** is a target for an SLI over a stated window. A **Service-Level Agreement (SLA)** is an externally committed service promise, often with consequences or remedies if breached. These terms should not be treated as interchangeable.

### 10.1 Error budget calculation

For a binary availability objective:

\[
Error\ budget=1-SLO
\]

A 99.9% SLO has an error budget of 0.1% over the stated measurement window.

For a 30-day month:

\[
30\times24\times60=43,200\text{ minutes}
\]

A 99.9% time-based objective permits:

\[
43,200\times0.001=43.2\text{ minutes}
\]

This calculation is valid only when downtime is the defined SLI and the window and exclusions are explicit. A request-based SLI has a different denominator and may be more appropriate for a service with variable usage.

### 10.2 Error-budget policy

An error budget supports a decision policy. If a service consumes its budget rapidly, the team may reduce risky changes, prioritise reliability work, investigate error causes or scale capacity. The policy should be agreed by product, engineering and operations stakeholders. It should not become a punishment metric.

### 10.3 Burn rate

Burn rate compares the rate of error-budget consumption with the rate that would exhaust the budget over the SLO window. Multi-window alerting combines a short window for rapid detection and a longer window for sustained burn. Exact thresholds depend on the service and incident response capability.

A high burn-rate alert should be actionable. An alert that fires repeatedly without a clear owner or response is an operational defect.

## 11. Monitoring, telemetry and capacity

Monitoring collects known signals and checks expected conditions. Observability is broader: it asks whether engineers can infer internal state from outputs when behaviour is not fully predicted in advance.

Useful telemetry includes:

- **metrics:** rates, counts, gauges, histograms and distributions;
- **logs:** structured events with context and severity;
- **traces:** request flows across components and services;
- **profiles:** resource use and execution hotspots;
- **events:** deployments, config changes, failovers and administrative actions.

OpenTelemetry provides vendor-neutral APIs, SDKs, OTLP and Collector components for telemetry collection and export. A backend is still needed for durable storage, query, visualisation and alerting. Context propagation connects spans across service boundaries and allows logs and metrics to be correlated with trace context. See [OpenTelemetry concepts](https://opentelemetry.io/docs/concepts/).

### 11.1 User-centred monitoring

Monitor what users experience. A process being alive does not prove the service works. A database connection check does not prove that a reservation can be safely committed. A dashboard should include request success, latency distribution, correctness, freshness, queue age, dependency health and resource saturation.

### 11.2 Alerting

An alert should indicate a condition that requires action within a defined time. Page on symptoms and urgent risk; use tickets or dashboards for slower-moving trends. Alert thresholds should account for noise, duration, rate of change and service criticality.

Do not use high-cardinality identifiers as metric labels without considering cost and cardinality explosion. Put request IDs and user identifiers in appropriately protected logs or traces, not unrestricted metric dimensions.

## 12. Incident response

An incident is an unplanned event that degrades or threatens a service or system's ability to meet required outcomes. Incident response coordinates restoration, impact assessment, communication and decision-making under uncertainty.

A practical incident lifecycle:

1. detect and declare;
2. classify severity and impact;
3. assign command roles;
4. establish a shared operational picture;
5. mitigate or restore service;
6. communicate to stakeholders;
7. verify recovery;
8. close the incident and preserve evidence;
9. conduct a post-incident review.

### 12.1 Incident command roles

Roles should be explicit. Common roles include:

- **Incident Commander:** sets priorities, coordinates responders and manages decisions.
- **Technical Lead:** directs technical diagnosis and mitigation.
- **Communications Lead:** maintains internal and external status updates.
- **Scribe:** records timeline, decisions, hypotheses and actions.

For a small incident, one person may hold multiple roles, but duties must remain clear. The technical lead should not have to manage all external communication while diagnosing a complex failure.

### 12.2 Severity and communications

Severity should be based on impact, scope, duration, safety, data integrity and business criticality, not only on technical complexity. Communication should state known impact, current mitigation, user action, next update time and uncertainty. Avoid claiming full recovery until validation checks pass.

### 12.3 Avoid making incidents worse

During an incident, risky changes can amplify impact. Mitigation should prioritise stabilisation, preserve data, reduce load, isolate failures and restore known-good configurations. Keep a record of commands and changes. Prefer reversible actions and explicit decision authority.

## 13. Post-incident review and organisational learning

A blameless postmortem does not mean accountability is absent. It means the review examines conditions, decisions, incentives, interfaces and safeguards rather than treating an individual's mistake as a complete explanation.

A strong postmortem contains:

- summary and severity;
- customer and system impact;
- start, detection, mitigation and recovery times;
- timeline;
- triggering event and contributing conditions;
- what worked and what failed;
- detection gaps;
- recovery gaps;
- action items with owners and due dates;
- evidence of follow-up and effectiveness.

Actions should be specific and testable. “Improve monitoring” is weak. “Add an alert for reservation queue age above the agreed threshold for ten minutes, route it to the on-call team and test it in staging” is verifiable.

Postmortems should feed engineering roadmaps, documentation, training and system changes. Repeated incidents with similar mechanisms indicate that prior corrective action did not address the system structure.

## 14. Recovery objectives and data protection

A disaster-recovery strategy needs explicit objectives:

- **Recovery Time Objective (RTO):** maximum acceptable time to restore the required service after a disruption.
- **Recovery Point Objective (RPO):** maximum acceptable data loss measured in time, or the latest point to which data must be recoverable.

RTO and RPO are business requirements translated into architecture and operational capabilities. A 15-minute RPO may require more frequent log archival or replication. A one-hour RTO may require automation, staff readiness, documented runbooks and tested dependencies.

### 14.1 Backup types and recovery

Backups may be full, incremental, differential, snapshot-based or log-based. Replication is not a substitute for backup: accidental deletion, corrupt writes or ransomware may propagate to replicas.

A reliable backup design considers:

- recovery scope and consistency;
- encryption and key availability;
- retention and immutability;
- off-site or separate failure domain;
- access control and audit;
- backup verification;
- restore testing;
- dependency ordering;
- data integrity checks.

### 14.2 PostgreSQL WAL and point-in-time recovery

PostgreSQL uses write-ahead logging (WAL) for crash recovery and supports continuous archiving and point-in-time recovery. A base backup plus a continuous, valid sequence of archived WAL files can restore a database to a consistent state at a chosen point after the backup start. The archive chain must be complete and the recovery procedure must be tested. Streaming replication can provide a warm standby, but it does not remove the need for independent backups. See [PostgreSQL continuous archiving and PITR](https://www.postgresql.org/docs/current/continuous-archiving.html).

### 14.3 Restore testing

A backup is not proven by a successful backup job. Restore tests should verify:

1. the backup can be located and accessed;
2. decryption keys and credentials are available;
3. the target environment can be provisioned;
4. data restores in the required time;
5. required point-in-time data is present;
6. application-level integrity checks pass;
7. dependent services and credentials are restored;
8. operators can complete the documented procedure;
9. RTO and RPO measurements meet the agreed objectives.

Record evidence, not just a checklist tick.

## 15. Fault injection and resilience engineering

Fault injection deliberately introduces controlled failure to test whether a system and organisation respond as expected. Experiments may include:

- killing an application instance;
- introducing latency or packet loss;
- denying access to a dependency;
- expiring a credential in a test environment;
- filling a queue;
- exhausting a resource limit;
- restoring from an old backup;
- deploying a faulty but reversible configuration.

A good experiment has a hypothesis, scope, safety limits, abort criteria, monitoring, owner and post-experiment analysis. Do not run uncontrolled production chaos experiments. Begin in a sandbox or staging environment with known rollback procedures.

Resilience engineering studies how systems anticipate, monitor, respond and learn. It recognises that failures are often emergent from interactions, not a single defective component.

## 16. Integrated case study: a database outage during reservations

### 16.1 Scenario

During peak registration, the primary database stops accepting writes. Search pages still display cached availability, but reservation commits fail. Some users retry repeatedly. The message queue grows, and the on-call engineer observes elevated connection count, lock waits and application timeouts.

### 16.2 Initial response

Declare the incident and assign command, technical, communications and scribe roles. Confirm user impact and data-integrity status. Stop harmful retry amplification and consider temporarily disabling reservation creation while preserving safe read-only access. Do not claim that cached availability is authoritative.

### 16.3 Recovery decision

Investigate whether the failure is resource exhaustion, disk, network, lock contention, corruption or a deployment issue. Choose a recovery action based on evidence. If failover occurs, verify replica freshness and transaction state before reopening writes. If restoration from backup is needed, assess RTO and RPO and validate the restored state.

### 16.4 Post-incident analysis

Questions include:

- Why did the database fail?
- Why was capacity or saturation not detected earlier?
- Were retries bounded and coordinated?
- Did the cache create unsafe user expectations?
- Could the service degrade gracefully?
- Was failover rehearsed?
- Did the queue preserve messages and expose age?
- Were recovery objectives realistic and tested?
- Did the deployment, schema or traffic pattern contribute?

Corrective actions might include query tuning, connection pooling, capacity changes, bounded retries, rate limiting, better readiness policy, queue-age alerting, tested failover, backup restoration drills and updated user communication.

## 17. Problem set

### Problems

**1.** Define reliability for a reservation service in a way that is measurable and tied to user-visible function.

**2.** A component has an exponential failure model with \(\lambda=0.0001\) failures/hour. Calculate reliability over 2,000 hours and MTTF.

**3.** A component follows a Weibull model with \(\beta=2\), \(\eta=1,000\) hours. Calculate reliability at 500 hours. Explain the hazard shape.

**4.** A repairable service has MTBF = 2,000 hours and MTTR = 4 hours. Estimate steady-state availability under the simple alternating up/down model.

**5.** Three independent components in series have reliabilities 0.99, 0.98 and 0.97. Calculate system reliability.

**6.** Two independent redundant components each have reliability 0.95. Calculate parallel reliability. Name two common-cause mechanisms that could invalidate the independence assumption.

**7.** Construct an FMEA row for stale inventory status. Include effect, cause, detection and corrective action.

**8.** A 99.95% availability objective is measured over 30 days. Calculate the time-based error budget in minutes.

**9.** Explain why a service with a 99.99% database availability metric may still have poor user-visible reliability.

**10.** Define RTO and RPO for a campus reservation service and describe how each influences architecture and operational process.

### Solution sketches

**1.** Example: the proportion of valid reservation attempts under a defined operating profile that complete with exactly one valid reservation or a correct conflict response, within a specified latency range, without loss or duplication of committed state. State the time window, exclusions and measurement point.

**2.** \(R(2000)=e^{-0.2}\approx0.8187\). \(MTTF=1/0.0001=10,000\) hours. The exponential assumption is constant hazard.

**3.** \(R(500)=e^{-(0.5)^2}=e^{-0.25}\approx0.7788\). Since \(\beta>1\), hazard increases with time under the model.

**4.** \(A=2000/(2000+4)=0.998004\), approximately 99.80%. The formula assumes the defined steady-state alternating up/down model and consistent time accounting.

**5.** \(R=0.99\times0.98\times0.97\approx0.9411\).

**6.** \(R=1-(0.05)^2=0.9975\), or 99.75%. Shared power, shared network, common software defects, common certificates or a bad configuration are examples of common-cause failure.

**7.** Failure mode: inventory cache is stale. Effect: user attempts to reserve an unavailable item. Cause: invalidation message lost or delayed. Detection: compare cache age, reconciliation and reservation conflict rate. Action: enforce authoritative transactional check, monitor freshness, make invalidation durable and provide a user-visible conflict response.

**8.** A 30-day month has 43,200 minutes. Error budget is \(43,200\times0.0005=21.6\) minutes.

**9.** User-visible reliability includes application code, networking, identity, cache correctness, service dependencies, data integrity, deployment and operator response. Database uptime is only one component and does not measure correctness or workflow success.

**10.** An RTO of 1 hour means the service must be restored within one hour after the defined disruption; an RPO of 15 minutes means no more than 15 minutes of relevant data loss is acceptable. Architecture may require automated failover, frequent log archiving, tested backups, separate failure domains, runbooks and trained responders. The target must be validated against business impact and cost.

## 18. Practical assignment

Create a reliability and SRE assurance package for the reservation service:

1. define reliability and user-visible SLIs;
2. calculate availability and error budgets;
3. construct a reliability block diagram for the critical request path;
4. produce an FMEA and FTA for reservation failure;
5. analyse failure-time data using an appropriate model or explain why data are insufficient;
6. define SLOs, alerting and burn-rate response;
7. write an incident command plan and postmortem template;
8. define RTO/RPO and backup/restore strategy;
9. execute a controlled fault-injection or restore test;
10. present residual risks and evidence that corrective actions worked.

## Further reading and primary course materials

- Google, [Site Reliability Engineering](https://sre.google/sre-book/table-of-contents/): practitioner book and online reference.
- Google, [Site Reliability Workbook](https://sre.google/workbook/table-of-contents/): hands-on SRE practices and examples.
- Google, [SRE Classroom](https://sre.google/classroom/): free practical workshops on distributed PubSub, image servers and SLOs; the classroom materials are CC BY 4.0.
- NIST, [SP 800-61 Rev. 3](https://csrc.nist.gov/pubs/sp/800/61/r3/final): cybersecurity incident response recommendations; its scope is cyber incident response, not all operational incidents.
- Patrick O'Connor and Andre Kleyner, *Practical Reliability Engineering*, 6th ed. (2025). Classical reliability reference; publisher/library access.
- Mohammad Modarres, Mark Kaminskiy and Vasiliy Krivtsov, *Reliability Engineering and Risk Analysis*. Classical reliability and risk reference; publisher/library access.
- [ReliaWiki](https://www.reliawiki.com/): free online reliability reference.
- Python [reliability library documentation](https://reliability.readthedocs.io/): Weibull fitting and quantitative reliability analysis.
- [PagerDuty Incident Response documentation](https://response.pagerduty.com/): operational response and postmortem practices.
- PostgreSQL, [Backup and Restore](https://www.postgresql.org/docs/current/backup.html): official backup and recovery documentation.


---

# Advanced lecture notes and worked extensions

## 19. Failure-rate interpretation and the bathtub curve

Some engineered populations are described using a bathtub-shaped hazard pattern:

1. early-life failures may be more frequent and then decline as latent manufacturing, installation or configuration defects are discovered;
2. a useful life period may exhibit an approximately constant hazard for a particular failure mechanism;
3. wear-out may increase failure hazard as components age or accumulate cycles.

This is a conceptual model, not a universal law. Real products may have several overlapping failure mechanisms, and the total hazard is a combination of causes. Software does not wear out in the same physical way as a mechanical bearing, but software service failure rates can increase through configuration drift, dependency changes, data growth, traffic growth and operational complexity.

The hazard model must match the physical or operational mechanism. A constant-rate model for a component undergoing wear-out may underestimate later-life failures. A Weibull curve fitted to a small sample may produce unstable shape estimates.

## 20. Reliability allocation and system architecture

A system-level reliability target can be allocated to subsystems, but allocation must reflect architecture and failure dependence. In a simple series system with independent elements:

\[
R_{system}=\prod_{i=1}^{n}R_i
\]

If the system target is 0.99 and four equal independent series elements are assumed, each element must have reliability:

\[
R_i=0.99^{1/4}\approx0.99749
\]

This is a mathematical allocation under a strong simplifying assumption. Real subsystems may have different criticality, redundant paths, common-cause failure and different operational exposure. Allocation should be done through architecture analysis, not by blindly distributing a target evenly.

### 20.1 Common-cause failure and beta factor

A simple beta-factor model partitions a component failure rate into independent and common-cause portions. The model can be useful for preliminary analysis of redundant components, but it requires evidence for the common-cause fraction and is not a universal description.

Consider two nominally redundant servers with independent hardware but identical software, same region and shared identity dependency. Their hardware failures may be independent while software or regional failures are common-cause. Redundancy should be evaluated at the failure-mode and failure-domain level.

## 21. Reliability growth and corrective-action effectiveness

Reliability growth is the improvement of reliability as faults are discovered and corrected during development, test and operation. The key is to distinguish fault removal from exposure reduction. A system may show fewer failures because it is used less, not because it became more reliable.

A reliability-growth record should include:

- failure count and exposure basis;
- failure mode and severity;
- configuration and operating conditions;
- corrective action;
- regression evidence;
- recurrence monitoring;
- remaining failure modes.

A closed FRACAS loop verifies whether the correction prevented recurrence. If the same failure reappears under a different symptom, the causal mechanism may not have been addressed.

## 22. SLO design details

An SLO must define the eligible event population. For a request-based availability SLI:

\[
SLI=\frac{\text{good eligible requests}}{\text{total eligible requests}}
\]

The system must define what counts as a good request. A 200 HTTP response is not necessarily good if it returns stale or incorrect data. Conversely, some expected business conflicts may be valid responses rather than service failures.

For latency, define the threshold and request population. For data freshness, define the source event and the time at which the derived view becomes available. For correctness, define the expected invariant and the test or reconciliation method.

### 22.1 Multi-window burn-rate alerts

Suppose a service has a 30-day SLO window. A burn-rate alert estimates how quickly the error budget is being consumed. A high burn rate over a short window can detect a rapidly developing outage; a sustained lower burn rate over a longer window can detect gradual degradation.

Alert windows should be sized so the team can respond before the budget is exhausted. A policy must also distinguish paging conditions from issues that can wait for normal work hours. Do not copy thresholds blindly from another service.

## 23. Incident simulation exercise

Scenario: a deployment introduces a query regression. Database CPU rises, reservation request latency increases, the queue grows, and clients retry after timeout. A portion of requests are ambiguous because the database committed but the response was lost.

The response team should:

1. declare the incident and assign roles;
2. stop retry amplification through rate limits or client guidance;
3. identify the deployment and affected configuration;
4. assess whether the authoritative reservation state remains correct;
5. decide whether to roll back or mitigate the query;
6. inspect duplicate/idempotency records and reconcile ambiguous outcomes;
7. communicate impact and next update;
8. verify recovery using user-centred checks;
9. conduct a blameless review focused on deployment gates, query plans, capacity and retry design.

The exercise tests coordination as well as technical diagnosis. The incident commander should not need to understand every query-plan detail to maintain the incident structure.

## 24. Recovery testing and service restoration evidence

A disaster-recovery test should simulate more than a database process restart. It should establish that data, identity, configuration, secrets, application versions, network routes and downstream dependencies can be restored in the correct order.

A recovery exercise should capture:

- declared failure scenario;
- start time and detection time;
- recovery decisions and approvals;
- backup or replica chosen;
- restore start and completion times;
- recovered transaction point;
- integrity validation results;
- user-visible service restoration time;
- exceptions and workarounds;
- measured RTO and RPO;
- corrective actions and retest date.

A recovery objective that has never been demonstrated is an aspiration, not verified capability.

## 25. Extended review questions

1. Explain why the bathtub curve is a useful conceptual model but not a universal law.
2. How would shared identity, network or configuration create common-cause failure across redundant services?
3. Why does failure rate require an exposure denominator?
4. What conditions must be defined before an SLI can be measured consistently?
5. How should an incident team handle a request that timed out after a possible commit?
6. Why is a successful backup job not sufficient evidence of recoverability?
## 26. Life-data analysis with right-censored observations

Reliability analysis must distinguish an observed failure time from a unit that has not failed by the end of observation. The latter contributes exposure information; it is not a failure at the censoring time and should not be discarded.

Let \(t_i\) be the observed time on test for unit \(i\), and let \(\delta_i=1\) when a failure is observed and \(0\) when the unit is right-censored. Under an independent, identically distributed exponential lifetime model with constant failure rate \(\lambda\), the likelihood is proportional to:

\[
L(\lambda)=\lambda^D e^{-\lambda T},\qquad D=\sum_i\delta_i,\quad T=\sum_i t_i
\]

The maximum-likelihood estimate is:

\[
\hat\lambda=\frac{D}{T}
\]

where \(T\) is the total observed exposure time. The reciprocal \(1/\hat\lambda\) is the estimated mean time to failure under the exponential model. The estimate is not justified if the constant-hazard assumption is implausible or the observations are dependent in a way the model ignores.

### 26.1 Worked example — failures and censoring

Eight independent units are observed. Five fail at 40, 60, 75, 80 and 90 days. Three have not failed when observation ends at 100 days. Total exposure is:

\[
T=40+60+75+80+90+100+100+100=645\text{ unit-days}
\]

There are \(D=5\) failures, so \(\hat\lambda=5/645\approx0.007752\) failures per unit-day. The exponential-model mean is approximately 129 days. The three 100-day observations are right-censored; treating them as failures at day 100 would overstate the observed failure count and bias the estimate.

### 26.2 What censoring does and does not mean

Right censoring occurs when observation ends before a unit fails. Left censoring means the failure happened before it was first observed. Interval censoring means the failure occurred between inspection times. Each requires an appropriate likelihood contribution. Censoring is often assumed non-informative: conditional on the model, the censoring mechanism does not preferentially remove units with different failure risk. If units are withdrawn because they exhibit warning signs, that assumption may fail.

## 27. Weibull models and repairable-system data

The two-parameter Weibull distribution has scale \(\eta>0\) and shape \(\beta>0\). Its reliability function and hazard are:

\[
R(t)=\exp\left[-(t/\eta)^\beta\right]
\]
\[
h(t)=\frac{\beta}{\eta}(t/\eta)^{\beta-1}
\]

When \(\beta<1\), the model has a decreasing hazard; when \(\beta=1\), it reduces to the exponential model with constant hazard; when \(\beta>1\), it has an increasing hazard. The shape estimate should be interpreted in the context of the failure mechanism, sampling plan, population and uncertainty. A fitted Weibull curve does not establish a physical wear-out mechanism by itself.

### 27.1 Repairable and non-repairable populations

A non-repairable unit contributes one time-to-failure observation. A repairable system can fail repeatedly and return to service; its data are recurrent event data, not a set of independent first-failure lifetimes. For repairable systems, analysts may use rate models such as a non-homogeneous Poisson process (NHPP) when its assumptions fit the data. The power-law model often used for reliability growth has cumulative expected failures proportional to \(t^\beta\); under that model, \(\beta<1\) represents a decreasing rate, \(\beta=1\) a constant rate and \(\beta>1\) an increasing rate.

Do not pool component life data, repair events, software incidents and service requests into one failure-rate denominator. Define the system boundary, operating exposure, failure definition, repair policy and configuration before calculating a rate.

## 28. Confidence and the limits of zero-failure demonstrations

A point estimate is not a certainty statement. Small samples can produce wide confidence intervals. Under a homogeneous Poisson/exponential model, if no failures occur over total exposure \(T\), the one-sided 95% upper confidence bound for the constant failure rate is:

\[
\lambda_U=\frac{-\ln(0.05)}{T}\approx\frac{2.996}{T}
\]

This is sometimes called the “rule of three” when expressed in terms of a fixed number of independent Bernoulli trials; the exposure-time form above applies to a Poisson process. It assumes a constant rate and independent exposure. Zero observed failures do not prove zero risk.

For a reliability demonstration, specify the target reliability, confidence level, test duration or sample size, failure definition, censoring rule, operating profile, environmental conditions and acceptance rule before the test begins. Otherwise, a successful test may have little statistical power.

## 29. Context7-verified operational documentation notes

Technical operational guidance must be tied to the actual software version. For current study, use the official documentation for the pinned release rather than copying a configuration snippet from an unrelated major version.

- **PostgreSQL:** transaction isolation, MVCC, serialization failures and point-in-time recovery are documented separately. A serializable transaction may be rolled back with a serialization failure; the application must retry the transaction. See [transaction isolation](https://www.postgresql.org/docs/current/transaction-iso.html) and [backup/restore](https://www.postgresql.org/docs/current/backup.html).
- **Kubernetes:** startup probes gate the execution of liveness and readiness probes until startup succeeds. Liveness/startup failures can trigger a container restart; readiness failure marks the Pod unready and removes it from matching Service traffic. See [probe concepts](https://kubernetes.io/docs/concepts/workloads/pods/probes/).
- **OpenTelemetry:** traces, metrics and logs have distinct APIs/SDKs and lifecycle status; context propagation is the correlation mechanism across service boundaries. See [specification status](https://opentelemetry.io/docs/specs/status/) and [Collector documentation](https://opentelemetry.io/docs/collector/).

Treat these as versioned technical references. The concepts are stable enough for teaching, but command-line flags, configuration fields, semantic conventions and SDK behaviour can change.

## 30. Additional examination problems

1. Estimate an exponential failure rate from a sample containing failures and right-censored observations. Explain why censored units contribute exposure but not a failure event.
2. A Weibull fit gives \(\beta=0.7\). State what the fitted model implies about hazard shape and why it does not prove the physical mechanism.
3. Explain why repeated repair events from one server should not automatically be analysed as independent non-repairable lifetimes.
4. A test experiences zero failures over 2,000 unit-hours. Calculate the one-sided 95% upper failure-rate bound under the constant-rate Poisson model and state the assumptions.
5. Explain why a successful backup job does not demonstrate that the service meets its recovery point and recovery time objectives.


## 31. Life-data analysis with right censoring

Reliability analysis must distinguish a failure from the end of observation. A unit that is still operating when a test ends has a right-censored lifetime: the true failure time is greater than the observed time. Treating its observation time as a failure biases the estimated lifetime downward.

For observations \((t_i,\delta_i)\), where \(t_i\) is observed time and \(\delta_i=1\) indicates a failure while \(\delta_i=0\) indicates right censoring, the likelihood for a lifetime model combines density contributions for failures and survival contributions for censored units.

### 31.1 Exponential model with censoring

For an exponential lifetime with failure rate \(\lambda\), density and survival are:

\[
f(t)=\lambda e^{-\lambda t},\qquad S(t)=e^{-\lambda t}
\]

The likelihood is:

\[
L(\lambda)=\prod_i[\lambda e^{-\lambda t_i}]^{\delta_i}[e^{-\lambda t_i}]^{1-\delta_i}
=\lambda^r e^{-\lambda\sum_i t_i}
\]

where \(r=\sum_i\delta_i\) is the number of observed failures. Maximising the log-likelihood gives:

\[
\hat\lambda=\frac{r}{\sum_i t_i}
\]

The denominator includes exposure from both failed and censored units. The reciprocal \(1/\hat\lambda\) estimates the mean lifetime under the exponential model. The constant-hazard assumption is strong; use it only when the process and data support it.

### 31.2 Weibull model with right censoring

The two-parameter Weibull survival and density are:

\[
S(t)=e^{-(t/\eta)^\beta},\qquad
f(t)=\frac{\beta}{\eta}\left(\frac{t}{\eta}\right)^{\beta-1}e^{-(t/\eta)^\beta}
\]

where \(\beta>0\) is the shape and \(\eta>0\) is the scale. The hazard rate is:

\[
h(t)=\frac{\beta}{\eta}\left(\frac{t}{\eta}\right)^{\beta-1}
\]

Thus \(\beta<1\) corresponds to decreasing hazard, \(\beta=1\) to constant hazard (the exponential model), and \(\beta>1\) to increasing hazard. These interpretations apply to the assumed population and operating conditions; they do not automatically identify a physical failure mechanism.

For right-censored data, the log-likelihood is:

\[
\ell(\beta,\eta)=\sum_i\delta_i\left[\ln\beta-\beta\ln\eta+(\beta-1)\ln t_i\right]-\sum_i\left(\frac{t_i}{\eta}\right)^\beta
\]

For a fixed \(\beta\), the maximum-likelihood scale estimate is:

\[
\hat\eta(\beta)=\left(\frac{\sum_i t_i^\beta}{r}\right)^{1/\beta}
\]

The shape is found numerically by solving the profile score equation. This requires positive observation times and at least one observed failure. A numerical optimizer may fail or return an extreme shape when the data contain little information; convergence is not a guarantee that the model is appropriate. Inspect the log-likelihood, parameter bounds, fitted survival curve and sensitivity to individual observations.

### 31.3 Estimation versus inference

A maximum-likelihood point estimate is not a confidence interval. A complete analysis should report uncertainty using a justified method, such as a profile-likelihood interval or a bootstrap whose sampling assumptions match the test design. With few failures, intervals can be wide and asymmetric. A zero-failure demonstration test may still provide information about a failure-rate upper bound, but its conclusion depends on confidence level, exposure model and independence assumptions.

## 32. Repairable systems and recurrent-event data

A component that is repaired and returned to service produces recurrent event data, not a single lifetime sample. Summing operating time and failures can estimate an aggregate rate under a homogeneous Poisson process, but it can conceal trend, heterogeneity and repair effectiveness. Distinguish:

- **Renewal process:** after each repair, the item is effectively “as good as new”; inter-failure times are modelled as independent draws from a lifetime distribution.
- **Minimal repair / non-homogeneous Poisson process:** the system returns to the same effective age after repair; the rate may depend on calendar or operating time.
- **Imperfect repair:** the repair changes effective age or condition but does not fully restore or leave it unchanged.

The model must match the maintenance policy and physical process. For a fleet of repairable assets, record exposure, downtime, repair type, operating environment, configuration and maintenance history. Pooling unlike items can create a misleading average rate.

## 33. Competing risks and accelerated life testing

A unit may fail from several mutually exclusive causes, such as bearing wear, electrical fault or corrosion. The observed time is the minimum of the latent cause-specific failure times. Cause-specific hazards describe instantaneous risk among units still surviving; cumulative incidence describes the probability of an observed cause by a time point. Simply fitting separate uncensored lifetime distributions to each cause can be biased because other causes remove units from observation.

Accelerated life testing increases stress to obtain information in less time. It requires an acceleration model that connects stress to failure-time behaviour and assumes that the dominant failure mechanism does not change across the tested stress range. Extrapolation beyond the observed stress region is model-dependent. State stress factors, censoring plan, sample allocation, failure analysis, measurement system and model validation evidence.

## 34. Minimum statistical reporting standard

A defensible reliability report should state:

- unit of analysis and population definition;
- time/exposure definition and observation window;
- event definition and censoring mechanism;
- failure counts and censored counts;
- model family and assumptions;
- parameter estimates and uncertainty intervals;
- goodness-of-fit and diagnostic checks;
- treatment of repairs, competing causes and heterogeneity;
- mission time and the reliability/availability measure being estimated;
- sensitivity, limitations and intended decision.

Do not report a Weibull shape as a material property. It is a parameter estimated for a defined population and test condition. Do not infer a maintenance interval solely from a point estimate; incorporate consequences, confidence, repair logistics, inspection effectiveness and the cost of false alarms or missed failures.

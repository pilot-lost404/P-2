# Engineering Systems and Software Architecture — University-Style Independent Self-Study Programme

This package is designed as a **structured, university-style independent self-study programme** with original teaching texts, assessments, design studios and executable practicals. The six primary course texts teach the subject matter directly. The external resource library is supplementary: it gives you textbooks, full university courses, lectures, documentation, papers and tools for deeper study.

This is an independent educational programme, not an accredited qualification and not an official course issued by MIT, NASA, CMU, Google or any other institution.

## Start here

1. Read [00 — Master Course](00-MASTER-COURSE.md) for programme outcomes, prerequisites, assessment expectations and the integrated capstone.
2. Study the six course texts in order. Work through their equations, diagrams, examples and problem sets.
3. Use the [Laboratory Manual](08-LABS-AND-CAPSTONE.md) to create engineering artefacts and test your understanding.
4. Follow the [78-Week Study Plan](09-STUDY-PLAN.md) for a structured sequence.
5. Solve the [Advanced Problem Sets and Worked Solutions](11-ADVANCED-PROBLEM-SETS-AND-WORKED-SOLUTIONS.md) after the course-text problem sets.
6. Use the [Resource Library](07-RESOURCE-LIBRARY.md) to deepen or cross-check individual subjects.
7. Read the [Research Notes](10-RESEARCH-NOTES.md) for source provenance, licensing and research limitations.

## The six primary course texts

| Course | Teaching material | Main coverage |
|---|---|---|
| I | [Systems Thinking and System Dynamics](01-systems-thinking-fundamentals.md) | Boundaries, feedback, stocks/flows, delays, archetypes, simulation, model testing and policy resistance |
| II | [Systems Engineering Fundamentals](02-systems-engineering-fundamentals.md) | Lifecycle, stakeholders, ConOps, functional architecture, interfaces, trade studies, MBSE, risk, integration and V&V |
| III | [Requirements Engineering](03-requirements-engineering.md) | Elicitation, modelling, specification, quality, quality attributes, acceptance, traceability, baselines and change |
| IV | [Software System Design and Distributed Systems](04-software-system-design-fundamentals.md) | Workloads, APIs, data, transactions, storage, queues, replication, consistency, consensus, failures and observability |
| V | [Software Architecture and Trade-off Analysis](05-architecture-and-trade-off-analysis.md) | Drivers, quality scenarios, styles, tactics, views, ADD, ADRs, ATAM/CBAM, fitness functions and evolution |
| VI | [Reliability Engineering, SRE and Incident Response](06-reliability-and-incident-response.md) | Probability, Weibull, availability, RBD, FMEA/FTA, FRACAS, SLOs, telemetry, incidents, postmortems and recovery |

## What makes this a course rather than a link list

Each primary text contains a course description, prerequisites, learning outcomes, a sequenced lecture plan, explanatory sections, formal models or equations where appropriate, worked examples, an integrated case, problem sets with solution guidance, practical assignments and references. The Lab Manual defines a sequence of 17 practical exercises that build toward one integrated capstone. The assessment bank adds six sample 100-mark examinations, keyed solutions, project rubrics and oral-defence criteria.

The six courses target advanced-undergraduate to introductory-graduate independent study. The programme is not an accredited qualification, degree, university module or substitute for supervised research and formal assessment. The recommended pace is 13 weeks per course (78 weeks overall), normally 8–12 hours per week. This is a demanding self-study programme; adjust the pace rather than skipping problem solving and practical work.

## Course files and companions

- [00 — Master Course](00-MASTER-COURSE.md)
- [07 — Resource Library](07-RESOURCE-LIBRARY.md)
- [08 — Laboratory Manual and Capstone](08-LABS-AND-CAPSTONE.md)
- [09 — 78-Week Study Plan](09-STUDY-PLAN.md)
- [10 — Research Notes and Provenance](10-RESEARCH-NOTES.md)
- [11 — Advanced Problem Sets and Worked Solutions](11-ADVANCED-PROBLEM-SETS-AND-WORKED-SOLUTIONS.md)
- [12 — Academic Quality Audit and Revision Record](12-ACADEMIC-AUDIT.md)
- [13 — University-Style Assessment Bank and Marking Guide](13-UNIVERSITY-ASSESSMENTS.md)
- [14 — Self-Study Learner Handbook](14-SELF-STUDY-LEARNER-HANDBOOK.md)
- [15 — CLO-to-Assessment Traceability Matrix](15-CLO-ASSESSMENT-TRACEABILITY.md)
- [16 — Lab Environment and Reproducibility](16-LAB-ENVIRONMENT-AND-REPRODUCIBILITY.md)
- [17 — Worked Examples and Reference Solutions](17-WORKED-EXAMPLES-AND-REFERENCE-SOLUTIONS.md)
- [18 — Upgrade Quality and Verification Report](18-UPGRADE-QUALITY-AND-VERIFICATION-REPORT.md)

## How to study

For each lecture topic, read the primary text, recreate key diagrams, derive equations without copying, complete the worked examples independently, and then solve the problem set. For modelling and design tasks, preserve editable source files and record assumptions, units, evidence and limitations. Do not submit a diagram or an architecture choice without explaining why it is correct for the stated context.

Use the external university courses for alternate explanations and additional exercises. The course text remains the core syllabus so that you are not forced to jump randomly between websites.

## Source and licensing policy

The course draws on university open-courseware, NASA and professional handbooks, published research, standards catalogues, publisher textbooks, official technical documentation and practitioner material. Resources are marked as free/open, free course material, online reading, library/paywalled or outline-only where known. A free-to-read page is not automatically licensed for redistribution.

FMHY was inspected as a discovery index. Legitimate educational entries are referenced where useful; torrent, unauthorised course-copy and access-bypass links are excluded. The course texts are original explanations and exercises, not copies of copyrighted textbook chapters or third-party slides.

See [Research Notes](10-RESEARCH-NOTES.md) for the Exa → Firecrawl → TinyFish research process, Context7 documentation checks and scope limitations.


## Academic quality and assessment

- [Academic audit and revision record](12-ACADEMIC-AUDIT.md)
- [University-style assessment bank](13-UNIVERSITY-ASSESSMENTS.md)

The 78-week plan is the full route. The separate 24-week roadmap is a compressed survey only; it is not equivalent to completing the full course sequence.


## Practical work

The package contains six runnable, standard-library practicals spanning system dynamics, engineering decision analysis, requirements review, Go concurrency/API design, architecture fitness functions and reliability statistics. The other numbered laboratories are accurately labelled design or analysis studios. All practicals state their commands, test oracles and epistemic limits.

# Course I — Systems Thinking and System Dynamics

**Academic level:** Upper-division undergraduate / introductory graduate  
**Suggested duration:** 13 teaching weeks  
**Prerequisites:** Algebra, functions and graphs; introductory probability is helpful but not required  
**Core question:** Why do complex systems produce the behaviour they do, and how can we intervene without creating worse problems elsewhere?

---

## Course description

Systems thinking is a way of explaining behaviour by studying relationships, structure, feedback, accumulation and delay rather than treating events as isolated incidents. System dynamics turns that perspective into an explicit modelling discipline. It represents the important stocks in a system, the flows that change them, the feedback structures that influence those flows, and the delays through which interventions take effect.

This course progresses from qualitative reasoning to quantitative models. It is not a course in drawing attractive causal-loop diagrams. A diagram is useful only when it expresses a defensible causal hypothesis. A model is useful only when its structure and behaviour have been tested against evidence and when its limitations are visible.

The recurring case is a technical-support organisation whose ticket backlog keeps growing despite repeated attempts to increase productivity. The same methods can be applied to public policy, healthcare, supply chains, software delivery, energy, education and environmental management.

## Learning outcomes

By the end of the course, a student should be able to:

1. Define a system boundary and justify which variables, actors and processes belong inside or outside it.
2. Distinguish an event, a behavioural pattern and the underlying structure that generates the pattern.
3. Construct and critique causal-loop diagrams, identifying reinforcing and balancing feedback and explaining link polarity.
4. Represent accumulation using stocks, inflows and outflows, and translate a stock-flow diagram into equations.
5. Explain how delays, nonlinear relationships, capacity constraints and information quality affect system behaviour.
6. Recognise common system archetypes without using them as substitutes for causal analysis.
7. Formulate a dynamic hypothesis, choose a model boundary, estimate parameters and test a simulation model.
8. Compare interventions using leverage, side effects, implementation delays, distributional impact and robustness.
9. Communicate uncertainty and model limitations without presenting a simulation as a prediction with false precision.

## Lecture sequence

| Lecture | Topic | Required output |
|---:|---|---|
| 1 | Systems, emergence and complexity | A boundary statement and stakeholder map |
| 2 | Events, patterns and reference modes | A behaviour-over-time graph |
| 3 | Causal reasoning and feedback | A causal-loop diagram with loop explanations |
| 4 | Stocks, flows and accumulation | A stock-flow diagram and units table |
| 5 | Delays, nonlinearities and oscillation | A delay analysis and qualitative behaviour hypothesis |
| 6 | System archetypes and policy resistance | A causal explanation of a recurring failure |
| 7 | Model formulation and boundary adequacy | A model-purpose statement and boundary critique |
| 8 | Equations, parameters and dimensional consistency | A working set of stock-flow equations |
| 9 | Model testing and validation | A documented test suite for a model |
| 10 | Policy design, leverage and unintended consequences | A comparison of two interventions |
| 11 | Simulation methods and model classes | A justified choice of modelling approach |
| 12 | Integrated case study and model defence | A written model report and oral defence |

---

# Part I — Foundations

## 1. A system is more than a collection of parts

A system is a set of elements connected by relationships that produce a behaviour or purpose. The elements alone do not explain the system. The arrangement of relationships matters. A queue of tickets, a team of engineers, an escalation policy and a service-level target form a system because each affects the others and together they generate an observable pattern of work and service quality.

A useful first distinction is between **composition** and **organisation**. Composition asks what entities exist. Organisation asks how they are connected, what information they exchange, and what rules govern their interactions. Two teams with the same headcount and tools can behave differently because their incentives, workload allocation, communication paths and feedback differ.

Systems may be described as open or closed relative to a chosen boundary. An open system exchanges material, energy, information or people with its environment. Most organisations and software services are open systems: users arrive, data enters, infrastructure fails, budgets change and regulators impose constraints. A perfectly closed model is usually an analytical simplification, not a literal description of reality.

### 1.1 System, subsystem and environment

A system boundary is an analytical decision. It identifies what the model will explain and what it will treat as an input or external condition. A campus equipment platform might include users, staff, equipment, inventory records, reservations, maintenance and notification services. It might treat the university's identity provider and payment service as external systems while explicitly modelling their failure rates and response times.

The boundary should follow the purpose of the investigation. If the question concerns queue growth, excluding staff fatigue may produce an incomplete explanation even though fatigue is difficult to measure. If the question concerns database query latency, modelling the institution's procurement process may add no useful explanatory power.

A boundary statement should name:

- the behaviour or decision being investigated;
- the time horizon;
- the geographic, organisational or technical scope;
- the important actors and processes inside the boundary;
- important external variables and assumptions;
- what is deliberately excluded and why.

A boundary is not an excuse to ignore inconvenient variables. Perform a boundary critique: ask whose outcomes are represented, whose costs are invisible, which externalities are omitted and which assumptions would change the conclusion.

### 1.2 Emergence and levels of explanation

Emergent behaviour is a system-level pattern produced by interactions among components. No single support engineer creates the backlog. The backlog emerges from the interaction of arrival rates, resolution capacity, ticket complexity, reopening, prioritisation and feedback about work quality.

An explanation at the component level may be accurate but incomplete. For example, an engineer may resolve fewer tickets after an increase in interruptions. The system-level explanation asks why interruption load increased, whether work assignment encourages context switching, and whether the metric used to evaluate performance creates the interruption pattern.

Complexity can be distinguished in several ways:

- **Complicated systems** have many components but can often be decomposed and analysed with stable interfaces and relatively predictable interactions.
- **Complex adaptive systems** contain interacting agents that adapt, learn and change their behaviour in response to other agents and to the system itself.
- **Dynamic complexity** arises when effects are delayed, nonlinear, counterintuitive or generated through feedback. A system can be physically simple and dynamically complex.

The distinction is practical. A complicated machine may be understood through decomposition and component testing. An adaptive organisation may require experimentation, monitoring, stakeholder analysis and policies that remain robust as behaviour changes.

## 2. Events, patterns and structure

A common analytical mistake is to respond to an event without studying the pattern that preceded it. A single service outage may be an event. A quarterly increase in outages is a pattern. A capacity-management process that reacts late to demand growth may be the structure generating that pattern.

Systems analysis therefore begins with **behaviour over time**. A reference mode is a graph or set of graphs describing how important variables have behaved historically and how stakeholders believe they should behave in the future. It should be measured where possible and explicitly marked as qualitative where measurement is unavailable.

For a service-desk backlog, plot at least:

1. open tickets;
2. incoming tickets per day;
3. resolved tickets per day;
4. reopened tickets per day;
5. average and high-percentile time to resolution;
6. staffing or effective resolution capacity.

Do not plot only the metric that triggered the investigation. A falling mean resolution time can coexist with a growing backlog if easy tickets are handled first while difficult cases age. Separate aggregate measures can conceal distributional effects.

A good reference mode specifies the time range, frequency, units, source, missing-data treatment and any policy or organisational changes that occurred during the period. It also distinguishes observed history from a target or forecast.

## 3. Feedback and causal structure

A feedback loop exists when a change in one variable eventually influences itself through a chain of causal relationships. The chain may contain several intermediate variables and delays.

A causal-loop diagram (CLD) is a qualitative map of such hypotheses. Variables are connected by directed causal links. Each link is assigned a polarity:

- A **positive link (+)** means that, other things being equal, a change in the cause produces a change in the same direction in the effect.
- A **negative link (−)** means that, other things being equal, a change in the cause produces a change in the opposite direction in the effect.

Polarity is not a moral judgment and does not indicate whether an effect is good or bad. A positive link can connect more fatigue to more errors; a negative link can connect a larger backlog to lower customer satisfaction. The sign describes the direction of causal influence, not desirability.

### 3.1 How to determine link polarity

Use a disciplined counterfactual test: suppose the cause increased while other relevant influences were held constant. Would the effect tend to increase or decrease? State the mechanism. If the answer depends on conditions, split the variable or qualify the relationship.

For example:

- More incoming tickets → more open tickets: positive, assuming resolution capacity does not change simultaneously.
- More open tickets → greater average waiting time: generally positive, under a fixed or slowly changing service capacity.
- Greater waiting time → more customer follow-up messages: positive, if users respond to delay by asking for updates.
- More follow-up messages → less time available for resolution: negative with respect to effective capacity.

The last two links produce a reinforcing deterioration loop: delay creates additional communication work, which reduces resolution capacity and creates more delay.

### 3.2 Reinforcing and balancing loops

A reinforcing loop amplifies an initial change. It may create growth or decline. A balancing loop counteracts change and tends to move a variable toward a goal, constraint or equilibrium. The presence of a balancing loop does not guarantee stability: delays, aggressive correction or nonlinear response can produce oscillation or overshoot.

Consider an inventory replenishment loop. A fall in stock increases the gap between actual and desired stock. The gap increases purchase orders, and arriving deliveries increase stock. This is balancing feedback. If order review and shipping take several weeks, the system may continue ordering after the shortage has already been corrected, creating excess inventory.

A loop's overall polarity is obtained by multiplying its link signs. An even number of negative links yields a reinforcing loop; an odd number yields a balancing loop. This is a useful structural check, but loop labels alone do not determine the system's behaviour. Multiple loops interact, and dominance changes over time.

### 3.3 CLD quality criteria

A technically useful CLD should:

- use variables rather than vague actions or entire systems as nodes;
- identify the causal mechanism behind each important link;
- name feedback loops and explain their operation in words;
- show important delays;
- distinguish variables that are conceptually different, such as demand and workload;
- use a clear boundary and avoid a diagram so dense that it cannot be inspected;
- identify evidence or assumptions supporting important relationships.

CLDs are not automatically quantitative models. A CLD does not specify units, parameter values or exact functional forms. It is a hypothesis about causal structure that guides further investigation.

## 4. Stocks and flows: the mathematics of accumulation

A **stock** is an accumulation at a point in time. Examples include open tickets, cash, inventory, active users, technical debt, employees, energy stored in a battery and unrepaired defects. A **flow** is a rate that changes a stock. Inflow adds to a stock; outflow removes from it.

The fundamental stock equation is:

\[
S(t)=S(t_0)+\int_{t_0}^{t}\big(I(\tau)-O(\tau)\big)\,d\tau
\]

where \(S\) is the stock, \(I\) is the inflow and \(O\) is the outflow. In a discrete simulation with time step \(\Delta t\):

\[
S_{t+1}=S_t+(I_t-O_t)\Delta t
\]

This is a conservation relationship. A stock cannot change unless one or more flows cross its boundary, or the model explicitly includes a reclassification or adjustment flow.

### 4.1 Units are a structural test

If the stock is measured in tickets and the flow in tickets per day, multiplying the flow by a time interval in days produces tickets. A model that adds tickets to tickets per day is dimensionally invalid.

| Quantity | Variable | Unit |
|---|---|---|
| Open tickets | \(B\) | tickets |
| New tickets | \(A\) | tickets/day |
| Resolved tickets | \(R\) | tickets/day |
| Reopened tickets | \(Q\) | tickets/day |
| Time step | \(\Delta t\) | days |

The backlog equation is:

\[
B_{t+1}=B_t+(A_t+Q_t-R_t)\Delta t
\]

A negative backlog is not a meaningful physical state. A model should constrain resolution so that it cannot resolve more tickets than are available, or it should represent the outflow using an explicit capacity and stock limitation.

### 4.2 Worked example: a ticket backlog

Suppose a support team begins with 200 open tickets. It receives 30 new tickets per day and initially resolves 25 per day. Assume no reopening for this first calculation.

The net accumulation rate is:

\[
30-25=5\text{ tickets/day}
\]

After 20 days, if both rates remain constant, the backlog is:

\[
B(20)=200+5(20)=300\text{ tickets}
\]

This calculation is simple, but its assumptions matter: ticket arrivals and resolution are constant, there is no variation in complexity, no ticket is reopened, and capacity does not respond to workload. A model that stops here is an arithmetic projection, not a dynamic explanation.

Now suppose effective resolution capacity depends on fatigue. As the backlog grows, staff work overtime. Overtime temporarily increases completed tickets but also increases fatigue. Fatigue reduces the quality of resolutions and increases rework. Reopened tickets then return to the backlog. A short-term productivity intervention can therefore worsen long-run throughput.

A richer model might contain four stocks: backlog, accumulated fatigue, staff experience and unresolved technical debt. Each stock requires explicit inflows and outflows. This avoids treating concepts that accumulate over time as instantaneous variables.

## 5. Delays and nonlinear relationships

A delay is the time between an action and its consequence. Delays can occur in material movement, information, decision approval, skill acquisition, hiring, software delivery and human learning. They are not merely inconvenient; they can change the qualitative behaviour of a system.

A first-order adjustment process can be represented as:

\[
\frac{dX}{dt}=\frac{X^*-X}{T}
\]

where \(X^*\) is the desired value and \(T\) is the adjustment time. A small \(T\) means rapid adjustment; a large \(T\) means slow adjustment. If a policy-maker observes a gap and adjusts aggressively while effects are delayed, overcorrection is possible.

A nonlinear relationship means the effect of a variable depends on its level or on other conditions. Examples include congestion, network effects, learning curves, threshold effects, saturation and capacity limits. A service that performs acceptably at 40% utilisation may experience rapidly increasing queueing delay as utilisation approaches 100%.

For an idealised M/M/1 queue, expected time in the system is:

\[
W=\frac{1}{\mu-\lambda},\qquad \lambda<\mu
\]

where \(\lambda\) is the arrival rate and \(\mu\) the service rate. The formula assumes Poisson arrivals, exponential service times, one server and a stable queue. It is not a universal law for all operations, but it demonstrates a critical nonlinear effect: as arrival rate approaches service rate, expected waiting time increases sharply.

For \(\lambda=8\) jobs/hour and \(\mu=10\) jobs/hour, the mean time in the system is 0.5 hours. If arrival rate rises to 9.5 jobs/hour while capacity remains fixed, mean time becomes 2 hours. A 18.75% increase in arrival rate has produced a 300% increase in mean time under this model. This is why operating close to nominal capacity can create fragility.

## 6. System archetypes and policy resistance

Archetypes are recurring feedback structures. They are useful as pattern-recognition aids, not as templates to paste onto every problem.

### 6.1 Limits to growth

A reinforcing process drives growth until a balancing constraint becomes dominant. For example, a successful product increases users, but support capacity, onboarding quality or infrastructure limits eventually constrain growth. A policy that strengthens the growth loop without addressing the constraint may create deteriorating service.

### 6.2 Fixes that fail

A symptomatic fix improves a measure in the short term but creates a delayed side effect that worsens the original problem. Overtime can reduce a queue today while increasing fatigue and errors next month. The analyst should identify the balancing or reinforcing loop that creates the delayed reversal.

### 6.3 Shifting the burden

A quick intervention reduces pressure to address the underlying cause. Repeated manual restarts may restore a service but reduce incentives to fix the memory leak that causes the crash. The quick fix becomes institutionalised and can weaken long-term capability.

### 6.4 Success to the successful

Two competing activities share a limited resource. Early advantage attracts more resources, which improves subsequent performance and attracts even more resources. In a project portfolio, one successful team may receive disproportionate staffing, leaving other teams unable to demonstrate their potential.

### 6.5 Tragedy of the commons

Individually rational users draw from a shared resource, creating collective depletion. Shared compute capacity, common test environments and public infrastructure can exhibit this pattern. Governance, capacity rules and incentives must account for aggregate effects.

## 7. A disciplined modelling process

A system dynamics model is an explicit representation built to answer a defined question. It is not a complete replica of reality. The purpose controls the boundary, detail, time horizon and required precision.

A robust process is:

1. **Define the problem.** Specify the behaviour to explain, the decision it informs and why the problem matters.
2. **Develop reference modes.** Plot historical behaviour and identify important patterns, including variation across groups.
3. **Form a dynamic hypothesis.** Explain the likely feedback and accumulation structure that could generate the observed behaviour.
4. **Choose a model boundary.** Include structures necessary to explain the behaviour; represent excluded influences as explicit assumptions or inputs.
5. **Build a causal structure.** Start with a CLD and then translate important accumulations into stocks and flows.
6. **Formulate equations.** Specify units, initial conditions, parameter values, nonlinear relationships and delay structures.
7. **Test the model.** Check structure, equations, behaviour, sensitivity and boundary adequacy.
8. **Explore policies.** Compare interventions over time, under uncertainty and across affected stakeholders.
9. **Communicate limitations.** State what the model can and cannot support.

### 7.1 Model testing and validation

Validation is not a single statistical score. It is an argument that the model is adequate for a particular purpose. Useful tests include:

- **Dimensional consistency:** equations use compatible units.
- **Boundary adequacy:** important causes are not excluded without justification.
- **Extreme-condition tests:** the model behaves sensibly under zero demand, very high demand, no capacity or very long delays.
- **Behaviour reproduction:** model behaviour resembles important historical patterns within a defensible tolerance.
- **Sensitivity analysis:** conclusions are not driven by one implausible parameter choice.
- **Parameter plausibility:** initial values and rates are grounded in data or explicitly elicited estimates.
- **Structure verification:** equations implement the intended causal hypothesis.
- **Policy robustness:** a preferred policy remains acceptable under plausible changes in uncertain parameters and external conditions.

A model can reproduce past data and still be structurally wrong. Different structures may fit the same historical series. A model should therefore be challenged using independent evidence, mechanism-based tests and stakeholder review.

### 7.2 Calibration and overfitting

Calibration adjusts parameter values to improve agreement between simulated and observed behaviour. It does not prove that the model is correct. If too many parameters are adjusted to fit a short time series, the model can overfit. Reserve a period or dataset for out-of-sample testing when enough data exists. Where data is limited, report ranges, sensitivity and expert assumptions rather than presenting a single precise result.

## 8. Choosing a modelling approach

System dynamics is well suited to questions about feedback, accumulation, policy and behaviour over time. Other modelling traditions may be more appropriate for different questions:

- **Discrete-event simulation** represents entities moving through queues and resource-constrained processes. It is useful for detailed operational questions such as call-centre staffing or hospital patient flow.
- **Agent-based modelling** represents individual agents with rules and interactions. It is useful when heterogeneity, adaptation and local interaction generate aggregate patterns.
- **Markov models** describe transitions among states under probabilistic assumptions.
- **Optimisation models** choose decisions that maximise or minimise an objective subject to constraints.
- **Causal inference** estimates effects of interventions from data under explicit identification assumptions. A simulation model alone does not establish causal effects empirically.

Hybrid models are possible, but complexity should be justified by the decision being supported. A simpler model with transparent assumptions is often more useful than a sophisticated model that cannot be explained or tested.

## 9. Integrated case study: why does the service backlog keep returning?

### 9.1 Problem definition

A university IT service desk reports that open tickets rise during each term. Management has hired temporary staff and introduced overtime, yet the backlog returns. Average time to first response improves, while time to final resolution for complex cases deteriorates.

The investigation asks: **Which feedback mechanisms sustain backlog growth, and which intervention is robust over a full academic year?**

### 9.2 Candidate structure

The model includes:

- backlog (stock);
- arrivals (inflow);
- completed tickets (outflow);
- reopened tickets (return flow);
- effective capacity;
- fatigue;
- staff experience;
- complexity mix;
- interruptions and status enquiries.

A dynamic hypothesis is that overtime initially increases completed tickets, but fatigue later increases errors and reopens. A second loop is that the backlog increases customer enquiries, which create interruptions, which reduce effective capacity. A balancing loop is that management recruits staff, but hiring and training are delayed.

### 9.3 Minimal equations

A deliberately simplified continuous-time model could use:

\[
\frac{dB}{dt}=A+Q-R
\]

\[
R=\min\left(B,\ C_0\cdot E\cdot (1-f)\right)
\]

\[
\frac{df}{dt}=\alpha\,OT-\beta f
\]

where \(B\) is backlog, \(A\) arrivals, \(Q\) reopened tickets, \(R\) completed tickets, \(C_0\) baseline capacity, \(E\) an experience/efficiency multiplier, \(f\) fatigue scaled from zero to one, \(OT\) overtime intensity, and \(\alpha,\beta\) are illustrative fatigue accumulation and recovery parameters. The equations are illustrative; a real model requires empirically defined units, parameterisation and testing.

A reopening function might depend on fatigue, ticket complexity and quality controls. A recruitment function might respond to a perceived backlog gap through a delayed adjustment process. The model should not imply that every ticket is identical if complexity is a dominant determinant of work.

### 9.4 Compare policies

Compare at least four policies:

1. increase overtime;
2. add temporary staff;
3. reduce ticket arrivals by fixing recurring root causes;
4. improve first-time resolution through training, knowledge management and quality review.

Evaluate total backlog, long-tail ticket age, service quality, staff fatigue, cost, equity across ticket categories and resilience under demand spikes. Do not select a policy solely because it minimises the average backlog in one baseline scenario.

### 9.5 What the case teaches

A local productivity target can degrade system throughput. Capacity is not only headcount multiplied by a nominal rate: it depends on skill, workload mix, interruptions, fatigue, tooling and rework. The best intervention may reduce demand or improve first-time resolution rather than simply increasing activity.

## 10. Problem set

### Problems

**1. Boundary critique.** Define a system boundary for investigating the increase in student assignment extensions. Identify five internal variables, three external variables and two stakeholders whose outcomes may not be represented in a university-wide average.

**2. Loop polarity.** Consider: higher backlog increases waiting time; greater waiting time increases customer follow-up messages; follow-up messages increase interruption load; interruption load reduces effective resolution capacity; lower capacity increases backlog. Determine the loop polarity and explain each causal link.

**3. Stock-flow calculation.** A warehouse begins with 1,200 units. Daily deliveries are 90 units, sales are 75 units and damaged units are 3 units. Calculate inventory after 10 days under constant flows. State two reasons the constant-flow assumption may be invalid.

**4. Queueing nonlinearity.** For an M/M/1 queue, calculate expected time in the system for \(\lambda=6\), \(\mu=8\) jobs/hour and then for \(\lambda=7.5\), \(\mu=8\). Explain why the result matters for capacity planning.

**5. Model testing.** Propose an extreme-condition test, a dimensional test and a sensitivity test for a model of software defect accumulation.

**6. Policy resistance.** Explain how a policy to reduce mean resolution time might increase the number of unresolved high-severity tickets.

### Solution sketches

**1.** A defensible boundary might include assignment load, student capacity, instructor marking capacity, extension policy, course timetable and support processes. External variables could include employment hours, illness or transport disruption. Stakeholders include students with caring responsibilities, instructors and academic administrators. Explain why each is inside or outside the boundary; another boundary can be defensible if it matches the question.

**2.** The first three links are positive. The link from interruption load to effective capacity is negative, and the link from capacity to backlog is also negative. Two negative links make the product of signs positive, so the loop is reinforcing: a larger backlog creates more follow-up work, which reduces effective capacity and further increases backlog. Delays can intensify the deterioration or make later corrective policies overshoot; they do not change the loop polarity.

**3.** Net daily accumulation is \(90-75-3=12\) units/day. After 10 days: \(1,200+12(10)=1,320\) units. Demand and damage rates may vary with season, price, storage conditions or stockout effects; deliveries may be scheduled in batches.

**4.** At 6 arrivals/hour, \(W=1/(8-6)=0.5\) hour. At 7.5 arrivals/hour, \(W=1/(8-7.5)=2\) hours. The system becomes highly sensitive as utilisation approaches capacity. This simplified result depends on M/M/1 assumptions and should not be treated as a precise forecast for a complex service process.

**5.** Extreme condition: set defect arrivals to zero and verify the defect stock cannot increase. Dimensional test: defects/day minus defects/day must produce a rate consistent with defects. Sensitivity: vary defect discovery delay and repair capacity over plausible ranges and inspect whether intervention rankings change.

**6.** A target may encourage closing simple tickets quickly, deferring difficult issues, splitting tickets or recording premature closure. The mean can improve while the tail worsens. Separate measures by severity and age, and inspect reopening and user outcomes.

## 11. Practical assignment

Build a system-dynamics model of a growing technical debt backlog. Required deliverables:

1. a problem statement and model purpose;
2. a behaviour-over-time reference mode, with assumed or observed data clearly marked;
3. a CLD with at least two reinforcing and two balancing loops;
4. a stock-flow model with no fewer than three stocks;
5. a units table, initial conditions and parameter register;
6. extreme-condition, dimensional and sensitivity tests;
7. policy comparison with uncertainty analysis;
8. a 1,500–2,000 word report discussing boundary limitations and unintended consequences.

## 12. Examination review

Be able to derive a stock equation from a diagram, explain link polarity, distinguish a reinforcing loop from a balancing loop, describe the effect of delay, identify an archetype from its causal structure, justify a model boundary, and explain why historical fit is not sufficient evidence of model validity.

## Further reading and primary course materials

- John D. Sterman, *Business Dynamics: Systems Thinking and Modeling for a Complex World* (2000). Advanced reference text; consult a university library or publisher.
- Donella H. Meadows, *Thinking in Systems: A Primer* (2008). Accessible conceptual foundation.
- MIT OCW, [15.871 Introduction to System Dynamics](https://ocw.mit.edu/courses/15-871-introduction-to-system-dynamics-fall-2013/): course material, assignments and cases.
- MIT OCW, [15.879 Building Serious System Dynamics Models from Scratch](https://ocw.mit.edu/courses/15-879-building-serious-system-dynamics-models-from-scratch-spring-2025/): advanced model-building lectures, notes and programming assignments.
- System Dynamics Society, [Learning Road Maps](https://systemdynamics.org/learning/road-maps/): staged modelling exercises.
- [Insight Maker](https://insightmaker.com/): browser-based model construction and simulation.
- [SEBoK](https://sebokwiki.org/): systems science and systems engineering context.


---

# Advanced lecture notes and worked extensions

## 13. Dynamic hypotheses, feedback dominance and mathematical behaviour

A causal loop diagram identifies plausible feedback structure, but it does not by itself determine how a system behaves. Behaviour emerges from the combined influence of loops, stock accumulation, delays, nonlinearities, initial conditions and external inputs. A model may contain two reinforcing loops and one balancing loop; which loop dominates can change as the state of the system changes.

### 13.1 A reinforcing growth structure

Consider a population of active users of a service. New users arrive through a word-of-mouth mechanism proportional to the existing user base, while users leave through churn. A simple model is:

\[
\frac{dU}{dt}=aU-cU=(a-c)U
\]

where \(U\) is the active user stock, \(a\) is the adoption rate and \(c\) is the churn rate. If \(a>c\), the stock grows exponentially; if \(a<c\), it decays exponentially. This is a first-order reinforcing structure with a balancing outflow.

The model is intentionally simplistic. It assumes a constant adoption and churn rate and unlimited market capacity. It cannot explain saturation or competition. Adding a carrying capacity \(K\) changes the adoption structure:

\[
\frac{dU}{dt}=rU\left(1-\frac{U}{K}\right)-cU
\]

The term \(1-U/K\) represents a simple capacity effect. As the population approaches \(K\), the growth contribution decreases. The equilibrium depends on the relationship between growth, capacity and churn. A logistic curve is not automatically appropriate for every adoption process; it is an assumed functional form that should be tested.

### 13.2 A service backlog with capacity feedback

A more useful technical support model distinguishes the ticket stock from the capacity that determines the outflow. Let:

\[
\frac{dB}{dt}=A-R
\]

\[
R=\min\left(B,\ C\right)
\]

where \(B\) is the backlog, \(A\) is the arrival rate and \(C\) is effective resolution capacity. If capacity is fixed, the backlog grows whenever average arrivals exceed capacity. But in a real organisation, capacity responds to backlog, hiring, overtime, experience, rework and fatigue.

A simple delayed hiring response can be represented as:

\[
\frac{dC}{dt}=\frac{C^*-C}{T_C}
\]

\[
C^*=C_0+k\max(0,B-B^*)
\]

where \(C^*\) is the desired capacity, \(B^*\) is the target backlog, \(k\) determines the response to excess backlog and \(T_C\) is the capacity adjustment time. The formulation represents management eventually increasing capacity when backlog exceeds a target. It is not yet a complete staffing model: recruitment and training delay the point at which additional headcount becomes productive.

To represent fatigue, define a fatigue stock \(F\) with accumulation from overtime and recovery when workload normalises:

\[
\frac{dF}{dt}=\alpha OT-\beta F
\]

where \(OT\) is overtime intensity, and \(\alpha,\beta\) are parameters with compatible units. Let effective capacity fall with fatigue:

\[
C_{effective}=C_{nominal}(1-\gamma F)
\]

for a bounded fatigue variable and a parameter \(\gamma\) chosen so capacity remains physically meaningful. This creates a delayed balancing response through hiring and a reinforcing deterioration mechanism through fatigue and rework. Students should test whether the chosen functional form behaves sensibly at extreme values.

### 13.3 Oscillation and overcorrection

Oscillation can occur when a controller reacts to a measured gap, but the system takes time to respond. A team sees the backlog rising and orders more staff. During the hiring and training delay, the backlog continues to rise, so the team orders even more staff. When the new capacity finally arrives, it may exceed demand; the backlog falls quickly, but staff reduction or redeployment also occurs slowly. The system can overshoot in both directions.

This is not limited to staffing. Inventory control, cloud autoscaling, admission control, production scheduling and rate limiting can all oscillate when feedback is delayed or gains are too aggressive.

A policy analysis should therefore vary:

- adjustment time;
- response strength or gain;
- information delay;
- capacity limits;
- demand variability;
- measurement noise;
- policy thresholds.

A policy that performs well under smooth demand may become unstable under bursts or delayed information.

## 14. Parameter estimation, calibration and identifiability

A parameter is a quantity in the model that is treated as fixed over the simulation or over a defined scenario. Examples include an average service rate, a delay time or a recovery rate. Parameters should be grounded in observed data, published evidence, engineering calculation or explicit expert elicitation.

Calibration may use least squares to minimise the difference between measured and simulated behaviour:

\[
J(\theta)=\sum_{t=1}^{n}w_t\left(y_t-\hat y_t(\theta)\right)^2
\]

where \(y_t\) is observed behaviour, \(\hat y_t(\theta)\) is simulated behaviour under parameter vector \(\theta\), and \(w_t\) weights observations. The objective function is a fitting tool, not proof of causal validity.

### 14.1 Identifiability

A parameter is identifiable when the available observations contain enough information to estimate it uniquely or within a useful range. Different parameter combinations may generate nearly identical behaviour. A model can therefore fit historical data well while its parameter estimates are unstable.

To investigate identifiability:

1. inspect parameter correlations;
2. vary one parameter at a time as an initial diagnostic;
3. use global sensitivity methods where appropriate;
4. test whether parameter estimates change drastically across time windows;
5. collect additional measurements that distinguish competing mechanisms;
6. report ranges rather than false precision.

### 14.2 Uncertainty and Monte Carlo analysis

When important parameters are uncertain, represent them as ranges or probability distributions. A Monte Carlo analysis samples parameter values and runs the model repeatedly. The resulting outcome distribution can show whether the preferred policy is robust or whether a recommendation depends on optimistic assumptions.

A Monte Carlo model does not make uncertain inputs disappear. The analyst must justify distributions, dependencies and bounds. Correlated parameters should not be sampled independently unless independence is credible.

## 15. Model structure and boundary tests

A model should be challenged in at least four dimensions:

1. **Structure:** do causal relationships and conservation rules represent the real mechanism?
2. **Behaviour:** can the model reproduce patterns that matter to the purpose?
3. **Policy:** does it behave plausibly under intervention, not only under historical inputs?
4. **Boundary:** have important effects been excluded, especially effects that could reverse the policy ranking?

A model with many equations may still have a poor boundary. A smaller model may be adequate if it includes the dominant feedback structure for the decision being examined.

### 15.1 Behavioural reproduction is not enough

Suppose two alternative models both reproduce the historical backlog. Model A assumes demand rises because the service becomes more popular. Model B assumes demand rises because the system generates more rework. The historical series alone may not distinguish them. The models predict different outcomes for interventions: marketing restriction may help A, while quality improvements may help B.

Seek evidence that can discriminate between causal hypotheses: ticket categories, reopening rates, new-user cohort size, service-quality trends and changes after interventions. If the evidence is insufficient, preserve both hypotheses and compare policies across them.

## 16. Applied modelling exercise: intervention comparison

A team is considering two interventions for a growing backlog:

- Policy A: add temporary resolution capacity immediately for 8 weeks.
- Policy B: spend 6 weeks improving the knowledge base and intake quality, with slower initial benefit but reduced rework and repeat demand.

The comparison should include more than the final backlog. Track:

- backlog volume and age distribution;
- arrivals and completions;
- reopen rate;
- quality of resolution;
- staff fatigue;
- cost of temporary capacity;
- time to benefit;
- demand variation;
- distribution of impact across simple and complex tickets.

Run baseline, high-demand, delayed-implementation and poor-adoption scenarios. Policy B may dominate in the long term but fail under a short-term emergency. A combined policy may be justified. The analysis should expose the time horizon and value judgments behind the recommendation.

## 17. Extended review questions

1. Explain why the same reinforcing loop can generate either growth or decline.
2. Under what circumstances can hiring more staff worsen long-run service capacity?
3. What is the difference between parameter uncertainty and structural uncertainty?
4. Why can a model reproduce historical data and still fail under a new policy?
5. When should a system dynamics model be combined with discrete-event or agent-based simulation?
6. What evidence would you collect to determine whether a backlog is driven primarily by demand, rework or capacity constraints?

A high-quality answer must state assumptions and distinguish the structure of the model from the evidence used to support it.
## 18. Numerical simulation, solver choice and time-step control

A stock-and-flow model is a mathematical model of accumulation. In continuous time, a stock vector \(x(t)\) is described by a differential equation:

\[
\frac{dx}{dt}=f(x(t),u(t),\theta,t)
\]

where \(u(t)\) represents external inputs and \(\theta\) contains parameters. A stock changes only through its net rate of accumulation. A causal-loop diagram does not, by itself, specify this equation: the modeller must define the operational mechanism, units, functional form, initial conditions and time basis.

### 18.1 Forward Euler integration

The simplest numerical method is forward Euler:

\[
x_{k+1}=x_k+f(x_k,u_k,\theta,t_k)\Delta t
\]

It estimates the next stock value using the current rate and a fixed time step \(\Delta t\). It is easy to implement and useful for understanding numerical simulation, but its error can be large when the time step is too coarse or the system changes rapidly.

**Worked example — exponential growth.** Let \(dx/dt=0.05x\), with \(x(0)=100\), and simulate ten days. The analytic solution is \(x(10)=100e^{0.5}\approx164.872\). Forward Euler with a one-day step gives \(100(1.05)^{10}\approx162.889\), about 1.20% below the analytic result. A 0.25-day step gives \(100(1.0125)^{40}\approx164.362\), about 0.31% below the analytic result. Halving the step should normally reduce discretisation error for a smooth first-order problem, but a converged simulation is not proof that the model structure is correct.

### 18.2 Solver choice and numerical pathologies

Other methods include midpoint/modified Euler and Runge–Kutta methods. Some simulation environments offer adaptive solvers that vary the step size to control estimated local error. Solver choice is not a substitute for understanding the model. Discontinuities, policy switches, event logic, stiff dynamics and long delays can require special care.

A practical numerical review should:

1. identify the fastest important time constant and any discrete events;
2. choose a starting time step that resolves those dynamics;
3. repeat the simulation with a smaller step;
4. compare the trajectories and the policy conclusions, not only the final value;
5. inspect oscillations, overshoot, negative stocks and artificial instability;
6. record the integration method, step size and solver settings with the model.

The rule “choose a time step no larger than one quarter of the smallest important time constant” is sometimes a useful starting heuristic, not a theorem. The appropriate step depends on the model, solver, acceptable error and the phenomenon being studied.

### 18.3 Delays and initialisation

A delay represents the time between a cause and its effect. A pipeline delay, information delay and decision delay are not necessarily the same mechanism. A pure time delay shifts a signal; a material pipeline stores material in transit; a first-order information delay smooths a signal over a characteristic response time. Choosing the wrong delay structure changes the model's behaviour.

Initial values must represent the state of the real system at the start of the modelled horizon. Initialising every stock to zero because it simplifies the simulation is generally wrong. For a pipeline, the initial material in transit must be accounted for; for a service backlog, the initial queue must match the observed backlog or be explicitly treated as a scenario assumption.

## 19. A validation protocol that separates structure, behaviour and policy

A model can reproduce historical data for the wrong reasons. Validation is therefore a set of tests against the model's intended purpose, not one goodness-of-fit statistic.

| Test family | Question | Example evidence |
|---|---|---|
| Boundary adequacy | Are the important feedbacks and accumulations inside the boundary? | Boundary critique and omitted-variable argument |
| Dimensional consistency | Do the equation units balance? | Unit table and software dimensional check |
| Parameter plausibility | Are values grounded in data or defensible estimates? | Source, range and elicitation notes |
| Extreme-condition test | Does the model behave plausibly at zero, very high or limiting values? | Deliberate stress runs |
| Behaviour reproduction | Can the model reproduce important historical patterns? | Time-series overlays and error measures |
| Sensitivity analysis | Do uncertain parameters or structures reverse the conclusion? | Parameter sweeps and structural alternatives |
| Policy robustness | Does a policy work across plausible futures, not only the base case? | Scenario and Monte Carlo comparison |
| Communication test | Can stakeholders understand the variables, equations and assumptions? | Independent model review |

Calibration estimates parameter values for a selected model structure. It does not establish that the structure is adequate. A model can be over-fitted when too many parameters are adjusted to reproduce a short or noisy historical series. A high in-sample fit may fail to predict a different period or policy regime.

### 19.1 Parameter uncertainty and structural uncertainty

Parameter uncertainty concerns values within a chosen model, such as average service time or intervention effectiveness. Structural uncertainty concerns the causal mechanisms included, omitted or represented differently. Varying a parameter cannot compensate for a missing feedback loop. For important decisions, compare plausible alternative structures as well as parameter ranges.

Monte Carlo analysis samples uncertain values from stated distributions and runs the model repeatedly. Report the assumptions behind each distribution, correlations between parameters, the number of runs, convergence checks and the distribution of outcomes. A histogram without a defensible uncertainty model is not a probability forecast.

## 20. Applied modelling exercise — numerical and structural robustness

Extend the service-backlog model from Sections 9 and 13.

**Part A — Numerical convergence**

1. Run the model with the original integration method and step size.
2. Repeat with half and one-quarter of the step size.
3. Compare peak backlog, time to recovery and cumulative work completed.
4. Explain whether the ranking of candidate policies changes.

**Part B — Extreme conditions**

Test zero arrivals, zero capacity, a sudden doubling of arrivals, an impossible negative service time, and a very long information delay. State which outcomes are physically plausible and which reveal a formulation defect.

**Part C — Parameter and structural uncertainty**

Vary arrival rates, staff capacity, interruption fraction and response delay. Then compare at least two structural alternatives for how demand and rework interact. Identify any policy whose apparent benefit disappears under a plausible alternative structure.

**Submission evidence:** model file, equation/units table, solver settings, reproducible run instructions, graphs with labelled axes and time horizons, sensitivity results, structural alternatives, and a two-page critique. A polished graph without the model file and assumptions is insufficient.

## 21. Additional examination problems

1. For \(dx/dt=0.1x\), derive the exact solution and one forward-Euler step. Explain why reducing \(\Delta t\) improves numerical accuracy but does not repair a missing causal mechanism.
2. A policy ranks first under one parameter set but last under a second plausible structure. Explain whether this is parameter sensitivity, structural uncertainty or both, and propose a robust decision rule.
3. A model reproduces historical backlog for five years but predicts negative queue size after a capacity intervention. Identify at least three possible causes and describe the tests that would distinguish them.


## 22. Local stability: connecting feedback structure to mathematics

A causal-loop diagram explains hypothesised causal structure. A stock-flow model adds accumulation and equations. Stability analysis asks whether a system near an equilibrium returns toward that equilibrium after a small perturbation, moves away from it, or exhibits oscillatory behaviour. This is a different question from whether a model reproduces a historical curve.

Consider the service-backlog model, with backlog \(B\) (requests), effective service capacity \(C\) (requests/day), external arrivals \(\lambda\) (requests/day), rework fraction \(\rho\), base capacity \(C_0\), response gain \(g\) (1/day per request, under this illustrative model), target backlog \(B_T\), and adjustment time \(\tau\) (days):

\[
\dot B=\lambda-(1-\rho)C,\qquad
\dot C=\frac{C_0+g(B-B_T)-C}{\tau}
\]

This linear form applies locally in the region where the response is active and backlog remains positive. It assumes service capacity is not capped and the target response is not saturated. These assumptions must be checked before interpreting the result.

At equilibrium, \(\dot B=\dot C=0\), therefore:

\[
C^*=\frac{\lambda}{1-\rho},\qquad
B^*=B_T+\frac{C^*-C_0}{g}
\]

The state vector is \(x=[B,C]^T\). The Jacobian matrix is:

\[
J=\begin{bmatrix}0&-(1-\rho)\\g/\tau&-1/\tau\end{bmatrix}
\]

Its characteristic equation is:

\[
\mu^2+\frac{1}{\tau}\mu+\frac{(1-\rho)g}{\tau}=0
\]

For \(0\leq\rho<1\), \(g>0\) and \(\tau>0\), both coefficients are positive, so the two eigenvalues have negative real parts. The equilibrium is locally asymptotically stable in this unsaturated linear region. Depending on the discriminant, the transient can be non-oscillatory or damped-oscillatory. Stability does not mean the system responds quickly: a large adjustment time can make recovery slow. Nor does local stability prove global stability when capacity caps, delays, nonlinear rework or changing demand are introduced.

### 22.1 Worked stability calculation

Let \(\rho=0.1\), \(g=0.02\) per day per request (under a normalised backlog unit), and \(\tau=10\) days. Then:

\[
\mu^2+0.1\mu+0.0018=0
\]

The discriminant is \(0.1^2-4(0.0018)=0.0028\), which is positive. The roots are approximately:

\[
\mu_{1,2}=\frac{-0.1\pm\sqrt{0.0028}}{2}
\]

Both roots are negative (approximately -0.0235 and -0.0765 per day), so local perturbations decay. The larger-magnitude negative eigenvalue corresponds to the faster mode; the other dominates the long-run tail. If the model output oscillates persistently under these assumptions, inspect the implementation, time step and equation signs.

## 23. Model credibility, uncertainty and numerical robustness

A model has at least four distinct uncertainty classes:

1. **Parameter uncertainty:** values such as arrival rate or rework fraction are not known exactly.
2. **Structural uncertainty:** the chosen causal relationships, delays or functional forms may be wrong or incomplete.
3. **Measurement uncertainty:** source data may be noisy, incomplete, biased or collected under different operating conditions.
4. **Scenario uncertainty:** future external conditions may differ from the cases that were modelled.

A parameter sensitivity analysis varies one parameter at a time to understand local influence, but it can miss interactions. A global analysis samples across a joint parameter space and should preserve meaningful dependencies between parameters. Monte Carlo output is a distribution conditional on the model and sampling assumptions, not an objective probability of what the real system will do.

Numerical validation must include step-size sensitivity. For forward Euler, the update is \(x_{k+1}=x_k+h f(x_k)\). A large time step can create numerical oscillations or instability that are not present in the continuous model. Repeat the experiment with a smaller step, compare the trajectories and state an acceptable error measure. A small time step reduces one numerical error source; it does not repair an incorrect model structure.

### 23.1 Minimum model verification record

For each model version, record:

- model boundary and purpose;
- equations, units and parameter sources;
- initial conditions and integration method;
- time step and simulation horizon;
- extreme-condition tests;
- dimensional-consistency results;
- reference behaviour and calibration data;
- step-size and parameter sensitivity;
- structural alternatives considered;
- limitations and decision context.

A policy ranking should be reported with its robustness. If the ranking reverses under plausible values or model structures, report the ranking as uncertain and identify which data or experiment would reduce the uncertainty.

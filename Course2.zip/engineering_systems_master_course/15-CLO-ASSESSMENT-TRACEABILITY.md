# Course Learning Outcomes and Assessment Traceability

## 1. How to read this matrix

Each course has five grouped course learning outcomes (CLOs). The numbered outcomes in each primary course file are preserved; the CLO groups below consolidate them into assessable capabilities. A CLO is considered taught when the learner studies the named sections and completes the specified formative retrieval work. It is considered demonstrated only when the learner produces the corresponding lab/project evidence and answers the mapped examination item under closed-book conditions.

**Evidence rule:** a link from a requirement to a test, a section to an exam item, or a course outcome to a project does not itself prove the outcome. The learner must inspect the artefact, run the test where relevant, interpret the result, and state its limits.

## 2. Course I — Systems Thinking and System Dynamics

| CLO | Demonstrable outcome (existing outcomes grouped) | Teaching and prerequisite sections | Formative check | Lab / assessment evidence | Final examination evidence | Capstone evidence |
|---|---|---|---|---|---|---|
| C1-LO1 | Define and critique a system boundary; distinguish events, patterns and generative structure (outcomes 1–2). | §§1–2, 7.2, 15; prerequisite: variables, graphs and units. | Draw two alternative boundaries and explain what each excludes. | Lab 1 boundary statement and stakeholder map. | Q1 dynamic hypothesis and model boundary. | Boundary statement plus excluded-variable rationale. |
| C1-LO2 | Construct causal-loop diagrams, determine link polarity and diagnose feedback/delay/archetype behaviour (outcomes 3, 5–6). | §§3, 5–6, 13; prerequisite: causal reasoning. | Closed-book polarity questions; identify one reinforcing and one balancing loop. | Lab 2 editable causal-loop diagram, loop register and policy critique. | Q1 dynamic hypothesis; Q5 policy critique. | Causal-loop diagram linked to behaviour-over-time evidence. |
| C1-LO3 | Formulate stocks, flows and dimensionally consistent state equations (outcome 4). | §§4, 9.3, 18; prerequisite: integration and rates. | Derive one stock equation and check dimensions. | Lab 3 model, variable dictionary, tests and plots. | Q2 stock-flow formulation and dimensional consistency. | Model equations, unit tests and numerical sensitivity results. |
| C1-LO4 | Estimate parameters, select a numerical method and validate a dynamic model (outcome 7). | §§7, 14, 18–19; prerequisite: basic statistics and numerical integration. | Compare Euler results at two time steps. | Lab 3 validation log; advanced numerical extension. | Q3 numerical integration; Q4 calibration/identifiability. | Calibration record, structural tests and uncertainty analysis. |
| C1-LO5 | Compare interventions robustly and communicate uncertainty, unintended consequences and limitations (outcomes 8–9). | §§9, 14–16, 19–21. | Policy comparison under changed assumptions. | Lab 3 policy experiment and Lab 2 boundary critique. | Q5 model validation and policy critique. | Robustness report; explicit distinction between scenario and prediction. |

## 3. Course II — Systems Engineering Fundamentals

| CLO | Demonstrable outcome (existing outcomes grouped) | Teaching and prerequisite sections | Formative check | Lab / assessment evidence | Final examination evidence | Capstone evidence |
|---|---|---|---|---|---|---|
| C2-LO1 | Explain the purpose of systems engineering, lifecycle processes and tailoring (outcomes 1–2). | §§1–2, 12, 21, 24; prerequisite: basic project life cycle. | Compare two lifecycle models against project risk and uncertainty. | Lab 4 lifecycle map and Lab 5 review record. | Q2 lifecycle and technical reviews. | Lifecycle strategy and review gate schedule. |
| C2-LO2 | Identify stakeholders, develop ConOps, derive needs and allocate functions/interfaces (outcomes 3–5). | §§3–5, 13, 16–17. | Turn a stakeholder statement into need, requirement and function. | Labs 4–5 ConOps, functional decomposition, allocation matrix and ICD. | Q1 stakeholder need to requirement; Q4 model/system structure. | Stakeholder register, ConOps, function tree and interface register. |
| C2-LO3 | Perform evidence-based trade studies, lifecycle-cost analysis and MBSE modelling (outcomes 6–7). | §§6–8, 20, 23; prerequisite: percentages and discounting. | Screen hard constraints before calculating weighted preferences. | Lab 8 trade study; Python decision-analysis practical. | Q3 constrained trade study; Q4 MBSE. | Architecture alternatives, assumptions, sensitivity and decision record. |
| C2-LO4 | Plan risk, safety, human-systems integration and configuration management (outcome 8). | §§9, 17–18, 21. | Draft a hazard/risk row with cause, consequence, control and verification. | Lab 9 risk and review artefacts. | Q5 risk treatment and assurance. | Hazard log, risk register, configuration baseline and residual-risk acceptance. |
| C2-LO5 | Design verification/validation evidence and lifecycle review/transition gates (outcomes 9–11). | §§10–12, 19, 21, 24. | Classify evidence as verification or validation and justify the choice. | Labs 5, 9 and 15; review checklist. | Q2 review gates; Q5 V&V. | Verification cross-reference matrix, validation plan, ORR evidence and transition plan. |

## 4. Course III — Requirements Engineering

| CLO | Demonstrable outcome (existing outcomes grouped) | Teaching and prerequisite sections | Formative check | Lab / assessment evidence | Final examination evidence | Capstone evidence |
|---|---|---|---|---|---|---|
| C3-LO1 | Distinguish needs, requirements, design and tasks; plan evidence-based stakeholder elicitation (outcomes 1–3). | §§1–5, 23; prerequisite: system context and stakeholder concepts. | Classify ten statements and select an elicitation method for each uncertainty. | Lab 6 stakeholder/evidence register. | Q2 elicitation plan. | Stakeholder needs register with provenance and open questions. |
| C3-LO2 | Write and structure clear, feasible, atomic and verifiable requirements, including quality, security, safety and sustainability dimensions (outcomes 4–5). | §§5–8, 16, 18, 24. | Rewrite vague, compound and solution-prescriptive statements. | Lab 6 SRS and quality-attribute scenario set; requirements linter. | Q1 requirement repair; Q5 SRS critique. | Approved requirements baseline and measurable acceptance conditions. |
| C3-LO3 | Model behaviour and data, validate a requirements set and resolve inconsistency/incompleteness (outcomes 6–8). | §§4, 13, 19–20, 24. | Inspect a state model for missing transitions and illegal states. | Labs 6–7 models, peer-review record and defect log. | Q3 requirements model and state transitions; Q5 set-level quality. | Context/use-case/state/data models plus requirements review minutes. |
| C3-LO4 | Derive verification methods, tests, traceability and release priorities (outcomes 9–10). | §§9–10, 25. | Derive positive, negative, boundary and temporal test conditions. | Lab 7 trace matrix and acceptance suite. | Q4 traceability and test derivation. | Bidirectional traceability and requirement verification evidence. |
| C3-LO5 | Manage baselines, change impact and iterative/hybrid requirements (outcomes 11–12). | §§11–12, 20–22, 26. | Evaluate the impact of a change across dependent requirements and tests. | Lab 7 change-impact graph and baseline record. | Q5 change-impact and specification governance. | Versioned baseline, change log, impact analysis and release plan. |

## 5. Course IV — Software System Design and Distributed Systems

| CLO | Demonstrable outcome (existing outcomes grouped) | Teaching and prerequisite sections | Formative check | Lab / assessment evidence | Final examination evidence | Capstone evidence |
|---|---|---|---|---|---|---|
| C4-LO1 | Characterise workload and specify API/data contracts with explicit invariants (outcomes 1–3). | §§1–3, 13–14; prerequisite: programming, SQL, HTTP and basic networking. | Derive throughput, concurrency and storage estimates from a workload statement. | Lab 8 workload/API/data model and Go concurrency practical. | Q1 concurrency invariant. | Workload model, API contract and authoritative data invariants. |
| C4-LO2 | Explain storage engines, transactions, concurrency anomalies, caches and asynchronous workflows (outcomes 4–5). | §§4–7, 15–18. | Classify a transaction anomaly and predict a retry/idempotency failure. | Lab 8 transaction tests and event/outbox design. | Q3 PostgreSQL isolation; Q5 overload/backpressure. | Data model, transaction protocol, outbox and reconciliation design. |
| C4-LO3 | Analyse partial failure, timeouts, replication, consistency, partitioning, CAP and consensus (outcomes 6–8). | §§8–10, 19–25; prerequisite: state machines and basic probability. | Draw an operation history and identify what it can prove. | Lab 16 fault-injection and safety/liveness analysis. | Q2 operation histories; Q4 consensus safety/liveness. | Consistency contract, failure model, protocol argument and limitations. |
| C4-LO4 | Design for backpressure, isolation, observability and graceful degradation (outcome 9). | §§11–13, 26–27. | Design a deadline/retry budget and predict retry amplification. | Labs 9 and 16; load/chaos experiment. | Q5 overload, backpressure and telemetry. | Capacity envelope, degradation policy and observability contract. |
| C4-LO5 | Evaluate an end-to-end design against correctness and quality scenarios (outcome 10). | §§12–16 and integrated case; review all prior topics. | Present a design decision with an explicit counterexample. | Lab 16 report and architecture review. | All five Course IV exam questions. | Integrated system design, tests, fault report and oral defence. |

## 6. Course V — Software Architecture and Trade-off Analysis

| CLO | Demonstrable outcome (existing outcomes grouped) | Teaching and prerequisite sections | Formative check | Lab / assessment evidence | Final examination evidence | Capstone evidence |
|---|---|---|---|---|---|---|
| C5-LO1 | Identify architectural drivers and define measurable quality-attribute scenarios (outcomes 1–3). | §§1–3, 12; prerequisite: requirements and software design. | Convert three vague qualities into stimulus/environment/response/measure scenarios. | Lab 10 quality-attribute and driver register. | Q1 quality-attribute scenario. | Architecture drivers and agreed scenario set. |
| C5-LO2 | Select styles, patterns, tactics and views for the system context (outcomes 4–6). | §§4–6, 13–17. | Compare two patterns and identify where each fails. | Lab 10 context, component, deployment and runtime views. | Q2 patterns and tactics. | Architecture model, view catalogue and rationale. |
| C5-LO3 | Record decisions and rationale in ADRs with traceable alternatives (outcome 7). | §§7, 17–18. | Critique a decision record for missing context, consequence or rejected option. | Lab 10 ADR set and decision log. | Q4 ADR critique. | Versioned ADRs linked to requirements and quality scenarios. |
| C5-LO4 | Evaluate architecture trade-offs, sensitivity points, risks and uncertainty (outcomes 8–9). | §§8–9, ATAM case and trade-study material. | Build a utility tree and identify a trade-off point. | Lab 10 evaluation workshop and sensitivity analysis. | Q3 ATAM utility tree; Q4 architecture critique. | ATAM-style report, risk themes, sensitivity and trade-off points. |
| C5-LO5 | Establish fitness functions and govern architecture evolution/technical debt (outcome 10). | §§10–12, evolution and governance sections. | Define a measurable architecture fitness function and a false-positive check. | Architecture dependency checker and Lab 10 governance plan. | Q5 architecture fitness function. | Fitness-function catalogue, review cadence and technical-debt treatment. |

## 7. Course VI — Reliability Engineering, SRE and Incident Response

| CLO | Demonstrable outcome (existing outcomes grouped) | Teaching and prerequisite sections | Formative check | Lab / assessment evidence | Final examination evidence | Capstone evidence |
|---|---|---|---|---|---|---|
| C6-LO1 | Define reliability concepts and derive reliability, hazard and life distributions (outcomes 1–3). | §§1–4, 13–15; prerequisite: probability, logarithms and calculus. | Derive exponential survival and identify Weibull hazard shape from β. | Lab 11 life-data analysis; reliability code practical. | Q1 series/parallel reliability; Q2 censored life-data. | Reliability model, population, mission and assumptions. |
| C6-LO2 | Analyse system structure, failure modes, fault trees and maintainability/availability (outcomes 4–6). | §§5–8, 16–18. | Convert an FMEA cause into a fault-tree event and identify common-cause risk. | Lab 11 FMEA/FTA/RBD and repair-time model. | Q1 reliability; Q4 FMEA/FTA. | FMEA, fault tree, RBD and availability model. |
| C6-LO3 | Define SLIs/SLOs and operational monitoring that reflects user outcomes (outcomes 7–8). | §§9–11, 19–20. | Calculate an error budget and classify a symptom vs cause metric. | Lab 12 SLI/SLO plan and telemetry specification. | Q5 SLO and incident. | SLI dictionary, SLO justification, burn alerts and error-budget policy. |
| C6-LO4 | Lead incident response, learn from incidents and design/test recovery (outcomes 9–10). | §§12–14, 21–23. | Conduct a timeline reconstruction and calculate demonstrated RPO/RTO. | Labs 13–14 incident simulation and restore test. | Q5 incident/recovery response. | Incident runbook, post-incident review, backup/restore evidence. |
| C6-LO5 | Use resilience/fault-injection methods and communicate limits of reliability evidence (outcomes 11–12). | §§15–18, advanced statistical notes. | Distinguish statistical uncertainty, model uncertainty and missing failure modes. | Labs 11–14 with fault-injection extension. | Q2–Q4 assumptions and uncertainty. | Reliability growth plan, fault-injection report and residual-risk statement. |

## 8. Assessment blueprint and coverage rule

The 100-mark examination for each course is mapped to five 20-mark questions, except the Course VI paper's explicitly weighted 15/20/25 allocation. The major practical and capstone rubrics carry the applied evidence. The examination is an individual mastery check; it must not be completed with notes, code assistants or external answer keys open.

Before claiming that a CLO is mastered, the learner must provide both:

1. **Conceptual evidence:** a correct closed-book explanation or derivation on a new scenario; and
2. **Applied evidence:** a lab/project artefact that survives the stated tests and includes an interpretation of what the tests do not establish.

No course CLO is intended to be assessed only by self-reported completion or by the mere presence of a document. Where the available rubric cannot be graded consistently by the learner, obtain an external reviewer and record that limitation.

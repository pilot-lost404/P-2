# Self-Study Learner Handbook

## 1. Purpose and honest academic status

This handbook turns the six-course sequence into a disciplined independent learning experience. A university course normally provides more than lecture notes: it specifies prerequisites and outcomes, sequences teaching, uses formative assessment, provides feedback, requires substantial assessed work, and checks whether an individual can transfer knowledge to unfamiliar problems. This programme approximates those functions through explicit weekly tasks, worked solutions, testable laboratories, rubrics, self-checks and an integrated capstone.

It remains an independently authored programme. It is not accredited, does not award credit, and cannot reproduce the supervision, peer interaction, laboratory facilities, examiner independence or institutional quality assurance of a university. Its academic level is best described as an advanced-undergraduate to introductory-graduate independent study sequence, with selected graduate-level topics. A strong learner should treat the course as a serious portfolio-building curriculum, not as a credential.

## 2. Entry diagnostic

Complete this diagnostic before beginning Course I. Do not use a language model or answer key during the first attempt. Record each answer and confidence (low / medium / high). A low-confidence correct answer still identifies an area to practise.

| No. | Diagnostic task | Expected competence | If not yet secure |
|---:|---|---|---|
| 1 | Rearrange `y = 3x + 7` to solve for `x`; evaluate it for `y = 31`. | Algebra and substitution | Review linear equations and units. |
| 2 | Explain the slope of a graph and distinguish slope from intercept. | Graph interpretation | Review functions and rates of change. |
| 3 | Convert 2.5 hours to seconds and 4 requests/minute to requests/hour. | Unit conversion | Review dimensional analysis. |
| 4 | Explain the difference between an average and a percentile. | Descriptive statistics | Review distributions and quantiles. |
| 5 | For independent events with probabilities 0.9 and 0.8, calculate the probability both occur. | Basic probability | Review multiplication rule and independence. |
| 6 | State what a loop invariant is in a program or process. | Basic algorithmic reasoning | Review preconditions, postconditions and invariants. |
| 7 | Explain what a primary key guarantees and what it does not guarantee. | Relational data basics | Review keys, constraints and transactions. |
| 8 | Explain why a timeout does not prove that a remote operation failed. | Basic network reasoning | Review partial failure and ambiguous outcomes. |

**Diagnostic key:** (1) `x = (31 - 7)/3 = 8`; (2) slope is change in the dependent variable per unit change in the independent variable; intercept is the value at zero on the independent variable when meaningful; (3) 9,000 seconds and 240 requests/hour; (4) average summarises central tendency, percentile gives a rank-based threshold; (5) 0.72; (6) a property that must remain true at a specified program point or throughout an iteration; (7) a primary key uniquely identifies a row and is non-null, but does not by itself enforce business rules such as non-overlapping reservations; (8) the remote system may have completed the operation while the response was lost.

Score interpretation is diagnostic rather than selective: 7–8 secure, begin the sequence; 5–6, complete the indicated refreshers during the first two weeks; 0–4, spend 2–4 weeks on algebra, graphs, probability, programming and databases before Course IV. Do not skip prerequisite remediation because later tools can hide conceptual gaps.

## 3. Programme structure and workload

There are six sequential courses, each planned for 13 weeks. At 8–12 hours per week this is 624–936 hours. The longer end is appropriate when the learner is new to the domain or is implementing the optional extensions. The compressed 24-week roadmap is a survey schedule only; it is not equivalent in practice depth or assessment coverage to the 78-week programme.

For every course, reserve one weekly block for theory, one for problem solving, and one for lab or design work. A practical weekly allocation is:

| Activity | Hours/week | Required evidence |
|---|---:|---|
| Core text and primary reference | 2–3 | Annotated notes; definitions and assumptions in your own words |
| Derivations and worked problems | 2–3 | Independently solved problems, with units and checks |
| Lab / model / engineering artefact | 2–4 | Code, model, specification or dossier plus reproducible evidence |
| Retrieval, reflection and revision | 1–2 | Closed-book quiz, error log and next-week action |

The workload is not achieved by passively watching videos or collecting links. Time counts when the learner performs retrieval, calculation, model construction, critique, implementation or evidence-based writing.

## 4. A repeatable learning cycle

Use this sequence for each lecture topic.

1. **Orient:** Read the stated learning outcome and prerequisite. Write one sentence explaining the engineering problem the topic addresses.
2. **Study:** Read the core notes once for structure, then again actively. Close the text and reproduce the definition, diagram or derivation.
3. **Work:** Follow one worked example, then solve a near-transfer problem without looking. Compare line by line; identify the first incorrect decision, not merely the final wrong answer.
4. **Test:** Complete the formative questions closed-book. Mark answers against the answer key and explain every incorrect option.
5. **Apply:** Use the method in a lab, case study or design artefact. State assumptions and evidence.
6. **Reflect:** Record the mistake, why it occurred, what would detect it next time and when to retry the question.
7. **Space:** Revisit the concept after roughly 1 day, 1 week and 1 month. Move a card or topic to a longer interval only after correct retrieval without notes.

Do not memorise a formula without being able to state its assumptions and units. Do not memorise a design pattern without a counterexample. Do not accept a passing test as evidence for a property the test does not exercise.

## 5. Worked-example fading

Use a three-pass method to avoid the illusion of understanding.

- **Pass A — fully worked:** Study the complete derivation and annotate why each step is valid.
- **Pass B — partially completed:** Hide selected steps or code lines and reproduce them. State the result before revealing it.
- **Pass C — transfer:** Solve a changed problem: alter the constraints, data, operating environment or failure mode. Explain whether the original method still applies.

For every quantitative solution, check dimensions, sign, boundary values and a limiting case. For every engineering design, check traceability, interface assumptions, failure behaviour and residual risk.

## 6. How to use solutions and answer keys

Attempt every problem before opening its solution. A model answer is a reference argument, not the only possible valid answer. For open-ended work, self-mark each rubric criterion as **not met**, **partly met**, **met**, or **exceeded**, and attach a piece of evidence. Do not award yourself marks for intention or effort.

For calculations, exact numerical agreement is expected within the stated rounding tolerance. For architecture and requirements work, the evidence must show that the proposal satisfies constraints and handles relevant failure cases. A beautiful diagram without a defensible explanation is not a complete answer.

When you cannot grade your own artefact reliably, mark the uncertainty explicitly and seek external review from a peer, practitioner, mentor or instructor. The capstone's oral defence questions are included to expose weaknesses that a document alone may hide.

## 7. Course mastery gates

A learner should not advance solely because a calendar week has ended. Use these minimum gates at the end of each course:

- at least 70% on the course final examination, with no major topic section below 50%;
- at least 70% on the major assignment rubric;
- all required lab tests and reproducibility checks pass, or any non-passing result has a documented and justified interpretation;
- the learner can explain the top five course concepts without notes;
- the learner can identify at least three assumptions or limitations in their own work.

These are self-study progression criteria, not formal accreditation standards. For high-consequence topics, a pass score is not proof of professional competence.

## 8. Laboratory protocol

Before changing a lab:

1. Read its README and identify the intended learning outcomes.
2. Record the language/runtime version and operating system.
3. Run the baseline command before making edits.
4. Read the code and tests; predict the output.
5. Change one variable or one behaviour at a time.
6. Run targeted tests, then the full test suite.
7. Save the command, output, input, source version and interpretation in a lab log.
8. Repeat with at least one boundary or fault condition.

A lab is not complete when the program runs. Explain why its result is valid, what its tests do not cover and what assumptions a real deployment would require. A failing test is data: diagnose it rather than removing it to make the suite green.

## 9. Technical writing standard

Every submitted artefact should contain:

- purpose and scope;
- assumptions, constraints and exclusions;
- method and rationale;
- source data and units;
- results and supporting evidence;
- uncertainty, limitations and threats to validity;
- conclusion tied to the stated question;
- version and reproducibility information.

Use stable identifiers for requirements, interfaces, risks, tests and decisions. Distinguish facts, assumptions, estimates and recommendations. Mark illustrative or synthetic data as such; never imply that generated data were measured from a real organisation.

## 10. Academic integrity and responsible tool use

You may use official documentation, textbooks, technical papers, code assistants and language models as learning aids. You remain responsible for checking every claim, derivation, code path and citation. Do not submit generated code or prose as evidence of understanding without being able to explain and modify it. Cite sources for borrowed definitions, standards, diagrams, datasets and code. Respect licenses. Never include credentials, personal information or production data in a public lab.

For each major artefact, keep a brief provenance record: sources consulted, tools used, generated material checked, tests executed, and changes made after feedback. The oral-defence questions are designed to verify authorship-level understanding.

## 11. Capstone review procedure

At the end of the six courses, assemble one coherent engineering dossier for the campus equipment service. Review it in this order:

1. Does the system boundary include the socio-technical service, not only the application?
2. Are the operational scenarios and stakeholder needs evidenced and internally consistent?
3. Is each important requirement measurable, traceable and verifiable?
4. Does the architecture preserve the critical invariants under concurrency and partial failure?
5. Do architecture decisions respond to measured quality-attribute scenarios?
6. Are reliability, SLO, incident and recovery claims supported by data or explicitly labelled assumptions?
7. Can another engineer reproduce the analysis and understand the residual risks?

A capstone that fails a safety, security, data-integrity or recovery-critical criterion should not receive a high overall mark merely because its presentation is polished.

## 12. Further learner support

Use [15 — CLO Assessment Traceability](15-CLO-ASSESSMENT-TRACEABILITY.md) to identify what evidence proves each outcome; [16 — Lab Environment and Reproducibility](16-LAB-ENVIRONMENT-AND-REPRODUCIBILITY.md) to run the practicals; and [17 — Worked Examples and Reference Solutions](17-WORKED-EXAMPLES-AND-REFERENCE-SOLUTIONS.md) when checking calculations and engineering arguments.


## 8. Week-by-week mastery contract

The 78-week schedule in `09-STUDY-PLAN.md` is the controlling schedule. Treat each 13-week course as a separate academic block. The weekly rhythm is deliberately cumulative: introduce a concept, reconstruct it, solve a problem, apply it, then critique the evidence. Do not advance simply because the calendar week has ended.

| Course block | Weeks | Main progression | Required end-of-block evidence |
|---|---:|---|---|
| I — Systems thinking | 1–13 | Boundary and behaviour → feedback and delay → stocks/flows → numerical model → validation/sensitivity → policy analysis | Dynamic model, dimensional audit, test log, sensitivity report, policy defence |
| II — Systems engineering | 14–26 | Lifecycle and stakeholders → needs and ConOps → functional architecture/interfaces → requirements and trade study → risk/integration → V&V and review | ConOps, architecture/decomposition, interface register, traceability, trade study, mini-PDR |
| III — Requirements | 27–39 | Context and elicitation → analysis and negotiation → modelling → requirement quality → verification/acceptance → baselines/change → agile/hybrid | Requirements baseline, model set, acceptance tests, traceability, change-impact record |
| IV — Software systems | 40–52 | Workload/API/data → transactions/storage → queues and failure models → replication/consistency/consensus → observability/resilience | API/data contract, transaction argument, failure analysis, concurrent service lab, distributed-systems design dossier |
| V — Architecture | 53–65 | Drivers and scenarios → architecture styles/tactics → views and decisions → trade-off evaluation → governance and evolution | Architecture description, ADR set, ATAM-style analysis, executable fitness function, exception/governance policy |
| VI — Reliability/SRE | 66–78 | Probability/life data → reliability models → FMEA/FTA → availability and SLOs → operations/incident → recovery → statistical assessment | Reliability analysis, assumptions and uncertainty, FMEA/FTA, SLO/error budget, incident analysis, tested restore plan |

### Minimum study loop for every technical topic

1. **Preview (10–15 minutes):** list what the topic assumes you already know and write one question you expect it to answer.
2. **Study (45–90 minutes):** read the primary course text. Re-derive equations and redraw diagrams without copying. Keep a glossary of terms that have precise technical meanings.
3. **Retrieve (15–25 minutes):** close the source and explain the topic from memory. Record gaps; do not mistake recognition for recall.
4. **Solve (45–90 minutes):** attempt the assigned problem before opening the solution guidance. Preserve the first attempt so errors are visible.
5. **Apply (60–180 minutes):** complete the mapped lab or design artefact. Include inputs, assumptions, units, version, commands and evidence.
6. **Critique (20–30 minutes):** state what the result establishes, what it does not establish, and what additional evidence would change your conclusion.

### Mastery gate

Before moving to the next course, you should be able to:

- explain every course learning outcome without relying on a copied definition;
- solve at least 80% of the closed-form numerical and short-answer work correctly on a second attempt;
- achieve at least 70% against the published rubric for each major artefact, with no critical safety, security, correctness or traceability defect left unexplained;
- reproduce every executable practical from a clean directory using the documented commands;
- defend one design decision, one rejected alternative and one model limitation orally for 10–15 minutes.

These are self-study progression thresholds, not accredited examination rules. For open-ended designs, ask a technically competent reviewer to grade the artefact; self-assessment alone is not independent validation.

## 9. Prerequisite diagnostic and remediation

Before Week 1, confirm that you can manipulate algebra, read graphs, use logarithms/exponents, reason with probability, interpret basic statistics, read structured pseudocode, and use a terminal. The diagnostic quiz in this handbook is a screen, not a full placement examination. If you miss a topic, review the relevant mathematics or programming material before beginning its associated course. In particular:

- Review algebra, functions, derivatives and first-order differential equations before Course I.
- Review probability, basic economics/discounting and lifecycle vocabulary before Course II.
- Review logic, state machines, test design and clear technical writing before Course III.
- Review data structures, SQL, concurrency basics, networking and operating-system fundamentals before Course IV.
- Review modular design, quality attributes and measurement before Course V.
- Review probability distributions, descriptive statistics and confidence intervals before Course VI.

## 10. Independent grading protocol

For every assessed submission, prepare a one-page evidence map: learning outcome → claim → artefact location → method → result → limitation. Grade the work against the corresponding published rubric. A numerical score without evidence is not a grade. Where no external reviewer is available, mark the grade as **self-assessed**, keep the original submission and schedule a second attempt after a delay of at least one week.

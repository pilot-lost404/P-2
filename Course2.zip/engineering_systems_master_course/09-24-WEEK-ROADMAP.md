# 24-Week Study Roadmap


## Status and limitation

This is an **accelerated survey route**, not the programme's mastery route. It compresses six technical disciplines into four weeks per course and therefore reduces the time available for mathematical derivation, independent problem sets, implementation, failure injection and formal assessment. Completing this 24-week route is useful for orientation or revision; it must not be reported as equivalent to completing the 78-week study plan. Use [the 78-week plan](09-STUDY-PLAN.md) for the full course sequence and assessment workload.

**Suggested pace:** 6–8 focused hours per week. This plan assumes the six detailed chapters in this pack are the primary notes and the Resource Library contains the selected supplementary material. Do not attempt to complete every optional reference.

## Weekly routine

For each week, allocate time roughly as follows:

- 2 hours: read the chapter section and make notes.
- 1–2 hours: watch or read the selected external course material.
- 2–3 hours: complete the week's lab or written work product.
- 30–60 minutes: self-test, update the glossary and write down unresolved questions.

## Weeks 1–4 — Systems thinking

| Week | Study | Practical work | Checkpoint |
|---:|---|---|---|
| 1 | Chapter 1: system boundaries, stakeholders and reference modes. Read Meadows' *Thinking in Systems* introduction/early chapters. | Lab 1: boundary and reference mode. | Explain why an outcome cannot be understood from a single event alone. |
| 2 | MIT 15.871 introduction and causal-loop material; reinforcing and balancing loops. | Lab 2: causal-loop model and policy resistance. | Draw and explain at least one reinforcing and one balancing loop. |
| 3 | MIT 15.871 stock-flow structures, accumulation and delay exercises; System Dynamics Society road maps. | Lab 3: build a small stock-flow model and check units. | Explain the difference between a stock and a flow without using vague examples. |
| 4 | Finish the systems-thinking chapter; study model testing, extreme conditions, sensitivity and robustness. | Complete model validation tests; optional MIT 15.879 first session. | Submit a model with assumptions, tests and limitations. |

## Weeks 5–8 — Systems engineering

| Week | Study | Practical work | Checkpoint |
|---:|---|---|---|
| 5 | Chapter 2: system lifecycle, V-model, stakeholder needs and technical processes. Read NASA Handbook overview. | Begin Lab 4: CONOPS and lifecycle. | Explain the lifecycle and distinguish verification from validation. |
| 6 | MIT 16.842 stakeholder analysis and requirements definition; NASA tutorial. | Complete context, stakeholder and CONOPS artefacts. | Show a direct link from stakeholder outcome to system need. |
| 7 | MIT 16.842 system architecture/concept generation, trade-space and selection. | Lab 5: functional decomposition and interfaces. | Show the architecture follows the functions and interfaces, not an arbitrary service count. |
| 8 | MBSE/SysML, integration, safety, technical reviews, commissioning and operations. | Complete a mini PDR package and review checklist. | Defend the concept and list evidence still required before implementation. |

## Weeks 9–12 — Requirements engineering

| Week | Study | Practical work | Checkpoint |
|---:|---|---|---|
| 9 | Chapter 3: context, elicitation, stakeholders, scope and assumptions. | Lab 6, parts 1–2: identify needs and draft requirements. | Demonstrate the difference between a need, a constraint and a design suggestion. |
| 10 | DTU RED material on elicitation, goals, context, structure and requirements QA. | Finish SRS and quality review. | Every high-priority requirement is atomic and testable. |
| 11 | OpenRE Gothenburg course materials; use cases, stories, quality attributes and modelling. | Lab 7: use case, user stories and acceptance tests. | Show traceability from stakeholder need to acceptance test. |
| 12 | Prioritisation, negotiation, verification, validation, traceability and change management. Review ISO 29148 public information. | Baseline the SRS; run a change-impact analysis. | Submit SRS, requirement matrix, test links and change record. |

## Weeks 13–16 — Software system design

| Week | Study | Practical work | Checkpoint |
|---:|---|---|---|
| 13 | Chapter 4: APIs, data boundaries, workloads, latency and interface design. | Lab 8, API contract and initial ER model. | Define workload assumptions before selecting infrastructure. |
| 14 | DDIA 2e data model/storage/transactions chapters; PostgreSQL transactions, indexes and query plans. | Complete ER model, transaction boundaries and index rationale. | Explain how a concurrent reservation is kept correct. |
| 15 | Free Distributed Systems book; Brown CS1380 lectures on time/order, replication and consistency. | Lab 9: consistency/failure exercise. | Explain a retry after a lost response and how idempotency prevents duplicate effects. |
| 16 | Kafka documentation, Kubernetes concepts and chapter sections on queues, replication, caching and scaling. | Build a small local design/implementation slice or detailed sequence simulation. | Explain which guarantees belong to the database, queue, application and client. |

## Weeks 17–20 — Architecture and trade-off analysis

| Week | Study | Practical work | Checkpoint |
|---:|---|---|---|
| 17 | Chapter 5: architectural drivers and quality attribute scenarios; CMU architecture lecture. | Lab 10, parts 1–2: write scenarios and identify drivers. | Each quality attribute has a measurable stimulus/response scenario. |
| 18 | Styles, patterns, tactics, modularity and deployment; read selected AOSA chapters. | Draw C4 context/container/component views. | Explain why each major component or boundary exists. |
| 19 | arc42, ADRs, architecture documentation and architecture fitness functions. | Write three ADRs with context, alternatives, decision and consequences. | Another engineer can reconstruct why the design was selected. |
| 20 | SEI ATAM/QAW and cost-benefit trade-off material; compare cloud framework checklists. | Complete trade study and architecture review. | Identify risks, sensitivity points and conditions that would change the choice. |

## Weeks 21–24 — Reliability, SRE and incident response

| Week | Study | Practical work | Checkpoint |
|---:|---|---|---|
| 21 | Chapter 6 reliability measures; read selected *Practical Reliability Engineering* sections if available. | Lab 11: availability calculation and reliability block diagram. | State exactly which system path the availability figure represents. |
| 22 | FMEA, FTA, Weibull/life data, maintainability and FRACAS. | Complete FMEA and fault tree; identify common-cause assumptions. | Separate measured failure data from expert estimates. |
| 23 | Google SRE Workbook and Google SRE Classroom Art of SLOs; OpenTelemetry docs. | Lab 12: SLI/SLO, alerts and telemetry plan. | Explain how an error budget relates to user-visible service quality. |
| 24 | Incident command, postmortems, backup/restore, RTO/RPO and recovery testing. | Labs 13–15 and final capstone review. | Present the dossier, incident runbook and restore evidence. |

## Milestones

| End of week | You should have |
|---:|---|
| 4 | Tested system-dynamics model |
| 8 | CONOPS, system context, functional decomposition and mini PDR package |
| 12 | SRS, prioritised baseline, traceability matrix and acceptance tests |
| 16 | API contract, data model and consistency/failure design |
| 20 | C4 architecture, ADRs, trade study and architecture review |
| 24 | Reliability analysis, SLO/observability plan, incident runbook, restore drill and capstone dossier |

## Revision strategy

At the end of each four-week module, close the notes and answer these from memory:

1. What is the purpose of this discipline?
2. What are its main concepts and artefacts?
3. What decisions does it enable?
4. What common mistakes make the work unreliable?
5. Which evidence proves that the artefact is useful?
6. How does this module constrain or inform the next one?

Use the labs as the practical exam. Re-do any task for which you cannot defend the assumptions or explain the evidence.

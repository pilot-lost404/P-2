# Course V — Software Architecture and Trade-off Analysis

**Academic level:** Upper-division undergraduate / introductory graduate  
**Suggested duration:** 13 teaching weeks  
**Prerequisites:** Software design, requirements engineering, databases and distributed-systems fundamentals  
**Core question:** How do we choose, document and evaluate a system's major structures so that it satisfies competing quality goals over time?

---

## Course description

Software architecture is the set of fundamental structures of a software-intensive system: the elements, their externally visible properties, relationships, constraints and principles that guide design and evolution. Architecture concerns the decisions that have broad consequences for system qualities, team organisation, deployment and future change.

This course treats architecture as a reasoning discipline rather than a diagramming exercise. Students learn how to identify architectural drivers, define quality-attribute scenarios, generate alternatives, select styles and tactics, document decisions, and evaluate consequences using structured methods such as Attribute-Driven Design (ADD), the Architecture Tradeoff Analysis Method (ATAM) and the Cost Benefit Analysis Method (CBAM).

The running case is a campus equipment platform growing from a small application into a multi-department service with separate ownership, audit requirements, external dependencies and availability goals. The aim is not to make the architecture “enterprise-grade” by adding components. It is to choose the least complex architecture that can credibly meet validated requirements and evolve under foreseeable change.

## Learning outcomes

By the end of the course, a student should be able to:

1. Explain the role and scope of software architecture and distinguish architecture from low-level design and implementation.
2. Identify architectural drivers from business goals, constraints, functional requirements and quality attributes.
3. Write measurable quality-attribute scenarios for performance, availability, security, modifiability, testability and interoperability.
4. Select and justify architectural styles, patterns and tactics based on the system context.
5. Model and document architecture using views, viewpoints, context diagrams, C4 and 4+1-style representations.
6. Apply a repeatable architecture design method such as ADD.
7. Capture consequential choices in Architecture Decision Records (ADRs).
8. Evaluate architectural alternatives using ATAM concepts, sensitivity points, trade-off points and risks.
9. Use cost-benefit and uncertainty analysis to support investment decisions.
10. Govern architecture evolution through fitness functions, technical debt management and review practices.

## Lecture sequence

| Lecture | Topic | Required output |
|---:|---|---|
| 1 | Architecture fundamentals and decision scope | System context and architecture scope |
| 2 | Architectural drivers and requirements | Ranked driver set |
| 3 | Quality attributes and scenarios | Quality-attribute utility tree |
| 4 | Architectural styles and patterns | Candidate style comparison |
| 5 | Architecture tactics | Tactic-to-quality mapping |
| 6 | Modularity, boundaries and interfaces | Component and dependency model |
| 7 | Views, viewpoints and documentation | C4 / logical / deployment views |
| 8 | Attribute-Driven Design and synthesis | ADD iteration record |
| 9 | ADRs and architecture governance | Decision log |
| 10 | ATAM and architecture evaluation | Evaluation workshop report |
| 11 | CBAM, cost, risk and uncertainty | Cost-benefit trade study |
| 12 | Architecture fitness, debt and evolution | Fitness-function and evolution plan |

---

# Part I — Architecture as a decision discipline

## 1. What software architecture describes

Architecture captures structures that are important to reason about the system. A structure may describe runtime components and connectors, development modules, deployment nodes, data ownership, security zones, layers, dependencies or the way teams own services.

A decision is architecturally significant when it has broad consequences for quality attributes, system evolution, cost, risk, organisational coordination or compliance. Examples include:

- selecting a relational data store as the authoritative source for reservation state;
- choosing a single deployment unit or independently deployable services;
- defining service boundaries and data ownership;
- choosing synchronous request-response or asynchronous event communication;
- deciding how identity and authorisation are enforced;
- selecting a consistency model for replicated data;
- defining the deployment topology and failure domains.

Not every design decision belongs in architecture documentation. The goal is to preserve decisions whose consequences are difficult or expensive to reverse and whose rationale is needed by future engineers.

### 1.1 Architecture versus detailed design

Architecture describes high-impact structures and constraints. Detailed design specifies algorithms, classes, data structures, component internals and local implementation choices. The boundary is contextual. A database index may be a local design decision in a small service, but an important architectural decision in a latency-critical data platform with strict resource constraints.

Architecture should guide detail without prescribing every line of code. If architecture documentation becomes a complete implementation specification, it can be expensive to maintain and may constrain local optimisation unnecessarily.

### 1.2 Architecture and system qualities

Architecture affects qualities that are observable at system level:

- response time and throughput;
- availability and resilience;
- security and privacy;
- modifiability and deployability;
- interoperability;
- testability and diagnosability;
- usability and accessibility;
- scalability and cost efficiency.

Quality attributes are not independent. A design that duplicates data to improve read availability may make consistency and data governance harder. A fine-grained service architecture may improve independent deployment but increase network latency and operational burden.

## 2. Architectural drivers

An architectural driver is a requirement, constraint or context factor that materially influences architecture. It may be functional, but it is often a quality attribute, external constraint or risk.

Common drivers include:

1. business or mission outcomes;
2. stakeholder priorities;
3. quality-attribute requirements;
4. regulatory, safety, privacy or contractual obligations;
5. technical constraints and existing infrastructure;
6. team skills and organisational ownership;
7. expected evolution and uncertainty;
8. operational and life-cycle cost;
9. schedule and delivery risk.

A long requirement list does not reveal which requirements should shape architecture. Analyse the requirements and identify the small subset that creates the strongest design pressure.

### 2.1 Architectural significance

A useful test is:

- Would this requirement affect the choice of architectural style or a major component boundary?
- Would failure to meet it create significant business, safety, legal or operational harm?
- Does it constrain several components or teams?
- Would changing it later cause broad rework?
- Does it introduce uncertainty that should be resolved early?

A requirement may be important to a product but not architecturally significant. For example, the exact label text on a button is usually not an architectural driver. A requirement that all operations work offline for 30 minutes may be.

## 3. Quality attributes and scenarios

Quality attributes should be stated as measurable scenarios. Labels such as “high performance” or “secure architecture” do not give engineers enough information to design or test.

A six-part quality-attribute scenario contains:

1. **Stimulus source:** actor or external source.
2. **Stimulus:** event or condition.
3. **Environment:** operating context.
4. **Artifact:** system, service, component or interface affected.
5. **Response:** what the architecture does.
6. **Response measure:** measurable success criterion.

### 3.1 Performance scenario

Example: During the registration peak, an authenticated user searches for available equipment. Under 1,000 concurrent sessions and the defined data set, the inventory query completes within the agreed p95 and p99 latency budgets, while reservation correctness remains intact.

The workload profile must define request mix, data volume, geographic distribution, concurrency and dependency conditions. A target without a workload profile is incomplete.

### 3.2 Availability scenario

Example: If one application instance fails during normal operation, the deployment platform routes new requests to healthy instances within a defined detection and recovery interval, with no committed reservation lost and no conflicting reservation created.

Availability can be expressed as a proportion of time or valid requests, but the time window and measurement method must be clear. Recovery time, data loss and correctness are separate measures.

### 3.3 Security scenario

Example: If an unauthorised principal attempts to access a private file, the access-control mechanism denies the request, records a security event without disclosing sensitive content, and exposes the event to the security monitoring system within a defined interval.

Security scenarios should be derived from threat modelling, assets, trust boundaries and abuse cases. “The system shall be secure” is not verifiable.

### 3.4 Modifiability scenario

Example: When the university adds a new equipment category and its eligibility rules change, the team can update the policy module and relevant tests without modifying unrelated reservation and notification logic, within an agreed engineering effort.

The response measure might be change lead time, number of affected modules, regression-test impact or deployment coordination. It must reflect a real stakeholder concern.

### 3.5 Testability and diagnosability

A system is testable when its state and behaviour can be observed and controlled sufficiently for meaningful tests. Diagnosability concerns the ability to identify causes of failure. Architecture supports these attributes through clear module boundaries, deterministic interfaces, telemetry, dependency injection, test environments, stable test data and explicit failure handling.

## 4. Architectural styles and patterns

An architectural style describes a family of structural organisation and interaction rules. A pattern describes a recurring problem and a reusable solution with known consequences. Neither is a universal recipe.

### 4.1 Layered architecture

A layered system organises responsibilities into layers such as presentation, application, domain and infrastructure. The approach can simplify separation of concerns and testing, but strict layering may introduce unnecessary pass-through code or constrain performance-critical interactions.

### 4.2 Hexagonal / ports-and-adapters architecture

The domain core defines ports representing required and provided interactions. Adapters implement those ports for databases, APIs, user interfaces, message brokers or external systems. This can isolate domain logic from infrastructure choices and improve testability. It does not automatically solve distributed consistency or poor domain modelling.

### 4.3 Modular monolith

A modular monolith is deployed as one unit but organised into explicit modules with controlled dependencies and data ownership. It can preserve simple transactions and reduce operational overhead while supporting internal boundaries. Its success depends on enforcing the boundaries rather than allowing every module to access every other module's internals.

### 4.4 Microservices

Microservices are independently deployable services organised around bounded contexts or capabilities, often with independent data ownership. Benefits may include autonomy, scaling isolation and technology choice. Costs include network calls, partial failure, distributed transactions, observability, deployment automation, service discovery, security policy and on-call complexity.

Microservices are not inherently more scalable than a well-designed monolith. They are a socio-technical architecture whose benefits depend on organisational capability and workload.

### 4.5 Event-driven architecture

In an event-driven system, components communicate through events that describe facts that have occurred. This can decouple producers and consumers and support asynchronous workflows. It introduces eventual consistency, event schema evolution, replay, ordering and duplicate-handling questions.

### 4.6 Pipe-and-filter and dataflow styles

A pipe-and-filter system transforms data through stages. It can support streaming and batch processing but requires careful management of backpressure, data contracts, failure recovery and ordering.

### 4.7 Microkernel / plug-in architecture

A minimal core provides stable extension points. Plug-ins add capabilities. This is useful when variants or third-party extensions are important, but extension contracts, isolation, version compatibility and security boundaries become central concerns.

### 4.8 Choosing a style

Choose a style by matching it to the drivers and evaluating the consequences. Avoid selecting microservices because a company of a different size or maturity uses them. A small team with one product and one deployable service may benefit from a modular monolith. A large organisation with independent domains, mature platform tooling and high operational capability may justify service decomposition.

## 5. Architecture tactics

A tactic is a design decision intended to influence a quality attribute. Patterns combine tactics into broader structures.

### 5.1 Availability tactics

- detect faults using health checks, heartbeats or monitoring;
- recover through restart, failover, retry, rollback or state restoration;
- prevent faults through isolation, redundancy or input validation;
- limit damage through bulkheads and failure containment;
- provide graceful degradation for non-critical capabilities.

Redundancy is useful only if replicas do not share the same dominant failure mode. Two services in one failure domain with identical bad configuration are not independent backups.

### 5.2 Performance tactics

- reduce work through caching or precomputation;
- improve throughput via concurrency, batching or parallelism;
- reduce communication through locality and efficient protocols;
- allocate capacity through queues, resource pools and load balancing;
- avoid contention through data partitioning or reduced shared state.

Performance tactics must be evaluated against consistency, freshness, cost and operational constraints.

### 5.3 Security tactics

- authenticate identities and services;
- authorise every protected operation;
- isolate trust zones;
- minimise privileges and retained data;
- protect data in transit and at rest;
- validate and constrain inputs;
- record security-relevant events;
- rotate and protect secrets;
- reduce attack surface and dependency exposure.

Security architecture includes failure handling. A system must define what happens when identity services, key-management services or policy engines are unavailable.

### 5.4 Modifiability tactics

- encapsulate volatile decisions;
- separate responsibilities and concerns;
- use stable interfaces and explicit contracts;
- limit dependencies and shared mutable state;
- defer binding where flexibility is valuable;
- maintain automated compatibility tests.

Excessive abstraction can increase complexity. Encapsulation should protect a real change boundary, not simply create more interfaces.

## 6. Modularity, coupling and cohesion

A module should have a coherent responsibility and a clear interface. **Cohesion** concerns how strongly the responsibilities within a module belong together. **Coupling** concerns dependencies among modules. A design generally benefits from high cohesion and manageable coupling, but these are qualitative concepts that require context.

A component boundary should consider:

- domain concepts and change ownership;
- data invariants and transaction scope;
- security and trust boundaries;
- performance and latency;
- failure isolation;
- deployment and scaling needs;
- team ownership and operational responsibility.

A common microservice failure is to split a system by technical layer rather than business capability, creating chatty service calls and coordinated releases. A common monolith failure is to let modules share tables and internal classes without ownership boundaries.

### 6.1 Dependency direction

Stable domain logic should generally not depend on volatile infrastructure details. Dependency inversion and ports-and-adapters can help keep the core independent of a particular database or messaging provider. However, a completely abstracted interface may hide capabilities the system needs. Abstraction should preserve required semantics rather than erase them.

## 7. Architecture views and documentation

A view is a representation of a system from a particular perspective. A viewpoint defines the conventions, concerns and stakeholders for that view. No single diagram describes an entire architecture.

Useful views include:

- context: system boundary and external actors;
- logical/component: responsibilities and dependencies;
- runtime/process: interactions and concurrency;
- development/module: source organisation and dependencies;
- deployment: processes, nodes, networks and failure domains;
- data: ownership, flows, stores and lifecycle;
- security: assets, trust boundaries and controls;
- operational: monitoring, recovery and support.

### 7.1 C4 model

C4 provides four zoom levels:

1. **System context:** people and external systems around the system.
2. **Container:** deployable or runtime units and major data stores.
3. **Component:** major responsibilities within a container.
4. **Code:** implementation-level structures where useful.

C4 diagrams should state scope and audience. A context diagram is not an exhaustive deployment view. A container diagram should identify technology only where it is relevant to understanding the architecture.

### 7.2 4+1 and other view models

A 4+1-style model separates logical, process, development and physical/deployment views, with use cases or scenarios tying them together. Alternative viewpoints may be more appropriate for safety, data or operational concerns. The essential discipline is to identify which stakeholder question each view answers.

### 7.3 Documentation quality

Architecture documentation should include:

- context and scope;
- architectural drivers;
- views and elements;
- interfaces and responsibilities;
- quality-attribute scenarios;
- decisions and rationale;
- constraints and assumptions;
- risks and known trade-offs;
- deployment and operations;
- unresolved questions and change history.

A diagram without element descriptions, interface semantics or decision rationale may create false confidence.

## 8. Attribute-Driven Design (ADD)

ADD is a method for designing architecture by decomposing the system based on quality-attribute requirements and functional requirements. The design process repeatedly selects an element to decompose, identifies drivers, chooses architectural patterns or tactics, and allocates responsibilities and interfaces.

A simplified iteration is:

1. confirm system scope and architectural drivers;
2. select an element or subsystem for decomposition;
3. identify applicable quality scenarios and constraints;
4. generate or select architectural tactics and patterns;
5. instantiate responsibilities and interfaces;
6. record decisions and risks;
7. check whether requirements and quality scenarios are addressed;
8. repeat until the architecture is sufficiently detailed for its purpose.

ADD encourages quality attributes to influence structure early rather than being tested only after implementation. It is not a one-time algorithm that automatically generates a correct architecture.

## 9. Architecture Decision Records (ADRs)

An ADR records a consequential decision, the context that motivated it, alternatives considered, rationale and consequences. It should be concise enough to maintain and detailed enough to explain the choice later.

A typical ADR contains:

- title and status;
- context and drivers;
- decision;
- alternatives considered;
- positive and negative consequences;
- risks and assumptions;
- revisit triggers;
- links to related requirements and records.

Example:

### ADR-004 — Use a relational database for authoritative reservation state

**Context:** The reservation domain has a no-overlap invariant, audit requirements and relationships among users, items and reservations.  
**Decision:** Use a relational database as the authoritative store for reservation commits.  
**Alternatives:** document database; distributed key-value store; separate database per service.  
**Rationale:** relational constraints and transactions simplify enforcement of key invariants for the current scale and team.  
**Consequences:** database availability and migration are critical; reporting and search may require read models; future partitioning needs a separate design.  
**Revisit triggers:** sustained workload beyond validated capacity, new multi-region write requirement, or organisational need for independent data ownership.

ADRs should record what was decided, not only what was built. “We use PostgreSQL” is not enough without rationale and consequences.

## 10. ATAM: architecture evaluation

The Architecture Tradeoff Analysis Method (ATAM), developed by the Carnegie Mellon Software Engineering Institute, evaluates architectural approaches against quality-attribute requirements and stakeholder goals. It is useful when several quality attributes interact and when decisions need structured review.

A simplified evaluation flow is:

1. present the evaluation purpose and participants;
2. present business drivers and architectural scope;
3. present the architecture;
4. identify architectural approaches;
5. build and prioritise a quality-attribute utility tree;
6. analyse architectural approaches against important scenarios;
7. identify risks, non-risks, sensitivity points and trade-off points;
8. summarise findings, issues and recommendations.

A **sensitivity point** is an architectural decision or parameter that significantly affects a quality response. A **trade-off point** affects more than one quality attribute, often improving one while worsening another. A **risk** is an architectural choice with the potential to cause undesirable outcomes; a non-risk is a well-supported decision that appears to satisfy a goal under stated assumptions.

ATAM is not a performance benchmark and does not produce a universal architecture score. Its value is the systematic discovery of risks and trade-offs through scenarios and stakeholder analysis.

### 10.1 Utility trees

A utility tree structures quality goals into attributes, refinements and concrete scenarios. Scenarios can be prioritised by business importance and technical difficulty. This helps the evaluation focus on the cases most likely to expose architectural weaknesses.

Example:

- Availability
  - failure recovery
    - if one application node fails during peak reservation use, traffic is redirected to healthy nodes within 30 seconds and no committed reservation is lost.
- Modifiability
  - policy evolution
    - add a new equipment eligibility rule without changing the reservation consistency mechanism or unrelated modules.
- Security
  - unauthorised access
    - deny access to a private reservation record and emit an auditable event.

The measures are illustrative and require stakeholder validation.

## 11. CBAM, cost and uncertainty

The Cost Benefit Analysis Method (CBAM) extends architecture evaluation by considering the economic consequences of architectural strategies. It helps compare the costs of tactics with their expected benefits in quality attributes or business outcomes.

A simple expected-value framing is:

\[
EV=\sum_i p_i V_i
\]

where \(p_i\) is the probability of outcome \(i\) and \(V_i\) is its value or consequence. The actual analysis may use discounted cash flows, utility, risk-adjusted benefit or stakeholder-specific valuations. Uncertain probabilities should be shown as ranges or scenarios.

A design that improves availability from 99.5% to 99.9% may have substantial value for a high-impact service but little value for a low-criticality internal tool if the cost of redundancy, staffing and testing is disproportionate. The business context matters.

### 11.1 Trade-study hygiene

- distinguish hard constraints from preferences;
- avoid double-counting related criteria;
- document how ratings were produced;
- test sensitivity to weights and uncertain estimates;
- show absolute costs as well as normalised scores;
- identify unacceptable risks that cannot be compensated by other strengths;
- account for operating and migration costs;
- record why rejected alternatives were rejected.

## 12. Architecture fitness functions and evolution

An architecture fitness function is an automated or repeatable check that provides evidence about an architectural characteristic. Examples include dependency-rule tests, API compatibility checks, security policy scans, deployment-time budgets, performance regression tests, data ownership checks or resilience experiments.

Fitness functions should be linked to architectural intent. A test that merely checks whether a package exists is not a useful fitness function unless the package itself represents a meaningful architectural rule.

Architecture changes as requirements, technologies, teams, threats and operational constraints evolve. Architecture debt is the future cost or risk created by a design choice or undocumented shortcut. It can be deliberate or accidental. A debt register should describe the mechanism, affected quality, cost of inaction, owner, mitigation options and revisit trigger.

Avoid treating all duplication as bad debt or all abstraction as good architecture. Sometimes a small amount of duplication reduces coupling and makes independent change safer. Sometimes a shared library becomes a central bottleneck.

## 13. Integrated case study: selecting the platform architecture

### 13.1 Drivers

The campus equipment platform has the following validated drivers for the case:

- prevent double-booking;
- provide an auditable reservation history;
- support peak registration demand;
- integrate with an external identity provider;
- allow policy changes by category and department;
- recover reservation and audit data after infrastructure loss;
- keep operational burden manageable for a small team.

### 13.2 Candidate alternatives

**A — Modular monolith:** one deployable application, clear internal modules, relational authoritative database and outbox for events.  
**B — Service decomposition:** separate identity integration, inventory, reservation, notification and reporting services with independent deployment and data ownership.  
**C — Managed platform:** adopt a vendor equipment system and build limited extensions and reporting around it.

### 13.3 Qualitative comparison

| Concern | A: Modular monolith | B: Services | C: Managed platform |
|---|---|---|---|
| Transactional reservation invariant | Relatively straightforward | More complex if state spans services | Depends on vendor semantics |
| Independent deployment | Limited | Strong | Vendor-controlled |
| Initial operational burden | Lower | Higher | Lower in some areas, integration remains |
| Vendor dependency | Low–medium | Low–medium | High |
| Team autonomy | Moderate | Requires multiple ownership boundaries | Limited by vendor product |
| Scaling | Scale application and database | Scale services independently | Depends on platform tier and contract |

The table is a starting hypothesis. It requires evidence from workload analysis, vendor evaluation, security review, operations and cost. If the team is small and the workload moderate, alternative A may be the best initial design. The architecture should preserve modular boundaries so that future extraction is possible only where evidence justifies it.

### 13.4 ATAM-style scenarios

Evaluate the three alternatives against reservation correctness under concurrent writes, recovery after database failure, an identity provider outage, policy change lead time, peak registration load and notification-provider outage. Identify which decisions are sensitivity points and which create cross-attribute trade-offs.

## 14. Problem set

### Problems

**1.** Explain why architecture is more than a collection of diagrams. Identify four architectural decisions and the quality attributes they affect.

**2.** Write one six-part quality scenario each for availability, security and modifiability for the equipment platform.

**3.** Compare a modular monolith and microservices for a small engineering team. Include organisational and operational consequences, not only technical structure.

**4.** Identify two availability tactics and explain their failure modes. Why is redundancy across a shared failure domain weak?

**5.** Draw context, container and component views for a reservation system. Explain the question answered by each view and at least one thing each view intentionally omits.

**6.** Draft an ADR for choosing a relational database as the authoritative reservation store. Include at least two alternatives and revisit triggers.

**7.** Explain sensitivity points and trade-off points with an example involving availability and consistency.

**8.** A proposed change increases expected availability but adds operational cost. Describe a CBAM-style analysis and the information needed before recommending it.

**9.** Design three architecture fitness functions for a system with service boundaries, API compatibility and deployment safety.

### Solution sketches

**1.** Architecture is a reasoned model of structures, constraints and high-impact decisions. Example decisions: service boundaries affect modifiability and team autonomy; database strategy affects consistency and availability; deployment topology affects failure isolation; identity integration affects security and interoperability.

**2.** Each scenario should identify stimulus source, stimulus, environment, artifact, response and measure. For availability, include failure detection, failover and recovery time. For security, include a threat actor and denial/audit response. For modifiability, include a concrete policy or category change and affected components or effort measure.

**3.** A monolith reduces deployment and distributed transaction complexity, and may suit a small team. Microservices create independent deployment but require on-call ownership, observability, service contracts, network failure management, security policy and automation. A service split without autonomous team ownership often increases coordination cost.

**4.** Redundancy provides alternate capacity; retry can recover from transient faults but can amplify overload. Failover can reduce downtime but may use stale data. If replicas share a region, power supply, network or bad configuration, one event can fail them together.

**5.** Context view shows users and external systems. Container view shows deployables, databases and message infrastructure. Component view describes responsibilities inside a container. Each view omits detail irrelevant to its level; none should be used as an all-purpose architecture picture.

**6.** Record need for relational constraints and transactions, alternatives, operational skills, migration risks and conditions under which scale or multi-region requirements justify reconsideration.

**7.** A leader-based reservation write path may preserve a unique reservation invariant, but during a partition only a side with coordination quorum can commit. The coordination and quorum parameters are sensitivity points; availability and consistency form a trade-off under the partition scenario.

**8.** Define the availability gain, impacted stakeholder outcomes, outage cost, cost of redundancy, operating cost, probability assumptions, risk reduction, sensitivity and alternatives. Do not assume every extra nine is worth the same amount.

**9.** Examples: test that domain modules cannot depend on forbidden infrastructure packages; run consumer-driven contract tests for supported API versions; require canary and rollback evidence before production rollout.

## 15. Practical assignment

Produce an architecture decision and evaluation package for the campus equipment platform:

1. architectural driver list and ranked quality-attribute utility tree;
2. at least two architecture alternatives with context, component and deployment views;
3. three or more ADRs;
4. ADD design iteration record;
5. ATAM-style evaluation workshop and risk themes;
6. cost-benefit analysis with sensitivity and uncertainty;
7. architecture documentation using C4 and arc42 sections;
8. fitness-function plan;
9. technical debt and evolution roadmap;
10. a written recommendation that states assumptions and unresolved risks.

## Further reading and primary course materials

- Len Bass, Paul Clements and Rick Kazman, *Software Architecture in Practice*, 4th ed. (2021). Core advanced reference; publisher/library access.
- Mark Richards and Neal Ford, *Fundamentals of Software Architecture* (2020). Practical architecture concepts and trade-offs.
- Carnegie Mellon, [Software Architecture in Practice / Software Architecture course material](https://mse.s3d.cmu.edu/0_documents/syllabi/17635-software-architectures-2026-syllabus-v1.01.pdf): 2026 graduate course syllabus.
- CMU SEI, [Software Architecture Design and Analysis](https://www.sei.cmu.edu/training/software-architecture-design-analysis/): professional training; may be paid.
- CMU SEI, [ATAM technical report collection](https://www.sei.cmu.edu/library/architecture-tradeoff-analysis-method-collection/): open reports and case studies.
- [C4 Model](https://c4model.com/): original architecture diagramming reference.
- [arc42](https://docs.arc42.org/home/): open architecture documentation template and examples.
- [Architecture Decision Records](https://adr.github.io/): ADR guidance and templates.
- Martin Fowler, [Software Architecture Guide](https://martinfowler.com/architecture/): practitioner essays and references.
- Chris Richardson, [Microservices Patterns](https://microservices.io/patterns): pattern descriptions and consequences.


---

# Advanced lecture notes and worked extensions

## 16. Architecture design as an iterative problem-solving process

Architecture should be designed in iterations. Each iteration addresses a limited set of drivers and reduces important uncertainty. A common mistake is to attempt to design every component before validating the highest-risk architectural assumptions.

A practical sequence is:

1. establish system scope and context;
2. collect business, functional, quality and constraint drivers;
3. prioritise architecturally significant requirements;
4. select the element or concern to decompose;
5. generate candidate mechanisms and patterns;
6. define responsibilities, interfaces and interactions;
7. analyse effects on quality scenarios;
8. record risks and decisions;
9. test the decision using an experiment, prototype or analysis where possible;
10. repeat at a finer level only where needed.

This sequence is compatible with ADD, but the design process is not purely linear. A load test may change the architecture; a threat model may reveal a new trust boundary; a team ownership decision may change service decomposition.

## 17. Worked ATAM-style utility tree

Assume the equipment service must support peak registration, protect reservation integrity and allow eligibility policy changes. A simplified utility tree may be structured as follows:

| Quality | Refinement | Scenario | Business priority | Technical difficulty |
|---|---|---|---|---|
| Availability | Dependency failure | Identity provider unavailable during reservation | High | Medium |
| Performance | Peak load | p95 reservation response meets approved target at registration peak | High | High |
| Security | Unauthorised access | Non-owner attempts to modify another user's reservation | Very high | Medium |
| Modifiability | Policy change | Add a department-specific eligibility rule without changing reservation invariants | High | Medium |
| Recoverability | Data loss | Restore reservation and audit state to required RPO within RTO | Very high | High |

This table directs the evaluation toward scenarios that matter. The priority reflects stakeholder value; difficulty reflects the engineering challenge. The combination helps determine which scenarios deserve deeper analysis.

## 18. Sensitivity and trade-off points

Consider a service that uses a cache to reduce inventory search latency. The cache time-to-live is a design parameter. A longer value may improve performance but increase stale availability results. A shorter value may reduce staleness but increase database load.

The cache lifetime is a **sensitivity point** because it materially affects performance and correctness. It is a **trade-off point** because changing it influences both attributes. The architecture evaluation should identify the acceptable staleness bound, measure database headroom and enforce the reservation invariant in the authoritative write path.

Another example is synchronous versus asynchronous notification. Synchronous delivery simplifies the user-visible sequence but increases reservation latency and makes availability depend on the notification provider. Asynchronous delivery improves isolation but creates eventual consistency, retries, duplicate handling and message-age monitoring.

## 19. Quantitative architecture trade-off example

Suppose three alternatives are scored on a 1–5 benefit scale. Criteria weights sum to one:

| Criterion | Weight |
|---|---:|
| Correctness / integrity | 0.30 |
| Availability | 0.25 |
| Modifiability | 0.20 |
| Operational simplicity | 0.15 |
| Life-cycle cost | 0.10 |

Illustrative scores:

| Alternative | Correctness | Availability | Modifiability | Simplicity | Cost | Weighted score |
|---|---:|---:|---:|---:|---:|---:|
| Modular monolith | 5 | 4 | 3 | 5 | 5 | 4.35 |
| Microservices | 3 | 4 | 5 | 2 | 2 | 3.45 |
| Managed platform | 4 | 4 | 2 | 4 | 3 | 3.60 |

The modular monolith ranks highest under these weights. The result should not be treated as a fact about the alternatives; it follows from the assumed scores and weights. Perform at least three sensitivity checks:

1. increase modifiability weight if multiple independent teams are expected;
2. reduce operational simplicity if the current team has mature SRE/platform capability;
3. vary life-cycle cost assumptions for the managed platform.

If the recommended alternative changes under small plausible weight adjustments, the decision is sensitive and the project should gather better evidence or defer commitment until a high-risk assumption is tested.

## 20. Technical debt as an architecture management problem

Technical debt is the future cost of constrained change, rework, reliability risk or operational effort created by a current decision or omission. It can be deliberate, accidental, strategic or unavoidable.

A useful debt record identifies:

- the design shortcut or constraint;
- the reason it was accepted;
- affected quality attributes;
- current symptoms and measurable cost;
- likelihood and consequence of continued deferral;
- owner and mitigation options;
- trigger or date for reassessment.

A debt register should not become a list of disliked code. It should support prioritisation. A small duplicated function may be cheaper and safer than a shared abstraction that couples independent domains. Conversely, duplicated security logic may create a serious consistency risk.

## 21. Architecture conformance and fitness functions

A fitness function tests an architectural rule or quality objective. Examples:

- a dependency test prohibits domain modules from importing infrastructure packages;
- a consumer-driven contract test verifies supported API compatibility;
- an automated deployment check requires rollback evidence and health gates;
- a security test checks access-control decisions for critical data paths;
- a load test checks a defined latency profile;
- a resilience experiment verifies that loss of a non-critical dependency does not block reservation commits.

Fitness functions need owners, thresholds, environments and response policies. A flaky test that is ignored creates the appearance of governance without real assurance.

## 22. Extended review questions

1. When should an architecture decision be deferred, and what evidence can reduce the uncertainty?
2. Explain why an architecture score cannot compensate for a violation of a mandatory safety or legal constraint.
3. Identify a sensitivity point and trade-off point in a cache or messaging design.
4. What makes a fitness function architecturally meaningful rather than merely convenient to automate?
5. How would you distinguish a deliberate architecture debt item from an accidental design defect?
6. What evidence should an architecture review require before a service boundary is approved?
## 23. Worked ATAM-style evaluation: from quality tree to risk themes

ATAM is a structured method for evaluating architecture against quality-attribute scenarios. It is not a generic checklist and does not certify an architecture as “good”. Its value is in exposing the reasoning, assumptions, risks, sensitivity points and trade-off points that follow from concrete scenarios.

### 16.1 Prepare the evaluation

The evaluation needs a defined system scope, business drivers, architecture description, stakeholders and representative quality scenarios. A diagram-only description is insufficient: the team must explain decisions, constraints, operational assumptions, dependencies and deployment boundaries.

### 16.2 Build a prioritised utility tree

A utility tree refines broad quality attributes into specific scenarios. Prioritisation should consider at least business importance and technical difficulty. Example:

| Attribute/refinement | Scenario | Business importance | Technical difficulty |
|---|---|---:|---:|
| Availability / reservation continuity | During registration peak, one application node fails; new requests are routed to healthy instances without losing a committed reservation | High | Medium |
| Performance / search latency | At the agreed peak workload and data volume, inventory search meets the defined p95 and p99 targets | High | Medium |
| Security / privilege boundary | A student attempts to alter a reservation owned by another user; the request is denied and audited without disclosing record data | High | Medium |
| Modifiability / policy change | A new department eligibility policy is introduced without modifying reservation persistence or notification delivery | Medium | High |
| Recoverability / data restoration | Following loss of the primary database, the service is restored within validated RTO/RPO limits and reconciliation confirms reservation integrity | High | High |

The table is not a numerical scoring system unless the stakeholders define one. Importance and difficulty labels guide workshop attention; they do not create precise probabilities.

### 16.3 Analyse architectural approaches

For each high-priority scenario:

1. identify the architectural decisions that affect the response;
2. state the mechanism by which each decision is expected to satisfy the scenario;
3. state assumptions and dependencies;
4. identify a sensitivity point where a decision materially affects a quality response;
5. identify a trade-off point where one decision affects multiple qualities in different directions;
6. identify a risk where the argument depends on uncertain or unsupported assumptions;
7. define the evidence needed to retire or accept the risk.

**Example:** A relational database with one authoritative reservation write path helps preserve the no-overlap invariant. It is a sensitivity point for correctness. During a database or quorum outage, rejecting writes can reduce availability; that is a trade-off point. If the design assumes a replica is synchronous but the actual deployment is asynchronous, the zero-data-loss claim is a risk. The evaluation should require a documented replication mode and a failover test before accepting the claim.

### 16.4 ATAM report structure

A useful report records: scope and participants; business drivers; architecture summary; utility tree and selected scenarios; analysed decisions; sensitivity points; trade-off points; risks and non-risks; unresolved assumptions; recommended experiments; and owners/dates for follow-up. Separate observed evidence from architect judgement.

## 24. Architecture decision quality and fitness-function design

A decision record should preserve context, the problem, options considered, decision, rationale, positive and negative consequences, assumptions, evidence and revisit triggers. The existence of an ADR does not prove that a decision was sound. Its value is that a future team can understand why it was made and what would invalidate it.

A good fitness function tests an architectural property that matters to the system. For the equipment platform:

| Architectural intent | Fitness function | False confidence to avoid |
|---|---|---|
| Reservation state has one authority | Integration test concurrent conflicting requests against the production database engine | Passing a mocked repository test |
| Modules preserve boundaries | Static dependency rule forbids domain code from importing web or infrastructure packages | Checking only package names |
| APIs remain compatible | Consumer contract tests across supported client versions | Testing only the server's own generated client |
| Recovery is demonstrable | Scheduled restore drill with integrity and RTO/RPO evidence | A green backup-job status |
| Deployment is safe | Automated canary analysis and rollback rehearsal | Assuming a successful container build proves release safety |

Fitness functions should be automated where feasible, but some architectural qualities require scenario-based human evaluation. A threat review, ATAM workshop or usability assessment cannot be replaced by a single unit test.

## 25. Additional examination problems

1. Build a utility tree with at least four concrete scenarios. Explain how importance and difficulty are assigned and who should participate.
2. For a shared database used by multiple services, identify one sensitivity point, one trade-off point and one architectural risk.
3. Write an ADR for a modular monolith that includes two rejected alternatives and explicit revisit triggers.
4. Design a fitness function for an operational quality that cannot be proven by a unit test alone.
5. Explain why a weighted score must not allow a candidate that violates a mandatory safety or legal constraint to win.


## 26. ATAM-style evaluation as a facilitated technical investigation

The Architecture Tradeoff Analysis Method (ATAM) is not a scoring spreadsheet and not a design approval ceremony. It is a structured evaluation that reveals how architectural decisions affect quality attributes, identifies sensitivity and trade-off points, and exposes risks relative to business and technical drivers. A self-study learner can conduct a disciplined small-scale ATAM-style workshop, but should not claim to have performed a formal SEI evaluation unless the method, participants and facilitation requirements are actually met.

### 26.1 Inputs

Prepare the following before the workshop:

- business and mission goals;
- architecture scope and context;
- constraints and assumptions;
- primary architectural approaches and key decisions;
- quality-attribute scenarios with stimulus, source, environment, response and measurable response measure;
- known risks, technical debt and unresolved questions.

A scenario should be testable. “The service is fast” is not an evaluable scenario. “At 500 concurrent active sessions during registration peak, 95% of reservation confirmation requests complete within 800 ms and 99% within 1.5 s, excluding client network delay” is more useful, provided the load and measurement boundary are realistic.

### 26.2 Workshop sequence

1. **Present business drivers:** agree on the mission, stakeholders, constraints and success measures.
2. **Present the architecture:** describe components, connectors, deployment, data ownership and important runtime paths.
3. **Identify architectural approaches:** record the mechanisms and decisions that support each quality attribute.
4. **Build and prioritise the utility tree:** decompose quality attributes into scenarios and prioritise them by importance and architectural difficulty.
5. **Analyse architectural approaches:** use a scenario to trace execution through the architecture; identify sensitivity points and assumptions.
6. **Identify trade-off points:** record decisions that improve one quality attribute while degrading another.
7. **Record risks and non-risks:** distinguish unverified assumptions from demonstrated problems; assign owners and evidence actions.
8. **Report findings:** produce risk themes, sensitivity points, trade-off points, unresolved issues and recommended next experiments.

### 26.3 Worked example — synchronous notification versus transactional outbox

A reservation transaction must confirm a booking and trigger a notification. A synchronous design commits the reservation and then calls the notification service inline. It is simple, but a provider outage can increase latency or cause ambiguous client outcomes. A transactional outbox writes the reservation and an outbox event in the same database transaction; a background dispatcher retries publication. This improves decoupling and recoverability but adds dispatch lag, duplicate delivery, outbox retention and operational ownership.

The trade-off is not “outbox is always better.” It depends on the required notification latency, transaction boundary, tolerance for duplicates, volume, operational maturity and failure consequences. The outbox still needs an idempotent consumer and a reconciliation path. It does not create exactly-once end-to-end delivery to an arbitrary email provider.

| Attribute | Synchronous call | Transactional outbox | Evidence needed |
|---|---|---|---|
| Reservation correctness | Reservation may commit before provider result is known | Reservation and event intent commit atomically | Crash/failure injection around commit and dispatch |
| User-visible latency | Can be coupled to provider latency | Confirmation can return after database commit | Load test and latency percentile |
| Notification delay | Usually low when provider works | Depends on dispatcher/backlog | Queue-age and delivery-lag distribution |
| Duplicate handling | Retry ambiguity still exists | At-least-once dispatch is expected | Idempotent consumer test |
| Operational complexity | Fewer components, tighter coupling | More components and monitoring | Runbook, alert and recovery test |

### 18.4 Example architecture risk register

| ID | Finding | Type | Why it matters | Evidence action |
|---|---|---|---|---|
| AR-01 | Notification outage may block reservation confirmation | Risk | Provider availability becomes part of reservation critical path | Inject provider timeout and measure confirmation semantics |
| AR-02 | Outbox dispatcher may publish duplicates after restart | Risk | Consumers may duplicate user-visible actions | Restart after publish/before acknowledgement; test idempotency |
| AR-03 | Unique database constraint enforces no-overlap for one item | Non-risk only if proven | Correctness claim depends on index/constraint semantics | Concurrent integration test against the selected database |
| AR-04 | Cache can return stale availability | Risk | User may see an item as free when a booking exists | Define staleness budget and revalidate at commit |

A risk is not removed by assigning it a low score. It is resolved only when evidence demonstrates the control works or an accountable owner explicitly accepts the residual exposure.

## 27. Architecture fitness functions and governance

A fitness function is an automated or repeatable check of an architectural characteristic over time. It should have a clear property, measurement, execution trigger, threshold, owner and response when it fails. Examples include:

- no dependency from the domain layer to HTTP or database adapter packages;
- no circular dependency between deployable modules;
- API compatibility tests pass for supported clients;
- critical request path latency remains within the agreed percentile under a representative workload;
- critical data is restorable within the approved RTO/RPO;
- every production endpoint emits the required trace and service-level telemetry.

A fitness function can be binary, threshold-based or trend-based. It can also be misleading. A dependency-layer rule will not prove that domain logic is cohesive. A latency test can be gamed by using an unrealistically small dataset. A code coverage threshold does not prove that assertions test business invariants. For every fitness function, document the property it approximates and the failure modes it cannot detect.

### 27.1 Governance loop

1. Select a high-value quality attribute or architecture constraint.
2. Define a measurable property and a meaningful test environment.
3. Implement an automated check where possible.
4. Establish a baseline and inspect false positives/negatives.
5. Run the check continuously at the correct lifecycle point.
6. Assign a decision owner for failures and exceptions.
7. Review whether the check still reflects architecture intent after the system changes.

The architecture lab supplies a dependency-graph checker as a teaching example. It is deliberately narrower than a full architecture fitness framework; learners must add a second metric and justify its measurement boundary in their extension work.

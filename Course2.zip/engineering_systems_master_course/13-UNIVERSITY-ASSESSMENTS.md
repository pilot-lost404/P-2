# University-Style Assessment Bank and Marking Guide

**Purpose:** Provide concrete assessment instruments for the six independent courses. These are original assessments written for this programme; they are not university past papers. Each sample paper is 100 marks and designed for approximately 2.5–3 hours unless otherwise stated.

## 1. Assessment model used in every course

| Component | Weight |
|---|---:|
| Problem sets / short quizzes | 20% |
| Practical labs | 25% |
| Mid-course assessment | 15% |
| Major project / assignment | 25% |
| Final written examination | 10% |
| Oral defence | 5% |
| **Total** | **100%** |

The final examination is a 100-mark paper used as a mastery checkpoint. Its course grade contribution is 10%; the other assessment components carry the remaining 90%. A learner following this independently should score themselves against the marking notes and seek external review for design and communication tasks.

## 2. Common marking rubric

Use the following rubric for written and practical work, adjusting the criterion weights to fit the task.

| Criterion | What earns full credit | Common deductions |
|---|---|---|
| Conceptual correctness | Correct concepts, terminology, assumptions and boundary conditions | Confusing related concepts; unjustified generalisation |
| Technical reasoning | Valid derivation or causal argument; intermediate steps shown | Correct-looking result without justification; invalid inference |
| Evidence and reproducibility | Data, units, sources, tests, diagrams and versions are provided | Unsupported claims; no test oracle; missing assumptions |
| Critical evaluation | Alternatives, limitations, uncertainty and failure modes are considered | One-sided argument; false certainty |
| Communication | Clear structure, labelled diagrams/tables and concise conclusions | Ambiguous notation; unexplained abbreviations; missing labels |

For a quantitative problem, use this default split: method/setup 25%, calculation 35%, interpretation 25%, units/assumptions/checks 15%. For a design problem: requirements/context 20%, alternatives 20%, reasoning 25%, verification/evidence 20%, limitations/communication 15%.

### Performance bands

- **90–100:** technically sound, defensible, reproducible, handles edge cases and limitations.
- **80–89:** strong reasoning with minor omissions or a small correctable error.
- **70–79:** core method is sound but the analysis misses material assumptions, tests or trade-offs.
- **60–69:** partial understanding; method or evidence is incomplete; significant guidance would be required.
- **Below 60:** major conceptual, mathematical or operational errors; insufficient evidence to support the conclusion.

## 3. Mid-course assessment blueprints

The mid-course assessment contributes 15% of each course grade. Use a 60-mark, 90-minute individual paper. Each blueprint tests the foundations needed before the second half of the course; use original values/scenarios when administering a second attempt.

| Course | Component | Marks | Expected evidence |
|---|---|---:|---|
| I — Systems Thinking | Reference mode and loop polarity | 15 | Boundary, directional causal links and loop classification |
| I — Systems Thinking | Stock-flow model and units | 15 | Correct accumulation equation and dimensional checks |
| I — Systems Thinking | Dynamic response calculation | 15 | Derivation and interpretation of a simple dynamic response |
| I — Systems Thinking | Model critique / extreme condition | 15 | Structural assumptions and a discriminating test |
| II — Systems Engineering | Need, stakeholder and requirement chain | 15 | Stakeholder outcome and allocated requirement |
| II — Systems Engineering | Lifecycle / V-model process | 15 | Correct activity and evidence placement |
| II — Systems Engineering | Functional decomposition and interface | 15 | Logical architecture and interface contract |
| II — Systems Engineering | Risk and V&V distinction | 15 | Risk treatment, verification vs validation |
| III — Requirements | Repair ambiguous requirements | 15 | Singular, measurable, verifiable statements |
| III — Requirements | Elicitation / stakeholder analysis | 15 | Technique selection and provenance |
| III — Requirements | Behaviour model and test derivation | 15 | State transitions and positive/negative tests |
| III — Requirements | Traceability and change impact | 15 | Change propagation, baseline and evidence |
| IV — Software / Distributed Systems | Concurrency anomaly | 15 | Counterexample history and violated invariant |
| IV — Software / Distributed Systems | API and idempotency | 15 | Contract, retry semantics and duplicate handling |
| IV — Software / Distributed Systems | Replication / consistency | 15 | Guarantee, fault model and trade-off |
| IV — Software / Distributed Systems | Fault test interpretation | 15 | Reproducible test design and limits |
| V — Architecture | Drivers and quality scenarios | 15 | Actionable quality scenario |
| V — Architecture | Pattern/tactic choice | 15 | Appropriate structure and promoted/inhibited properties |
| V — Architecture | Views and ADR critique | 15 | Fit-for-purpose documentation |
| V — Architecture | ATAM-style risk reasoning | 15 | Risk, sensitivity and trade-off points |
| VI — Reliability / SRE | Reliability and availability calculations | 20 | Correct probability model and assumptions |
| VI — Reliability / SRE | FMEA, FTA or RBD analysis | 15 | Causal logic and dependency awareness |
| VI — Reliability / SRE | SLI/SLO and error budget | 15 | User-centred indicator and correct budget |
| VI — Reliability / SRE | Recovery objective | 10 | RTO/RPO and verification plan |

## 4. Course I examination — Systems Thinking and System Dynamics

**Time:** 2 hours 45 minutes. **Marks:** 100. Show diagrams, units and intermediate calculations.

### Question 1 — Dynamic hypothesis and loop structure (20 marks)

A campus equipment service has a growing overdue-return backlog. Staff respond by sending more reminders. Reminder work interrupts staff processing, leaving less time for returns, repairs and inventory updates. Users then receive stale availability information and contact staff more often.

**Tasks**
1. Identify a plausible reinforcing feedback loop and state the direction of each link (8).
2. Identify one balancing process that could eventually limit backlog growth (4).
3. State two possible delays and explain how each changes behaviour (4).
4. State one model-boundary choice and one excluded variable that could materially affect the conclusion (4).

**Marking key**
- Reinforcing loop: backlog ↑ → reminders ↑ → interruptions ↑ → effective processing capacity ↓ → backlog ↑. The relationship from interruptions to capacity is negative; capacity to backlog is negative. Two negative links make the loop reinforcing. Award full link marks only if all signs are consistent.
- Balancing process: additional temporary capacity / reduced arrivals / overdue items returned; explicitly describe a counteracting effect.
- Delays: reminder response delay, return/repair processing delay, hiring/training delay, information update delay. Explain overshoot/oscillation or delayed correction rather than merely naming the delay.
- Boundary: include staff workload and user behaviour; a plausible excluded variable is institutional policy, budget, semester demand or physical equipment stock.

### Question 2 — Stock-flow formulation and dimensional consistency (20 marks)

Let backlog be measured in items. New overdue cases arrive at 14 items/day. Processing capacity is 18 items/day, proportional to the staffed fraction `s`, with `s = 0.75`.

1. Write the stock equation and initial condition for backlog (5).
2. Calculate the net daily change (4).
3. Give the units for arrival rate, processing rate, staffed fraction and backlog (5).
4. Explain why “backlog = arrivals − processing” is dimensionally and conceptually wrong as a stock equation (6).

**Marking key**
- `B(t) = INTEG(A(t) − P(t), B0)` with non-negative constraint or explicit handling of depletion.
- `P = 18 × 0.75 = 13.5 items/day`; net flow = `14 − 13.5 = +0.5 items/day`.
- `B`: items; `A,P`: items/day; `s`: dimensionless.
- A stock is an accumulated quantity; rate difference is its derivative. The equation needs an integration operator and initial value. It is not valid to subtract rates and call the result items.

### Question 3 — Numerical integration and step size (20 marks)

For `dx/dt = 0.05x`, `x(0)=100`, compute the forward-Euler estimate at `t=10` using step size `h=1`. Compare it with the exact solution and explain the role of step size.

**Marking key**
- Euler recurrence: `x_(n+1)=x_n(1+0.05h)`. For ten steps, `x(10)=100(1.05)^10 ≈ 162.889` (8).
- Exact solution: `x(t)=100e^(0.05t)`, so `x(10)=100e^0.5 ≈164.872` (5).
- Absolute error ≈1.983; relative error ≈1.20% (3).
- Smaller step generally reduces Euler truncation error for this smooth model; it does not validate the structure, assumptions or data (4).

### Question 4 — Calibration, identifiability and uncertainty (20 marks)

A model has two parameters, contact rate `β` and recovery rate `γ`, but the only observed data are a single peak infected-population value.

1. Explain why the two parameters may not be separately identifiable from this observation (7).
2. Describe two additional kinds of data that could improve identifiability (5).
3. Distinguish parameter uncertainty from structural uncertainty (4).
4. Propose one sensitivity or uncertainty test and state what its output would mean (4).

**Marking key**
- A single scalar observation cannot generally identify two free parameters; parameter combinations may generate similar peak values; explain observational equivalence / non-unique parameter fit.
- Time-series infection/recovery observations, contact surveys, duration of infectivity, repeated settings/interventions or independent parameter measurements.
- Parameter uncertainty concerns values within a chosen model structure; structural uncertainty concerns whether the equations/causal structure itself is appropriate.
- One-at-a-time/local sensitivity, global parameter sampling, Monte Carlo, profile likelihood; interpret ranges or influential parameters. Award no full credit for merely naming a tool.

### Question 5 — Model validation and policy critique (20 marks)

A simulation matches a historical backlog curve after parameter tuning. The author concludes that reducing reminder frequency will reduce total overdue items by 30%.

Identify five distinct tests or arguments needed before accepting this policy conclusion (20).

**Marking key**
Award up to 4 each for a sound, non-duplicative item: boundary adequacy; structure/equation review; dimensional consistency; extreme-condition tests; behaviour reproduction beyond calibration period; sensitivity to parameters and time-step; independent validation data; stakeholder/operational plausibility; compare policy across uncertainty; test side effects and delayed response; transparent model documentation. Explicitly state that historical fit alone does not validate causal structure.

## 5. Course II examination — Systems Engineering Fundamentals

**Time:** 2 hours 45 minutes. **Marks:** 100.

### Question 1 — Stakeholder need to system requirement (20 marks)

A university wants a shared equipment reservation system. Identify four distinct stakeholder groups, one need per group, and derive four testable system-level requirements. For each requirement give a verification method (20).

**Marking key**
- Stakeholder groups are distinct (students, lab staff, maintenance, department admin, IT/security, procurement, accessibility office, etc.).
- Needs are expressed as outcomes, not implementation choices.
- Requirements are singular, measurable, feasible and uniquely identified; acceptance thresholds stated. Example: “For an authenticated eligible user, the service shall return a reservation confirmation or a conflict response within 2 seconds for 95% of requests under 200 concurrent sessions.”
- Verification method matches claim: test, analysis, inspection or demonstration; distinguish verification from validation.

### Question 2 — Lifecycle and technical reviews (20 marks)

Place these artefacts at sensible life-cycle points: ConOps, stakeholder-needs baseline, system requirements, logical architecture, interface-control document, verification plan, validation report, transition plan. Explain what decision a Preliminary Design Review (PDR) should be able to make (20).

**Marking key**
- Artefacts placed in an iterative lifecycle, not a simplistic one-way waterfall; maturity increases across reviews.
- PDR evaluates whether the preliminary design satisfies allocated requirements and can proceed to detailed design, with risks/interfaces/verification strategy understood.
- Strong answers acknowledge lifecycle tailoring and that review names/entry criteria vary by organisation.

### Question 3 — Trade study with constraints (20 marks)

Three designs have estimated lifecycle costs and availability: A: ₹10 lakh, 99.6%; B: ₹13 lakh, 99.8%; C: ₹9 lakh, 98.7%. A mandatory requirement is availability ≥99.5%. The decision team has also elicited 1–5 preference scores (5 = better) for three preference criteria: A scores 5/3/4 and B scores 3/5/5 for lifecycle-cost preference, maintainability and interoperability respectively; C scores 5/4/3. These scores are analyst judgements, not measured quantities. First screen the hard constraints. Then calculate the weighted score for A and B using (i) weights 0.45/0.25/0.30 and (ii) weights 0.15/0.45/0.40 in the order shown. Explain why the preferred option changes and identify two limitations of weighted scoring.

**Marking key**
- A (99.6%) and B (99.8%) both pass the 99.5% hard availability constraint; C (98.7%) fails and is excluded before preference scoring (6).
- Under weights 0.45/0.25/0.30, A = 4.20 and B = 4.10; A ranks first. Under weights 0.15/0.45/0.40, A = 3.70 and B = 4.70; B ranks first. Show weighted substitutions and interpret sensitivity (8).
- Limitations: preference-score subjectivity, compensability, double counting, uncertainty hidden by point estimates and false precision (6).

### Question 4 — MBSE and SysML (20 marks)

Explain how a model-based approach can connect stakeholder needs, requirements, structure, behaviour, analysis and verification cases. Name two benefits and two risks of introducing a modelling tool. State the formal SysML version identified in the course references as of 21 November 2026 (20).

**Marking key**
- Model relationships and traceability accurately described; model is more than a diagram store.
- Benefits: consistency checks, impact analysis, shared semantic model, early analysis, trace links.
- Risks: tool lock-in, poor modelling discipline, training cost, immature vendor feature support, model not validated, version migration.
- OMG SysML 2.0 formal specification, published September 2025; SysML 1.7 is previous formal version from June 2024.

### Question 5 — Verification versus validation and risk (20 marks)

A prototype passes every stated function test, but users cannot complete a common workflow without staff assistance. Explain the verification/validation distinction, propose a validation experiment, and outline a risk treatment for the workflow failure (20).

**Marking key**
- Verification: product satisfies specified requirements; validation: product meets stakeholder needs in intended context.
- Validation plan uses representative users, tasks, environment, success measures, accessibility and error observations.
- Risk treatment includes root-cause analysis, owner, mitigation, residual risk and evidence/closure; avoid treating a successful unit test as user validation.

## 6. Course III examination — Requirements Engineering

**Time:** 2 hours 45 minutes. **Marks:** 100.

### Question 1 — Requirement repair (20 marks)

Rewrite the following into testable, appropriately scoped requirements and state assumptions: “The app should be fast, secure and easy to use.” Produce one performance requirement, one access-control requirement and one usability requirement (20).

**Marking key**
- Performance requirement includes actor/action, operating condition, measurable response and percentile/load threshold.
- Access control specifies identity/role/object/action/denial and audit behaviour; does not merely say “secure”.
- Usability requirement defines representative users/task and measurable completion/error/time criterion; avoid arbitrary thresholds without validation.
- Each requirement is singular, feasible and verifiable; assumptions disclosed.

### Question 2 — Elicitation plan (20 marks)

You have one week to learn how equipment checkout works across three departments. Develop an elicitation plan using at least four techniques, identify sources, and explain how you will resolve contradictory information (20).

**Marking key**
- Technique selection maps to uncertainty: interviews for tacit rules, observation for actual workflow, document/data inspection for policy/history, workshop for conflicting goals, prototype for UI workflow.
- Includes students, staff, maintenance, administrators and IT where relevant.
- Reconciliation uses provenance, exception cases, policy authority, observed practice, unresolved conflict register and validation with stakeholders.

### Question 3 — Requirements model and state transitions (20 marks)

Define a reservation lifecycle with states `Requested`, `Confirmed`, `Collected`, `Returned`, `Cancelled` and `Expired`. Give valid transitions, at least three invalid transitions and one invariant (20).

**Marking key**
- Correct state/event/guard/action treatment; transition conditions are explicit.
- Invalid cases include collect-before-confirm, return-before-collection, cancel-after-return, duplicate collection or expired reservation collection.
- Invariant example: at most one active confirmed reservation owns a given equipment unit over overlapping time intervals; state consistency should be explicit.

### Question 4 — Traceability and test derivation (20 marks)

Requirement R-04: “A user may collect equipment only after the reservation is confirmed and the user is eligible.” Construct a short trace chain from stakeholder need to requirement to design element to test cases. Include at least one negative test and one boundary test (20).

**Marking key**
- Need is distinct from implementation requirement.
- Design element and control point are explicit (server-side transition/authorisation check; not only UI).
- Tests include eligible + confirmed (positive), ineligible + confirmed (negative), eligible + unconfirmed (negative), expired/withdrawn or race case (boundary/concurrency).
- Test expected results are observable and unambiguous.

### Question 5 — Specification quality and change impact (20 marks)

A stakeholder changes the return deadline from 17:00 to 19:00. Describe the impact analysis and baseline update. Name five quality checks for the resulting specification set (20).

**Marking key**
- Trace graph traverses policy, requirement, UI, service logic, notifications, schedule data, test cases, training and operations; stakeholder approval and versioning.
- Individual quality checks include necessary, unambiguous, singular, feasible, verifiable, traceable, consistent, prioritised; set-level checks include completeness, conflict, duplication and coverage.
- Explain impact on acceptance tests, backward compatibility/data migration and communications.

## 7. Course IV examination — Software System Design and Distributed Systems

**Time:** 3 hours. **Marks:** 100. State the fault model and consistency guarantee in every distributed design answer.

### Question 1 — Concurrency invariant (20 marks)

Two users attempt to reserve the final available unit at nearly the same time. State the safety invariant, describe a database transaction design that preserves it, and explain why “check availability, then insert” outside a transaction is unsafe (20).

**Marking key**
- Safety invariant: never have more active overlapping reservations than available units; for one unit, at most one active overlapping reservation.
- Use an atomic database constraint/transactional design: unique/exclusion constraint where suitable, row locking or serializable transaction with retry; explain a valid approach for chosen schema.
- Check-then-act can suffer a race: both transactions observe availability before either writes. UI checks do not enforce invariant.

### Question 2 — Operation history and linearizability (20 marks)

Client A invokes `put(k,1)` and completes. Client B then invokes `get(k)` and returns `0`. Is this history linearizable for a single-copy register? Explain. Distinguish linearizability from serializability (20).

**Marking key**
- Not linearizable: A's completed write precedes B's invocation in real-time order, so B must observe value 1 or a later write, not 0.
- Linearizability is a real-time-respecting property of concurrent object histories; serializability concerns equivalence of committed database transactions to a serial order. The object, transaction and isolation levels are related but not interchangeable concepts.

### Question 3 — PostgreSQL isolation (20 marks)

Compare READ COMMITTED, REPEATABLE READ and SERIALIZABLE in PostgreSQL. Explain what the application must do when a SERIALIZABLE transaction is aborted with a serialization failure (20).

**Marking key**
- READ COMMITTED statement-level snapshot; REPEATABLE READ transaction snapshot from first relevant statement; SERIALIZABLE adds Serializable Snapshot Isolation checks for dangerous dependency structures.
- Serialization failures require retrying the **whole transaction**, with bounded retry/backoff where appropriate, not only the failed SQL statement.
- Note that PostgreSQL predicate locks used for SSI tracking do not behave like ordinary blocking row locks; do not describe them as blocking every conflicting write.

### Question 4 — Consensus safety and liveness (20 marks)

Define safety and liveness for a replicated state machine. Explain two Raft safety properties and describe a network-partition case in which progress may stop without violating safety (20).

**Marking key**
- Safety: nothing bad happens; committed entries are not lost/contradictory state machines do not apply different commands at one log index. Liveness: under stated timing/availability assumptions, useful progress eventually occurs.
- Valid Raft properties: Election Safety, Leader Append-Only, Log Matching, Leader Completeness, State Machine Safety.
- Minority partition may not elect/commit without majority; the system sacrifices availability/progress to preserve safety under the model.

### Question 5 — Overload, backpressure and telemetry (20 marks)

A notification queue grows without bound during a provider outage. Propose an overload-control design and an observability plan with three signals. Include one Kubernetes probe warning (20).

**Marking key**
- Bounded queue, admission control, retry with exponential backoff/jitter, dead-letter policy, idempotent consumer, circuit breaker, load shedding/prioritisation, expiry and replay semantics.
- Metrics: queue age/depth, success/error/timeout rate, end-to-end latency, retry count, consumer lag; traces correlate user request to notification; logs avoid sensitive data/cardinality explosions.
- Readiness gates traffic; liveness restarts a wedged process; a liveness probe should not fail merely because an external notification provider or database is unavailable. Startup probe protects slow startup.

## 8. Course V examination — Software Architecture and Trade-off Analysis

**Time:** 2 hours 45 minutes. **Marks:** 100.

### Question 1 — Six-part quality attribute scenario (20 marks)

Write one measurable performance scenario and one modifiability scenario for the campus equipment platform. Include source, stimulus, environment, artifact, response and response measure (20).

**Marking key**
- All six elements explicit. Example: “During semester peak with 200 concurrent sessions, the reservation API receives a search request; the service returns p95 within 500 ms for 95% of requests over a five-minute window.”
- Modifiability example includes change source, requested change, environment, artifact, expected implementation and measurable lead time/affected modules/tests.
- Thresholds are justified or labelled as assumptions pending stakeholder validation.

### Question 2 — Patterns and tactics (20 marks)

Compare a modular monolith and a service-oriented architecture for this workload. Identify two architectural tactics per option and state one promoted and one inhibited quality attribute per pattern (20).

**Marking key**
- Contextual rather than universal recommendation; workload/team/data/operational maturity considered.
- Correct pattern structure and semantics; tactics are concrete (bulkhead, caching, asynchronous processing, replication, encapsulation, dependency inversion, etc.).
- Trade-offs include deployment independence vs distributed failure, local transactions vs network coordination, operational overhead, change coupling and scaling.

### Question 3 — ATAM-style utility tree (20 marks)

Create a small utility tree with four quality refinements and three prioritised scenarios. Identify a risk, a sensitivity point and a trade-off point (20).

**Marking key**
- Quality attributes decomposed to actionable, testable scenarios.
- Priorities include business importance and technical difficulty, not a single vague ranking.
- Risk, sensitivity and trade-off points are distinguished with explicit architecture decisions and consequences.

### Question 4 — ADR critique (20 marks)

An ADR says: “We chose microservices because they are scalable and modern.” Identify at least five defects and rewrite the decision record headings/content needed to make it reviewable (20).

**Marking key**
- Missing context/drivers, constraints, alternatives, measurable criteria, decision rationale, consequences, failure modes, migration/reversal and status.
- Avoids treating a technology fashion as evidence. Decision tied to a scenario and costs/benefits.

### Question 5 — Architecture fitness functions (20 marks)

Propose two automated architecture fitness functions and explain what each can detect and what it cannot prove (20).

**Marking key**
- Examples: dependency rule test; API compatibility test; load test with threshold; schema migration check; vulnerability policy; availability chaos test.
- Clearly state oracle and limits: sampled workload, test environment, false positives/negatives, coverage limits, environmental drift. Fitness function is a continuing signal, not full proof.

## 9. Course VI examination — Reliability Engineering, SRE and Incident Response

**Time:** 3 hours. **Marks:** 100. State all model assumptions.

### Question 1 — Series and parallel reliability (20 marks)

Three independent series components have reliabilities 0.99, 0.98 and 0.995 over the same mission time. Calculate system reliability. Then consider two independent parallel units, each with reliability 0.90, and calculate their combined reliability. Explain the independence assumption (20).

**Marking key**
- Series: `0.99 × 0.98 × 0.995 = 0.965349` (8).
- Parallel success if at least one succeeds: `1 − (1−0.90)^2 = 0.99` (6).
- Independence means component outcomes are statistically independent over the mission; common-cause failure, shared power/network/environment, common software/design or maintenance errors can invalidate the simple formula (6).

### Question 2 — Exponential life-data estimate with censoring (20 marks)

Five units fail at 40, 60, 75, 80 and 90 days. Three other units survive to 100 days and are right-censored. Under an exponential lifetime model with a constant hazard, estimate the failure rate and mean lifetime. Explain the assumption (20).

**Marking key**
- Total exposure `T = 40+60+75+80+90 + 3×100 = 645 unit-days` (6).
- Number of failures `D=5`; exponential likelihood `L(λ) ∝ λ^D exp(−λT)`; MLE `λ̂=D/T=5/645≈0.007752 per day` (8).
- Mean `1/λ̂≈129 days` (3).
- Right-censored observations contribute exposure time but not a failure event. Constant hazard/exponential assumption may not fit wear-out or infant mortality data (3).

### Question 3 — Zero-failure demonstration (15 marks)

A test observes zero failures over 1,000 device-hours. Under a homogeneous Poisson/exponential model, compute the one-sided 95% upper bound on the failure rate. Interpret it carefully (15).

**Marking key**
- `λ_U=−ln(0.05)/T≈2.996/1000≈0.002996 per device-hour` (8).
- It is an upper confidence bound under the model/coverage assumptions, not proof of zero failure probability or guaranteed field reliability (4).
- Need representative stress/mission conditions, independence/homogeneity and adequate failure detection; test design matters (3).

### Question 4 — FMEA, FTA and risk treatment (20 marks)

For “reservation confirmation is sent although no reservation was committed,” give one failure mode, effect, cause, detection/control, and a small fault-tree structure for the top event. Explain why multiplying FMEA severity, occurrence and detection rankings is not a probability (20).

**Marking key**
- Distinguish failure mode, effect and cause; examples include asynchronous event emitted before transaction commit, outbox mismatch, lost/duplicate message, stale read.
- Controls include transactional outbox, idempotent consumer, commit-state check, reconciliation and alerting.
- Tree has causal gates/conditions; OR/AND logic matches the top event and dependencies are not silently assumed independent.
- RPN is an ordinal prioritisation score; rankings are not calibrated probabilities and equal products can hide different risk profiles.

### Question 5 — SLO, incident and recovery (25 marks)

A service has a 99.9% availability SLO over a 30-day month. Calculate the error budget in minutes. Then state the incident response sequence and distinguish RTO from RPO for the service (25).

**Marking key**
- Total month assumed 30×24×60 = 43,200 minutes; 0.1% error budget = 43.2 minutes (6).
- Sequence: detect/declare, incident command/roles, assess impact, mitigate/rollback/fail over, communicate, verify recovery, preserve timeline/evidence, postmortem and tracked corrective actions (11).
- RTO is target maximum time to restore service; RPO is target maximum data loss measured in time. Both must derive from business impact and be tested (6).
- Availability SLO definition must state eligible events/window/exclusions and user perspective; avoid treating every HTTP response as an equivalent successful event (2).

## 10. Major project deliverables and course-specific rubric

Each course project is worth 25% of that course's grade. Use a 100-point project rubric, then convert to the course weight.

### Course I project — Dynamic model and policy evaluation

Deliver: problem statement and reference mode; model boundary; causal-loop diagram; stock-flow model; equation/units dictionary; parameter source register; structural and behavioural tests; baseline and policy runs; sensitivity/uncertainty analysis; model critique and decision memo.

**Rubric:** structure/boundary 15; equation and dimensional validity 20; parameter provenance 10; tests and validation 20; sensitivity/uncertainty 15; policy interpretation 10; documentation/reproducibility 10.

### Course II project — System concept and PDR package

Deliver: stakeholder register; ConOps; needs and requirements baseline; functional/logical architecture; interfaces; trade study; technical risk register; verification and validation strategy; life-cycle and review plan.

**Rubric:** stakeholder/context 15; requirements and trace 15; architecture/decomposition 15; interface definition 10; trade analysis 15; risk/safety 10; V&V/review evidence 15; communication 5.

### Course III project — Requirements baseline and acceptance suite

Deliver: elicitation plan/evidence; stakeholder and context model; use cases/state/data model; SRS; measurable quality scenarios; requirement-quality report; traceability matrix; acceptance tests; change-impact demonstration.

**Rubric:** elicitation provenance 15; models/context 10; requirement quality 20; coverage/consistency 15; quality requirements 10; traceability 10; tests/acceptance 15; change management 5.

### Course IV project — Distributed service design and test dossier

Deliver: workload model; API contract; database schema/constraints; transaction/isolation analysis; consistency guarantee; sequence/failure diagrams; retry/idempotency policy; prototype or simulation; concurrency/fault tests; trace/log/metric plan.

**Rubric:** workload and requirements 10; data/API design 15; correctness invariants 20; failure/consistency reasoning 20; test quality 15; observability 10; trade-offs/documentation 10.

### Course V project — Architecture decision and evaluation dossier

Deliver: architectural drivers and quality scenario set; at least three alternatives; views; tactics and patterns; ADR set; ATAM-style utility tree and risk themes; cost/uncertainty analysis; fitness functions; evolution plan.

**Rubric:** drivers/scenarios 15; alternative quality 15; structural design/views 15; tactics/patterns 10; ADR quality 10; evaluation/risk/trade-off 20; fitness/evolution 10; communication 5.

### Course VI project — Reliability, SLO and recovery case

Deliver: reliability assumptions/data; quantitative model; RBD/FTA/FMEA; criticality and treatment plan; SLI/SLO and budget; monitoring and alert design; incident simulation; postmortem; backup/restore test; RTO/RPO argument.

**Rubric:** model/assumptions 15; data/statistics 15; FMEA/FTA/RBD 15; risk treatment 10; SLO/measurement 15; incident response 10; recovery evidence 15; documentation 5.

## 11. Oral defence — 5% per course

A 15–20 minute individual defence is sufficient for a self-study review:

1. **2 minutes:** define the problem, boundary and intended outcome.
2. **4 minutes:** explain the core method/model/architecture and key assumptions.
3. **4 minutes:** defend one important technical choice with evidence and an alternative.
4. **3 minutes:** explain one failure mode or limitation and its mitigation/test.
5. **2–7 minutes:** answer examiner questions and identify what would change the conclusion.

**Viva rubric:** conceptual command 25%; technical reasoning 25%; evidence/provenance 20%; critical awareness 20%; clarity and response to challenge 10%.

Sample viva probes:
- Course I: What observation would falsify your dynamic hypothesis?
- Course II: Which requirement is not allocated, and why is that a review blocker?
- Course III: Which requirement has the weakest verification method?
- Course IV: Which operation-history counterexample breaks your chosen consistency claim?
- Course V: Which quality scenario changes the architecture decision if its threshold doubles?
- Course VI: Which assumption dominates the reliability estimate, and how would you test it?

## 12. Lab submission checklist

- [ ] Preconditions, software/tool versions and environment stated.
- [ ] Input files/data/configuration identified and versioned.
- [ ] Procedure is reproducible from a clean starting state.
- [ ] Expected behaviour/test oracle stated before presenting results.
- [ ] At least one edge case or failure case explored.
- [ ] Raw evidence included: commands, tests, traces, logs, graphs or calculations.
- [ ] Units, assumptions, thresholds and data source recorded.
- [ ] Results interpreted; not merely pasted.
- [ ] Limitations and untested cases stated.
- [ ] Conclusions mapped to the relevant learning outcome.

## 13. Academic integrity and external teaching resources

Use university lab handouts to learn the intended problem and test methodology. Write your own implementation and analysis. Do not submit other learners' solutions, copy a protected exam, or present externally authored material as original work. Cite the exact source, edition/version, access date and licence where relevant. Follow the collaboration and AI-use policy of any institution or course you are enrolled in; policies can differ. When using AI assistance, disclose it wherever the applicable academic rules require, verify technical claims and remain able to explain every line and decision in your submission.

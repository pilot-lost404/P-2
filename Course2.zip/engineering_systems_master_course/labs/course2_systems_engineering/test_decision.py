import unittest

from decision import evaluate, present_value


class EngineeringEconomicsTests(unittest.TestCase):
    def test_present_value_reference_example(self):
        value = present_value(100.0, [25.0, 30.0, 35.0], 0.05)
        self.assertAlmostEqual(value, 181.25472411186695, places=10)

    def test_hard_constraints_are_screened_before_weighted_score(self):
        options = [
            {"name": "A", "availability": 0.996, "scores": {"cost": 5, "maintainability": 3}},
            {"name": "B", "availability": 0.998, "scores": {"cost": 3, "maintainability": 5}},
            {"name": "C", "availability": 0.987, "scores": {"cost": 5, "maintainability": 4}},
        ]
        result = evaluate(
            options,
            constraints={"availability": {"min": 0.995}},
            weights={"cost": 0.5, "maintainability": 0.5},
        )
        self.assertEqual([item["name"] for item in result["feasible"]], ["A", "B"])
        self.assertEqual(result["infeasible"][0]["name"], "C")
        self.assertEqual(result["ranking"][0]["name"], "A")

    def test_no_feasible_option_is_reported_not_scored(self):
        result = evaluate(
            [{"name": "A", "availability": 0.90, "scores": {"cost": 5}}],
            constraints={"availability": {"min": 0.99}},
            weights={"cost": 1.0},
        )
        self.assertEqual(result["ranking"], [])
        self.assertEqual(result["status"], "NO_FEASIBLE_ALTERNATIVE")

    def test_weight_sensitivity_can_reverse_preference_ranking(self):
        options = [
            {"name": "A", "availability": 0.996, "scores": {"cost": 5, "maintainability": 3, "interoperability": 4}},
            {"name": "B", "availability": 0.998, "scores": {"cost": 3, "maintainability": 5, "interoperability": 5}},
        ]
        constraints = {"availability": {"min": 0.995}}
        cost_weighted = evaluate(options, constraints, {"cost": 0.45, "maintainability": 0.25, "interoperability": 0.30})
        quality_weighted = evaluate(options, constraints, {"cost": 0.15, "maintainability": 0.45, "interoperability": 0.40})
        self.assertEqual(cost_weighted["ranking"][0]["name"], "A")
        self.assertEqual(quality_weighted["ranking"][0]["name"], "B")

    def test_invalid_discount_rate_is_rejected(self):
        with self.assertRaises(ValueError):
            present_value(100, [10], -1.0)


if __name__ == "__main__":
    unittest.main()

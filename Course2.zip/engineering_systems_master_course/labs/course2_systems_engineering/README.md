# Practical 2 — Constraint-first engineering trade study

**Course mapping:** Course II, C2-LO3; supports the lifecycle and PDR work in C2-LO1/C2-LO5.  
**Type:** Executable decision-analysis practical.  
**Dependencies:** Python 3.13.x; standard library only.

## Learning objectives

You will distinguish mandatory constraints from preference criteria, calculate discounted cost, create a weighted comparison with explicit scoring assumptions and test whether a recommendation is sensitive to weight selection.

## Input model

`trade_study.json` contains three candidate system designs. Availability of at least 99.5% and lifecycle cost no greater than ₹15 lakh are hard feasibility constraints. Only feasible options are ranked. Preference scores are analyst-elicited 1–5 ratings, not physical measurements. The weights are normalised by the program; the scoring scale, evidence and uncertainty must be justified in your report.

## Run

```bash
python decision.py trade_study.json
```

Expected output:

```text
status=RANKED
feasible: A, B
infeasible: C
1. A: weighted_score=4.200
2. B: weighted_score=4.100
alternate_weight_ranking=B, A
present_value=181.2547241119
```

The present-value example is a separate calculation: 100 at time zero, then 25, 30 and 35 at the ends of years 1–3, discounted at 5%. The result is 181.2547241 cost units (181.25 to two decimal places).

## Required investigation

1. Verify that C is rejected before preference scoring because it misses the mandatory availability threshold.
2. Recalculate the ranking using the default weights and the alternate weights. Explain why the preferred design reverses.
3. Change the availability threshold from 99.5% to 99.0%. Explain what changes and why constraints should represent genuine mandatory needs rather than be tuned to favour an option.
4. Change one lifecycle-cost assumption and calculate its present value independently by hand or spreadsheet.
5. Add one non-compensable constraint (for example, a mandatory safety certification) and one risk criterion. Explain why a weighted score cannot compensate for a failed mandatory requirement.
6. Write a one-page decision record including decision owner, alternatives, constraints, evidence quality, assumptions, uncertainty, sensitivity and residual risks.

## Verification

```bash
python -m unittest discover -v
```

Tests verify the reference present value, constraint-first screening, no-feasible-option handling, weight normalisation and ranking sensitivity. They do not determine whether the input ratings or thresholds are valid; that is an engineering and stakeholder decision.

## Submission

Submit the edited JSON input, exact command/output, independent calculation, sensitivity analysis and a 700–1,000-word decision record. Identify where the model would produce false confidence.

"""Constraint-first engineering trade study and present-value calculator."""
from __future__ import annotations

from typing import Any


def present_value(time_zero_cost: float, future_costs: list[float], discount_rate: float) -> float:
    """Return present value of costs, with future_costs paid at periods 1..n."""
    if discount_rate <= -1.0:
        raise ValueError("discount_rate must be greater than -1")
    if time_zero_cost < 0 or any(cost < 0 for cost in future_costs):
        raise ValueError("costs must be non-negative")
    return float(time_zero_cost) + sum(
        float(cost) / ((1.0 + discount_rate) ** period)
        for period, cost in enumerate(future_costs, start=1)
    )


def _passes(value: float, constraint: dict[str, float]) -> bool:
    if "min" in constraint and value < constraint["min"]:
        return False
    if "max" in constraint and value > constraint["max"]:
        return False
    return True


def evaluate(
    options: list[dict[str, Any]],
    constraints: dict[str, dict[str, float]],
    weights: dict[str, float],
) -> dict[str, Any]:
    """Screen hard constraints first, then rank feasible options by preferences.

    Option score fields are dimensionless preference scores (larger is better).
    The caller owns the score scale and must document how it was elicited.
    """
    if not options:
        raise ValueError("at least one option is required")
    if not weights or any(weight < 0 for weight in weights.values()) or sum(weights.values()) <= 0:
        raise ValueError("weights must be non-negative and have a positive total")
    required = set(weights)
    feasible: list[dict[str, Any]] = []
    infeasible: list[dict[str, Any]] = []
    for option in options:
        name = str(option.get("name", "")).strip()
        if not name:
            raise ValueError("each option must have a name")
        failures = []
        for attribute, limit in constraints.items():
            if attribute not in option:
                failures.append(f"missing:{attribute}")
            elif not _passes(float(option[attribute]), limit):
                failures.append(attribute)
        item = {"name": name, "constraint_failures": failures}
        if failures:
            infeasible.append(item)
            continue
        scores = option.get("scores", {})
        missing = required - set(scores)
        if missing:
            raise ValueError(f"option {name} lacks preference scores for: {sorted(missing)}")
        weighted = sum(float(scores[k]) * float(w) for k, w in weights.items()) / sum(weights.values())
        feasible.append({"name": name, "score": weighted, "scores": dict(scores)})
    ranking = sorted(feasible, key=lambda item: (-item["score"], item["name"]))
    return {
        "status": "RANKED" if ranking else "NO_FEASIBLE_ALTERNATIVE",
        "feasible": feasible,
        "infeasible": infeasible,
        "ranking": ranking,
    }


def main() -> None:
    import argparse
    import json
    from pathlib import Path

    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("input_json", nargs="?", type=Path, default=Path("trade_study.json"))
    args = parser.parse_args()
    config = json.loads(args.input_json.read_text(encoding="utf-8"))
    result = evaluate(config["options"], config["constraints"], config["weights"])
    print(f"status={result['status']}")
    print("feasible:", ", ".join(item["name"] for item in result["feasible"]) or "none")
    print("infeasible:", ", ".join(item["name"] for item in result["infeasible"]) or "none")
    for rank, item in enumerate(result["ranking"], start=1):
        print(f"{rank}. {item['name']}: weighted_score={item['score']:.3f}")
    alternate_weights = config.get("alternate_weights")
    if alternate_weights:
        sensitivity = evaluate(config["options"], config["constraints"], alternate_weights)
        alternate_order = ", ".join(item["name"] for item in sensitivity["ranking"]) or "none"
        print(f"alternate_weight_ranking={alternate_order}")
    pv_case = config.get("present_value")
    if pv_case:
        pv = present_value(pv_case["time_zero_cost"], pv_case["future_costs"], pv_case["discount_rate"])
        print(f"present_value={pv:.10f}")


if __name__ == "__main__":
    main()

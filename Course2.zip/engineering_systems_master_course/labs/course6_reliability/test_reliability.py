import unittest
import subprocess
import sys
from pathlib import Path

from reliability import (
    Observation,
    exponential_mle,
    weibull_mle,
    weibull_survival,
    exponential_bootstrap_ci,
)


class ReliabilityTests(unittest.TestCase):
    def test_exponential_mle_includes_censored_exposure(self):
        data = [
            Observation(40, True), Observation(60, True), Observation(75, True),
            Observation(80, True), Observation(90, True),
            Observation(100, False), Observation(100, False), Observation(100, False),
        ]
        rate = exponential_mle(data)
        self.assertAlmostEqual(rate, 5 / 645, places=12)

    def test_weibull_fit_returns_positive_parameters(self):
        data = [
            Observation(18, True), Observation(25, True), Observation(31, True),
            Observation(38, True), Observation(44, True), Observation(55, True),
            Observation(60, False), Observation(60, False), Observation(60, False),
            Observation(60, False),
        ]
        shape, scale = weibull_mle(data)
        self.assertGreater(shape, 0.0)
        self.assertGreater(scale, 0.0)
        self.assertGreater(weibull_survival(30, shape, scale), 0.0)
        self.assertLess(weibull_survival(30, shape, scale), 1.0)

    def test_weibull_shape_one_reduces_to_exponential(self):
        # This tests the Weibull survival formula at beta=1.
        self.assertAlmostEqual(weibull_survival(10, 1.0, 20.0), 0.6065306597126334, places=12)

    def test_parametric_bootstrap_interval_is_reproducible(self):
        data = [Observation(x, True) for x in [40, 60, 75, 80, 90]] + [Observation(100, False)] * 3
        first = exponential_bootstrap_ci(data, replicates=300, seed=17)
        second = exponential_bootstrap_ci(data, replicates=300, seed=17)
        self.assertEqual(first, second)
        self.assertLess(first[0], first[1])
        self.assertGreater(first[0], 0.0)

    def test_cli_runs_with_the_documented_dataset(self):
        folder = Path(__file__).resolve().parent
        result = subprocess.run(
            [sys.executable, str(folder / "reliability.py"), str(folder / "life_data.csv")],
            text=True, capture_output=True, check=False,
        )
        self.assertEqual(result.returncode, 0, result.stderr)
        self.assertIn("total_exposure=645.000", result.stdout)
        self.assertIn("exponential_rate=0.00775194", result.stdout)

    def test_no_failures_cannot_identify_finite_mle(self):
        data = [Observation(10, False), Observation(15, False)]
        with self.assertRaises(ValueError):
            weibull_mle(data)

    def test_nonpositive_observation_is_rejected(self):
        with self.assertRaises(ValueError):
            exponential_mle([Observation(0, True)])


if __name__ == "__main__":
    unittest.main()

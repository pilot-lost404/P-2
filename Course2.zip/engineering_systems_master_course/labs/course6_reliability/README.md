# Practical 6 — Right-censored reliability data

**Course mapping:** Course VI, C6-LO1, C6-LO2 and C6-LO5.  
**Type:** Executable life-data analysis practical.  
**Dependencies:** Python 3.13.x; standard library only.

## Data

`life_data.csv` contains eight independent units observed under one illustrative test plan: five failures at 40, 60, 75, 80 and 90 days, and three units right-censored at 100 days. The total observed exposure is 645 unit-days. The data are synthetic and are used for teaching; do not interpret them as field reliability evidence.

## Run

```bash
python reliability.py life_data.csv
```

Expected output (bootstrap interval is deterministic for the supplied seed):

```text
n=8 failures=5 censored=3
total_exposure=645.000 unit-days
exponential_rate=0.00775194 per-day
exponential_mttf=129.000 days
weibull_shape=3.168451
weibull_scale=99.134984 days
exponential_bootstrap_95pct_ci=(0.00247969, 0.01845645) per-day
weibull_survival_at_30d=0.977596
weibull_survival_at_60d=0.815689
```

The exponential MLE is failures divided by total exposure: \(5/645=0.00775194\) failures per unit-day. The 129-day reciprocal is conditional on the constant-hazard exponential model. The Weibull fit is a right-censored maximum-likelihood estimate; \(\beta\approx3.168\) indicates an increasing fitted hazard under this model, not proof of a specific physical wear-out mechanism.

The reported bootstrap interval is an approximate parametric percentile interval. It simulates from the fitted exponential model, reapplies a common administrative censor time of 100 days and uses a fixed seed. It assumes independent, homogeneous units and non-informative common administrative censoring. The interval is broad because only five failures are observed. It is not a universal reliability confidence interval and should not be used for a real safety decision without a design-specific statistical review.

## Verification

```bash
python -m unittest discover -v
```

The tests cover censored exposure in the exponential MLE, positive Weibull parameters, the exponential special case, bootstrap reproducibility, invalid observation times and CLI execution.

## Required investigation

1. Treat the three censored units as if they failed at day 100. Recalculate the exponential estimate and explain the bias this introduces.
2. Compare the exponential and Weibull survival estimates at 30 and 60 days. Discuss the constant-hazard assumption.
3. Change the bootstrap seed and replicate count. Report Monte Carlo variability; do not interpret it as new physical information.
4. Remove one failure observation at a time and assess sensitivity of Weibull shape and scale.
5. Explain what additional data are required for a confidence interval on the Weibull parameters, recurrent-event analysis and competing-risk analysis.
6. Describe how a repair policy changes the statistical model: renewal, minimal repair or imperfect repair.
7. Write a reliability report with population definition, exposure, censoring, model assumptions, point estimates, uncertainty, diagnostics and limitations.

## Submission

Submit the input data, exact command/output, calculations, a survival plot, sensitivity study and a 1,000–1,500-word statistical report. Make explicit that eight synthetic observations cannot establish a production maintenance policy.

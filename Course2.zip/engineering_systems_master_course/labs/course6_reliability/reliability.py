"""Exponential and two-parameter Weibull MLE for right-censored life data."""
from __future__ import annotations

import math
from dataclasses import dataclass
from typing import Iterable


@dataclass(frozen=True)
class Observation:
    time: float
    event_observed: bool


def _validate(data: Iterable[Observation]) -> list[Observation]:
    observations = list(data)
    if not observations:
        raise ValueError("at least one observation is required")
    if any(not math.isfinite(item.time) or item.time <= 0 for item in observations):
        raise ValueError("all observation times must be finite and positive")
    if not any(item.event_observed for item in observations):
        raise ValueError("at least one observed failure is required for a finite MLE")
    return observations


def exponential_mle(data: Iterable[Observation]) -> float:
    """MLE failure rate; all failed and censored observation time is exposure."""
    observations = _validate(data)
    failures = sum(item.event_observed for item in observations)
    total_exposure = sum(item.time for item in observations)
    return failures / total_exposure


def weibull_mle(data: Iterable[Observation], tolerance: float = 1e-10) -> tuple[float, float]:
    """Return Weibull (shape, scale) MLE for independent right-censored data.

    A profile-likelihood score is solved by bisection. This implementation
    assumes independent lifetimes and non-informative right censoring.
    """
    observations = _validate(data)
    failures = [item for item in observations if item.event_observed]
    r = len(failures)
    maximum_time = max(item.time for item in observations)
    scaled = [item.time / maximum_time for item in observations]
    fail_log_sum = sum(math.log(item.time / maximum_time) for item in failures)

    def score(beta: float) -> float:
        powers = [value ** beta for value in scaled]
        denominator = sum(powers)
        weighted_log = sum(power * math.log(value) for power, value in zip(powers, scaled))
        return r / beta + fail_log_sum - r * weighted_log / denominator

    low = 0.05
    high = 1.0
    while score(high) > 0 and high < 128.0:
        high *= 2.0
    if score(high) > 0:
        raise ValueError("no finite Weibull shape MLE found; inspect the data and censoring")

    for _ in range(200):
        middle = (low + high) / 2.0
        value = score(middle)
        if abs(value) < tolerance or (high - low) < tolerance:
            low = high = middle
            break
        if value > 0:
            low = middle
        else:
            high = middle
    shape = (low + high) / 2.0
    scaled_sum = sum(value ** shape for value in scaled)
    scale = maximum_time * (scaled_sum / r) ** (1.0 / shape)
    return shape, scale


def weibull_survival(time: float, shape: float, scale: float) -> float:
    if time < 0 or shape <= 0 or scale <= 0:
        raise ValueError("time must be non-negative and shape/scale must be positive")
    return math.exp(-((time / scale) ** shape))


def weibull_hazard(time: float, shape: float, scale: float) -> float:
    if time <= 0 or shape <= 0 or scale <= 0:
        raise ValueError("time, shape and scale must be positive")
    return (shape / scale) * ((time / scale) ** (shape - 1.0))


def weibull_mean(shape: float, scale: float) -> float:
    if shape <= 0 or scale <= 0:
        raise ValueError("shape and scale must be positive")
    return scale * math.gamma(1.0 + 1.0 / shape)


def main() -> None:
    import argparse
    import csv
    from pathlib import Path

    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("input_csv", nargs="?", type=Path, default=Path("life_data.csv"))
    args = parser.parse_args()
    with args.input_csv.open(newline="", encoding="utf-8") as handle:
        observations = [
            Observation(float(row["time_days"]), row["event_observed"].strip() in {"1", "true", "True"})
            for row in csv.DictReader(handle)
        ]
    failures = sum(item.event_observed for item in observations)
    exposure = sum(item.time for item in observations)
    rate = exponential_mle(observations)
    shape, scale = weibull_mle(observations)
    print(f"n={len(observations)} failures={failures} censored={len(observations)-failures}")
    print(f"total_exposure={exposure:.3f} unit-days")
    print(f"exponential_rate={rate:.8f} per-day")
    print(f"exponential_mttf={1/rate:.3f} days")
    print(f"weibull_shape={shape:.6f}")
    print(f"weibull_scale={scale:.6f} days")
    ci_low, ci_high = exponential_bootstrap_ci(observations, replicates=2000, seed=20261121)
    print(f"exponential_bootstrap_95pct_ci=({ci_low:.8f}, {ci_high:.8f}) per-day")
    for mission in (30.0, 60.0):
        print(f"weibull_survival_at_{mission:g}d={weibull_survival(mission, shape, scale):.6f}")



def exponential_bootstrap_ci(
    data: Iterable[Observation],
    replicates: int = 2000,
    seed: int = 20261121,
    alpha: float = 0.05,
) -> tuple[float, float]:
    """Approximate percentile CI under a common administrative censor time.

    The procedure simulates from the fitted exponential model and reapplies a
    common right-censor time equal to the maximum observation time. It is not
    valid for informative censoring, staggered entry or heterogeneous units.
    """
    import random

    observations = _validate(data)
    if replicates < 100:
        raise ValueError("use at least 100 bootstrap replicates")
    if not 0 < alpha < 1:
        raise ValueError("alpha must be in (0, 1)")
    censor_times = {item.time for item in observations if not item.event_observed}
    if len(censor_times) > 1:
        raise ValueError("bootstrap implementation requires one common administrative censor time")
    censor_time = max(observations, key=lambda item: item.time).time
    fitted_rate = exponential_mle(observations)
    rng = random.Random(seed)
    estimates: list[float] = []
    for _ in range(replicates):
        sample = []
        for _ in observations:
            lifetime = rng.expovariate(fitted_rate)
            if lifetime <= censor_time:
                sample.append(Observation(lifetime, True))
            else:
                sample.append(Observation(censor_time, False))
        estimates.append(exponential_mle(sample) if any(x.event_observed for x in sample) else 0.0)
    estimates.sort()

    def percentile(probability: float) -> float:
        position = (len(estimates) - 1) * probability
        lower = int(math.floor(position))
        upper = int(math.ceil(position))
        if lower == upper:
            return estimates[lower]
        fraction = position - lower
        return estimates[lower] * (1.0 - fraction) + estimates[upper] * fraction

    return percentile(alpha / 2.0), percentile(1.0 - alpha / 2.0)


if __name__ == "__main__":
    main()

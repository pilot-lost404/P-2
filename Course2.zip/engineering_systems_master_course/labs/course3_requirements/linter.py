"""Transparent, deliberately conservative requirements quality pre-checker.

Findings are prompts for human review. This tool does not prove correctness,
completeness, feasibility, stakeholder validity or formal verifiability.
"""
from __future__ import annotations

import argparse
import csv
import json
import re
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Iterable


VAGUE_TERMS = {
    "fast", "quickly", "promptly", "easy", "easily", "user-friendly",
    "robust", "efficient", "secure", "reliable", "adequate", "appropriate",
}


@dataclass(frozen=True)
class Finding:
    requirement_id: str
    code: str
    severity: str
    message: str


def lint_rows(rows: Iterable[dict[str, str]]) -> list[Finding]:
    materialised = list(rows)
    findings: list[Finding] = []
    seen: set[str] = set()
    for index, row in enumerate(materialised, start=2):
        req_id = (row.get("id") or "").strip()
        statement = (row.get("statement") or "").strip()
        if not req_id:
            findings.append(Finding(f"row-{index}", "MISSING_ID", "error", "Requirement identifier is missing."))
        elif req_id in seen:
            findings.append(Finding(req_id, "DUPLICATE_ID", "error", "Identifier is not unique."))
        else:
            seen.add(req_id)

        if not statement:
            findings.append(Finding(req_id or f"row-{index}", "MISSING_STATEMENT", "error", "Requirement statement is empty."))
        elif not re.search(r"\bshall\b", statement, flags=re.IGNORECASE):
            findings.append(Finding(req_id, "NO_NORMATIVE_STATEMENT", "warning", "Statement does not contain the normative term 'shall'; check whether it is a requirement or explanatory text."))
        else:
            lower = statement.casefold()
            found_terms = sorted(term for term in VAGUE_TERMS if re.search(rf"\b{re.escape(term)}\b", lower))
            if found_terms:
                findings.append(Finding(req_id, "VAGUE_TERM", "warning", f"Review vague term(s): {', '.join(found_terms)}."))
            if re.search(r"\bshall\b.*\band\b.*\bshall\b", lower):
                findings.append(Finding(req_id, "POSSIBLE_COMPOUND", "warning", "Multiple normative clauses may be combined; check atomicity."))

        for field, code, label in [
            ("source", "MISSING_SOURCE", "Source/provenance"),
            ("verification_method", "MISSING_VERIFICATION", "Verification method"),
            ("acceptance_criteria", "MISSING_ACCEPTANCE", "Acceptance criteria"),
        ]:
            if not (row.get(field) or "").strip():
                findings.append(Finding(req_id or f"row-{index}", code, "error", f"{label} is missing."))
    return findings


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("input_csv", type=Path)
    parser.add_argument("--output", type=Path, default=Path("findings.json"))
    args = parser.parse_args()
    with args.input_csv.open(newline="", encoding="utf-8-sig") as handle:
        findings = lint_rows(csv.DictReader(handle))
    args.output.write_text(json.dumps([asdict(item) for item in findings], indent=2), encoding="utf-8")
    errors = sum(item.severity == "error" for item in findings)
    warnings = sum(item.severity == "warning" for item in findings)
    print(f"findings={len(findings)} errors={errors} warnings={warnings}")
    print(f"report={args.output}")
    if errors:
        raise SystemExit(1)


if __name__ == "__main__":
    main()

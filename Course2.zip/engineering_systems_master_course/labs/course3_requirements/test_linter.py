import unittest

from linter import lint_rows


class RequirementsLinterTests(unittest.TestCase):
    def test_well_formed_measurable_requirement_has_no_findings(self):
        rows = [{
            "id": "SYS-001",
            "statement": "The service shall return a confirmation or conflict response within 800 ms for at least 95% of eligible requests under 200 concurrent sessions.",
            "source": "Campus service owner interview 2026-11-01",
            "rationale": "Registration peaks require bounded response time.",
            "verification_method": "Performance test",
            "acceptance_criteria": "95th percentile response time <= 800 ms at 200 concurrent sessions.",
        }]
        self.assertEqual(lint_rows(rows), [])

    def test_duplicate_identifier_is_reported(self):
        rows = [
            {"id": "SYS-001", "statement": "The system shall record a return.", "source": "Workshop", "verification_method": "Test", "acceptance_criteria": "A return record is persisted."},
            {"id": "SYS-001", "statement": "The system shall record damage.", "source": "Workshop", "verification_method": "Test", "acceptance_criteria": "A damage record is persisted."},
        ]
        codes = {finding.code for finding in lint_rows(rows)}
        self.assertIn("DUPLICATE_ID", codes)

    def test_vague_or_unverifiable_requirement_is_flagged(self):
        rows = [{
            "id": "SYS-002",
            "statement": "The system shall be fast and user-friendly.",
            "source": "Email",
            "rationale": "People want a good experience.",
            "verification_method": "",
            "acceptance_criteria": "",
        }]
        codes = {finding.code for finding in lint_rows(rows)}
        self.assertIn("VAGUE_TERM", codes)
        self.assertIn("MISSING_VERIFICATION", codes)
        self.assertIn("MISSING_ACCEPTANCE", codes)

    def test_missing_source_is_reported(self):
        rows = [{
            "id": "SYS-003", "statement": "The system shall retain an audit event.",
            "source": "", "verification_method": "Inspection", "acceptance_criteria": "An event is visible in the audit export.",
        }]
        self.assertIn("MISSING_SOURCE", {finding.code for finding in lint_rows(rows)})


if __name__ == "__main__":
    unittest.main()

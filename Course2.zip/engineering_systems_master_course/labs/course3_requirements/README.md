# Practical 3 — Requirements quality pre-checker

**Course mapping:** Course III, C3-LO2 through C3-LO5.  
**Type:** Executable requirements-review support tool, followed by human analysis.  
**Dependencies:** Python 3.13.x; standard library only.

## Learning objectives

You will create a structured requirements register, identify missing metadata and common language defects, separate automatic checks from expert judgement, and derive review actions from the findings.

## Data schema

The CSV must contain `id`, `statement`, `source`, `rationale`, `verification_method` and `acceptance_criteria`. The linter flags duplicate/missing identifiers, missing provenance, missing verification or acceptance criteria, vague terms and a narrow pattern for compound normative clauses. Findings are prompts for human review. A clean run does **not** prove that the requirements are complete, feasible, necessary, secure, safe, consistent or aligned with stakeholder intent.

## Run the accepted example

```bash
python linter.py requirements.csv --output findings.json
```

Expected result:

```text
findings=0 errors=0 warnings=0
report=findings.json
```

## Run the deliberately defective review sample

```bash
python linter.py requirements_review.csv --output review-findings.json
```

Expected result: 4 findings, comprising 2 errors and 2 warnings. The CLI exits with status 1 because required metadata is missing. This non-zero exit is intentional and should be used in a pipeline to block an incomplete register.

## Required investigation

1. Inspect the findings and identify the statement-level evidence behind each one.
2. Rewrite SYS-003 as at least two measurable requirements. Do not invent numeric thresholds; state which stakeholder, operational data or standard is needed to choose each threshold.
3. Split SYS-004 into atomic requirements only if the two obligations can be verified independently. Preserve their traceability to the same need.
4. Add two deliberately subtle defects that the linter does not detect (for example, an infeasible response target or a missing failure mode). Record the false negative.
5. Add one rule, test it against both data files, and discuss the expected false-positive/false-negative trade-off.
6. Conduct a human set-level review for completeness, consistency, feasibility, security, privacy, safety, accessibility and sustainability.

## Verification

```bash
python -m unittest discover -v
```

The tests verify duplicate detection, missing-source detection, vague-term warnings, missing verification/acceptance metadata and a clean reference requirement. They do not validate natural-language meaning.

## Submission

Submit the original and revised CSVs, machine findings, test output, review log and a 1,000-word analysis of what automation can and cannot judge. Include at least one false positive and one false negative.

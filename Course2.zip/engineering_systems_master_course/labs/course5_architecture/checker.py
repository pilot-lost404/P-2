"""Checks declared module dependencies against architecture layer rules."""
from __future__ import annotations

import argparse
import json
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Any


@dataclass(frozen=True)
class Finding:
    code: str
    module: str
    message: str


def _find_cycles(graph: dict[str, list[str]]) -> list[list[str]]:
    visiting: set[str] = set()
    visited: set[str] = set()
    stack: list[str] = []
    cycles: list[list[str]] = []
    recorded: set[tuple[str, ...]] = set()

    def visit(node: str) -> None:
        if node in visiting:
            start = stack.index(node)
            cycle = stack[start:] + [node]
            # Canonicalise cycle rotation for deterministic duplicate removal.
            ring = cycle[:-1]
            rotations = [tuple(ring[i:] + ring[:i]) for i in range(len(ring))]
            key = min(rotations) if rotations else tuple(cycle)
            if key not in recorded:
                recorded.add(key)
                cycles.append(cycle)
            return
        if node in visited:
            return
        visiting.add(node)
        stack.append(node)
        for neighbour in sorted(graph.get(node, [])):
            if neighbour in graph:
                visit(neighbour)
        stack.pop()
        visiting.remove(node)
        visited.add(node)

    for node in sorted(graph):
        visit(node)
    return cycles


def check_architecture(model: dict[str, Any]) -> list[Finding]:
    layers = model.get("layers", {})
    modules = model.get("modules", {})
    if not isinstance(layers, dict) or not isinstance(modules, dict):
        raise ValueError("model must contain 'layers' and 'modules' objects")
    findings: list[Finding] = []
    graph: dict[str, list[str]] = {}
    module_layer: dict[str, str] = {}

    for module, definition in modules.items():
        layer = definition.get("layer")
        if layer not in layers:
            findings.append(Finding("UNKNOWN_LAYER", module, f"Layer '{layer}' is not declared."))
        else:
            module_layer[module] = layer
        dependencies = definition.get("depends_on", [])
        if not isinstance(dependencies, list):
            findings.append(Finding("INVALID_DEPENDENCIES", module, "depends_on must be a list."))
            dependencies = []
        graph[module] = []
        for dependency in dependencies:
            if dependency not in modules:
                findings.append(Finding("UNKNOWN_DEPENDENCY", module, f"Dependency '{dependency}' is not declared."))
                continue
            graph[module].append(dependency)
            source_layer = module_layer.get(module, layer)
            target_layer = modules[dependency].get("layer")
            if source_layer in layers and target_layer in layers and layers[target_layer] >= layers[source_layer]:
                findings.append(Finding("LAYER_DIRECTION", module, f"'{module}' in {source_layer} depends on '{dependency}' in {target_layer}; dependencies must point to a lower-numbered inner layer."))

    for cycle in _find_cycles(graph):
        findings.append(Finding("DEPENDENCY_CYCLE", cycle[0], "Dependency cycle: " + " -> ".join(cycle)))
    return findings


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("model_json", type=Path)
    parser.add_argument("--output", type=Path, default=Path("architecture-findings.json"))
    args = parser.parse_args()
    model = json.loads(args.model_json.read_text(encoding="utf-8"))
    findings = check_architecture(model)
    args.output.write_text(json.dumps([asdict(item) for item in findings], indent=2), encoding="utf-8")
    print(f"findings={len(findings)}")
    print(f"report={args.output}")
    if findings:
        raise SystemExit(1)


if __name__ == "__main__":
    main()

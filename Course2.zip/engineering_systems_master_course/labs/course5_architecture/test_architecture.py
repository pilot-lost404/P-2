import unittest

from checker import check_architecture


class ArchitectureFitnessTests(unittest.TestCase):
    def test_clean_onion_dependency_directions_pass(self):
        model = {
            "layers": {"domain": 0, "application": 1, "presentation": 2, "infrastructure": 2},
            "modules": {
                "domain": {"layer": "domain", "depends_on": []},
                "application": {"layer": "application", "depends_on": ["domain"]},
                "http_api": {"layer": "presentation", "depends_on": ["application"]},
                "postgres_adapter": {"layer": "infrastructure", "depends_on": ["application", "domain"]},
            },
        }
        self.assertEqual(check_architecture(model), [])

    def test_outward_dependency_is_reported(self):
        model = {
            "layers": {"domain": 0, "application": 1, "infrastructure": 2},
            "modules": {
                "domain": {"layer": "domain", "depends_on": ["postgres_adapter"]},
                "application": {"layer": "application", "depends_on": ["domain"]},
                "postgres_adapter": {"layer": "infrastructure", "depends_on": ["application"]},
            },
        }
        codes = {finding.code for finding in check_architecture(model)}
        self.assertIn("LAYER_DIRECTION", codes)

    def test_unknown_dependency_is_reported(self):
        model = {
            "layers": {"domain": 0, "application": 1},
            "modules": {"application": {"layer": "application", "depends_on": ["missing"]}},
        }
        self.assertIn("UNKNOWN_DEPENDENCY", {finding.code for finding in check_architecture(model)})

    def test_dependency_cycle_is_reported(self):
        model = {
            "layers": {"application": 1},
            "modules": {
                "service_a": {"layer": "application", "depends_on": ["service_b"]},
                "service_b": {"layer": "application", "depends_on": ["service_a"]},
            },
        }
        self.assertIn("DEPENDENCY_CYCLE", {finding.code for finding in check_architecture(model)})


if __name__ == "__main__":
    unittest.main()

# Practical 5 — Architecture dependency fitness function

**Course mapping:** Course V, C5-LO2 through C5-LO5.  
**Type:** Executable architecture-rule check plus design evaluation.  
**Dependencies:** Python 3.13.x; standard library only.

## Learning objectives

You will encode a layer dependency rule, detect unknown dependencies and cycles, understand how a fitness function can preserve architectural intent, and explain why static dependency rules cannot replace architecture evaluation.

## Model

`architecture.json` defines four conceptual layers. Domain is the innermost layer (rank 0), application is rank 1, and presentation/infrastructure are outer layers (rank 2). Dependencies must point to a strictly lower-numbered inner layer. Modules within the same outer layer do not receive permission to depend on one another by default. The rule is an example of dependency inversion; it is not a universal architecture law.

## Run

```bash
python checker.py architecture.json --output findings.json
```

Expected output:

```text
findings=0
report=findings.json
```

The test suite also supplies deliberately invalid examples containing an outward dependency, an unknown dependency and a cycle.

## Required investigation

1. Introduce a dependency from `reservation_domain` to `postgres_adapter`. Confirm that the fitness function fails and identify the architectural principle being violated.
2. Introduce a cycle between two application modules. Record the diagnostic.
3. Add a module in a new `integration` layer. Define its allowed dependencies before updating the checker; do not silently assign an arbitrary rank.
4. Propose a second fitness function for API compatibility, build time, latency, dependency vulnerabilities or backup recovery. Define its measurement boundary, trigger, threshold, owner and exception process.
5. Conduct an ATAM-style mini-workshop using at least three quality-attribute scenarios. Identify one sensitivity point and one trade-off point. Explain why a dependency checker cannot discover them.
6. Document one false positive and one blind spot of the rule set.

## Verification

```bash
python -m unittest discover -v
```

Tests cover a clean layer graph, prohibited direction, unknown dependency and dependency cycle. They do not prove that the architecture is cohesive, secure, scalable or fit for the stakeholder's mission.

## Submission

Submit architecture JSON, test results, one detected regression, a second fitness function, ATAM-style analysis and a short governance procedure for exceptions.

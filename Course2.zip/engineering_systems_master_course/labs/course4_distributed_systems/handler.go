package main

import (
	"context"
	"encoding/json"
	"errors"
	"io"
	"net/http"
)

func NewHandler(store *Store) http.Handler {
	return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		if r.URL.Path != "/reservations" {
			http.NotFound(w, r)
			return
		}
		if r.Method != http.MethodPost {
			w.Header().Set("Allow", http.MethodPost)
			http.Error(w, "method not allowed", http.StatusMethodNotAllowed)
			return
		}

		r.Body = http.MaxBytesReader(w, r.Body, 1<<20)
		decoder := json.NewDecoder(r.Body)
		decoder.DisallowUnknownFields()
		var request Request
		if err := decoder.Decode(&request); err != nil {
			http.Error(w, "invalid JSON request", http.StatusBadRequest)
			return
		}
		var extra any
		if err := decoder.Decode(&extra); !errors.Is(err, io.EOF) {
			http.Error(w, "request must contain one JSON object", http.StatusBadRequest)
			return
		}

		reservation, replay, err := store.Reserve(r.Context(), request)
		if err != nil {
			switch {
			case errors.Is(err, ErrCapacityFull), errors.Is(err, ErrIdempotencyConflict):
				http.Error(w, err.Error(), http.StatusConflict)
			case errors.Is(err, ErrUnknownSlot):
				http.Error(w, err.Error(), http.StatusNotFound)
			case errors.Is(err, ErrInvalidRequest):
				http.Error(w, err.Error(), http.StatusUnprocessableEntity)
			case errors.Is(err, context.Canceled), errors.Is(err, context.DeadlineExceeded):
				http.Error(w, err.Error(), http.StatusRequestTimeout)
			default:
				http.Error(w, "internal server error", http.StatusInternalServerError)
			}
			return
		}
		status := http.StatusCreated
		if replay {
			status = http.StatusOK
		}
		w.Header().Set("Content-Type", "application/json")
		w.WriteHeader(status)
		_ = json.NewEncoder(w).Encode(reservation)
	})
}

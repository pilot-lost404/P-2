package main

import (
	"net/http"
	"net/http/httptest"
	"strings"
	"testing"
)

func TestReservationHandlerCreateReplayAndConflict(t *testing.T) {
	handler := NewHandler(NewStore(map[string]int{"slot-1": 1}))
	body := `{"slot_id":"slot-1","user_id":"user-1","idempotency_key":"key-1"}`

	first := httptest.NewRecorder()
	handler.ServeHTTP(first, httptest.NewRequest(http.MethodPost, "/reservations", strings.NewReader(body)))
	if first.Code != http.StatusCreated {
		t.Fatalf("first status=%d body=%s", first.Code, first.Body.String())
	}

	replay := httptest.NewRecorder()
	handler.ServeHTTP(replay, httptest.NewRequest(http.MethodPost, "/reservations", strings.NewReader(body)))
	if replay.Code != http.StatusOK {
		t.Fatalf("replay status=%d body=%s", replay.Code, replay.Body.String())
	}

	conflictBody := `{"slot_id":"slot-1","user_id":"user-2","idempotency_key":"key-2"}`
	conflict := httptest.NewRecorder()
	handler.ServeHTTP(conflict, httptest.NewRequest(http.MethodPost, "/reservations", strings.NewReader(conflictBody)))
	if conflict.Code != http.StatusConflict {
		t.Fatalf("conflict status=%d body=%s", conflict.Code, conflict.Body.String())
	}
}

func TestReservationHandlerRejectsMalformedRequestAndWrongMethod(t *testing.T) {
	handler := NewHandler(NewStore(map[string]int{"slot-1": 1}))
	malformed := httptest.NewRecorder()
	handler.ServeHTTP(malformed, httptest.NewRequest(http.MethodPost, "/reservations", strings.NewReader("{")))
	if malformed.Code != http.StatusBadRequest {
		t.Fatalf("malformed status=%d", malformed.Code)
	}
	wrongMethod := httptest.NewRecorder()
	handler.ServeHTTP(wrongMethod, httptest.NewRequest(http.MethodGet, "/reservations", nil))
	if wrongMethod.Code != http.StatusMethodNotAllowed {
		t.Fatalf("method status=%d", wrongMethod.Code)
	}
}

# Practical 4 — Concurrent reservation API and idempotency

**Course mapping:** Course IV, C4-LO1, C4-LO2 and C4-LO5.  
**Type:** Executable concurrency and API-contract practical.  
**Dependencies:** Go 1.23 or compatible newer Go release; standard library only.

## Learning objectives

You will preserve a shared-state invariant under concurrent requests, explain a linearisation point, distinguish request idempotency from exactly-once delivery, test race freedom and state the limits of a single-process in-memory implementation.

## Scope boundary

This lab is a deliberately small, single-process teaching service. A mutex protects the reservation capacity and idempotency record as one critical section. State is lost on restart and is not shared across server instances. It is **not** a distributed database, not a consensus protocol and not a production-ready reservation service. A multi-instance system must enforce the invariant in an authoritative transactional store or a correctly designed replicated state machine.

## Verify the implementation

```bash
go test ./...
go test -race ./...
go vet ./...
```

The tests submit 100 concurrent distinct requests to a slot of capacity one. Exactly one reservation must be created; all other callers receive a capacity conflict. Additional tests cover replay, conflicting idempotency-key reuse, cancelled contexts, unknown slots and HTTP request validation.

## Run the API

```bash
go run .
```

The server listens on `http://localhost:8080`. Submit a reservation:

```bash
curl -i -X POST http://localhost:8080/reservations \
  -H "Content-Type: application/json" \
  -d '{"slot_id":"slot-1","user_id":"student-1","idempotency_key":"request-001"}'
```

Expected first response: `201 Created` with a JSON reservation identifier. Repeat the exact request: expected `200 OK` with the same reservation identifier. Send a different user and idempotency key for `slot-1`: expected `409 Conflict` because slot-1 has capacity one.

For Windows PowerShell:

```powershell
$body = @{ slot_id = 'slot-1'; user_id = 'student-1'; idempotency_key = 'request-001' } | ConvertTo-Json
Invoke-RestMethod -Method Post -Uri 'http://localhost:8080/reservations' -ContentType 'application/json' -Body $body
```

Press Ctrl+C to request graceful shutdown.

## Required investigation

1. Identify the linearisation point in `Store.Reserve` and explain which state variables are protected together.
2. Remove the mutex temporarily and run the race detector. Record the failure; restore the mutex and rerun the race test.
3. Change the capacity to two and prove the test oracle changes from one success to two successes. Add a corresponding test.
4. Send the same idempotency key with a different slot or user. Explain why the server returns conflict rather than replaying a different action.
5. Restart the server and observe the loss of state. Explain why process-local locks cannot enforce a cross-instance invariant.
6. Design a database-backed variant. Specify the unique constraint, transaction isolation, retry behaviour, idempotency table and recovery semantics. Do not claim the in-memory lab has tested that design.
7. Draw a failure timeline for a client timeout after the server commits. Identify why a retry must use the same idempotency key.

## Verification

The package uses only standard-library Go packages. No external database, broker, cache or orchestration cluster is required. Passing `go test -race` demonstrates that the exercised paths did not expose a data race in this test run; it is not a proof of all possible executions or of durability.

## Submission

Submit the source, test output (including `-race`), one concurrency history, a sequence diagram, a production persistence design and a limitations statement.

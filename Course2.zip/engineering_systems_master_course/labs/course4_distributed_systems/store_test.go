package main

import (
	"context"
	"errors"
	"sync"
	"testing"
)

func TestConcurrentReservationsPreserveCapacityInvariant(t *testing.T) {
	store := NewStore(map[string]int{"slot-1": 1})
	const callers = 100
	var wg sync.WaitGroup
	var mu sync.Mutex
	created := 0
	conflicts := 0
	unexpected := make(chan error, callers)

	for i := 0; i < callers; i++ {
		wg.Add(1)
		go func(i int) {
			defer wg.Done()
			req := Request{SlotID: "slot-1", UserID: userID(i), IdempotencyKey: keyID(i)}
			_, replay, err := store.Reserve(context.Background(), req)
			mu.Lock()
			defer mu.Unlock()
			if err == nil && !replay {
				created++
			} else if errors.Is(err, ErrCapacityFull) {
				conflicts++
			} else {
				unexpected <- err
			}
		}(i)
	}
	wg.Wait()
	close(unexpected)
	for err := range unexpected {
		t.Errorf("unexpected result: %v", err)
	}
	if created != 1 || conflicts != callers-1 {
		t.Fatalf("created=%d conflicts=%d; want 1 and %d", created, conflicts, callers-1)
	}
	if got := store.ReservationCount(); got != 1 {
		t.Fatalf("reservation count=%d; want 1", got)
	}
}

func TestIdempotentReplayReturnsOriginalReservation(t *testing.T) {
	store := NewStore(map[string]int{"slot-1": 1})
	req := Request{SlotID: "slot-1", UserID: "user-1", IdempotencyKey: "key-1"}
	first, replay1, err := store.Reserve(context.Background(), req)
	if err != nil || replay1 {
		t.Fatalf("first call: replay=%v err=%v", replay1, err)
	}
	second, replay2, err := store.Reserve(context.Background(), req)
	if err != nil || !replay2 {
		t.Fatalf("replay call: replay=%v err=%v", replay2, err)
	}
	if first.ID != second.ID || store.ReservationCount() != 1 {
		t.Fatalf("replay changed result or count: first=%+v second=%+v count=%d", first, second, store.ReservationCount())
	}
}

func TestIdempotencyKeyCannotBeReusedForDifferentPayload(t *testing.T) {
	store := NewStore(map[string]int{"slot-1": 1, "slot-2": 1})
	_, _, err := store.Reserve(context.Background(), Request{SlotID: "slot-1", UserID: "user-1", IdempotencyKey: "same-key"})
	if err != nil {
		t.Fatal(err)
	}
	_, _, err = store.Reserve(context.Background(), Request{SlotID: "slot-2", UserID: "user-1", IdempotencyKey: "same-key"})
	if !errors.Is(err, ErrIdempotencyConflict) {
		t.Fatalf("got %v; want ErrIdempotencyConflict", err)
	}
}

func TestUnknownSlotAndCancelledContextAreRejected(t *testing.T) {
	store := NewStore(map[string]int{"slot-1": 1})
	_, _, err := store.Reserve(context.Background(), Request{SlotID: "missing", UserID: "u", IdempotencyKey: "k"})
	if !errors.Is(err, ErrUnknownSlot) {
		t.Fatalf("got %v; want ErrUnknownSlot", err)
	}
	ctx, cancel := context.WithCancel(context.Background())
	cancel()
	_, _, err = store.Reserve(ctx, Request{SlotID: "slot-1", UserID: "u", IdempotencyKey: "k"})
	if !errors.Is(err, context.Canceled) {
		t.Fatalf("got %v; want context.Canceled", err)
	}
}

func userID(i int) string { return "user-" + itoa(i) }
func keyID(i int) string  { return "key-" + itoa(i) }
func itoa(i int) string {
	if i == 0 {
		return "0"
	}
	out := ""
	for i > 0 {
		out = string(rune('0'+i%10)) + out
		i /= 10
	}
	return out
}

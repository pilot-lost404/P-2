package main

import (
	"context"
	"errors"
	"fmt"
	"strconv"
	"sync"
)

var (
	ErrCapacityFull        = errors.New("slot capacity is full")
	ErrUnknownSlot         = errors.New("slot does not exist")
	ErrIdempotencyConflict = errors.New("idempotency key was already used for a different request")
	ErrInvalidRequest      = errors.New("slot_id, user_id and idempotency_key are required")
)

type Request struct {
	SlotID         string `json:"slot_id"`
	UserID         string `json:"user_id"`
	IdempotencyKey string `json:"idempotency_key"`
}

type Reservation struct {
	ID     string `json:"id"`
	SlotID string `json:"slot_id"`
	UserID string `json:"user_id"`
}

type Store struct {
	mu         sync.Mutex
	capacities map[string]int
	used       map[string]int
	byKey      map[string]Reservation
	nextID     uint64
}

// NewStore constructs an in-memory teaching store. It is not durable or shared
// across processes. Production implementations must enforce the invariant in
// an authoritative transactional persistence layer.
func NewStore(capacities map[string]int) *Store {
	copied := make(map[string]int, len(capacities))
	for slot, capacity := range capacities {
		copied[slot] = capacity
	}
	return &Store{
		capacities: copied,
		used:       make(map[string]int),
		byKey:      make(map[string]Reservation),
	}
}

// Reserve creates at most the configured number of reservations for a slot.
// The critical section protects the invariant and idempotency record together.
func (s *Store) Reserve(ctx context.Context, request Request) (Reservation, bool, error) {
	if request.SlotID == "" || request.UserID == "" || request.IdempotencyKey == "" {
		return Reservation{}, false, ErrInvalidRequest
	}
	if err := ctx.Err(); err != nil {
		return Reservation{}, false, err
	}

	s.mu.Lock()
	defer s.mu.Unlock()
	if err := ctx.Err(); err != nil {
		return Reservation{}, false, err
	}

	if existing, ok := s.byKey[request.IdempotencyKey]; ok {
		if existing.SlotID != request.SlotID || existing.UserID != request.UserID {
			return Reservation{}, false, ErrIdempotencyConflict
		}
		return existing, true, nil
	}

	capacity, exists := s.capacities[request.SlotID]
	if !exists {
		return Reservation{}, false, ErrUnknownSlot
	}
	if s.used[request.SlotID] >= capacity {
		return Reservation{}, false, ErrCapacityFull
	}

	s.nextID++
	reservation := Reservation{
		ID:     fmt.Sprintf("res-%06s", strconv.FormatUint(s.nextID, 10)),
		SlotID: request.SlotID,
		UserID: request.UserID,
	}
	s.used[request.SlotID]++
	s.byKey[request.IdempotencyKey] = reservation
	return reservation, false, nil
}

func (s *Store) ReservationCount() int {
	s.mu.Lock()
	defer s.mu.Unlock()
	return len(s.byKey)
}

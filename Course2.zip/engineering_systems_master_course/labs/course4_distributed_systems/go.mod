module example.edu/engineering-systems/reservation-lab

go 1.23

"""Deterministic stock-flow model for a service request backlog.

Rates are measured in requests/day and capacity in requests/day.
The numerical method is explicit forward Euler; learners must test step size.
"""
from __future__ import annotations

import argparse
import csv
from dataclasses import asdict, dataclass
from pathlib import Path


@dataclass(frozen=True)
class ModelParameters:
    initial_backlog: float = 120.0
    initial_capacity: float = 24.0
    arrivals_per_day: float = 30.0
    rework_fraction: float = 0.10
    base_capacity: float = 24.0
    capacity_gain: float = 0.015
    target_backlog: float = 100.0
    adjustment_days: float = 14.0


@dataclass(frozen=True)
class State:
    day: float
    backlog: float
    capacity: float
    arrivals: float
    rework: float
    completions: float


def simulate(
    params: ModelParameters,
    days: float = 180.0,
    step_days: float = 1.0,
) -> list[State]:
    """Simulate backlog and delayed capacity adaptation with explicit Euler."""
    if days <= 0:
        raise ValueError("days must be positive")
    if step_days <= 0 or step_days > days:
        raise ValueError("step_days must be positive and no larger than days")
    if params.adjustment_days <= 0:
        raise ValueError("adjustment_days must be positive")
    if not 0 <= params.rework_fraction < 1:
        raise ValueError("rework_fraction must be in [0, 1)")
    if min(params.initial_backlog, params.initial_capacity, params.arrivals_per_day,
           params.base_capacity, params.capacity_gain, params.target_backlog) < 0:
        raise ValueError("state and rate parameters must be non-negative")

    backlog = float(params.initial_backlog)
    capacity = float(params.initial_capacity)
    result = [State(0.0, backlog, capacity, params.arrivals_per_day, 0.0, 0.0)]
    steps = int(round(days / step_days))
    if abs(steps * step_days - days) > 1e-9:
        raise ValueError("days must be an integer multiple of step_days")

    for index in range(steps):
        desired_capacity = params.base_capacity + params.capacity_gain * max(
            backlog - params.target_backlog, 0.0
        )
        capacity_change = (desired_capacity - capacity) / params.adjustment_days
        # Completions cannot exceed the work currently available in the stock.
        completions = min(max(capacity, 0.0), backlog / step_days)
        rework = params.rework_fraction * completions
        backlog_change = params.arrivals_per_day + rework - completions

        backlog = max(0.0, backlog + step_days * backlog_change)
        capacity = max(0.0, capacity + step_days * capacity_change)
        day = (index + 1) * step_days
        result.append(State(day, backlog, capacity, params.arrivals_per_day, rework, completions))
    return result


def scenario_parameters(name: str) -> ModelParameters:
    base = ModelParameters()
    if name == "base":
        return base
    if name == "training":
        return ModelParameters(**{**asdict(base), "base_capacity": 28.0})
    if name == "rework-reduction":
        return ModelParameters(**{**asdict(base), "rework_fraction": 0.04})
    if name == "demand-smoothing":
        return ModelParameters(**{**asdict(base), "arrivals_per_day": 26.0})
    raise ValueError(f"unknown scenario: {name}")


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--scenario", choices=["base", "training", "rework-reduction", "demand-smoothing"], default="base")
    parser.add_argument("--days", type=float, default=180.0)
    parser.add_argument("--step", type=float, default=1.0)
    parser.add_argument("--output", type=Path, default=Path("output.csv"))
    args = parser.parse_args()
    rows = simulate(scenario_parameters(args.scenario), args.days, args.step)
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with args.output.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(asdict(rows[0]).keys()))
        writer.writeheader()
        writer.writerows(asdict(row) for row in rows)
    final = rows[-1]
    print(f"scenario={args.scenario} days={args.days:g} step={args.step:g}")
    print(f"final_backlog={final.backlog:.3f} requests")
    print(f"final_capacity={final.capacity:.3f} requests/day")
    print(f"csv={args.output}")


if __name__ == "__main__":
    main()

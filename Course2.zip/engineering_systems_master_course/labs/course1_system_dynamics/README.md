# Practical 1 — Dynamic backlog model

**Course mapping:** Course I, especially CLO C1-LO3 through C1-LO5.  
**Type:** Executable numerical modelling practical.  
**Difficulty:** Intermediate.  
**Dependencies:** Python 3.13.x; standard library only.

## Learning objectives

By completing this practical you should be able to translate a stock-flow hypothesis into equations, implement an explicit Euler integrator, enforce stock constraints, test dimensional and boundary behaviour, compare policy scenarios and explain numerical/model uncertainty.

## Model and units

The model tracks backlog \(B\) in requests and effective service capacity \(C\) in requests/day. Arrivals \(\lambda\), completions and rework are requests/day. A fraction \(\rho\) of completed work returns as rework. Desired capacity responds to backlog with gain \(g\), and actual capacity adjusts toward desired capacity over time constant \(\tau\):

\[
\dot B=\lambda+\rho q-q,\qquad q=\min(C,B/\Delta t)
\]

\[
\dot C=\frac{C_0+g\max(B-B_T,0)-C}{\tau}
\]

The implementation uses integration step \(\Delta t\) and forward Euler. The cap \(B/\Delta t\) prevents the numerical step from completing more of the current stock than is present at the beginning of that step. All default values are illustrative, not measurements from a real university. The model has no seasonal demand, staffing recruitment pipeline, skill mix, priority classes or stochastic arrivals; learners must not present the results as a forecast.

## Run

From this directory:

```bash
python model.py --scenario base --days 180 --step 1 --output output.csv
python model.py --scenario training --days 180 --step 1 --output training.csv
python model.py --scenario rework-reduction --days 180 --step 1 --output rework.csv
python model.py --scenario demand-smoothing --days 180 --step 1 --output demand.csv
```

Expected reference output for the base case:

```text
scenario=base days=180 step=1
final_backlog=696.988 requests
final_capacity=32.827 requests/day
csv=output.csv
```

Expected 180-day backlog across the provided parameter alternatives:

| Scenario | Final backlog (requests) |
|---|---:|
| Base | 696.988 |
| Increased base capacity (“training”) | 445.445 |
| Lower rework fraction | 569.199 |
| Demand smoothing | 413.248 |

These values are regression oracles for the supplied numerical model, not evidence that the policies will have those effects in a real service.

## Required investigation

1. Reproduce all four scenarios and retain the CSV outputs.
2. Plot backlog and capacity against time. Add arrivals, rework and completions to the same analysis using a readable axis or separate plots.
3. Change the step from 1 day to 0.5 and 0.25 days. Compare final backlog and the full trajectory; explain numerical convergence and any remaining modelling limitations.
4. Run an extreme-condition experiment with zero arrivals and high initial capacity. Confirm the backlog does not become negative.
5. Set rework to zero, then increase it toward 0.5. Explain how rework changes the effective service requirement.
6. Perform a one-at-a-time sensitivity analysis for arrival rate, rework fraction, response gain and adjustment time. Do not vary several parameters without explaining the confounding.
7. Propose one structural alternative (for example, explicit staff recruitment/training delay or seasonal arrivals). State what data would be needed to distinguish it from the supplied model.

## Verification

```bash
python -m unittest discover -v
```

The tests check stock-flow arithmetic, non-negative backlog, invalid step-size rejection and sensitivity to a finer integration step. They do not validate the model against field data or establish the causal structure as true.

## Submission

Submit the source and version, four scenario CSVs, plots, a parameter table with units, test output, step-size comparison and a 1,000–1,500-word report. Include a statement explaining what the model is not able to predict.

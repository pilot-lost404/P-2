import unittest

from model import ModelParameters, simulate


class SystemDynamicsTests(unittest.TestCase):
    def test_stock_flow_balance_for_one_step(self):
        params = ModelParameters(
            initial_backlog=100.0,
            initial_capacity=20.0,
            arrivals_per_day=30.0,
            rework_fraction=0.10,
            base_capacity=20.0,
            capacity_gain=0.0,
            target_backlog=100.0,
            adjustment_days=10.0,
        )
        rows = simulate(params, days=1.0, step_days=1.0)
        self.assertAlmostEqual(rows[-1].backlog, 112.0, places=9)
        self.assertAlmostEqual(rows[-1].capacity, 20.0, places=9)

    def test_backlog_never_becomes_negative(self):
        params = ModelParameters(
            initial_backlog=1.0,
            initial_capacity=100.0,
            arrivals_per_day=0.0,
            rework_fraction=0.0,
            base_capacity=100.0,
            capacity_gain=0.0,
        )
        rows = simulate(params, days=5.0, step_days=1.0)
        self.assertTrue(all(row.backlog >= 0.0 for row in rows))
        self.assertAlmostEqual(rows[-1].backlog, 0.0)

    def test_invalid_time_step_is_rejected(self):
        with self.assertRaises(ValueError):
            simulate(ModelParameters(), days=10, step_days=0)

    def test_finer_step_is_close_to_coarse_step(self):
        params = ModelParameters()
        coarse = simulate(params, days=30, step_days=1.0)[-1]
        fine = simulate(params, days=30, step_days=0.25)[-1]
        self.assertLess(abs(coarse.backlog - fine.backlog), 2.0)


if __name__ == "__main__":
    unittest.main()
